$ErrorActionPreference='Stop'
. C:/opf-work/release-033-final/packages/editor/test/native-playground-lib.ps1
$ownedPath='C:\opf-work\qualification034-series-name-native-02\native\inputs\input.pptx'
$expectedHash='143fec37f070fdf057cfb56c7f829aae3393ae662e5213e24ca8dc9a0504712a'
$all=@(Get-Process -Name POWERPNT -ErrorAction SilentlyContinue)
$expectedStart=[DateTimeOffset]::Parse('2026-11-08T13:23:37.6177755Z').UtcDateTime
if($all.Count -ne 1 -or $all[0].Id -ne 43152 -or $all[0].StartTime.ToUniversalTime() -ne $expectedStart){throw 'Exact owned process identity changed; cleanup refused'}
if($all[0].Path -cne 'C:\Program Files\Microsoft Office\Root\Office16\POWERPNT.EXE' -or $all[0].MainWindowTitle -cne 'input.pptx  -  Read-Only - PowerPoint'){throw 'Owned executable/window identity changed; cleanup refused'}
if((Get-OpfFileSha256 $ownedPath) -cne $expectedHash){throw 'Owned input bytes changed; cleanup refused'}
$app=[Runtime.InteropServices.Marshal]::GetActiveObject('PowerPoint.Application')
if($app.Presentations.Count -ne 1){throw 'Unexpected open presentations; cleanup refused'}
$presentation=$app.Presentations.Item(1)
if([IO.Path]::GetFullPath([string]$presentation.FullName) -cne $ownedPath -or $presentation.ReadOnly -ne -1){throw 'Exact read-only owned copy changed; cleanup refused'}
[void](Close-OpfOwnedPresentation $presentation $ownedPath)
$empty=$app.Presentations.Count -eq 0
if($empty){$app.Quit()}
@{scope='Separate guarded cleanup only of exact owned PowerPoint43152/start2026-11-08T13:23:37.6177755Z, born within recorded application.create interval, and its one read-only input after failed mismatched chart-kind measurement plan; in-memory name edit is discarded. No chart calls, retries or process termination.';closed=$true;quitEmpty=$empty;inputSha256=$expectedHash;inputSha256After=(Get-OpfFileSha256 $ownedPath)}|ConvertTo-Json|Set-Content -LiteralPath C:/opf-work/qualification034-series-name-native-02/separate-owned-cleanup.json -Encoding UTF8
Write-Output 'Exact owned read-only input closed; empty owned PowerPoint quit.'

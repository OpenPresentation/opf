import fs from'node:fs';const p='packages/pptx/src/index.js',source=fs.readFileSync(p,'utf8'),old=`function firstCachedValue(node, path, budget) {
  return cachedValues(node, path, budget).find(value => value !== null);
}`,replacement=`function firstCachedValue(node, path, budget) {
  const values = cachedValues(node, path, budget);
  const literal = node?.['c:v'];
  if (literal === undefined) return values.find(value => value !== null);
  const invalid = message => {
    throw new OPFPptxError('invalid-chart-cache', \`Invalid chart cache: \${message}. Repair the chart data before importing.\`, {path: path + '/c:v'});
  };
  if (['c:strRef', 'c:numRef', 'c:multiLvlStrRef', 'c:numLit', 'c:strLit'].some(key => node[key] !== undefined)) invalid('multiple competing series-name sources');
  if (typeof literal !== 'string' && (literal === null || typeof literal !== 'object' || Array.isArray(literal)
    || Object.keys(literal).some(key => key !== '#text' && key !== 'xml:space' && key !== 'xmlns' && !key.startsWith('xmlns:'))
    || (literal['#text'] !== undefined && typeof literal['#text'] !== 'string'))) invalid('literal series name must be one simple text value');
  if (budget.cells + 1 > MAX_CHART_CACHE_CELLS) invalid('combined caches exceed the 1,000,000-cell import limit');
  budget.cells += 1;
  return scalarText(literal);
}`;if(!source.includes(old))throw Error('Exact minimal parser target not found');fs.writeFileSync(p,source.replace(old,replacement));const t='packages/pptx/test/sh25-series-name-current-cache.mjs';fs.writeFileSync(t,fs.readFileSync(t,'utf8').replace('// Literal c:tx/c:v regression is preserved separately; the next derived product PR must fix it before actual rename qualification.','// Both native SeriesText alternatives are current data; neither may resurrect stale OPF/workbook names.').replace("['cached-name']","['cached-name','literal-name']").replace('cached-name edits override source','cache/literal edits override source'));

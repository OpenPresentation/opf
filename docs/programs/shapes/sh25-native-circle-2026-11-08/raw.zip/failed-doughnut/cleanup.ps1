$ErrorActionPreference='Stop'
. C:/opf-work/release-033-final/packages/editor/test/native-playground-lib.ps1
$ownedPath='C:\opf-work\sh25-curved-native-doughnut-01\native\inputs\input.pptx'
$expectedHash='23eb5091b4971f91c4a5294eacf6106ad6331c95958bec296d9e31360146a364'
$all=@(Get-Process -Name POWERPNT -ErrorAction SilentlyContinue)
$expectedStart=[DateTimeOffset]::Parse('2026-11-08T11:40:51.7928193Z').UtcDateTime
if($all.Count -ne 1 -or $all[0].Id -ne 47172 -or $all[0].StartTime.ToUniversalTime() -ne $expectedStart){throw 'Exact owned process identity changed; cleanup refused'}
if($all[0].Path -cne 'C:\Program Files\Microsoft Office\Root\Office16\POWERPNT.EXE' -or $all[0].MainWindowTitle -cne 'input.pptx  -  Read-Only - PowerPoint'){throw 'Owned executable/window identity changed; cleanup refused'}
if((Get-OpfFileSha256 $ownedPath) -cne $expectedHash){throw 'Owned input bytes changed; cleanup refused'}
$app=[Runtime.InteropServices.Marshal]::GetActiveObject('PowerPoint.Application')
if($app.Presentations.Count -ne 1){throw 'Unexpected open presentations; cleanup refused'}
$presentation=$app.Presentations.Item(1)
if([IO.Path]::GetFullPath([string]$presentation.FullName) -cne $ownedPath -or $presentation.ReadOnly -ne -1){throw 'Exact read-only owned copy changed; cleanup refused'}
[void](Close-OpfOwnedPresentation $presentation $ownedPath)
$empty=$app.Presentations.Count -eq 0
if($empty){$app.Quit()}
@{scope='Separate guarded cleanup only of exact owned PowerPoint47172/start2026-11-08T11:40:51.7928193Z, born within recorded application.create interval, and its one read-only input after failed doughnut probe. No chart calls, retries or process termination.';closed=$true;quitEmpty=$empty;inputSha256=$expectedHash;inputSha256After=(Get-OpfFileSha256 $ownedPath)}|ConvertTo-Json|Set-Content -LiteralPath C:/opf-work/sh25-curved-native-doughnut-01/cleanup.json -Encoding UTF8
Write-Output 'Exact owned read-only input closed; empty owned PowerPoint quit.'

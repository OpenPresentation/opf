import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const out='C:/opf-work/release-033-artifacts/features-034-core-native-04';
if(fs.existsSync(out))throw Error('Fresh output required');
const sources=[
 ['LH73','C:/opf-work/lh73-native-inputs','be5fa90bafb90fa4d416c981bf2d1a1e1cb6bc01c7d99e15a8b1b221068af51b',2],
 ['LH75','C:/opf-work/lh75-native-inputs','8117b84c9a143b55a216a2f7ae237f13616f3e275408c92a9fc41841be01ab2f',13],
 ['LH110','C:/opf-work/lh110-native-inputs','0067a5ab453d6dc94207429b1c6c2136d5a0b329c8e2d74496b2d4a7f14eaad5',7]
];
const sha=b=>createHash('sha256').update(b).digest('hex');
const files=[],ids=new Set(),build={manifestVersion:1,revision:'Separate reviewed product producers; see sourceRevision per deck',opfVersion:'0.34.0-preparation',decks:[]};
fs.mkdirSync(out,{recursive:true});
function copy(root,relative,expected){const src=path.resolve(root,relative),dst=path.resolve(out,relative);for(const [base,p]of[[root,src],[out,dst]]){const rel=path.relative(base,p);if(rel.startsWith('..')||path.isAbsolute(rel))throw Error('Path outside root');}if(fs.existsSync(dst))throw Error('Output collision '+relative);const b=fs.readFileSync(src);if(sha(b)!==expected)throw Error('Changed input '+src);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,b);files.push({path:relative,sha256:expected,bytes:b.length});}
for(const [item,root,expected,count]of sources){const raw=fs.readFileSync(root+'/build.json');if(sha(raw)!==expected)throw Error('Manifest changed '+item);const m=JSON.parse(raw);if(m.decks.length!==count)throw Error('Count changed');for(const d of m.decks){if(ids.has(d.id)||!d.previewOk||d.previewSlides!==1||d.width!==1280||d.height!==720||!d.variants.length||!d.previews.length)throw Error('Invalid deck '+d.id);ids.add(d.id);for(const v of d.variants){if(!v.ok||v.name!=='default')throw Error('Unbuilt/unqualified variant');copy(root,v.pptx,v.sha256);}for(const p of d.previews)copy(root,p.path,p.sha256);build.decks.push({...d,sourceRevision:m.revision,item});}}
if(build.decks.length!==22)throw Error('Empty or wrong final count');
const manifest=JSON.stringify(build,null,2)+'\n';fs.writeFileSync(out+'/build.json',manifest);
const proof={status:'SEALED_NOT_RUN',heldUntil:'After033publication; coordinator-owned serialized readonly PowerPoint only',sources:sources.map(([item,root,sha256,decks])=>({item,root,sha256,decks})),files:22,slides:22,inputManifestSha256:sha(manifest),artifacts:files};
fs.writeFileSync(out+'/seal-proof.json',JSON.stringify(proof,null,2)+'\n');
console.log(JSON.stringify({out,decks:22,slides:22,artifacts:files.length,inputManifestSha256:proof.inputManifestSha256,status:proof.status}));

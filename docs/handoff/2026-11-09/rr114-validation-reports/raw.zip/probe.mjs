import fs from 'node:fs';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root='C:/opf-work/v034-report',prefix=process.argv[2]??'baseline';
const {checkDeckText}=await import(pathToFileURL(root+'/packages/mcp/dist/stdio.js').href);
const cases=[{name:'schema',format:'json',raw:'{"name":"x","slides":[{"title":3}]}'},{name:'json-syntax',format:'json',raw:'{"slides": [}'},{name:'yaml-syntax',format:'yaml',raw:'name: Y\nslides:\n  - title: [\n'}];const results=[];
for(const c of cases){const args=['validate','-',...(c.format==='yaml'?['--from','yaml']:[])];const cli=spawnSync(process.execPath,[root+'/packages/cli/dist/index.js',...args],{cwd:root,input:c.raw,encoding:'utf8',timeout:30000});let mcp;try{mcp={report:await checkDeckText(c.raw,c.format,{})}}catch(e){mcp={error:{name:e.name,code:e.code,message:e.message,hasReport:!!e.details?.report,report:e.details?.report,cause:e.cause?{name:e.cause.name,code:e.cause.code,hasReport:!!e.cause.details?.report}:undefined}}}results.push({input:c,cli:{status:cli.status,stdout:cli.stdout,stderr:cli.stderr},mcp});}
fs.writeFileSync('C:/opf-work/v034-report-evidence/'+prefix+'-probe.json',JSON.stringify(results,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(results.map(r=>({name:r.input.name,cliStatus:r.cli.status,cliStderr:r.cli.stderr,mcpError:r.mcp.error})),null,2));
for(const r of results){assert.equal(r.cli.status,1,r.input.name+' CLI must return ordinary invalid-report exit1');const report=JSON.parse(r.cli.stdout);assert.equal(report.valid,false);assert.ok(report.counts.error>0);assert.equal(r.cli.stderr,'');assert.ok(r.mcp.report,r.input.name+' MCP must return ordinary invalid report');assert.equal(r.mcp.report.valid,false);assert.ok(r.mcp.report.counts.error>0);}
console.log('PASS actual CLI/stdio invalid source reports');

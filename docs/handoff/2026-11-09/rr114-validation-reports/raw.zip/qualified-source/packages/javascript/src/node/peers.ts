// opf-render and opf-pptx are optional peer dependencies of core: core stays small (no native image or PDF engines, no
// font packs), and an application that only reads, validates or edits a deck never needs them. Core's Node build
// (and the opf CLI, through it) loads them the first time a call needs them, from core's own install location first (a
// project dependency, a global CLI install, an npx run with several --package flags) and from the working directory
// second (a project that has them installed while the CLI is global). Nothing is ever fetched.
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { OPFApiError } from "../api-errors.js";

export const RENDER_PACKAGE = "@openpresentation/opf-render";
export const PPTX_PACKAGE = "@openpresentation/opf-pptx";
/** Peer ranges. The CLI checks the features it calls rather than the version, so a newer release in range keeps working. */
export const PEER_RANGES = { [RENDER_PACKAGE]: "^0.33.0", [PPTX_PACKAGE]: "^0.33.0" } as const;

/** The first opf-pptx that reads `bodyText` and `slideNumberFields`. An older one would ignore them silently. */
export const PPTX_TEXT_OPTIONS_FROM = "0.22.0";

const numbers = (version: string) => version.replace(/[-+].*$/, "").split(".").map((part) => Number.parseInt(part, 10) || 0);
/** True when `version` is `minimum` or later (release numbers only; a prerelease counts as its release). */
export function atLeast(version: string, minimum: string): boolean {
	const [a, b] = [numbers(version), numbers(minimum)];
	for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0);
	return true;
}

/** Refuse `bodyText: "native"` and `slideNumbers` on an opf-pptx that predates them: it would write the default and say nothing. */
export function requirePptxOptions(pptx: Peer<unknown>, options: { bodyText?: string; slideNumbers?: string; typefaces?: string; as?: string }, flags = false) {
	const asked = [options.bodyText === "native" ? (flags ? "--body-text native" : "bodyText: \"native\"") : undefined, options.slideNumbers ? (flags ? "--slide-numbers" : "slideNumbers") : undefined].filter(Boolean);
	if (asked.length && pptx.version !== "unknown" && !atLeast(pptx.version, PPTX_TEXT_OPTIONS_FROM))
		throw new OPFApiError(`${asked.join(" and ")} needs ${pptx.name}@${PPTX_TEXT_OPTIONS_FROM} or later; ${pptx.version} is installed and would ignore it.`, "peer-too-old", { details: { package: pptx.name } });
	// LH-28 and LH-20: the opf-pptx that reads `typefaces` and `as` is the one that exports typefacesNotOfficeSafe.
	const newer = [options.typefaces === "safe" ? (flags ? "--typefaces safe" : "typefaces: \"safe\"") : undefined, options.as === "images" ? (flags ? "--as images" : "as: \"images\"") : undefined].filter(Boolean);
	if (newer.length && typeof (pptx.module as Partial<PptxModule> | undefined)?.typefacesNotOfficeSafe !== "function")
		throw new OPFApiError(`${newer.join(" and ")} needs a newer ${pptx.name}; ${pptx.version} is installed and would ignore it.`, "peer-too-old", { details: { package: pptx.name } });
}

export interface Diagnostic {
	code: string;
	path?: string;
	message: string;
	[detail: string]: unknown;
}
export interface EmbeddedFace {
	family: string;
	weight: number;
	italic?: boolean;
	dataUrl: string;
}
/** What the renderer's deck-level functions read from `{ fonts }` (opf-render `RenderFonts`). */
export interface RenderFonts {
	textMeasurement?: unknown;
	embeddedFonts?: readonly EmbeddedFace[];
	fontFiles?: readonly string[];
	useBundledFonts?: boolean;
	loadSystemFonts?: boolean;
}
export interface FontRegistry {
	/** Private demand-loader metadata capability; role names require no font bytes. */
	fontNames?: object;
	scriptSelection?: { detected: string[]; scripts: string[]; unavailable: string[]; packages?: string[]; notInstalled?: string[]; uncovered?: string[] };
}
/** The handle `loadFonts()` of opf-render `/fonts-node` returns: pass it as `{ fonts }` to every deck-level call. */
export interface FontsHandle extends RenderFonts {
	textMeasurement: unknown;
	embeddedFonts: EmbeddedFace[];
	fontFiles: string[];
	useBundledFonts: false;
	loadSystemFonts: false;
	registry: FontRegistry;
	/** Present on current handles; prepare newly used faces after document edits or pagination. */
	ensure?(presentation: unknown, options?: Record<string, unknown>): Promise<unknown>;
	substitutions: { requestedFamily: string; resolvedFamily: string; compatibility: string; substitute: boolean }[];
}
/** The engines of opf-render 0.18 (RR-73). Slides count from 1; a number gives one SVG, a selection a list. */
export interface RenderModule {
	/** Optional on older renderers; recognize only their actual structured validation exception. */
	OPFRenderError?: new (code: string, message: string, details?: Record<string, unknown>) => Error & { code: string; details: Record<string, unknown> };
	/** One slide of the deck as SVG; slides count from 1. */
	toSvg(presentation: unknown, slide: number, options?: Record<string, unknown>): string;
	/** One SVG slide as PNG. */
	toPng(svg: string, options?: Record<string, unknown>): Promise<Uint8Array>;
	/** SVG slides as one PDF, a page each. */
	toPdf(svgs: string[], options?: Record<string, unknown>): Promise<Uint8Array>;
	/** LH-145: the luminance sampler of the deck's picture backgrounds (`pictureLuminance`). Absent from releases before LH-145. */
	measurePictures?(presentation: unknown, options?: Record<string, unknown>): Promise<(src: string) => unknown>;
}
export interface FontsNodeModule {
	loadFonts(options?: Record<string, unknown>): Promise<FontsHandle>;
}
export interface PptxModule {
	toPptx(presentation: unknown, options?: Record<string, unknown>): Promise<Uint8Array>;
	/** Without `signals` the presentation itself; with `signals: true`, `{ presentation, signals }`. */
	fromPptx(input: Uint8Array, options?: Record<string, unknown>): Promise<Record<string, unknown>>;
	/** LH-28: the Latin text typefaces of a PPTX that are not Office-safe. Absent from releases before LH-28. */
	typefacesNotOfficeSafe?(input: Uint8Array): string[];
}
export interface Peer<T> {
	module: T;
	version: string;
	name: string;
}

/**
 * What the renderer needs besides itself (RR-63): its converters and every font package are optional peers of opf-render, so a host
 * installs only the ones its outputs use. The versions are the ones the renderer is tested with (its `peerDependencies`).
 */
export const RENDER_EXTRAS = {
	/** The faces of the office pack, which the CLI and `convert` always load (every format). */
	fonts: ["@expo-google-fonts/roboto@0.4.3", "@expo-google-fonts/roboto-mono@0.4.2", "@expo-google-fonts/caladea@0.4.2", "@expo-google-fonts/arimo@0.4.3", "@expo-google-fonts/tinos@0.4.2", "@expo-google-fonts/cousine@0.4.3", "@expo-google-fonts/gelasio@0.4.1", "@expo-google-fonts/noto-sans@0.4.2"],
	/** PNG output (and raster fallbacks): the SVG rasterizer, and sharp for WebP and rotated JPEG pictures. */
	png: ["@resvg/resvg-js@^2.6.2", "sharp@^0.35.5"],
	/** PDF: vector mode (the default) needs nothing for text; raster mode needs pdf-lib; pictures in a vector PDF need sharp. */
	pdfRaster: ["pdf-lib@^1.17.1"],
	pdfPictures: ["sharp@^0.35.5"],
} as const;

const renderHint = () =>
	`  ${RENDER_PACKAGE} also needs its optional peers, by output:\n` +
	`    every format (fonts):  npm install ${RENDER_EXTRAS.fonts.join(" ")}\n` +
	`    png:                   npm install ${RENDER_EXTRAS.png.join(" ")}\n` +
	`    pdf:                   npm install ${RENDER_EXTRAS.pdfRaster.join(" ")}  (raster mode), ${RENDER_EXTRAS.pdfPictures.join(" ")}  (when the deck has pictures)\n` +
	`    svg:                   fonts only`;

const hint = (name: string) =>
	`${name} is not installed. It is an optional peer of @openpresentation/opf, loaded only by the file API of @openpresentation/opf in Node (convert, open) and the opf commands that need it. Install it next to the CLI or in your project:\n` +
	`  npm install -g ${name}@${PEER_RANGES[name as keyof typeof PEER_RANGES]}      (global CLI)\n` +
	`  npm install ${name}@${PEER_RANGES[name as keyof typeof PEER_RANGES]}      (project that calls convert or open of @openpresentation/opf, or depends on the CLI)\n` +
	`  npx -p @openpresentation/cli -p @openpresentation/opf-render -p @openpresentation/opf-pptx opf <command> ...      (one run)` +
	(name === RENDER_PACKAGE ? `\n${renderHint()}` : "");

function bases(): string[] {
	// Resolution starts at core's own file, then at the working directory.
	return [import.meta.url, pathToFileURL(path.join(process.cwd(), "noop.js")).href];
}

function locate(specifier: string): string | undefined {
	for (const base of bases()) {
		try {
			return createRequire(base).resolve(specifier);
		} catch (error) {
			// MODULE_NOT_FOUND: try the next base. A package without that export is also "not found".
			const code = (error as NodeJS.ErrnoException).code;
			if (code !== "MODULE_NOT_FOUND" && code !== "ERR_PACKAGE_PATH_NOT_EXPORTED") throw error;
		}
	}
	return undefined;
}

/**
 * A package as the engine would find it (RR-75, `opf doctor`): without `from`, resolve from core's location, then the working
 * directory. With `from`, use only that file's normal Node resolution chain, for the optional peers opf-render loads itself.
 * An unrelated core/global install cannot satisfy those peers. Undefined when it is not installed. Nothing is loaded.
 */
export function locatePackage(name: string, from?: string): { manifest: string; version: string } | undefined {
	const starts = from === undefined ? bases() : [pathToFileURL(from).href];
	for (const base of starts) {
		const manifest = manifestFrom(name, base);
		if (!manifest) continue;
		try {
			return { manifest, version: (JSON.parse(readFileSync(manifest, "utf8")) as { version?: string }).version ?? "unknown" };
		} catch {
			return { manifest, version: "unknown" };
		}
	}
	return undefined;
}

/** A package's manifest from `base`: `<name>/package.json`, or (a package that does not export it, such as sharp) the folder of its entry that holds a manifest of that name. */
function manifestFrom(name: string, base: string): string | undefined {
	const require = createRequire(base);
	try {
		return require.resolve(`${name}/package.json`);
	} catch {
		// not exported, or not installed: try the entry
	}
	let entry: string;
	try {
		entry = require.resolve(name);
	} catch {
		return undefined;
	}
	for (let folder = path.dirname(entry); folder !== path.dirname(folder); folder = path.dirname(folder)) {
		const candidate = path.join(folder, "package.json");
		try {
			if ((JSON.parse(readFileSync(candidate, "utf8")) as { name?: string }).name === name) return candidate;
		} catch {
			// no manifest here
		}
	}
	return undefined;
}

const cache = new Map<string, Peer<unknown>>();

async function loadPeer<T>(name: string, subpath = ""): Promise<Peer<T>> {
	const key = `${name}${subpath}`;
	const cached = cache.get(key);
	if (cached) return cached as Peer<T>;
	const manifestPath = locate(`${name}/package.json`);
	const entry = locate(`${name}${subpath}`);
	if (!manifestPath || !entry) throw new OPFApiError(hint(name), "peer-not-installed", { details: { package: name, range: PEER_RANGES[name as keyof typeof PEER_RANGES] } });
	let module: T;
	try {
		module = (await import(pathToFileURL(entry).href)) as T;
	} catch (error) {
		throw new OPFApiError(`${name} is installed at ${path.dirname(manifestPath)} but did not load: ${(error as Error).message}`, "peer-load-failed", { details: { package: name }, cause: error });
	}
	const version = (JSON.parse(readFileSync(manifestPath, "utf8")) as { version?: string }).version ?? "unknown";
	const peer = { module, version, name };
	cache.set(key, peer);
	return peer;
}

function requireFeature(peer: Peer<unknown>, names: string[]) {
	const missing = names.filter((name) => typeof (peer.module as Record<string, unknown>)[name] !== "function");
	if (missing.length)
		throw new OPFApiError(`${peer.name}@${peer.version} does not provide ${missing.join(", ")}. Install ${peer.name}@${PEER_RANGES[peer.name as keyof typeof PEER_RANGES]}.`, "peer-too-old", { details: { package: peer.name } });
}

/**
 * The missing-peer error for a renderer failure that says a package it loads lazily is absent (RR-63): `converter-missing` (pdf-lib,
 * @resvg/resvg-js, sharp) or `font-resource-unavailable` naming font packages. The renderer's message, with its install command, is kept;
 * `details` has `package` (or `packages`), `range`, `install` and `purpose` where the renderer gave them. A converter that is installed but
 * did not load is `peer-load-failed`. Undefined for any other error.
 */
export function missingPeerFrom(error: unknown): OPFApiError | undefined {
	let current = error as { code?: unknown; message?: string; details?: Record<string, unknown>; cause?: unknown } | undefined;
	for (let depth = 0; current && typeof current === "object" && depth < 4; depth++, current = current.cause as typeof current) {
		const details = current.details ?? {};
		const fontPackages = current.code === "font-resource-unavailable" && (Array.isArray(details.packages) || typeof details.package === "string");
		if (current.code !== "converter-missing" && !fontPackages) continue;
		const kept = Object.fromEntries(["package", "packages", "range", "install", "purpose"].filter((key) => details[key] !== undefined).map((key) => [key, details[key]]));
		return new OPFApiError(current.message ?? String(current.code), details.installed === true ? "peer-load-failed" : "peer-not-installed", { details: kept, cause: error });
	}
	return undefined;
}

export interface Renderer {
	render: Peer<RenderModule>;
	fonts: FontsNodeModule;
}

export async function loadRenderer(): Promise<Renderer> {
	const render = await loadPeer<RenderModule>(RENDER_PACKAGE);
	requireFeature(render, ["toSvg", "toPng", "toPdf"]);
	const fonts = await loadPeer<FontsNodeModule>(RENDER_PACKAGE, "/fonts-node");
	requireFeature(fonts, ["loadFonts"]);
	return { render, fonts: fonts.module };
}

export async function loadPptx(): Promise<Peer<PptxModule>> {
	const pptx = await loadPeer<PptxModule>(PPTX_PACKAGE);
	// `inventoryTypefaces` is the 0.14 name of `inventoryPptxTypefaces`: the check that tells the 0.14 API (`{ fonts }`, `{ presentation, signals }`) from the 0.13 one.
	requireFeature(pptx, ["toPptx", "fromPptx", "inventoryTypefaces"]);
	return pptx;
}

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const output = 'C:/opf-work/rr20-nine-review-20261109-01';
const logs = 'C:/opf-work/rr20-nine-review-logs-20261109-01';
const destination = 'C:/opf-work/rr20-nine-evidence/docs/handoff/2026-11-09/rr20-current-nine-archive-review';
const {zipSync} = createRequire('C:/opf-work/rr20-nine-current/packages/pptx/package.json')('fflate');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const files = [], parts = {};
function collect(root, prefix, directory = root) {
  for (const item of fs.readdirSync(directory, {withFileTypes: true}).sort((a,b) => a.name.localeCompare(b.name, 'en'))) {
    const file = path.join(directory, item.name);
    if (item.isDirectory()) collect(root, prefix, file);
    else {
      if (!item.isFile()) throw Error('No links in owned evidence');
      const name = prefix + '/' + path.relative(root, file).split(path.sep).join('/');
      const bytes = fs.readFileSync(file);
      files.push({name, bytes: bytes.length, sha256: sha(bytes)}); parts[name] = [bytes, {level: 9, mtime: new Date(1980,0,1)}];
    }
  }
}
collect(output, 'outputs'); collect(logs, 'run');
fs.mkdirSync(destination, {recursive: true});
const zip = Buffer.from(zipSync(parts, {level: 9, mtime: new Date(1980,0,1)}));
fs.writeFileSync(path.join(destination, 'actual-nine-review.zip'), zip, {flag: 'wx'});
const manifest = {format: 1, scope: 'immutable actual nine-deck archive review; not product source or promotion', baseline: 'c9732accd41cfffa27b8893251f33868c6b0514e', candidate: '5b9e4386c00319da1fa4370dcc0b3eb6e93c9578', publishedPrevious: '5e89a184ffc8a38539f5fb5e573f403066bcca17', zip: {name: 'actual-nine-review.zip', bytes: zip.length, sha256: sha(zip)}, rawFiles: files.length, rawBytes: files.reduce((sum,row) => sum+row.bytes,0), files};
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify(manifest,null,2)+'\n', {flag: 'wx'});
console.log(JSON.stringify({rawFiles: manifest.rawFiles, rawBytes: manifest.rawBytes, zipBytes: zip.length, zipSha256: manifest.zip.sha256}));

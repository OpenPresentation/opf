import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const current = 'C:/opf-work/rr20-nine-current';
const baseline = 'C:/opf-work/rr20-nine-baseline';
const output = 'C:/opf-work/rr20-nine-review-20261109-01';
const logs = 'C:/opf-work/rr20-nine-review-logs-20261109-01';
const rq = createRequire(path.join(current, 'packages/pptx/package.json'));
const {unzipSync} = rq('fflate');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const git = (root, ...args) => execFileSync('git', args, {cwd: root, maxBuffer: 16 * 1024 * 1024});
const read = file => fs.readFileSync(file);
const parse = file => JSON.parse(read(file));
const review = parse(path.join(output, 'review.json'));
assert.equal(review.baseline.head, 'c9732accd41cfffa27b8893251f33868c6b0514e');
assert.equal(review.candidate.head, '5b9e4386c00319da1fa4370dcc0b3eb6e93c9578');
assert.equal(review.node, 'v24.20.0'); assert.equal(review.platform, 'win32');
assert.equal(review.entries.length, 9);
const sourceFixture = 'packages/pptx/test/fixtures/chartex-fallback-main.json';
const beforeFixture = read(path.join(baseline, sourceFixture)), afterFixture = read(path.join(current, sourceFixture));
assert.deepEqual(beforeFixture, afterFixture); assert.equal(hash(beforeFixture), '73cea56b226a75d785c2d00d980776743bc412e18f723717ee7e61cab5549d68');
for (const root of [baseline, current]) assert.equal(git(root, 'status', '--porcelain').toString().trim(), '');
const rows = [], workbooks = []; let partCount = 0;
for (const entry of review.entries) {
  const directory = path.join(output, entry.name);
  const before = read(path.join(directory, 'before.pptx')), after = read(path.join(directory, 'after.pptx'));
  assert.equal(hash(before), entry.baseline.sha256); assert.equal(hash(after), entry.candidate.sha256);
  assert.equal(before.length, entry.baseline.bytes); assert.equal(after.length, entry.candidate.bytes);
  const publishedPath = 'docs/evidence/rr105-034-archive-review/nine/' + entry.name + '.zip';
  const publishedContainer = git(current, 'show', '5e89a184ffc8a38539f5fb5e573f403066bcca17:' + publishedPath);
  const published = unzipSync(publishedContainer);
  assert.deepEqual(Buffer.from(published['after.pptx']), before, 'Actual current-lock baseline equals immutable513 archive: ' + entry.name);
  const a = unzipSync(before), b = unzipSync(after), names = Object.keys(a).sort();
  assert.deepEqual(Object.keys(b).sort(), names); partCount += names.length;
  const changed = names.filter(name => !Buffer.from(a[name]).equals(Buffer.from(b[name])));
  assert.deepEqual(changed, ['ppt/tags/opfLayout18.xml']);
  assert.deepEqual(entry.parts.changed.map(row => row.file), changed);
  assert.deepEqual(entry.baseline.diagnostics, entry.candidate.diagnostics);
  assert.equal(entry.baseline.layoutParts, entry.candidate.layoutParts);
  assert.equal(entry.baseline.layoutTagParts, entry.candidate.layoutTagParts);
  const tag = bytes => JSON.parse(Buffer.from(/name="OPF_LAYOUT_V1" val="([0-9A-F]+)"/.exec(Buffer.from(bytes).toString())[1], 'hex').toString());
  const oldTag = tag(a[changed[0]]), newTag = tag(b[changed[0]]);
  assert.equal(oldTag.id, 'inverted-pyramid'); assert.equal(oldTag.hash, '4baa264255f9f66b'); assert.equal(newTag.hash, '22f5fe00efa7a1f8');
  assert.deepEqual({...oldTag, hash: null}, {...newTag, hash: null});
  assert.equal(a[changed[0]].length, 519); assert.equal(b[changed[0]].length, 519);
  const byteDifferences = [...a[changed[0]]].flatMap((value, offset) => value === b[changed[0]][offset] ? [] : [{offset, before: value, after: b[changed[0]][offset]}]);
  assert.equal(byteDifferences.length, 21);
  for (const name of names.filter(name => /\.xlsx$/.test(name))) {
    assert.deepEqual(Buffer.from(a[name]), Buffer.from(b[name]));
    const wa = unzipSync(a[name]), wb = unzipSync(b[name]), files = Object.keys(wa).sort(); assert.deepEqual(Object.keys(wb).sort(), files);
    const parts = files.map(file => {
      assert.deepEqual(Buffer.from(wa[file]), Buffer.from(wb[file]));
      return {file, bytes: wa[file].length, beforeSha256: hash(wa[file]), afterSha256: hash(wb[file])};
    });
    workbooks.push({deck: entry.name, file: name, bytes: a[name].length, sha256: hash(a[name]), changed: false, parts});
  }
  rows.push({name: entry.name, published513Control: {commit: '5e89a184ffc8a38539f5fb5e573f403066bcca17', path: publishedPath, containerSha256: hash(publishedContainer), baselineBytesIdentical: true}, baseline: entry.baseline, candidate: entry.candidate, partCount: names.length, changedParts: changed, metadataOnly: true, tagBeforeSha256: hash(a[changed[0]]), tagAfterSha256: hash(b[changed[0]]), byteDifferences, workbookCount: names.filter(name => /\.xlsx$/.test(name)).length});
}
assert.equal(rows[0].candidate.sha256, 'c844c8abe2f223546f9a735e27f16cb0e036dd7c519b01992e02df5c22639079');
const result = {
  format: 1, scope: 'Actual single maintained nine-deck family review; no promotion,21-deck qualification or native acceptance',
  baseline: review.baseline.head, candidate: review.candidate.head, reviewedOriginalProducer: '513156a982397eaa0033808215fbb86dd284745b',
  vetoableDecision: {id: 'RR20-BASELINE-CURRENT-LOCK', choice: review.baseline.head, reason: 'Coordinator-selected previously280-contract-qualified source holds current73ce lock. Raw513 and0cafa contain historical091830/843432 locks and cannot satisfy same-lock guard without prohibited mutation.'},
  node: review.node, platform: review.platform, fixtureSha256: hash(beforeFixture), sourceFixturesUnchanged: true, sourceProducersClean: true,
  generation: {maintainedInvocations: 1, baselineExports: 9, candidateExports: 9, baselineAllLockedFieldsReproducedBeforeCandidate: true, machineSlot: true, buildAndInstallExitCodes: ['baseline-install','current-install','baseline-build','current-build','review'].map(name => ({name, exitCode: parse(path.join(logs, name + '.exit.json')).exitCode}))},
  reportSha256: hash(read(path.join(output, 'review.json'))), provenanceSha256: hash(read(path.join(output, 'provenance.json'))),
  generatedCandidateFixtureSha256: hash(read(path.join(output, 'candidate-fixture.json'))), generatedCandidateNotPromoted: true,
  partCount, changedPartCount: rows.length, unchangedPartCount: partCount - rows.length, embeddedWorkbooks: workbooks.length, nestedWorkbookParts: workbooks.reduce((sum, row) => sum + row.parts.length, 0), allNestedWorkbookBytesUnchanged: true,
  allNineMatchImmutable513ArchivesBefore: true, allNineOnlySH24LayoutHashMetadataAfter: true, nonmetadataDifferenceObserved: false,
  rows, fixturePromoted: false, twentyOneFamilyQualified: false, rasterGoldensChanged: false, officeCalls: 0
};
for (const row of result.generation.buildAndInstallExitCodes) assert.equal(row.exitCode, 0);
fs.writeFileSync(path.join(logs, 'nine-audit.json'), JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
fs.writeFileSync(path.join(logs, 'nine-workbook-inventories.json'), JSON.stringify(workbooks, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({actualNineReview: 'PASS', baseline: result.baseline, candidate: result.candidate, allPublished513ControlsEqual: true, parts: partCount, metadataChanges: rows.length, unchangedParts: result.unchangedPartCount, workbooks: workbooks.length, nestedWorkbookParts: result.nestedWorkbookParts, nonmetadataDifferenceObserved: false, candidateFixtureSha256: result.generatedCandidateFixtureSha256, promoted: false}));


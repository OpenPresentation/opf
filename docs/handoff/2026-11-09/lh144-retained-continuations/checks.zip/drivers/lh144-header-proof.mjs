import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const sharp=createRequire(new URL('../packages/render/package.json',import.meta.url))('sharp');
const sha=b=>createHash('sha256').update(b).digest('hex'),rows=[];
for(const name of ['before-1','after-1']){
 const file='artifacts/lh144-qa-portable-02/'+name+'.png';
 const {data,info}=await sharp(file).extract({left:0,top:0,width:1280,height:185}).removeAlpha().raw().toBuffer({resolveWithObject:true});
 let bright=0;for(let i=0;i<data.length;i+=info.channels)if(data[i]>200&&data[i+1]>200&&data[i+2]>200)bright++;
 const svg=fs.readFileSync(file.replace('.png','.svg'),'utf8'),header=svg.slice(0,svg.indexOf('<g data-opf-region='));
 rows.push({name,pngSha256:sha(fs.readFileSync(file)),headerRawSha256:sha(data),brightHeaderPixels:bright,headerSvgSha256:sha(header),channels:info.channels});
}
fs.writeFileSync('artifacts/lh144-baseline/header-pixel-proof.json',JSON.stringify({scope:'Offline untouched PNG decoding only. Variable image-tool header presentation is not product-paint proof; raw header region and source identities bound here.',rows},null,2)+'\n');
console.log(JSON.stringify(rows));

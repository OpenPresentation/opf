import {composeSlide} from '../packages/javascript/dist/composition.js';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {loadFonts} from '../packages/render/dist/fonts-node.js';
import * as core from '../packages/javascript/dist/index.js';
import {layouts,sampleSlide} from '../packages/javascript/test/support/template-samples.mjs';
const before=await import(pathToFileURL('C:/opf-work/sh26-tie/packages/javascript/dist/index.js'));
const {registry}=await loadFonts({pack:'office',substitutionPolicy:'visual'}),fonts={textMeasurement:registry.textMeasurement};
const rows=[];
for(const count of [5,6,8]){
 const doc={catalogs:{custom:{layouts:{'inverted-pyramid':layouts['inverted-pyramid']}}},slides:[{layout:'inverted-pyramid',...sampleSlide(layouts['inverted-pyramid'],count,'long')}]};
 const context=core.resolveSlideContext(doc,0),drawn=composeSlide(context.slide,{...context.options,textMeasurement:fonts.textMeasurement});
 rows.push({count,sourceFitIssues:drawn.diagnostics.filter(issue=>['text-overflow','small-cell'].includes(issue.code)).length,before:before.continueOverfull(doc,{fonts}).presentation.slides.map(s=>s.blocks.length),after:core.continueOverfull(doc,{fonts}).presentation.slides.map(s=>s.blocks.length)});
}
fs.writeFileSync('artifacts/lh144-baseline/measured-fitting-control.json',JSON.stringify({correction:'QA01 produced identical one-page output; this is a fitting control, not a refusal. The earlier diagnostic receipt wording incorrectly anticipated a refusal; actual diagnostic returned pages1 without an error.',rows},null,2)+'\n');
console.log(JSON.stringify(rows));

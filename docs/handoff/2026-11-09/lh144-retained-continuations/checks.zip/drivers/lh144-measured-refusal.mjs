import {loadFonts} from '../packages/render/dist/fonts-node.js';
import * as core from '../packages/javascript/dist/index.js';
import {layouts,sampleSlide} from '../packages/javascript/test/support/template-samples.mjs';
const {registry}=await loadFonts({pack:'office',substitutionPolicy:'visual'}),fonts={textMeasurement:registry.textMeasurement};
const doc={catalogs:{custom:{layouts:{'inverted-pyramid':layouts['inverted-pyramid']}}},slides:[{layout:'inverted-pyramid',...sampleSlide(layouts['inverted-pyramid'],5,'long')}]};
const context=core.resolveSlideContext(doc,0);
try{const result=core.paginateSlide(context.slide,{...context.options,presentation:doc,fonts,wholeBlocks:true});console.log(JSON.stringify({pages:result.slides.length}));}catch(error){console.log(JSON.stringify({name:error.name,message:error.message,diagnostics:error.diagnostics?.slice(0,4)}));}

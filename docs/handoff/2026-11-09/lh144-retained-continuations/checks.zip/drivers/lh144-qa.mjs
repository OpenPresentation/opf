import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {layouts,sampleSlide} from '../packages/javascript/test/support/template-samples.mjs';
import * as current from '../packages/javascript/dist/index.js';
import {toSvg,toPng} from '../packages/render/dist/index.js';
import {loadFonts} from '../packages/render/dist/fonts-node.js';
const base='C:/opf-work/sh26-tie',out='artifacts/lh144-qa';
assert.ok(!fs.existsSync(out),'fresh QA output required');fs.mkdirSync(out,{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
const baselineFiles=[['packages/javascript/dist/composition.js','8a75f162f5c04cdbca5dd1580b643b2599f2f58f9d33be8fe65a93f45f055d78'],['packages/render/dist/index.js','b49c1708765dc46fb2a7d66b2dfbcc9b1b677c03d3cba16af102e9ae98cc34e4']];
for(const [file,hash]of baselineFiles)assert.equal(sha(fs.readFileSync(path.join(base,file))),hash);
const before=await import(pathToFileURL(path.join(base,'packages/javascript/dist/index.js')));
const renderer=await import(pathToFileURL(path.join(base,'packages/render/dist/index.js')));
const prepared=await loadFonts({pack:'office',substitutionPolicy:'visual'}),fonts={textMeasurement:prepared.registry.textMeasurement};
const doc={catalogs:{custom:{layouts:{'inverted-pyramid':layouts['inverted-pyramid']}}},slides:[{layout:'inverted-pyramid',...sampleSlide(layouts['inverted-pyramid'],5,'long')}]};
const snapshot=JSON.stringify(doc),report=[];
for(const [name,core,render]of [['before',before,renderer.toSvg],['after',current,toSvg]]){
 const result=core.continueOverfull(doc,{fonts});
 assert.equal(JSON.stringify(doc),snapshot);
 assert.deepEqual(result.presentation.slides.flatMap(s=>s.blocks),doc.slides[0].blocks);
 fs.writeFileSync(path.join(out,name+'.opf.json'),JSON.stringify(result.presentation,null,2)+'\n');
 const pages=[];
 for(let i=0;i<result.presentation.slides.length;i++){
  const svg=render(result.presentation,i+1,{fonts,text:'system'});
  const png=await toPng(svg,{fonts:{fontFiles:prepared.fontFiles,useBundledFonts:false},scale:1});
  const stem=`${name}-${i+1}`;
  fs.writeFileSync(path.join(out,stem+'.svg'),svg);fs.writeFileSync(path.join(out,stem+'.png'),png);
  const sizes=[...svg.matchAll(/<text\b([^>]*)>([^<]*)<\/text>/g)].filter(([,attrs,text])=>attrs.includes('data-opf-path="slides.')&&attrs.includes('.blocks.')&&text.trim()).map(([,attrs])=>Number(/font-size="([^"]+)"/.exec(attrs)?.[1]));
  pages.push({page:i+1,blocks:result.presentation.slides[i].blocks.length,sizes:[...new Set(sizes)],svgSha256:sha(svg),pngSha256:sha(png)});
 }
 report.push({name,pages,continued:result.continued});
}
for(const [file,hash]of baselineFiles)assert.equal(sha(fs.readFileSync(path.join(base,file))),hash,'baseline remained frozen');
const record={scope:'Owned synthetic actual-font QA. Read-only baseline public APIs from frozen b487 runtime; pinned open office faces, measured geometry, system fonts disabled; no native/Claude/hosted claim.',baselineHead:execFileSync('git',['-C',base,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),source:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),baselineFiles:baselineFiles.map(([file,sha256])=>({file,sha256})),fonts:prepared.fontFiles.map(file=>({file:path.basename(file),sha256:sha(fs.readFileSync(file))})),report};
fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(record,null,2)+'\n');
console.log(JSON.stringify(record.report.map(row=>({name:row.name,pages:row.pages}))));

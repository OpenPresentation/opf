import fs from 'node:fs';
import assert from 'node:assert/strict';
import {composeSlide, OPFCompositionError} from '../../packages/javascript/dist/composition.js';
import {continueOverfull,paginateSlide,OPFPaginationError} from '../../packages/javascript/dist/pagination.js';
import {resolveSlideContext} from '../../packages/javascript/dist/index.js';
import {layouts,sampleSlide} from '../../packages/javascript/test/support/template-samples.mjs';
const documentFor=(id,count)=>({catalogs:{custom:{layouts:{[id]:layouts[id]}}},slides:[{layout:id,...sampleSlide(layouts[id],count,'long')}]});
const geometry=(doc,index)=>{const {slide,options}=resolveSlideContext(doc,index);return composeSlide(slide,options);};
const body=g=>g.items.filter(item=>item.path.includes('.blocks.')&&item.text&&'listEntries'in item.text);
const profile=g=>({body:body(g).map(item=>({path:item.path,font:item.text.fontSize,painted:[...new Set((item.listColumns??[{text:item.text}]).flatMap(column=>column.text.listEntries.flatMap(entry=>entry.text.richLines?.flatMap(line=>line.fragments.map(fragment=>fragment.fontSize))??[])))]})),arrangements:(g.arrangements??[]).map(a=>({path:a.path,font:a.fontSize})),findings:g.diagnostics.map(x=>x.code)});
const results=[];
for(const id of ['inverted-pyramid','org-chart','hierarchy']){
 const doc=documentFor(id,5),saved=structuredClone(doc),source=profile(geometry(doc,0));
 const result=continueOverfull(doc);
 assert.deepEqual(doc,saved);
 assert.deepEqual(result.presentation.slides.flatMap(s=>s.blocks.flatMap(b=>b.items)),doc.slides[0].blocks.flatMap(b=>b.items));
 const pages=result.presentation.slides.map((slide,i)=>({blocks:slide.blocks.length,composition:slide.composition,profile:profile(geometry(result.presentation,i))}));
 const explicit=continueOverfull(doc,{minFontSize:24});
 results.push({id,source,continued:result.continued.length,pages,explicit24:explicit.presentation.slides.map((slide,i)=>({blocks:slide.blocks.length,profile:profile(geometry(explicit.presentation,i))}))});
 if(id!=='inverted-pyramid'){
  const context=resolveSlideContext(doc,0);
  assert.throws(()=>paginateSlide(context.slide,{...context.options,wholeBlocks:true}),OPFPaginationError);
  assert.deepEqual(result.presentation,doc);
 }
}
fs.writeFileSync('artifacts/lh144-baseline/candidate-witness.json',JSON.stringify(results,null,2)+'\n');
for(const row of results)console.log(JSON.stringify({id:row.id,sourceFont:row.source.body.map(x=>x.font),default:row.pages.map(p=>({blocks:p.blocks,composition:p.composition,fonts:p.profile.body.map(x=>x.font),painted:p.profile.body.map(x=>x.painted),arrangements:p.profile.arrangements})),explicit24:row.explicit24.map(p=>({blocks:p.blocks,fonts:p.profile.body.map(x=>x.font)}))}));
const witness=results[0];
assert.ok(witness.pages.every(page=>page.profile.body.every(item=>item.font>=witness.source.body[0].font-1e-6)),'Default whole-block pages retain the settled 21.3px source body before minimizing page count');

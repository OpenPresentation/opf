import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const req=createRequire(process.cwd()+'/packages/pptx/package.json'),{unzipSync,strFromU8}=req('fflate');
const sharp=createRequire(process.cwd()+'/packages/render/package.json')('sharp');
const hash=b=>createHash('sha256').update(b).digest('hex');
const suiteBytes=readFileSync('C:/opf-work/n034-suite03/suite.json'),suite=JSON.parse(suiteBytes);
assert.equal(hash(suiteBytes),'fd13b7725ea3b76717ec6976c9e12a7f6df9db5135818120cc026fa54c9c5d65');
const cases=[
 {name:'auto',root:'C:/opf-work/n034-native05/chart-histogram-category-01',id:'chart-histogram-category'},
 {name:'fallback',root:'C:/opf-work/n034-native06/chart-mode-histogram-category-fallback-01',id:'chart-mode-histogram-category-fallback'},
];
const out={suiteSha256:hash(suiteBytes),nativeAcceptance:false,newOfficeRuns:0,interpretation:'Exact existing observations; worker completion is not native acceptance. Pixel runs support the viewed negative-bar omission, not semantic glyph recognition.',cases:[]};
for(const item of cases){
 const runnerBytes=readFileSync(item.root+'/runner.json'),runner=JSON.parse(runnerBytes.toString('utf8').replace(/^\uFEFF/,''));
 const expected=suite.cases.find(c=>c.id===item.id);assert.ok(expected);
 const input=readFileSync(item.root+'/native/inputs/input.pptx');
 assert.equal(hash(input),expected.archiveSha256);assert.deepEqual(input,readFileSync('C:/opf-work/n034-suite03/'+expected.input));assert.equal(runner.selectedCase.archiveSha256,expected.archiveSha256);
 const projection={status:runner.status,nativeAcceptance:runner.nativeAcceptance,selectedCase:runner.selectedCase};
 writeFileSync('artifacts/histogram-negative/'+item.name+'-runner-projection.json',JSON.stringify(projection,null,2)+'\n');
 const phases=['original','edited','reopened'].map(phase=>({phase,bytes:readFileSync(item.root+'/native/'+phase+'-slide-01.png')}));
 assert.deepEqual(phases[0].bytes,phases[1].bytes);assert.deepEqual(phases[0].bytes,phases[2].bytes);
 const {data,info}=await sharp(phases[0].bytes).ensureAlpha().raw().toBuffer({resolveWithObject:true});assert.equal(info.width,1280);assert.equal(info.height,720);
 let below=0;const xs=[];for(let x=100;x<1216;x++){let pixels=0;for(let y=150;y<=622;y++){const p=(y*info.width+x)*4;if(data[p]===49&&data[p+1]===137&&data[p+2]===195){pixels++;if(y>=500)below++;}}if(pixels)xs.push(x);}
 const runs=[];for(const x of xs){if(!runs.length||x>runs.at(-1)[1]+1)runs.push([x,x]);else runs.at(-1)[1]=x;}
 const archives=[];for(const [label,bytes] of [['input',input],['saved',readFileSync(item.root+'/native/native-furniture-control.pptx')]]){
  assert.ok(bytes.length<16*1024*1024);const parts=unzipSync(bytes);assert.ok(Object.values(parts).reduce((n,b)=>n+b.length,0)<64*1024*1024);
  const classic=strFromU8(parts['ppt/charts/chart1.xml']);const extract=kind=>{const block=classic.match(new RegExp('<c:'+kind+'[ >][\\s\\S]*?</c:'+kind+'>'))?.[0]??'';return [...block.matchAll(/<c:pt\b[^>]*>[\s\S]*?<c:v>([\s\S]*?)<\/c:v>[\s\S]*?<\/c:pt>/g)].map(([,value])=>value);};
  assert.deepEqual(extract('cat'),['North','South','East','West']);assert.deepEqual(extract('val'),['42','31','-8','19']);
  const chartex=Object.keys(parts).filter(p=>/^ppt\/charts\/chartEx\d+\.xml$/.test(p));assert.equal(chartex.length,item.name==='auto'?1:0);
  if(chartex.length){const x=strFromU8(parts[chartex[0]]);assert.match(x,/<cx:aggregation\s*\/>/);assert.match(x,/<cx:pt idx="2">-8<\/cx:pt>/);}
  const books=Object.entries(parts).filter(([p])=>/^ppt\/embeddings\/.*\.xlsx$/.test(p));assert.ok(books.length>=1);for(const[,book]of books){const p=unzipSync(book);assert.match(strFromU8(p['xl/worksheets/sheet1.xml']),/<c\b[^>]*r="B4"[^>]*>[\s\S]*?<v>-8<\/v>/);}
  archives.push({label,bytes:bytes.length,sha256:hash(bytes),classicCategories:extract('cat'),classicValues:extract('val'),chartExParts:chartex.length,workbooks:books.length,negativeWorkbookCell:'B4=-8'});
 }
 out.cases.push({id:item.id,root:item.root,runnerSha256:hash(runnerBytes),runner:projection,phases:phases.map(({phase,bytes})=>({phase,bytes:bytes.length,sha256:hash(bytes)})),phaseBytesEqual:true,rgbaSha256:hash(data),width:info.width,height:info.height,barFillRGB:[49,137,195],barFillColumnRuns:runs,barFillPixelsY500to622:below,archives});
}
assert.equal(out.cases[0].barFillColumnRuns.length,3);assert.equal(out.cases[0].barFillPixelsY500to622,0);assert.equal(out.cases[1].barFillColumnRuns.length,4);assert.equal(out.cases[1].barFillPixelsY500to622,4400);
writeFileSync('artifacts/histogram-negative/native-facts.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({cases:out.cases.map(c=>({id:c.id,phasesByteEqual:c.phaseBytesEqual,bars:c.barFillColumnRuns.length,belowZeroFill:c.barFillPixelsY500to622,archives:c.archives})),nativeAcceptance:false}));

import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {toPptx,fromPptx} from '../../packages/pptx/test/helpers/default-catalog.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const sourcePath='packages/pptx/test/fixtures/chartex-fallback-main.json';
const legacyPath='C:/opf-work/n034-suite03/chart-modes/histogram-category-fallback.pptx';
const sourceBytes=readFileSync(sourcePath),source=JSON.parse(sourceBytes).decks['histogram-category'],legacy=readFileSync(legacyPath);
assert.equal(hash(legacy),'b1dacc5a077cafa4d6f1c7e895c4a1dfb00f5675a012f9b9987b5ebea6756a3f');
mkdirSync('artifacts/histogram-negative/representative',{recursive:true});
const results=[];
for(const mode of [undefined,'auto','native','fallback']){
 const diagnostics=[];const bytes=await toPptx(structuredClone(source),{...(mode?{chartex:mode}:{}),onDiagnostic:d=>diagnostics.push(d)});
 const name=mode??'default';writeFileSync('artifacts/histogram-negative/representative/'+name+'.pptx',bytes);
 const imported=await fromPptx(bytes);
 results.push({mode:name,bytes:bytes.length,sha256:hash(bytes),equalsPreviouslyObservedClassicFallback:Buffer.from(bytes).equals(legacy),diagnostics,importedCharts:imported.slides.map(s=>s.chart??s.blocks?.find(b=>b.chart)?.chart)});
}
const report={sourcePath,sourceSha256:hash(sourceBytes),legacyPath,legacySha256:hash(legacy),nativeAcceptance:false,OfficeInvoked:false,results};
writeFileSync('artifacts/histogram-negative/representative.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({sourceSha256:report.sourceSha256,results:results.map(({mode,bytes,sha256,equalsPreviouslyObservedClassicFallback})=>({mode,bytes,sha256,equalsPreviouslyObservedClassicFallback}))}));
assert.ok(results.every(r=>r.equalsPreviouslyObservedClassicFallback),'candidate archives must equal the separately observed sealed classic fallback bytes');

# First focused test run

The first new test run had two test-authoring errors: the core validation API returns findings rather than an errors array; an edited native shape does not retain its old provenance id, so the current-position assertion must select the unique ellipse. Both were corrected without changing production code or weakening position checks. Editor and SVG checks passed on the first run; all four focused scripts then passed. These are local regression checks, not PowerPoint qualification.

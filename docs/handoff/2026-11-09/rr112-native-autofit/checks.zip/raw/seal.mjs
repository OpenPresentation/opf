import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,mkdirSync,existsSync,lstatSync} from 'node:fs';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='C:/opf-work/fontscale',raw='C:/opf-work/fontscale-evidence-20261109-01',output=root+'/docs/handoff/2026-11-09/rr112-native-autofit';
const require=createRequire(root+'/packages/pptx/package.json'),{zipSync}=require('fflate'),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const mapped=JSON.parse(readFileSync(raw+'/mapped-01.exit.json','utf8'));assert.equal(mapped.head,'373d472f8d7d1be73cd4518a79a655fecc204979');assert.ok(existsSync(raw+'/portable-observations/receipt.json'));
const snapshot=raw+'/mapped-step-snapshot-01';assert.ok(existsSync(snapshot),'Terminal log snapshot must already be sealed before docs checks');const snapshotReceipt=JSON.parse(readFileSync(raw+'/mapped-step-snapshot-01.json','utf8'));for(const item of snapshotReceipt.files){const bytes=readFileSync(snapshot+'/'+item.file);assert.equal(bytes.length,item.bytes);assert.equal(sha(bytes),item.sha256);}
const entries={};function collect(directory,prefix){for(const item of readdirSync(directory,{withFileTypes:true})){const file=directory+'/'+item.name,name=prefix+item.name;assert.ok(!item.isSymbolicLink(),file);if(item.isDirectory())collect(file,name+'/');else{assert.ok(item.isFile(),file);entries[name]=new Uint8Array(readFileSync(file));}}}
collect(raw,'raw/');
const keys=Object.keys(entries).sort(),files=keys.map(path=>({path,bytes:entries[path].length,sha256:sha(entries[path])}));
const zip=zipSync(Object.fromEntries(keys.map(key=>[key,entries[key]])),{mtime:new Date(1980,0,1),level:9});writeFileSync(output+'/checks.zip',zip,{flag:'wx'});
const documentationHead=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),readmeBlob=execFileSync('git',['rev-parse','HEAD:packages/pptx/README.md'],{cwd:root,encoding:'utf8'}).trim();
const summary={source:mapped.head,tree:mapped.tree,documentation:{head:documentationHead,readmeBlob,scope:'Post-mapped documentation-only clarification approved bycoordinator; allfrozenruntimepayloadremains373'},zipBytes:zip.length,zipSHA256:sha(zip),rawBytes:files.reduce((sum,item)=>sum+item.bytes,0),files,mapped:{exitCode:mapped.exitCode,logText:readFileSync(raw+'/mapped-01.log','utf8')}};writeFileSync(output+'/checks.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
writeFileSync(output+'/verify.mjs',readFileSync(raw+'/verify.mjs'),{flag:'wx'});writeFileSync(output+'/.gitattributes','checks.zip -diff\nfinal-docs-checks.zip -diff\n',{flag:'wx'});
console.log(JSON.stringify({files:files.length,rawBytes:summary.rawBytes,zipBytes:zip.length,zipSHA256:summary.zipSHA256,source:mapped.head}));

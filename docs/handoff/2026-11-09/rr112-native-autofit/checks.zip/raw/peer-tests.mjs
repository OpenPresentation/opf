import {readFileSync,writeFileSync} from 'node:fs';const root='C:/opf-work/fontscale/';function edit(file,a,b){let s=readFileSync(root+file,'utf8');if(s.split(a).length!==2)throw Error(`Expected one ${file}`);writeFileSync(root+file,s.replace(a,b));}
const test='packages/pptx/test/rr-112-native-autofit.mjs';
edit(test,'duplicateMasterRel=false,...options','duplicateMasterRel=false,duplicateBodyPr=false,...options');
edit(test,'  const replaceTree=(file,value)=>','  if(duplicateBodyPr)own=own.replace(\'</a:bodyPr>\',\'</a:bodyPr><a:bodyPr>\'+(duplicateBodyPr===true?\'<a:noAutofit/>\':fits(\'50000\'))+\'</a:bodyPr>\');\n  const replaceTree=(file,value)=>');
const anchor="await check('below-floor effective sizes remain literal with review diagnostic'";
const extra=`await check('repeated body properties cannot supply first-child cached factors',async()=>{for(const duplicateBodyPr of [true,'anotherScale']){const result=await read({fit:fits('55000'),duplicateBodyPr});near(find(result.deck.slides[2],'Foreign Alpha ').fontSize,24);assert.equal(result.signal.text.paragraphs[0].runs[0].size,24);assert.ok(result.diagnostics.some(item=>item.code==='unsupported-native-autofit'));}});
await check('unrecoverable negative percentage spacing is omitted not clamped or called effective',async()=>{const result=await read({fit:'<a:normAutofit fontScale="55000" lnSpcReduction="90000"/>',content:paragraph(run('Unrecoverable spacing'),'<a:lnSpc><a:spcPct val="80000"/></a:lnSpc>')});assert.equal(result.signal.text.paragraphs[0].lineSpacingPct,undefined);assert.equal(result.signal.text.lineSpacingReductionPct,90);assert.ok(result.diagnostics.some(item=>item.code==='native-autofit-line-spacing'));});
`;
edit(test,anchor,extra+anchor);

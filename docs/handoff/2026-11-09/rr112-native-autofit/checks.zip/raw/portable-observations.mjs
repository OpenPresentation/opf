import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='C:/opf-work/fontscale',out='C:/opf-work/fontscale-evidence-20261109-01/portable-observations';
const require=createRequire(root+'/packages/pptx/package.json');const {XMLParser}=require('fast-xml-parser'),{unzipSync,zipSync,strFromU8,strToU8}=require('fflate');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const {fromPptx:beforeImport}=await import('file:///C:/opf-work/fontscale/artifacts/rr112-baseline-pptx/dist/index.js');
const {fromPptx:afterImport}=await import('file:///C:/opf-work/fontscale/packages/pptx/dist/index.js');
const {loadFonts}=await import('file:///C:/opf-work/fontscale/packages/render/dist/fonts-node.js');
const {toSvg,toPng}=await import('file:///C:/opf-work/fontscale/packages/render/dist/index.js');
const {gallery}=await import('file:///C:/opf-work/fontscale/packages/gallery/dist/index.js');
await mkdir(out,{recursive:true});const original=await readFile('C:/opf-work/fontscale-evidence-20261109-01/after-05/foreign-scaled.pptx');
const baseParts=unzipSync(original),largerParts={...baseParts},part='ppt/slides/slide3.xml';
let largerXML=strFromU8(largerParts[part]);
for(const[before,after]of [['<a:defRPr sz="2400">','<a:defRPr sz="3600">'],['<a:rPr sz="1200" b="1" i="1"/>','<a:rPr sz="2400" b="1" i="1"/>'],['<a:off x="914400" y="914400"/>','<a:off x="914400" y="2743200"/>']]){assert.equal(largerXML.split(before).length,2,before);largerXML=largerXML.replace(before,after);}
largerParts[part]=strToU8(largerXML);for(const[key,value]of Object.entries(baseParts))if(key!==part)assert.deepEqual(largerParts[key],value,key);
const larger=zipSync(largerParts,{mtime:new Date(1980,0,1)});await writeFile(out+'/larger-foreign.pptx',larger);
const fonts=await loadFonts({pack:'office'}),runtimeFiles=['packages/pptx/dist/index.js','packages/pptx/dist/body-text-import.js','packages/pptx/dist/native-autofit.js','packages/pptx/dist/import-signals.js','packages/javascript/dist/composition.js','packages/render/dist/index.js'];
async function identity(){return Object.fromEntries(await Promise.all(runtimeFiles.map(async file=>[file,sha(await readFile(root+'/'+file))])));}
const initial=await identity(),records=[];
const xml=new XMLParser({preserveOrder:true,ignoreAttributes:false,attributeNamePrefix:'',trimValues:false,parseTagValue:false});
function painted(svg){const values=[];function walk(nodes,parent={}){for(const node of nodes??[]){const attributes={...parent,...node[':@']};if(node['#text']!==undefined){const text=String(node['#text']).replaceAll('\u00a0',' ');if(text.includes('Foreign Alpha')||text.includes('Foreign Beta'))values.push({text,fontSize:Number.parseFloat(attributes['font-size']),fontFamily:attributes['font-family'],x:attributes.x,y:attributes.y,trace:Object.fromEntries(Object.entries(attributes).filter(([key])=>key.startsWith('data-opf-')))});}for(const[key,value]of Object.entries(node))if(key!==':@'&&key!=='#text'&&Array.isArray(value))walk(value,attributes);}}walk(xml.parse(svg));return values;}
for(const[scenario,input]of [['default',original],['larger',larger]])for(const[phase,importer]of [['before',beforeImport],['after',afterImport]]){
  const name=scenario+'-'+phase,diagnostics=[],document=await importer(input,{onDiagnostic:item=>diagnostics.push(item)});
  assert.equal(document.slides[2].blocks?.[0]?.type,'text','Genuine body under default import; no inferHeadings override');
  const svg=toSvg(document,3,{fonts,catalogs:[gallery],trace:true});assert.equal(typeof svg,'string');const png=await toPng(svg,{fonts}),actual=painted(svg);
  for(const[file,bytes]of [[name+'.opf.json',JSON.stringify(document,null,2)+'\n'],[name+'.svg',svg],[name+'.png',png]])await writeFile(out+'/'+file,bytes);
  const alpha=actual.find(run=>run.text.includes('Foreign Alpha')),beta=actual.find(run=>run.text.includes('Foreign Beta'));
  assert.ok(alpha&&beta,'Both visible fragments exist');
  records.push({name,scenario,phase,selectedSourceSlide:3,inputSHA256:sha(input),svgSHA256:sha(svg),pngSHA256:sha(png),sourceSlide:document.slides[2],actual,diagnostics});
}
const final=await identity();assert.deepEqual(final,initial,'Runtime bytes remain unchanged throughout observation');
const expected={'default-before':[32,16],'default-after':[32,16],'larger-before':[48,32],'larger-after':[26.4,17.6]};
const comparisons=records.map(item=>{const actual=item.actual.map(run=>run.fontSize),wanted=expected[item.name];return{name:item.name,actual,expected:wanted,matchesObservedContract:actual.length===wanted.length&&actual.every((size,index)=>Math.abs(size-wanted[index])<1e-9)};});
const receipt={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),node:process.version,fontLoading:{api:'loadFonts({pack:office})',policy:'Default metric substitutions, pinned bundled open fonts; no system/Office fonts or network'},substitutions:fonts.substitutions,runtime:initial,inputChanges:{default:'Exact original input retained',larger:'Only two authored run/default point attributes36/24 and native textboxy3in to preserve body role; all other parts exact; no import flags, compositionminimum/cap/box override'},records,comparisons,originalQA02:{exitCode:1,literalPhysicalExpectation:[17.6,8.8],defaultActual:[32,16],remainsFailed:true,interpretation:'Existing rich-run16px floor raises all rich ratios. Requested OPF13.2/6.6pt and native physical/default painted claims differ; no core defect or native-fidelity acceptance.'},scope:'Actual default observations plus ONE separately approved larger foreign-body scenario. Additional control never substitutes for the original default observation. Portable pinned-font pixels only; no native Office acceptance.'};
await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));assert.ok(comparisons.every(item=>item.matchesObservedContract),'Actual observations match separately stated contracts');

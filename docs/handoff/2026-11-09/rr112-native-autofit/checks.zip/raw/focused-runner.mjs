import {spawnSync,execFileSync} from 'node:child_process';
import {mkdirSync,writeFileSync} from 'node:fs';
const root='C:/opf-work/fontscale',directory='C:/opf-work/fontscale-evidence-20261109-01';
const node='C:/Users/micha/AppData/Local/npm-cache/_npx/00a8f3ae68dc15e1/node_modules/node/bin/node.exe';
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const entries=[['before-final','packages/pptx/test/rr-112-native-autofit.mjs',{OPF_TEST_PPTX_MODULE:'file:///C:/opf-work/fontscale/artifacts/rr112-baseline-pptx/dist/index.js',OPF_AUTOFIT_ARTIFACTS:directory+'/before-final'}],...['import-signals','native-body-rich-text','native-body-inherited-style','list-inherited-runs','sh-05-powerpoint-shapes','styled-table-import'].map(id=>['focused-'+id,'packages/pptx/test/'+id+'.mjs',{OPF_NATIVE_BODY_ARTIFACTS:directory+'/focused-native-body-artifacts'}])];
const rows=[];
for(const[id,file,extra]of entries){const start=Date.now(),result=spawnSync(node,[file],{cwd:root,env:{...process.env,...extra},encoding:'utf8',maxBuffer:32*1024*1024});writeFileSync(directory+'/'+id+'.log',(result.stdout??'')+(result.stderr??''));const row={id,head,command:[node,file],env:extra,exitCode:result.status,signal:result.signal,elapsedMs:Date.now()-start,...(result.error?{error:String(result.error)}:{})};writeFileSync(directory+'/'+id+'.exit.json',JSON.stringify(row,null,2)+'\n');rows.push(row);console.log(JSON.stringify(row));}
writeFileSync(directory+'/focused-results.json',JSON.stringify({head,rows},null,2)+'\n');if(rows.slice(1).some(row=>row.exitCode!==0))process.exitCode=1;

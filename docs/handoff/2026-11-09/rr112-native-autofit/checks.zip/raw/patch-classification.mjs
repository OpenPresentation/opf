import {readFileSync,writeFileSync} from 'node:fs';
const root='C:/opf-work/fontscale/';function edit(file,before,after){const path=root+file,s=readFileSync(path,'utf8');if(s.split(before).length!==2)throw Error(`${file}: not one match`);writeFileSync(path,s.replace(before,after));}
edit('packages/pptx/src/body-text-import.js',"!languageOnly && current && tag !== 'a:br' ? scaledNativeRun", "!languageOnly && current && (tag !== 'a:br' || Number(properties.sz) > 0) ? scaledNativeRun");
edit('packages/pptx/src/import-signals.js',"tag === 'a:br' ? properties : scaledNativeRun(properties, fit)","tag === 'a:br' && !(Number(properties.sz) > 0) ? properties : scaledNativeRun(properties, fit)");
edit('packages/pptx/src/table-import.js',"tag === 'a:br' ? properties : scaledNativeRun(properties, fit, report)","tag === 'a:br' && !(Number(properties.sz) > 0) ? properties : scaledNativeRun(properties, fit, report)");
edit('packages/pptx/src/index.js',"    if (item && ordinaryBody) item.readNativeBody = () => readBody(index);",`    if (item && ordinaryBody) {
      const currentBody = readBody(index);
      item.readNativeBody = () => currentBody;
      // A saved scale also governs native heading/list size comparisons. Only
      // scaled bodies use resolved sizes here; ordinary classification is unchanged.
      if (currentBody?.some(paragraph => paragraph.nativeFontScale !== undefined)) {
        const pointSize = paragraph => Math.max(0, ...asArray(paragraph?.richText).filter(run => run && typeof run === 'object' && run.text?.trim()).map(run => run.fontSize ?? 0));
        item.paragraphs = item.paragraphs.map((paragraph, paragraphIndex) => ({...paragraph, maxFontSize: pointSize(currentBody[paragraphIndex])}));
        item.maxFontSize = Math.max(0, ...item.paragraphs.map(paragraph => paragraph.maxFontSize));
      }
    }`);
edit('packages/pptx/test/rr-112-native-autofit.mjs',"assert.ok(result.diagnostics.some(item=>item.code==='unsupported-body-inherited-style'));});\nawait check('wrong placeholder index", "assert.ok(!result.diagnostics.some(item=>item.code==='native-autofit-applied'));});\nawait check('wrong placeholder index");
edit('packages/pptx/test/rr-112-native-autofit.mjs',"{text:'Exact body ',fontSize:24},{text:'rich words',fontSize:12,bold:true}","{text:'Exact body ',fontSize:24,bold:false,italic:false,underline:false},{text:'rich words',fontSize:12,bold:true,italic:false,underline:false}");

import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='C:/opf-work/fontscale',out='C:/opf-work/fontscale-evidence-20261109-01/portable';
const require=createRequire(root+'/packages/pptx/package.json');const {XMLParser}=require('fast-xml-parser');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const {fromPptx:beforeImport}=await import('file:///C:/opf-work/fontscale/artifacts/rr112-baseline-pptx/dist/index.js');
const {fromPptx:afterImport}=await import('file:///C:/opf-work/fontscale/packages/pptx/dist/index.js');
const {loadFonts}=await import('file:///C:/opf-work/fontscale/packages/render/dist/fonts-node.js');
const {toSvg,toPng}=await import('file:///C:/opf-work/fontscale/packages/render/dist/index.js');
const {gallery}=await import('file:///C:/opf-work/fontscale/packages/gallery/dist/index.js');
await mkdir(out,{recursive:true});const input=await readFile('C:/opf-work/fontscale-evidence-20261109-01/after-05/foreign-scaled.pptx');
const fonts=await loadFonts({pack:'office'});
const runtimeFiles=['packages/pptx/dist/index.js','packages/pptx/dist/body-text-import.js','packages/pptx/dist/native-autofit.js','packages/pptx/dist/import-signals.js','packages/javascript/dist/composition.js','packages/render/dist/index.js'];
async function identity(){const pairs=await Promise.all(runtimeFiles.map(async file=>[file,sha(await readFile(root+'/'+file))]));return Object.fromEntries(pairs);}
const initial=await identity();const records=[];
const xml=new XMLParser({preserveOrder:true,ignoreAttributes:false,attributeNamePrefix:'',trimValues:false,parseTagValue:false});
function painted(svg){const values=[];function walk(nodes,parent={}){for(const node of nodes??[]){const attributes={...parent,...node[':@']};if(node['#text']!==undefined){const text=String(node['#text']).replaceAll('\u00a0',' ');if(text.includes('Foreign Alpha')||text.includes('Foreign Beta'))values.push({text,fontSize:Number.parseFloat(attributes['font-size']),fontFamily:attributes['font-family'],x:attributes.x,y:attributes.y});}for(const[key,value]of Object.entries(node))if(key!==':@'&&key!=='#text'&&Array.isArray(value))walk(value,attributes);}}walk(xml.parse(svg));return values;}
for(const[name,importer,expected]of [['before',beforeImport,[32,16]],['after',afterImport,[17.6,8.8]]]){
  const diagnostics=[],document=await importer(input,{onDiagnostic:item=>diagnostics.push(item)}),target={...document,slides:[document.slides[2]]};
  const svg=toSvg(target,{fonts,catalogs:[gallery]})[0],png=await toPng(svg,{fonts}),actual=painted(svg);
  const alpha=actual.find(run=>run.text.includes('Foreign Alpha')),beta=actual.find(run=>run.text.includes('Foreign Beta'));
  assert.ok(alpha&&beta,'Both actual visible rich fragments exist');assert.ok(Math.abs(alpha.fontSize-expected[0])<1e-9,JSON.stringify(alpha));assert.ok(Math.abs(beta.fontSize-expected[1])<1e-9,JSON.stringify(beta));
  for(const[file,bytes]of [[name+'.opf.json',JSON.stringify(document,null,2)+'\n'],[name+'.svg',svg],[name+'.png',png]])await writeFile(out+'/'+file,bytes);
  records.push({name,selectedSourceSlide:3,svgSHA256:sha(svg),pngSHA256:sha(png),actual,diagnostics});
}
const final=await identity();assert.deepEqual(final,initial,'No source-dist change during rendering');
const substitutions=typeof fonts.substitutions==='function'?fonts.substitutions():fonts.substitutions;
const receipt={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),node:process.version,inputSHA256:sha(input),fontLoading:{api:'loadFonts({pack:office})',policy:'Default metric substitutions; pinned bundled open fonts only; no system/Office fonts or network'},substitutions,runtime:initial,records,scope:'Actual imported OPF and pinned-font portable SVG/PNG. No native Office, cross-viewer or arbitrary-import layout acceptance.'};
await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));

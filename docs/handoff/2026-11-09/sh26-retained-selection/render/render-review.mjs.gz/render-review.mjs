import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {writeFileSync,readFileSync} from 'node:fs';
import {composeSlide} from '../../packages/javascript/dist/composition.js';
import {paginate} from '../../packages/javascript/dist/pagination.js';
import {layouts,sampleSlide} from '../../packages/javascript/test/support/template-samples.mjs';
import {toSvg,toPng} from '../../packages/render/dist/index.js';
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();assert.equal(head,'b487178e7d5425c3bb272a4b294dfea3ba15e7cc');
const files=[];const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const id of['inverted-pyramid','org-chart','hierarchy'])for(const count of[5,6]){
 const source=sampleSlide(layouts[id],count,'long');const deck={catalogs:{custom:{layouts:{[id]:layouts[id]}}},slides:[{layout:id,...source}]};
 const raw=composeSlide(source,{layout:layouts[id]});
 for(const mode of count===5?['raw-refused','first-default-page']:['raw-refused']){
  const document=mode==='raw-refused'?deck:paginate(deck).presentation;
  const svg=toSvg(document,1,{trace:true});assert.equal(typeof svg,'string');const png=await toPng(svg,{scale:.75});
  const name=`${id}-${count}-long-${mode}`;writeFileSync(new URL(`./${name}.svg`,import.meta.url),svg);writeFileSync(new URL(`./${name}.png`,import.meta.url),png);
  files.push({name,mode,sourceFontSizes:raw.items.filter(i=>i.text&&i.path.includes('.blocks.')).map(i=>i.text.fontSize),sourceDiagnostics:raw.diagnostics,svgSHA256:sha(svg),pngSHA256:sha(png),pngBytes:png.length});
 }
}
writeFileSync(new URL('./render-receipt.json',import.meta.url),JSON.stringify({source:head,compositionSourceSHA256:sha(readFileSync('packages/javascript/src/composition.ts')),compositionDistSHA256:sha(readFileSync('packages/javascript/dist/composition.js')),rendererDistSHA256:sha(readFileSync('packages/render/dist/index.js')),measurement:'Portable estimate; bundled base fonts; SVG and resvg raster, not native/PPTX',files},null,2)+'\n');console.log(JSON.stringify({source:head,captures:files.length,modes:files.map(f=>f.name)}));

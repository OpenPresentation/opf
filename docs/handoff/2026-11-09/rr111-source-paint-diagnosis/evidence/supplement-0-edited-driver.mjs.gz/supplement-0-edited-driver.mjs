import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root='C:/opf-work/rr111-paint',rawRoot='C:/opf-work/rr111-paint-diagnostic-01',output=process.argv[2];
assert.ok(output);await fs.mkdir(output,{recursive:false});
const require=createRequire(path.join(root,'packages/mcp/package.json')),importDependency=async name=>import(pathToFileURL(require.resolve(name)).href);
const {chromium}=require('playwright'),{Client}=await importDependency('@modelcontextprotocol/sdk/client/index.js'),{InMemoryTransport}=await importDependency('@modelcontextprotocol/sdk/inMemory.js');
const {createOpfServer}=await import(pathToFileURL(path.join(root,'packages/mcp/dist/index.js')).href),{installedFontFiles}=await import(pathToFileURL(path.join(root,'packages/mcp/dist/stdio.js')).href);
const hash=value=>createHash('sha256').update(value).digest('hex'),baseline=await fs.readFile(path.join(rawRoot,'baseline/deck-app.html')),candidate=await fs.readFile(path.join(rawRoot,'candidate/deck-app.html'));
assert.equal(hash(baseline),'9dd2198042e122c5a62aeea24615ab408cbaf9e940749cf70f344b524f86471e');assert.equal(hash(candidate),'10d6b3bcbc93e9590205b8363e6c0e427223d8cbe40032c8681c7f48d36741a0');
// Use the maintained host verbatim. No new permission, sandbox or download transport.
const maintained=await fs.readFile(path.join(root,'packages/mcp/test/deck-app-browser.mjs'),'utf8'),HOST=maintained.match(/const HOST_PAGE = `([\s\S]*?)`;/)[1];assert.ok(!HOST.includes('${'));
const VIEW_CSP="default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self' data:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'self'";
const listen=handler=>new Promise(resolve=>{const http=createServer(handler);http.listen(0,'127.0.0.1',()=>resolve(http));});
const hostHttp=await listen((_req,res)=>res.writeHead(200,{'content-type':'text/html; charset=utf-8'}).end(HOST)),viewHttp=await listen((req,res)=>res.writeHead(200,{'content-type':'text/html; charset=utf-8','content-security-policy':VIEW_CSP}).end(req.url==='/baseline'?baseline:candidate)),hostUrl=`http://127.0.0.1:${hostHttp.address().port}/`,viewBase=`http://localhost:${viewHttp.address().port}`;
const server=createOpfServer({version:'0.0.0-test',deckApp:{readFontFile:installedFontFiles()}}),client=new Client({name:'rr111-edited-both-observer',version:'1.0.0'}),[clientSide,serverSide]=InMemoryTransport.createLinkedPair();await server.connect(serverSide);await client.connect(clientSide);
const deck={name:'Download witness',language:'en-US',design:{fontScheme:'roboto'},slides:[{id:'current',title:'Current content',blocks:[{text:'Original body.'}]}]},expected=structuredClone(deck);expected.slides[0].blocks[0].text='The source body was edited and all of its words remain.';const expectedText=JSON.stringify(expected,null,2);
const result={startedUtc:new Date().toISOString(),scenario:'exact edited Both/accepted host/full source edit/rename/Download; original target screenshot before diagnostic layout reads',baselineSha256:hash(baseline),candidateSha256:hash(candidate),hostTemplateSha256:hash(HOST),csp:VIEW_CSP,sandbox:'allow-scripts allow-same-origin',viewport:{width:1000,height:700},iframe:{width:960,height:640},variants:[],noEarlierScreenshots:true,noEarlierDiagnosticLayoutReads:true,noForcedMeasurement:true,noArbitrarySleep:true,remoteMcpRpc:0,providerCalls:0,sourceChanges:false};let browser;
try{
 browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});result.browser=browser.version();
 for(const variant of ['baseline','candidate']){
  const context=await browser.newContext({viewport:{width:1000,height:700}}),page=await context.newPage(),errors=[],consoleEvents=[],denied=[],browserDownloads=[];
  page.on('pageerror',error=>errors.push(String(error)));page.on('console',message=>consoleEvents.push({type:message.type(),text:message.text()}));page.on('download',download=>browserDownloads.push(download.suggestedFilename()));
  await page.route(/^https?:/,route=>{const origin=new URL(route.request().url()).origin;if([new URL(hostUrl).origin,new URL(viewBase).origin].includes(origin))return route.continue();denied.push(route.request().url());return route.abort();});
  await page.exposeFunction('callServer',params=>client.callTool(params));await page.goto(hostUrl);
  const args={document:deck,view:'both'},toolResult=await client.callTool({name:'show_deck',arguments:args});
  await page.evaluate(setup=>{window.host={requests:[],context:[],messages:[],toolCalls:[],displayModes:[],downloads:[]};window.startView(setup);},{viewUrl:viewBase+'/'+variant,arguments:args,result:toolResult,theme:'light',downloadMode:'accepted'});
  await page.waitForFunction(()=>window.host.context.length>0,null,{timeout:60000});const frame=page.frame({url:new RegExp('/'+variant+'$')}),source=frame.locator('#deck-source .cm-content');
  await source.click();await source.press('ControlOrMeta+A');await page.keyboard.insertText(expectedText);
  await page.waitForFunction(body=>window.host.context.at(-1)?.structuredContent?.document?.slides?.[0]?.blocks?.[0]?.text===body,expected.slides[0].blocks[0].text,{timeout:15000});
  assert.deepEqual((await page.evaluate(()=>window.host)).context.at(-1).structuredContent.document,expected);assert.equal(await source.innerText(),expectedText);
  const painted=(await frame.locator('#deck-canvas').innerText()).split(/\r?\n/u).map(line=>line.trim()).filter(Boolean).join(' ');assert.equal(painted,expected.slides[0].title+' '+expected.slides[0].blocks[0].text);
  await frame.getByRole('button',{name:'Rename deck',exact:true}).click();const filename=frame.getByRole('textbox',{name:'File name',exact:true});await filename.fill('Q3#1 100%');await filename.press('Enter');
  // Exact maintained non-blocking probe. No diagnostic range/style/geometry read before original capture.
  await frame.evaluate(()=>{window.downloadProbe={blobs:0,anchors:0};const create=URL.createObjectURL.bind(URL);URL.createObjectURL=(...args)=>{window.downloadProbe.blobs++;return create(...args);};document.addEventListener('click',event=>{if(event.target.closest?.('a[download]'))window.downloadProbe.anchors++;},true);});
  await frame.getByRole('button',{name:'Download source',exact:true}).click();const probe=await frame.evaluate(()=>window.downloadProbe);
  if(variant==='candidate'){
   assert.deepEqual(probe,{blobs:0,anchors:0});assert.deepEqual(browserDownloads,[]);await page.waitForFunction(()=>window.host.downloads.length===1,null,{timeout:15000});
   assert.deepEqual((await page.evaluate(()=>window.host)).downloads,[{contents:[{type:'resource',resource:{uri:'file:///Q3%231-100%25.opf.json',mimeType:'application/json',text:expectedText}}]}]);assert.equal(await frame.locator('#deck-notice').isHidden(),true);
  }
  // Original maintained shoot point, before all supplemental CM/DOM/range/style/font observations.
  const screenshot=variant+'-original-capture.png';await page.locator('#view').screenshot({path:path.join(output,screenshot)});
  const snapshot=await frame.evaluate(()=>{
   const content=document.querySelector('#deck-source .cm-content'),source=document.querySelector('#deck-source'),view=content.cmTile?.root?.view,scroll=source.querySelector('.cm-scroller'),editor=source.querySelector('.cm-editor');
   const rect=value=>{const b=value.getBoundingClientRect();return{x:b.x,y:b.y,width:b.width,height:b.height};},style=value=>{const s=getComputedStyle(value);return Object.fromEntries(['display','visibility','opacity','color','backgroundColor','fontFamily','fontSize','fontWeight','fontStyle','lineHeight','letterSpacing','whiteSpace','textIndent','transform','clipPath','contain','contentVisibility','overflow','overflowX','overflowY','zIndex','paddingLeft','paddingRight'].map(k=>[k,s[k]]));};
   const ranges=[],walker=document.createTreeWalker(content,NodeFilter.SHOW_TEXT);let node;while(node=walker.nextNode()){if(!node.textContent.trim())continue;const range=document.createRange();range.selectNodeContents(node);ranges.push({text:node.textContent,rect:rect(range),rects:[...range.getClientRects()].map(r=>({x:r.x,y:r.y,width:r.width,height:r.height})),style:style(node.parentElement)});}
   return{time:performance.now(),mode:document.getElementById('deck-view')?.dataset.mode,cm:{viewport:view.viewport,visibleRanges:view.visibleRanges,inView:view.inView,documentLength:view.state.doc.length,document:view.state.doc.toString(),measureScheduled:view.measureScheduled,updateState:view.updateState,contentHeight:view.contentHeight,defaultLineHeight:view.defaultLineHeight,documentTop:view.documentTop,scaleX:view.scaleX,scaleY:view.scaleY},boxes:{source:rect(source),editor:rect(editor),content:rect(content),scroll:rect(scroll),footer:rect(document.querySelector('.deck-foot')),canvas:rect(document.getElementById('deck-canvas'))},styles:{source:style(source),editor:style(editor),content:style(content),scroll:style(scroll)},viewport:{innerWidth,innerHeight,devicePixelRatio},scroll:{top:scroll.scrollTop,left:scroll.scrollLeft,clientWidth:scroll.clientWidth,clientHeight:scroll.clientHeight,scrollWidth:scroll.scrollWidth,scrollHeight:scroll.scrollHeight},documentFonts:{status:document.fonts.status,faces:[...document.fonts].map(face=>({family:face.family,weight:face.weight,style:face.style,status:face.status}))},lines:[...content.querySelectorAll('.cm-line')].map(line=>({text:line.textContent,rect:rect(line),style:style(line)})),ranges,textContent:content.textContent,innerText:content.innerText,notice:{hidden:document.getElementById('deck-notice').hidden,text:document.getElementById('deck-notice').textContent},probe:window.downloadProbe};
  });
  await fs.writeFile(path.join(output,variant+'-post-original-capture.json'),JSON.stringify(snapshot,null,2)+'\n');const host=await page.evaluate(()=>window.host);assert.equal(snapshot.cm.document,expectedText);assert.deepEqual(host.context.at(-1).structuredContent.document,expected);assert.deepEqual(denied,[]);
  result.variants.push({variant,screenshot,screenshotSha256:hash(await fs.readFile(path.join(output,screenshot))),probe,errors,consoleEvents,denied,browserDownloads,host,postCapture:{cm:snapshot.cm,boxes:snapshot.boxes,fonts:snapshot.documentFonts,lines:snapshot.lines.map(l=>l.text)}});await context.close();console.log(JSON.stringify({variant,captured:true,probe,hostDownloads:host.downloads.length,CM:snapshot.cm,errors,consoleEvents}));
 }
}finally{await browser?.close();await client.close();await server.close();await new Promise(resolve=>hostHttp.close(resolve));await new Promise(resolve=>viewHttp.close(resolve));result.finishedUtc=new Date().toISOString();result.ownedBrowserAndServersClosed=true;await fs.writeFile(path.join(output,'receipt.json'),JSON.stringify(result,null,2)+'\n');}
console.log(JSON.stringify({completed:true,variants:result.variants.map(v=>v.variant),browser:result.browser,noFurtherStageControls:true}));

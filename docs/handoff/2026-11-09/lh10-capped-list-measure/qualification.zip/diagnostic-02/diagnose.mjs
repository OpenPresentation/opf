import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {execFileSync} from 'node:child_process';import {createRequire} from 'node:module';
const root='C:/opf-work/integration-034',out='C:/opf-work/lh10-pyramid-diagnostic-02',sha=b=>createHash('sha256').update(b).digest('hex');
const git=(...a)=>execFileSync('git',a,{cwd:root,encoding:'utf8'}).trim();
const source=git('rev-parse','HEAD'),base='b8fdd1cb88273a4f9963c9c01b89fbf1d5d5cc1b';
const sourceTrees=Object.fromEntries(['packages/javascript/src','packages/render/src','packages/gallery/catalog'].map(p=>{const current=git('rev-parse','HEAD:'+p),old=git('rev-parse','401d9f9f03f7c293cdcee8e7d14ec7e5161bde63:'+p);assert.equal(current,old);return[p,current];}));
function inventory(){const files={};for(const pkg of ['javascript','render','gallery']){const dir=path.join(root,'packages',pkg,'dist');function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else files[path.relative(root,p).replaceAll('\\','/')]=sha(fs.readFileSync(p));}}walk(dir);}return files;}
const runtimeBefore=inventory();
const {paginate}=await import('file:///'+root+'/packages/javascript/dist/pagination.js');
const {toSvg,resolvePresentation}=await import('file:///'+root+'/packages/render/dist/index.js');
const metrics=JSON.parse(fs.readFileSync('C:/opf-work/golden2-review/docs/handoff/2026-11-09/golden2-review/complete/metrics.json','utf8'));
const recorded=metrics.cases.find(c=>c.id==='pyramid');assert.deepEqual(recorded.before.source,recorded.after.source);
const authored=structuredClone(recorded.after.source),authoredJSON=JSON.stringify(authored),expected=authored.slides[0].blocks.flatMap(b=>b.items);assert.equal(expected.length,35);
const paged=paginate(authored),presentation=paged.presentation;assert.equal(JSON.stringify(authored),authoredJSON);
const fixture=JSON.parse(fs.readFileSync(root+'/packages/render/test/golden/layout-templates-rr96-color-variants.json','utf8'));
const baseline=toSvg(presentation,{trace:true});assert.equal(baseline.length,4);
const guard=baseline.map((svg,i)=>{const key='paginated pyramid 5 long page '+(i+1),actual=sha(svg),tracked=fixture.entries[key].svg,review=recorded.after.pages[i].hashes.svg;return{key,actual,tracked,review,matches:actual===tracked&&actual===review};});
fs.writeFileSync(out+'/guard.json',JSON.stringify({source,base,sourceTrees,guard},null,2)+'\n');assert.ok(guard.every(g=>g.matches),'ALL baseline SVG hashes must match official fixture before trusting diagnostics');
fs.writeFileSync(out+'/authored.opf.json',JSON.stringify(authored,null,2)+'\n');fs.writeFileSync(out+'/paginated-baseline.json',JSON.stringify(paged,null,2)+'\n');
const variants=[['baseline',presentation],['auto',structuredClone(presentation)],['two-columns',structuredClone(presentation)]];
for(const [name,deck]of variants.slice(1))for(const slide of deck.slides.slice(1))for(const block of slide.blocks)block.columns=name==='auto'?'auto':2;
const {XMLParser}=createRequire(root+'/packages/pptx/package.json')('fast-xml-parser');
const parser=new XMLParser({preserveOrder:true,ignoreAttributes:false,attributeNamePrefix:'',parseTagValue:false,parseAttributeValue:false,trimValues:false});
const visibleRows=svg=>{
 const rows=[];
 function textValue(nodes,inherited){let text='';const fonts=[];for(const node of nodes){if(Object.hasOwn(node,'#text')){const value=String(node['#text']);text+=value;if(value.trim()){const size=Number(inherited['font-size']);assert.ok(Number.isFinite(size)&&size>0,'Every visible glyph has an inherited numeric font-size');fonts.push(size);}}for(const tag of Object.keys(node).filter(k=>k!==':@'&&k!=='#text')){const child=textValue(node[tag],{...inherited,...node[':@']});text+=child.text;fonts.push(...child.fonts);}}return{text,fonts};}
 function walk(nodes,inherited={}){for(const node of nodes)for(const tag of Object.keys(node).filter(k=>k!==':@'&&k!=='#text')){const attrs={...inherited,...node[':@']};if(tag==='text'){if(attrs['aria-hidden']==='true')continue;const path=attrs['data-opf-path'];if(!/\.items\.\d+(?:\.|$)/.test(path??''))continue;const row=textValue(node[tag],attrs);assert.ok(row.text.length>0);assert.ok(row.fonts.length>0);rows.push({path,text:row.text.replaceAll('\u00a0',' ').trim(),fonts:[...new Set(row.fonts)]});}else walk(node[tag],attrs);}}
 walk(parser.parse(svg));return rows;
};
const reports=[];
for(const [name,deck]of variants){
 assert.deepEqual(deck.slides.flatMap(s=>s.blocks.flatMap(b=>b.items)),expected);assert.deepEqual(deck.catalogs,presentation.catalogs);
 const svgs=name==='baseline'?baseline:toSvg(deck,{trace:true}),bound=resolvePresentation(deck),pages=[];
 for(let i=0;i<deck.slides.length;i++){
  assert.equal(deck.slides[i].layout,presentation.slides[i].layout);assert.deepEqual(deck.slides[i].composition,presentation.slides[i].composition);
  fs.writeFileSync(out+'/'+name+'-'+(i+1)+'.svg',svgs[i]);
  const geometry=bound.slides[i].geometry,body=geometry.items.filter(item=>['items','bullets'].includes(item.field));
  const items=body.map(item=>{const columns=item.listColumns??[],entries=columns.length?columns.flatMap(c=>c.text.listEntries):item.text.listEntries;
   assert.deepEqual(entries.map(e=>e.index),item.value.map((_,i)=>i));
   const fragments=entries.flatMap(e=>e.text.richLines.flatMap(l=>l.fragments));
   return{path:item.path,box:item.box,fontSize:item.text.fontSize,fonts:[...new Set(fragments.map(f=>f.fontSize))],columns:columns.map(c=>({start:c.start,end:c.end,box:c.box,fontSize:c.text.fontSize})),entryCount:entries.length,entryIndices:entries.map(e=>e.index),fitMaxCharacters:Math.max(...entries.flatMap(e=>e.text.lines.map(l=>l.trim().length))),height:item.text.height,overflow:item.text.overflow};});
  const visible=visibleRows(svgs[i]),lines=visible.map(r=>r.text);assert.ok(lines.length>0);assert.equal(new Set(visible.map(r=>r.path.replace(/\.text$/, ''))).size,items.reduce((n,b)=>n+b.entryCount,0),'Every body entry has visible text');
  pages.push({index:i,key:guard[i].key,svgSHA256:sha(svgs[i]),composition:geometry.composition,declaredComposition:deck.slides[i].composition,body:items,regions:geometry.regions,arrangements:geometry.arrangements?.map(a=>({kind:a.kind,path:a.path,design:a.design})),actualVisibleMaxCharacters:Math.max(...lines.map(l=>l.length)),actualVisibleLineCount:lines.length,visible,diagnostics:geometry.diagnostics,mappings:paged.pages[i].mappings});
  fs.writeFileSync(out+'/'+name+'-'+(i+1)+'.svg',svgs[i]);
 }
 reports.push({name,fullItemCount:expected.length,fullItemsInOrder:JSON.stringify(deck.slides.flatMap(s=>s.blocks.flatMap(b=>b.items)))===JSON.stringify(expected),mappingCoverageUnchanged:true,pages});fs.writeFileSync(out+'/'+name+'.opf.json',JSON.stringify(deck,null,2)+'\n');
}
assert.deepEqual(inventory(),runtimeBefore,'Existing dist bytes did not change');
const result={source,base,sourceTrees,runtimeFiles:Object.keys(runtimeBefore).length,runtimeSHA256:sha(JSON.stringify(runtimeBefore)),sourceUnchanged:JSON.stringify(authored)===authoredJSON,guardPassed:true,guard,reports,limits:'Estimated official template fixture only; no runtime/source edit, raster golden update, native/rendered-physical acceptance, or implementation'};
fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n');fs.writeFileSync(out+'/runtime.json',JSON.stringify(runtimeBefore,null,2)+'\n');
console.log(JSON.stringify({guardPassed:true,source,runtimeFiles:result.runtimeFiles,cases:reports.map(r=>({name:r.name,pages:r.pages.map(p=>({index:p.index,max:p.actualVisibleMaxCharacters,returnedMax:p.composition.maxFontSize,fonts:p.body.map(b=>b.fonts),columns:p.body.map(b=>b.columns.length),fitFailures:p.diagnostics.filter(d=>['text-overflow','small-cell'].includes(d.code)).length})),items:r.fullItemCount,order:r.fullItemsInOrder,mappings:r.mappingCoverageUnchanged}))},null,2));

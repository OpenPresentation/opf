import fs from 'node:fs';import assert from 'node:assert/strict';import {createRequire} from 'node:module';import {createHash} from 'node:crypto';
const out='C:/opf-work/lh10-source-evidence-01/representative',sharp=createRequire('C:/opf-work/lh10-measure/packages/render/package.json')('sharp'),sha=b=>createHash('sha256').update(b).digest('hex');
const groups=s=>s.match(/<g\b[^>]*data-opf-path="slides\.1\.title"[\s\S]*?<\/g>/g);
const before=groups(fs.readFileSync(out+'/before-2.svg','utf8')),after=groups(fs.readFileSync(out+'/after-2.svg','utf8'));assert.equal(before.length,2);assert.deepEqual(before,after);
const top=async file=>sharp(fs.readFileSync(out+'/'+file)).ensureAlpha().extract({left:0,top:0,width:1280,height:190}).raw().toBuffer(),a=await top('before-2-full.png'),b=await top('after-2-full.png');assert.deepEqual(a,b);
const result={titleGroupsExact:true,titleGroupCount:2,titleGroupSHA256:sha(before.join('')),fullSizeHeadingRGBAExact:true,headingRegion:{x:0,y:0,width:1280,height:190,bytes:a.length,sha256:sha(a)},scope:'Offline exact source/pixel proof; display impressions do not override bytes'};
fs.writeFileSync(out+'/heading-proof.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));

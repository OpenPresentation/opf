import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {toSvg,toPng,resolvePresentation} from 'file:///C:/opf-work/sh27-rtl/packages/render/dist/index.js';
import {loadFonts} from 'file:///C:/opf-work/sh27-rtl/packages/render/dist/fonts-node.js';
import {gallery} from 'file:///C:/opf-work/sh27-rtl/packages/gallery/dist/index.js';
const root='C:/opf-work/sh27-rtl',out='C:/opf-work/sh27-rtl-evidence-01/callout-preview';fs.mkdirSync(out);
const src='data:image/png;base64,'+fs.readFileSync(root+'/packages/pptx/test/fixtures/images/wide.png').toString('base64');
const source={name:'Signed image annotations',language:'en-US',design:{fontScheme:'roboto'},slides:[{title:'Edge notes',subtitle:'Labels keep their image anchor.',composition:{overflow:'error'},blocks:[{image:{src,alt:'Public synthetic wide image',callouts:[{text:'Left edge',x:-.15,y:.15,width:.5,height:.3},{text:'Above image',x:.45,y:-.12,width:.5,height:.25}]},placement:{edge:'right',size:.6,inset:true},fit:'contain'}]}]};
fs.writeFileSync(out+'/source.opf.json',JSON.stringify(source,null,2)+'\n',{flag:'wx'});
const fonts=await loadFonts(),options={fonts,catalogs:[gallery],trace:true},geometry=resolvePresentation(source,options).slides[0].geometry,image=geometry.items.find(i=>i.image).image;
assert.equal(geometry.diagnostics.some(d=>d.code==='text-overflow'),false);assert.ok(image.callouts[0].box.x<image.calloutFrame.x);assert.ok(image.callouts[1].box.y<image.calloutFrame.y);
for(const label of image.callouts){assert.ok(label.box.x>=0&&label.box.y>=0&&label.box.x+label.box.width<=1280&&label.box.y+label.box.height<=720);}
const svg=toSvg(source,1,options);fs.writeFileSync(out+'/slide.svg',svg,{flag:'wx'});const png=await toPng(svg,{fonts});fs.writeFileSync(out+'/slide.png',png,{flag:'wx'});
const hash=b=>createHash('sha256').update(b).digest('hex'),sourceFiles=['spec/schemas/opf.schema.json','packages/javascript/src/composition.ts','packages/javascript/src/overlay-shapes.ts','packages/javascript/src/schema-check.ts','packages/pptx/src/image-callout-provenance.js'];
const receipt={scope:'Representative SVG/PNG preview only; not native PowerPoint or authoritative goldens',gitHeadAtRender:execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),dirtyAtRender:execFileSync('git',['-C',root,'status','--porcelain'],{encoding:'utf8'}).trim()!=='',sourceFiles:sourceFiles.map(path=>({path,sha256:hash(fs.readFileSync(root+'/'+path))})),files:['source.opf.json','slide.svg','slide.png'].map(path=>{const b=fs.readFileSync(out+'/'+path);return{path,bytes:b.length,sha256:hash(b)}}),imageFrame:image.calloutFrame,callouts:image.callouts.map(c=>({text:c.text,box:c.box,fontSize:c.fit.fontSize,overflow:c.fit.overflow})),nativeAcceptance:false};fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));

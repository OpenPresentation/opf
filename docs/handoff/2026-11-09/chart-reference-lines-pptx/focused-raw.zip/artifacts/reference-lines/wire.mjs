import fs from'node:fs';const p='packages/pptx/src/index.js';let s=fs.readFileSync(p,'utf8');const replace=(a,b)=>{if(!s.includes(a))throw Error('missing '+a.slice(0,100));s=s.replace(a,b);};
replace("import {addChartMarks,applyStackValueDeletes,attachChartMarkTags,importChartMarks} from './chart-marks.js';","import {addChartMarks,applyStackValueDeletes,attachChartMarkTags,importChartMarks} from './chart-marks.js';\nimport {referenceChartTypes,applyReferenceSeries,readNativeReferences,addReferenceOverlays,attachReferenceTags,importReferenceOverlays,ordinaryMixedGroups} from './chart-references.js';");
replace('context.chartMarkTags = new Map();','context.chartMarkTags = new Map();\n  context.referenceTags = new Map();');
replace('const chartMarks=importChartMarks(shapes,relationships,entries);',`const chartMarks=importChartMarks(shapes,relationships,entries,diagnostic=>options.onDiagnostic?.({...diagnostic,path:\`slides.\${slideIndex}\`}));
  const referenceContext={scale:Math.min(dimensions.widthInches,dimensions.heightInches)*96/720,colors:readSlideTheme(slidePath,{part:p=>entries[p],relationships:p=>parseRelationships(entries,p)})};
  const referenceOverlays=importReferenceOverlays(shapes,asArray(tree?.['p:graphicFrame']),relationships,entries,{...referenceContext,report:diagnostic=>options.onDiagnostic?.({...diagnostic,path:\`slides.\${slideIndex}\`})});`);
replace("if (chartMarks.consumed.has(shape)) { roles.set(shapeKeys.get(shape), 'chart-mark'); continue; }","if (referenceOverlays.consumed.has(shape)) { roles.set(shapeKeys.get(shape), 'chart-mark'); continue; }\n    if (chartMarks.consumed.has(shape)) { roles.set(shapeKeys.get(shape), 'chart-mark'); continue; }");
replace('({datasets: options.dataProvenance?.datasets, markedCharts: chartMarks.charts, report:', '({datasets: options.dataProvenance?.datasets, markedCharts: chartMarks.charts, referenceContext, referenceOverlays: referenceOverlays.byPart, report:');
replace("const imported = chartExRelId\n      ?",`const referenceState={};
    const imported = chartExRelId
      ?`);
replace('{marked: data.markedCharts?.has(name) === true}', '{marked: data.markedCharts?.has(name) === true, referenceContext:data.referenceContext, referenceState}');
replace('chartEvidence(decodeText(entries[part])), {datasets:', 'chartEvidence(referenceState.xml??decodeText(entries[part])), {datasets:');
replace("const chart = restored?.type === 'combo' ? elideComboDefault(restored, data.datasets) : restored;",`let chart = restored?.type === 'combo' ? elideComboDefault(restored, data.datasets) : restored;
    const references=[...(referenceState.references??[]),...(data.referenceOverlays?.get(part)??[])].sort((a,b)=>a.index-b.index).map(({index:_index,...ref})=>ref);
    if(chart&&references.length)chart={...chart,referenceLines:references};`);
replace("{marked = false} = {}) {", "{marked = false,referenceContext,referenceState={}} = {}) {");
replace('const doc = parseRequiredXml(entries, relationship.path);\n  const plotArea = doc["c:chartSpace"]?.["c:chart"]?.["c:plotArea"];',`parseRequiredXml(entries, relationship.path);
  const refs=readNativeReferences(decodeText(entries[relationship.path]),{...referenceContext,report});
  Object.assign(referenceState,{xml:refs.xml,references:refs.references});
  const doc=refs.doc;
  const plotArea = doc["c:chartSpace"]?.["c:chart"]?.["c:plotArea"];`);
replace("const comboSeries = combo ? comboSeriesOf(combo) : undefined;\n  const chartNode = combo ? {node: combo.bar, type: 'combo'} : firstChartNode(plotArea);",`const mixed=combo?undefined:ordinaryMixedGroups(plotArea);
  const comboSeries = combo ? comboSeriesOf(combo) : mixed;
  const chartNode = combo ? {node: combo.bar, type: 'combo'} : mixed?{node:asArray(plotArea['c:barChart'])[0]??asArray(plotArea['c:areaChart'])[0]??asArray(plotArea['c:lineChart'])[0],type:'combo'}:firstChartNode(plotArea);
  if(mixed)report?.({option:'type',message:mixed.some(e=>e.area)?'Every current area/line group is retained as a combo chart; OPF combo cannot represent area series, so area series become columns. Current values, names and source order are retained; this changes the representation.':'All ordinary native groups are retained as a combo chart rather than selecting only the first group.'});`);
// Keep end-label ordinary patches from seeing helpers: helpers are appended after the ordinary style pass by own final patch.
replace("if (chartData.combo?.length && chartData.combo.length === chartData.series.length) {\n    slide.addChart(...comboChart(chartData, chartOptionsXml, {palette, chartOptions, labelColor, font: context.fonts.body, textSize}));\n    return;\n  }",`const referenceLines=layer?.references?.lines??[];
  const refInfo=referenceLines.length?{key:objectName,lines:referenceLines,primaryCount:chartData.series.length,color:labelColor,context:colorContext(context),textSize,hidden:[]}:undefined;
  if(refInfo)context.chartHeadings.get(objectName).references=refInfo;
  const comboArgs=chartData.combo?.length&&chartData.combo.length===chartData.series.length?comboChart(chartData,chartOptionsXml,{palette,chartOptions,labelColor,font:context.fonts.body,textSize}):undefined;
  const secondary=chartLayout?.secondaryValueAxis;
  if(comboArgs&&secondary)comboArgs[1].valAxes=[{valAxisMinVal:chartLayout.valueAxis.min,valAxisMaxVal:chartLayout.valueAxis.max,valAxisMajorUnit:chartLayout.valueAxis.majorUnit},{...comboArgs[1].valAxes?.[1],valAxisMinVal:secondary.min,valAxisMaxVal:secondary.max,valAxisMajorUnit:secondary.majorUnit}];
  if(referenceLines.some(l=>l.native)){
    const base=comboArgs?.[0]??[{type:chartData.type,data:chartData.series,options:{lineDataSymbol:chartOptionsXml.lineDataSymbol,barDir:chartData.barDir,barGrouping:chartData.barGrouping}}];
    slide.addChart(referenceChartTypes(base,chartData.series,referenceLines),comboArgs?.[1]??chartOptionsXml);
    addReferenceOverlays(slide,referenceLines,{key:objectName,tags:context.referenceTags,context:colorContext(context),color:labelColor,font:context.fonts.body,size:textSize/100});
    return;
  }
  if(comboArgs){slide.addChart(...comboArgs);addReferenceOverlays(slide,referenceLines,{key:objectName,tags:context.referenceTags,context:colorContext(context),color:labelColor,font:context.fonts.body,size:textSize/100});return;}`);
replace("if (marks) addChartMarks(slide, layer, 'over', marks);", "if (marks) addChartMarks(slide, layer, 'over', marks);\n  addReferenceOverlays(slide,referenceLines,{key:objectName,tags:context.referenceTags,context:colorContext(context),color:labelColor,font:context.fonts.body,size:textSize/100});");
replace('attachChartMarkTags(entries,context.chartMarkTags);','attachChartMarkTags(entries,context.chartMarkTags);\n  attachReferenceTags(entries,context.referenceTags);');
replace("  // opf-pptx#175: after every chart rewrite, each classic series",`  for(const [part,bytes]of Object.entries(entries)){
    if(!/^ppt\\/slides\\/slide\\d+\\.xml$/.test(part))continue;const rels=parseRelationships(entries,part);
    for(const [frame]of decodeText(bytes).matchAll(/<p:graphicFrame>[\\s\\S]*?<\\/p:graphicFrame>/g)){
      const name=/<p:cNvPr\\b[^>]*\\bname="([^"]+)"/.exec(frame)?.[1],info=context.chartHeadings.get(name)?.references;
      if(!info)continue;const id=/<c:chart\\b[^>]*\\br:id="([^"]+)"/.exec(frame)?.[1],p=rels.get(id)?.path;
      if(!p||!entries[p])throw Error('Generated reference chart is missing.');entries[p]=encodeText(applyReferenceSeries(decodeText(entries[p]),info));
    }
  }
  // opf-pptx#175: after every chart rewrite, each classic series`);
replace('datasets: context.datasets, parseRelationships, report: context.reportDiagnostic','datasets: context.datasets, parseRelationships, report: context.reportDiagnostic, chartXml: xml=>readNativeReferences(xml,{scale:Math.min(context.dimensions.widthInches,context.dimensions.heightInches)*96/720}).xml');
fs.writeFileSync(p,s);
const q='packages/pptx/src/chart-marks.js';let t=fs.readFileSync(q,'utf8').replace("import {chartBandColor} from '@openpresentation/opf/composition';\n",'');t=t.replace("    for (const band of layer.references?.bands ?? []) rect(band.box, 'band', chartBandColor(paint.surface, `#${paint.text}`));\n",'');t=t.replace(/  for \(const entry of layer\.references\?\.lines \?\? \[\]\) \{[\s\S]*?\n  \}\n/,'');t=t.replace('export function importChartMarks(shapes, relationships, entries) {','export function importChartMarks(shapes, relationships, entries, report) {');t=t.replace('            consumed.add(shape);',`            if(['reference','reference-label','band'].includes(record.role)){report?.({code:'legacy-chart-reference-overlay',message:'A legacy inferred chart reference/band remains visible ordinary content; no explicit reference value is inferred from its title or old tag.'});continue;}
            consumed.add(shape);`);fs.writeFileSync(q,t);
const d='packages/pptx/src/data-provenance.js';let u=fs.readFileSync(d,'utf8').replace('datasets, parseRelationships, report}) {','datasets, parseRelationships, report, chartXml=xml=>xml}) {').replace('chartEvidence(dec.decode(entries[part]))','chartEvidence(chartXml(dec.decode(entries[part])))');fs.writeFileSync(d,u);

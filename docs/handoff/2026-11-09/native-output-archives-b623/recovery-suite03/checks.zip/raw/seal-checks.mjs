import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { crc32, deflateRawSync, inflateRawSync } from 'node:zlib';
const packet='docs/handoff/2026-11-09/native-output-archives-b623/recovery-suite03/';
const sources=[['artifacts/native-recovery-archive-checks','raw'],['artifacts/check-changed','selection']];
const files=sources.flatMap(([root,prefix])=>readdirSync(root,{withFileTypes:true}).filter(f=>f.isFile()).map(f=>({file:`${prefix}/${f.name}`,source:path.join(root,f.name)}))).sort((a,b)=>Buffer.compare(Buffer.from(a.file),Buffer.from(b.file)));
const sha=data=>createHash('sha256').update(data).digest('hex');
let offset=0;const locals=[],central=[],inventory=[];
for(const file of files){
 const data=readFileSync(file.source),compressed=deflateRawSync(data,{level:9}),name=Buffer.from(file.file),crc=crc32(data);
 assert.ok(data.length<16*1024*1024);assert.equal(crc32(inflateRawSync(compressed)),crc);assert.ok(inflateRawSync(compressed).equals(data));
 const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);local.writeUInt32LE(crc,14);local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(data.length,22);local.writeUInt16LE(name.length,26);locals.push(local,name,compressed);
 const entry=Buffer.alloc(46);entry.writeUInt32LE(0x02014b50);entry.writeUInt16LE(0x0314,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);entry.writeUInt16LE(8,10);entry.writeUInt16LE(33,14);entry.writeUInt32LE(crc,16);entry.writeUInt32LE(compressed.length,20);entry.writeUInt32LE(data.length,24);entry.writeUInt16LE(name.length,28);entry.writeUInt32LE((0o100644<<16)>>>0,38);entry.writeUInt32LE(offset,42);central.push(entry,name);offset+=local.length+name.length+compressed.length;
 inventory.push({file:file.file,bytes:data.length,sha256:sha(data)});
}
const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);const zip=Buffer.concat([...locals,directory,end]);
writeFileSync(packet+'checks.zip',zip,{flag:'wx'});writeFileSync(packet+'checks.files.json',JSON.stringify({file:'checks.zip',bytes:zip.length,sha256:sha(zip),members:inventory},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({result:'PASS',checkMembers:inventory.length,checkArchiveBytes:zip.length}));

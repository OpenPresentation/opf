import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { crc32, deflateRawSync, inflateRawSync } from 'node:zlib';
const packet='docs/handoff/2026-11-09/native-output-archives-b623/';
const sources=[['artifacts/native-output-archive-checks','raw'],['artifacts/check-changed','selection']];
const files=sources.flatMap(([root,prefix])=>readdirSync(root,{withFileTypes:true}).filter(f=>f.isFile()).map(f=>({file:`${prefix}/${f.name}`,source:path.join(root,f.name)}))).sort((a,b)=>Buffer.compare(Buffer.from(a.file),Buffer.from(b.file)));
const sha=data=>createHash('sha256').update(data).digest('hex');
let offset=0;const locals=[],central=[],inventory=[];
for(const file of files){
 const data=readFileSync(file.source),compressed=deflateRawSync(data,{level:9}),name=Buffer.from(file.file),crc=crc32(data);
 assert.ok(data.length<16*1024*1024);assert.equal(crc32(inflateRawSync(compressed)),crc);assert.ok(inflateRawSync(compressed).equals(data));
 const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);local.writeUInt32LE(crc,14);local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(data.length,22);local.writeUInt16LE(name.length,26);locals.push(local,name,compressed);
 const entry=Buffer.alloc(46);entry.writeUInt32LE(0x02014b50);entry.writeUInt16LE(0x0314,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);entry.writeUInt16LE(8,10);entry.writeUInt16LE(33,14);entry.writeUInt32LE(crc,16);entry.writeUInt32LE(compressed.length,20);entry.writeUInt32LE(data.length,24);entry.writeUInt16LE(name.length,28);entry.writeUInt32LE((0o100644<<16)>>>0,38);entry.writeUInt32LE(offset,42);central.push(entry,name);offset+=local.length+name.length+compressed.length;
 inventory.push({file:file.file,bytes:data.length,sha256:sha(data)});
}
const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);const zip=Buffer.concat([...locals,directory,end]);
writeFileSync(packet+'checks.zip',zip,{flag:'wx'});writeFileSync(packet+'checks.files.json',JSON.stringify({file:'checks.zip',bytes:zip.length,sha256:sha(zip),members:inventory},null,2)+'\n',{flag:'wx'});
const original=JSON.parse(readFileSync('artifacts/native-output-archive-checks/check-changed.exit.json','utf8'));
const recovery=JSON.parse(readFileSync('artifacts/native-output-archive-checks/only-failed-text.exit.json','utf8'));
assert.equal(original.exitCode,1);assert.equal(recovery.exitCode,0);
const receipt={publication:'PUBLIC-SAFE evidence-only NEVER MERGE; OPEN for separately authorized suite03 recovery append',producerSource:'b623a3674037f29d68496e96a3f5b6da55d73470',testedArchiveHead:'7860e66f6e304ba2d6aa4db89aa99f155c615dbb',node:'24.20.0',pnpm:'10.33.2',install:{command:'pnpm install --frozen-lockfile --offline --ignore-scripts',exitCode:0,scope:'own new archive checkout'},requiredCheck:{...original,aggregate:'RED retained',passed:['default package build 10.5s','Biome 1.1s','check:changes 0.7s','check:skill-commands 20.6s'],failed:'check:text: missing sparse painting-Linux.json.gz',typecheck:'SKIPPED: no TypeScript changes',totalSeconds:31.8},onlyFailedTextRecovery:{...recovery,tests:7,passed:7,scannedFiles:9060,restoredBytes:16102,restorationReceipt:'checks.zip:raw/restore-one-painting.json'},archives:{files:464,rawBytes:62403385,zipBytes:38757463,allMembersCRCAndSHA256:true,originalBytesAndMtimesUnchanged:true,independentDotNetReader:'PASS all464',pythonReader:'UNRUN: unavailable; original setup refusal preserved',dotNetOriginalAdapterRefusal:'signed Int32 external-attribute decoding; corrected with exact16-bit mask; no archive change'},corpusOrGenericPreparationRunsInThisTask:0,physicalOfficeRuns:0,providerCalls:0,deployments:0,releases:0,nativeAcceptance:false,suiteSealed:false,scope:'Archival integrity only. Normal metadata-driver package build is not independent corpus rebuilding or native qualification.'};
writeFileSync(packet+'receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
let readme=readFileSync(packet+'README.md','utf8');
readme+='\nRequired check at archive head7860e66f6: default package build, Biome, changelog and skill-command checks passed; typechecking skipped. The original aggregate remains RED solely because the sparse checkout omitted the historical painting-Linux.json.gz test input. Restoring only its exact HEAD/b623 blob (16,102 bytes, unchanged index) allowed ONLY the unchanged failed text check to pass7/7, scanning9,060 files. checks.zip retains all original and recovery logs/receipts. This is not a replacement aggregate-green claim. The .NET ZIP reader independently verified all464 members; its original signed-attribute adapter refusal and unavailable Python attempt remain explicit.\n\nThis evidence branch is OPEN only for the coordinator-authorized fresh suite03 recovery result. The three archives above and the original failed preparation remain unchanged. No suite03 outcome is claimed here.\n';
writeFileSync(packet+'README.md',readme);
console.log(JSON.stringify({result:'PASS',checkArchiveBytes:zip.length,checkMembers:inventory.length,metadataAggregate:'RED retained',onlyFailedTextRecovery:'7/7 PASS'}));

# OPF continuation — November 9 UTC / November 8 Pacific

This supersedes the immediate-state and observer wording in the November8 handoff. Preserve the full original scope in issue1139 and docs/handoff/2026-11-07:0.33 packages are published;0.34 is unpublished. No new package release occurred. Read working-rules.md and the outstanding native/owner boundaries before acting.

## Current release and site state

| Item | Observed state | Next action |
| --- | --- | --- |
| Org033 | Reviewed207 merged through exact required-all gate at9bbaa4d3ace64870d1f63939d6c643dfc88b1111. ActualNative42565659315 ran24public+22WorkerPASS on91569/treefa367; root8Windows cases and portrait/mobile visual review pass. | Production run42568982910 is RED: immutable ffda9b29 public suite21PASS/3navigation-or-reload test timeouts. Gate82313 is terminal1; NO active observer. Failed job129003971330 raw logSHAe96170b8d917bb8b7926a07c7f8e74897b2c86909a06be03c58e7b8cb719af85 and artifact13653440261 retained. Causal trace diagnosis next; no blind retry, timeout relaxation or production-adoption claim. |
| Gallery033 | Original172 public rollout remains verified. Maintenance176 at97f13/tree0bc has actualNative35/35PASS plus independent3maintained/7API/6UI/4captures; rootreceipt verification and visual review pass. Exact required-all gate91803 terminal0 merged atdff216ee548d7cf3db59ea54767525e4c3c72f3c,06:33:05Z; merge tree0bc188d8ba4edc9385dde6faac74d515641c98fd is exact. | ONE active default-production observer50037 follows exactdff216, interval180; log C:/opf-work/release-033-artifacts/gallery176-main-production-gate-01.log. No176production-completion claim. |
| DEV033 | Genuine200 remainsf18; bootstrap203 merged. Latest names-only preview metadata still has3names and lacks CONVEX_SERVICE_SECRET and AI_GATEWAY_API_KEY. No values read/copied or blind retry. | Exact previously held two-secret transfer owner decision, then native/auth/service qualification. Legacy pptx-dev-preview removal remains held until replacement/credential preservation; preserve shared R2 data. |

## Reviewed 0.34 repair assembly

Normal local assembly ef5405b3bbf9c47c8ae2e790e08aa72dcb18875f/treec51d176abbfc8786a79272b57c030f295d7c8bcf folds the five sources below. Runtime assembly is locally committed; required combined mapped checks/push are next. Never push any folded source branch again. No evidence-only branch was merged.

| PR | Frozen source | Actual component evidence |
| --- | --- | --- |
|1216 SH24 public catalog copy|237645bb0c22364af9060a01ff080b599f20a391|Only public inverted-pyramid description plus maintained content hashes; selected local checks pass. Original remote failures classified and retained; final generated fixtures/previews/archives still owed.|
|1217 thumbnail repairs|fc4f4380f36e77971a3666f629920e50fd99ea79|Unused render batch guard/full portrait containment; mapped8steps/146editor scripts and realbrowser24checks/12cache/7painted phases pass. Actualremote fails stale36menu and startup budget; source follow-ups below address them.|
|1218 SH20 parser portability|ca5ef93b857611922d9d75e4733dd99e98232c03|One module-relative dependency expression; real baseline fail/candidate pass; original14CLI+7direct guard controls and mapped67.1s pass. No Office/domain change; cross-platform final gate owed.|
|1219 catalog consumer contracts|261024588590c1ec9b787af4b9fb420445b603a1|Exact matching-installed-gallery records/order/unique IDs;238CLI Node tests/94command/82drawing and18actualmenu sections pass. Composed coverage retains original row/sparse-input reds; corrected metadata checks pass.|
|1221 startup font analysis|418239bfd5446440813edaa9ca7e9c3ca4ef2e24|Only per-view successful face-selection cache. Actual public work1298→3; unchanged benchmark completePASS1570<3200sample,4311<6400large;10SVG+4PNGexact.147decks/1020faces and lazy/script controls pass. Protected Venn key lock/107unrun broad scripts and original mapped red remain explicit.|

assembly.json and verify-assembly.mjs bind all five ancestors/18package-or-tool paths, unchanged Chart/spec/PPTX/CI/locks and exact source owners. The separate84641 audit covers only its earlier four-source stage. Tracking-only Shapes merge conflict retained the SH24 line and both SH20 progress lines. Source identity is not final combined acceptance.

## MCP source download follow-up

Confirmed RR111 issue1220 / draftPR1222 at1036e3e819257879d573772a9994c9142248ab07 is independently APPROVED for adapter scope but NOT folded yet. The public source.onDownload adapter uses the installed standard host download capability, preserves current source/MIME/encoded filename and rejects unsupported/denied/errors without iframe fallback or sandbox/CSP change. Actual browser12/12, app/globaltypes and MCP55pass/1optionalfontskip; strict gallery-tracker freshness remainsRED after adding the row. No unrelated tracker regeneration or warn override. Initial wrong public-option candidate failure remains retained. This fix belongs to0.34; no third release or0.33hotpatch.

The previously reported partial-Source image is NOT a demonstrated product defect. Conflicting visual/filename/A-B interpretations are explicitly retracted. Root and independent reviewers decode all four original/control PNGs: first12Source-row RGB bytes are identical SHA85b645d8ba5d283ef9239b5b5e8b345803d8a97980e55f21f2330250d76c202d with positive glyph ink; both matched A-B whole PNGs are identical SHAda12a6f3ba1db50d8e0e042189cc60e5d7cbcc4291aa2b87cf699f77c8fccfa9. No paint workaround selected. Corrected evidence-only dbf3bebf2f871d25be71dfa4ed9604838bd1c944 is PUSHED at codex/rr-111-source-paint-diagnosis, NEVERMERGE. Its independent built-in Node PNG verifier passes85 raw artifacts; root and peer verification pass. Original unsupported-download refusal and actual candidate host RPC remain retained. No actual Claude-host save or general visual acceptance claim.

## Evidence branches — NEVER MERGE

- Org local7case evidence:e81d94436ada770fac0f55048889cab02285d568.
- Org207 exact preview8cases/8traces/6screenshots/actual receipt:c52195fb8b491e20c14b26c1efebae93544876b1, private Data-Advantage/openpresentation-site branch codex/evidence-org207-preview-20261109; root offline verification passes.
- Org207 hosted viewer:2186e006900e0bb5c35a87791b109e624e816e89, private codex/evidence-org207-mcp-viewer-20261109. Actual protocol/resource/render/views/deck-name edit+undo pass5/12RPC; source download fails in strict sandbox; body/context/source equality passes before a soft-wrap-sensitive witness stops bodyUndo/Redo. No Claude connector/login or PDF/PPTX claim. RR111 fixes the concrete download integration separately.
- Gallery176:01cdc41d24a166a94208ed71341be9f3e41cf195, codex/evidence-gallery176-preview-20261109. Root verifies actual108303byte receipt SHA7758cb4b9e858da5b2586c28a6fe9763834c2ae18238c5c38257793cd8c7bc45. Extra exact-number probe remainsRED; one public baseline GET proves production/candidate examples byte-identical and65tiny source numeric differences inherited (max1.4210854715202004e-14). No tolerance/source change or metadata regression.

## Holds and full remaining scope

Chart representation approval remains PENDING. Newly assigned independent proposal agent inspected clean fresh main9545016583ccfa151077cda4d51043ac6505a140; full proposed fields/three JSON decks and independent native/import review are published at https://github.com/OpenPresentation/opf/issues/1139#issuecomment-6733705793. Proposed six types/value+secondary axes, native category-center spans and ordinary SLIDE overlays for bars/singletons (ownership tags do not bind transforms), optional endpoint labels/narrow stroke. Existing pinned native bounds/constant workbook-cell limitations, dot fallback bug, first-group import risk and indirect title-focus gutter movement are explicit. No chart tracked edits or implementation; automatic goal continuation is not agreement.

Fresh elevated GLOBAL Win32_Process inventory2026-11-09T06:31:23.1327146Z remainsPOWERPNT6584,count1,OfficeCalls0. No attach/kill/native retry. Original glyph05/06/09/10, A/B/C native inheritance and SH21live edit/save/reopen qualification remain open. All final goldens/review, archive causal promotion, strict trackers/budgets, full/default-main/cross-platform/slow/native, final Release dry+real/7registry identities/assets and all genuine034site/docs/examples/gallery/MCP/E3 gates remain open. Future site stages G1/H2/H3/I1 stay frozen for genuine034adoption; do not fake versions or reuse033receipts.

Owner-only: exact held credential transfer; chart agreement; D2; LibreOffice promotion; Claude connector and local.mcpb removal; new login/DNS/account-plan/repository-visibility actions. Later explicit deployment authorization remains valid. Preserve every original issue1139 requirement; no scoped remainder is silently closed.

## Current coordinator work

The preceding goal turn made progress: a fresh isolated chart proposal and independent native/import findings were published, changing the next implementation action to explicit owner design review. No chart code changed. Current independent tasks: causal production-trace diagnosis; RR111 original partial-paint A/B evidence sealing and separate adapter-scope acceptance review; root combined mapped validation of the five-source assembly. No production rerun or release is authorized by a successful local-only check.

Combined five-source mapped run86997 is confirmed live: root checks/typecheckPASS, core4237PASS/1inverted-pyramid composition-goldenFAIL, CLI238Node/94command/82drawingPASS315.3s and MCPPASS92.5s; remaining package steps still running. Do not fold source or commit while those tests read this checkout. Exact sourceef540 remains unchanged. Root's two exact missing historical XML fixtures were hydrated from HEAD without overwrite; no generated snapshot or tolerance was edited.

Actual Org production receipt13652254807/SHA4eab786f1dfba1bd74275cba7ade3ffa5f229e965fb877b4b0f94509ff1958f2 binds source9bbaa/treefa367/deploymente24ce5a8-e653-48bc-981f-fc4e77d87e7b/versionffda9b29-d6f7-4633-a567-3f487825d8fe. Original failed trace ZIP13653440261 is SHA87242dbe40cd9fd3df4c0779b6116952b03458b04144bc6ce6a505c6da7b3f61. Three late navigations have only4.27/4.40/2.80s left in their shared30s tests; final assertions remainUNRUN. Concrete inherited Next fingerprinted assets revalidate atmax-age0 instead of Next's immutable contract; a separate narrow two-prefix cache repair is in progress. No test timeout, assertion or product performance claim was changed.

Unified issue1139 current body was updated and exact returned body/31checkboxes verified. Every original requirement remains retained, with explicit CE20 startup and RR111 rows. Chart proposal6733705793 remains pending, not implicitly approved by this goal continuation.

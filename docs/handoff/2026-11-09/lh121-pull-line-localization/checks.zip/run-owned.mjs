import {openSync,closeSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const [prefix,cwd,command,...args]=process.argv.slice(2);
if(existsSync(prefix+'.log')||existsSync(prefix+'.exit.json'))throw Error('fresh output required');
const fd=openSync(prefix+'.log','wx'),start=new Date();const result=spawnSync(command,args,{cwd,env:{...process.env,npm_config_store_dir:'C:/opf-work/.pnpm-store',GIT_NO_LAZY_FETCH:'1'},stdio:['ignore',fd,fd],windowsHide:true});closeSync(fd);const receipt={command,args,cwd,started:start.toISOString(),finished:new Date().toISOString(),seconds:(Date.now()-start)/1000,exit:result.status,signal:result.signal,error:result.error?String(result.error):null};writeFileSync(prefix+'.exit.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));process.exit(result.status??1);

import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createRequire,registerHooks} from 'node:module';
import {readFileSync,writeFileSync,existsSync,mkdirSync,realpathSync} from 'node:fs';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
import {isDeepStrictEqual} from 'node:util';
const root='C:/opf-work/rr105-histneg',out='C:/opf-work/n034-hist-primary01',expectedHead='62e41b41451758458f532f06b0ca2085131de492';
const hash=b=>createHash('sha256').update(b).digest('hex'),git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
assert.equal(git('rev-parse','HEAD'),expectedHead);assert.equal(git('status','--porcelain'),'');assert.ok(!existsSync(out),'fresh output must not exist');
const inside=(base,file)=>{const rel=path.relative(base,file);return rel===''||!rel.startsWith('..')&&!path.isAbsolute(rel);};
assert.ok(inside('C:/opf-work',path.resolve(out))&&path.resolve(out)!==path.resolve(root));
const sourcePath='C:/opf-work/n034-suite03/sources/chart-histogram-category.opf.json',suitePath='C:/opf-work/n034-suite03/suite.json';
const sourceBytes=readFileSync(sourcePath),suiteBefore=readFileSync(suitePath),source=JSON.parse(sourceBytes),original=structuredClone(source);
assert.equal(hash(sourceBytes),'feacbc02309d0af1e0c9c9ddfc92465f1f6ac13e1359c0a4e4fb15bc5de70344');assert.equal(hash(suiteBefore),'fd13b7725ea3b76717ec6976c9e12a7f6df9db5135818120cc026fa54c9c5d65');
assert.deepEqual(source.design,{fontScheme:'roboto',dimensions:{widthInches:13.333333,heightInches:7.5}});
assert.deepEqual(source.slides[0].chart.data,{columns:['Region','Value'],rows:[['North',42],['South',31],['East',-8],['West',19]]});
assert.deepEqual(readFileSync(root+'/packages/pptx/src/index.js'),readFileSync(root+'/packages/pptx/dist/index.js'));
const req=createRequire(root+'/package.json'),edges=[];let phase='module-load';
const hook=registerHooks({resolve(specifier,context,nextResolve){const result=nextResolve(specifier,context);assert.ok(result.url.startsWith('file:')||result.url.startsWith('node:'),'no remote module');edges.push({phase,specifier,parentURL:context.parentURL??null,url:result.url,format:result.format??null});return result;}});
const bindings=[];async function load(name){const entry=req.resolve(name),manifest=req.resolve(name+'/package.json'),real=realpathSync(entry),pkg=JSON.parse(readFileSync(manifest));assert.ok(inside(root,real),name+' must bind owned source/dependencies');bindings.push({name,version:pkg.version,entry,realEntry:real,entrySha256:hash(readFileSync(real)),packageJson:realpathSync(manifest),packageJsonSha256:hash(readFileSync(manifest))});return import(pathToFileURL(entry).href);}
const core=await load('@openpresentation/opf'),pptx=await load('@openpresentation/opf-pptx'),galleryModule=await load('@openpresentation/gallery');
const gallery=galleryModule.gallery;assert.ok(gallery);const validation=core.validate(source,{catalogs:[gallery],only:['format','references']});assert.equal(validation.valid,true);
mkdirSync(out);const put=(name,bytes)=>writeFileSync(path.join(out,name),bytes,{flag:'wx'});put('source.opf.json',sourceBytes);put('producer.mjs',readFileSync(fileURLToPath(import.meta.url)));
let exportCalls=0,status='FAILED',error=null;const diagnostics=[],importDiagnostics=[];let result={};
try{
 phase='export';exportCalls++;const bytes=await pptx.toPptx(source,{catalogs:[gallery],chartex:'auto',provenance:'full',onDiagnostic:entry=>diagnostics.push(entry)});put('candidate.pptx',bytes);
 assert.deepEqual(source,original);assert.deepEqual(readFileSync(sourcePath),sourceBytes);assert.deepEqual(readFileSync(suitePath),suiteBefore);
 phase='audit';const peer=createRequire(req.resolve('@openpresentation/opf-pptx/package.json')),{unzipSync,strFromU8}=peer('fflate'),{XMLParser}=peer('fast-xml-parser');
 const parser=new XMLParser({ignoreAttributes:false,attributeNamePrefix:'@',parseTagValue:false}),array=v=>v===undefined?[]:Array.isArray(v)?v:[v],text=v=>typeof v==='string'?v:v?.['#text']??'';
 const parts=unzipSync(bytes);assert.deepEqual(Object.keys(parts).filter(p=>/^ppt\/charts\/chart(?:Ex)?\d+\.xml$/.test(p)),['ppt/charts/chart1.xml']);
 const chart=strFromU8(parts['ppt/charts/chart1.xml']);assert.match(chart,/<c:barDir val="col"\/>/);const points=kind=>{const block=chart.match(new RegExp('<c:'+kind+'[ >][\\s\\S]*?</c:'+kind+'>'))?.[0]??'';return [...block.matchAll(/<c:pt idx="(\d+)"><c:v>([^<]*)<\/c:v><\/c:pt>/g)].map(([,i,value])=>[Number(i),value]);};
 assert.deepEqual(points('cat'),original.slides[0].chart.data.rows.map(([label],i)=>[i,label]));assert.deepEqual(points('val'),original.slides[0].chart.data.rows.map(([,value],i)=>[i,String(value)]));
 const workbook=Object.keys(parts).filter(p=>/^ppt\/embeddings\/.*\.xlsx$/.test(p));assert.equal(workbook.length,1);const book=unzipSync(parts[workbook[0]]),xml=p=>strFromU8(book[p]);const strings=array(parser.parse(xml('xl/sharedStrings.xml')).sst.si).map(entry=>text(entry.t));const rows=array(parser.parse(xml('xl/worksheets/sheet1.xml')).worksheet.sheetData.row).map(row=>array(row.c).map(cell=>cell['@t']==='s'?strings[Number(cell.v)]:cell['@t']==='inlineStr'?text(cell.is.t):Number(cell.v)));assert.deepEqual(rows,[original.slides[0].chart.data.columns,...original.slides[0].chart.data.rows]);
 const slide=strFromU8(parts['ppt/slides/slide1.xml']);assert.equal([...slide.matchAll(/<p:graphicFrame>/g)].length,1);assert.doesNotMatch(slide,/AlternateContent|chartEx/);
 const notice=diagnostics.filter(d=>d.code==='chart-data-adapted');assert.equal(notice.length,1);assert.equal(notice[0].adaptation,'chartex-fallback');assert.match(notice[0].message,/categorical histogram.*negative/i);assert.doesNotMatch(notice[0].message,/pass chartex|does not write/);
 phase='import';const imported=await pptx.fromPptx(bytes,{catalogs:[gallery],onDiagnostic:entry=>importDiagnostics.push(entry)});put('imported.opf.json',JSON.stringify(imported,null,2)+'\n');assert.equal(imported.slides.length,1);const charts=[];function collect(v){if(Array.isArray(v))v.forEach(collect);else if(v&&typeof v==='object'){if(v.chart)charts.push(v.chart);for(const[k,item]of Object.entries(v))if(k!=='chart')collect(item);}}collect(imported);assert.equal(charts.length,1);assert.equal(charts[0].type,'column');assert.deepEqual(charts[0].data,original.slides[0].chart.data);assert.equal(imported.slides[0].shapes?.length??0,0);
 const adapted=structuredClone(original);adapted.slides[0].chart.type='column';
 result={candidateBytes:bytes.length,candidateSha256:hash(bytes),chartExParts:0,classicCharts:1,workbookRows:rows,importedCharts:1,importedType:'column',completeData:true,wholeDocumentDiffersOnlyByType:isDeepStrictEqual(imported,adapted),inputPreserved:true,previousPrimaryDiagnosticSha256:'1b9655431dc68021cfae788b33470293a827d59757d6f520d03653f00c7c048b',matchesEarlierPrimaryDiagnostic:hash(bytes)==='1b9655431dc68021cfae788b33470293a827d59757d6f520d03653f00c7c048b'};status='PASS';
}catch(e){error={name:e.name,message:e.message,stack:e.stack};}
finally{
 hook.deregister();const moduleFiles=[...new Set(edges.filter(e=>e.url.startsWith('file:')).map(e=>fileURLToPath(e.url)))].sort().map(file=>{const real=realpathSync(file);assert.ok(inside(root,real),'unexpected external module '+real);const b=readFileSync(real);return {resolved:file,realPath:real,bytes:b.length,sha256:hash(b),phases:[...new Set(edges.filter(e=>e.url.startsWith('file:')&&fileURLToPath(e.url)===file).map(e=>e.phase))]};});
 put('module-bindings.json',JSON.stringify({bindings,resolutionEdges:edges,moduleFiles},null,2)+'\n');put('diagnostics.json',JSON.stringify({export:diagnostics,import:importDiagnostics},null,2)+'\n');const receipt={status,error,sourceHead:git('rev-parse','HEAD'),sourceTree:git('rev-parse','HEAD^{tree}'),qualifiedSource:'7514fa6e45c02c8e40da213e12ee2199a56b61ce',runtimeSource:'6fc49797226d16d4b86e75f1b2efa6977f7f8aa7',runtimeSourceTree:git('rev-parse','HEAD:packages/pptx/src'),node:process.version,lockBlob:git('rev-parse','HEAD:pnpm-lock.yaml'),sourcePath,sourceSha256:hash(sourceBytes),sourceSha256After:hash(readFileSync(sourcePath)),suiteSha256Before:hash(suiteBefore),suiteSha256After:hash(readFileSync(suitePath)),options:{chartex:'auto',provenance:'full',catalog:'actual source-built @openpresentation/gallery; no font/seed/style overrides'},validation,exportCalls,newOfficeRuns:0,newRendererRuns:0,nativeAcceptance:false,releaseAcceptance:false,scope:'ONE exact primary source export. Earlier bare canonical b1d native witness does not qualify this differently authored source.',actualModuleFiles:moduleFiles.length,actualResolutionEdges:edges.length,...result};put('receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({status,exportCalls,candidateSha256:result.candidateSha256,candidateBytes:result.candidateBytes,actualModuleFiles:moduleFiles.length,actualResolutionEdges:edges.length,inputPreserved:result.inputPreserved,nativeAcceptance:false,error}));
}
if(status!=='PASS')process.exitCode=1;

import fs from 'node:fs';
import path from 'node:path';
import {spawnSync,execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='C:/opf-work/ce20-startup',output='C:/opf-work/ce20-startup-diagnostic-01/remaining-controls';
assert.ok(!fs.existsSync(output));fs.mkdirSync(output);
const steps=['lazy-fonts','lazy-faces','script-fonts','script-fonts-auto','script-fonts-auto-robust'].map(name=>({name,args:[`test/${name}.mjs`],cwd:path.join(root,'packages/render')}));
steps.push({name:'text-recovery',args:['C:/Users/micha/AppData/Local/npm-cache/_npx/00a8f3ae68dc15e1/node_modules/pnpm/bin/pnpm.cjs','run','check:text'],cwd:root});
const receipt={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),startedUtc:new Date().toISOString(),steps:[]};
for(const step of steps){const start=Date.now(),startedUtc=new Date().toISOString(),result=spawnSync(process.execPath,step.args,{cwd:step.cwd,encoding:'utf8',timeout:300000,windowsHide:true,maxBuffer:16*1024*1024});fs.writeFileSync(path.join(output,step.name+'.log'),(result.stdout??'')+(result.stderr??''));const entry={name:step.name,args:step.args,cwd:step.cwd,startedUtc,finishedUtc:new Date().toISOString(),milliseconds:Date.now()-start,status:result.status,signal:result.signal,error:result.error?.message};receipt.steps.push(entry);fs.writeFileSync(path.join(output,step.name+'.exit.json'),JSON.stringify(entry,null,2)+'\n');console.log(JSON.stringify({name:step.name,status:result.status,milliseconds:entry.milliseconds}));}
receipt.finishedUtc=new Date().toISOString();receipt.success=receipt.steps.every(step=>step.status===0);fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');if(!receipt.success)process.exitCode=1;

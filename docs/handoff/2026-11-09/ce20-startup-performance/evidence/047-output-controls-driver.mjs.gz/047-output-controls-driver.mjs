import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root='C:/opf-work/ce20-startup',editor=path.join(root,'packages/editor'),built=path.join(editor,'artifacts/playground'),output=process.argv[2];
assert.ok(output);await fs.mkdir(output,{recursive:false});
const require=createRequire(path.join(editor,'package.json')),{chromium}=require('playwright');
const hash=value=>createHash('sha256').update(value).digest('hex');
const before=gunzipSync(await fs.readFile('C:/opf-work/ce20-startup-diagnostic-01/baseline-playground.js.gz')),after=await fs.readFile(path.join(built,'playground.js'));
assert.equal(hash(before),'d1ed169145c8b1f78b7ed65f8063b380d543b61f0c85b3572559bf570f5ae9e5');assert.notEqual(hash(before),hash(after));
const {playgroundDeck}=await import(pathToFileURL(path.join(editor,'test/support/startup-decks.mjs')).href),sample=await playgroundDeck();
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.ttf':'font/ttf','.wasm':'application/wasm'};
const server=createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost');if(url.pathname==='/favicon.ico')return res.writeHead(204).end();const [,variant,...parts]=url.pathname.split('/');assert.ok(['before','after'].includes(variant));const route='/'+parts.join('/');let body;if(route==='/playground.js')body=variant==='before'?before:after;else{const file=path.resolve(built,'.'+decodeURIComponent(route)),relative=path.relative(built,file);assert.ok(!relative.startsWith('..')&&!path.isAbsolute(relative));body=await fs.readFile(file);}res.writeHead(200,{'Content-Type':types[path.extname(route)]??'application/octet-stream'}).end(body);}catch{res.writeHead(404).end();}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base=`http://127.0.0.1:${server.address().port}`;
const result={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),beforeBundleSha256:hash(before),afterBundleSha256:hash(after),ownedServer:base,startedUtc:new Date().toISOString(),browser:null,variants:[],success:false};let browser;
try{
  browser=await chromium.launch();result.browser=browser.version();
  for(const variant of ['before','after']){
    const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),errors=[],denied=[];
    page.on('pageerror',error=>errors.push(error.message));page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
    await page.route(/^https?:/,route=>{if(route.request().url().startsWith(base+'/'))return route.continue();denied.push(route.request().url());return route.abort();});
    await page.addInitScript(deck=>{window.OPF_EDITOR_HOST={persistence:false,document:deck,onReady:handles=>{window.__opf=handles;}};},sample);
    assert.equal((await page.goto(`${base}/${variant}/index.html`)).status(),200);await page.locator('#preview svg').first().waitFor({timeout:120000});await page.evaluate(async()=>{await window.__opf.editor.ready;await window.__opf.editor.whenIdle();await document.fonts.ready;});
    const thumbnails=await page.locator('.slide-card .thumbnail svg').evaluateAll(items=>items.map(item=>item.outerHTML));assert.equal(thumbnails.length,6);
    const canvases=[];
    for(const index of [0,1,4,5]){
      await page.evaluate(async value=>{window.__opf.editor.setSlide(value);await window.__opf.editor.whenIdle();await document.fonts.ready;},index);
      const svg=await page.locator('#preview svg').first().evaluate(node=>node.outerHTML),name=`${variant}-canvas-${index}.svg`;await fs.writeFile(path.join(output,name),svg);
      const png=await page.locator('#preview svg').first().screenshot({path:path.join(output,`${variant}-canvas-${index}.png`),animations:'disabled'});
      canvases.push({index,svgSha256:hash(svg),pngSha256:hash(png),svg});
    }
    await fs.writeFile(path.join(output,variant+'-thumbnails.json'),JSON.stringify(thumbnails)+'\n');
    result.variants.push({variant,errors,denied,thumbnails:thumbnails.map(hash),canvases});assert.deepEqual(errors,[]);assert.deepEqual(denied,[]);await context.close();
  }
  assert.deepEqual(result.variants[1].thumbnails,result.variants[0].thumbnails,'all six actual manager thumbnails remain exact');
  assert.deepEqual(result.variants[1].canvases,result.variants[0].canvases,'all four actual canvas SVG and PNG outputs remain exact');result.success=true;
}finally{await browser?.close();await new Promise(resolve=>server.close(resolve));result.serverStopped=true;result.finishedUtc=new Date().toISOString();for(const variant of result.variants)for(const canvas of variant.canvases)delete canvas.svg;await fs.writeFile(path.join(output,'receipt.json'),JSON.stringify(result,null,2)+'\n');}
console.log(JSON.stringify(result));

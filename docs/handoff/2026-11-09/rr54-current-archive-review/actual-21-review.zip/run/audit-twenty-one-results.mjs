import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const current='C:/opf-work/rr20-nine-current',baseline='C:/opf-work/rr20-nine-baseline';
const output='C:/opf-work/rr54-current-review-20261109-01',logs='C:/opf-work/rr54-current-review-logs-20261109-01';
const {unzipSync}=createRequire(path.join(current,'packages/pptx/package.json'))('fflate');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const git=(root,...args)=>execFileSync('git',args,{cwd:root,maxBuffer:16*1024*1024});
const read=file=>fs.readFileSync(file),json=file=>JSON.parse(read(file));
const fixturePath='packages/pptx/test/fixtures/rr-54-unchanged.json';
const fixtureBytes=read(path.join(current,fixturePath)),fixture=JSON.parse(fixtureBytes);
assert.equal(hash(fixtureBytes),'d62b991a3772856d812296cf12582be2ede6850e39d644d3414ab39a89a06e27');
assert.deepEqual(read(path.join(baseline,fixturePath)),fixtureBytes);
const review=json(path.join(output,'review.json')),candidate=json(path.join(output,'candidate-fixture.json'));
assert.equal(review.baselineHead,'c9732accd41cfffa27b8893251f33868c6b0514e');
assert.equal(review.baselineExportRef,review.baselineHead);
assert.equal(review.candidateHead,'5b9e4386c00319da1fa4370dcc0b3eb6e93c9578');
assert.deepEqual(review.entries.map(row=>row.name),Object.keys(fixture.entries));
assert.deepEqual(candidate.entries,fixture.entries);
const oldReviews=fixture.source.rr54ArchiveReviews??[];
assert.deepEqual(candidate.source.rr54ArchiveReviews.slice(0,-1),oldReviews);
assert.equal(candidate.source.rr54ArchiveReviews.length,oldReviews.length+1);
assert.deepEqual({...candidate.source,rr54ArchiveReviews:null},{...fixture.source,rr54ArchiveReviews:null});
const rows=[];let nativeCount=0,parts=0,workbooks=0,workbookParts=0;
for(const row of review.entries){
 const entry=fixture.entries[row.name];assert.equal(row.baseline,entry.sha256);assert.equal(row.candidate,row.baseline);
 assert.equal(row.baselineBytes,entry.rr20Bytes);assert.equal(row.candidateBytes,row.baselineBytes);
 assert.equal(row.baselineParts,entry.rr20PartCount);assert.equal(row.candidateParts,row.baselineParts);assert.deepEqual(row.changedParts,[]);
 if(entry.nativeSlideSha256){nativeCount++;assert.equal(row.candidateNativeSlideSha256,entry.nativeSlideSha256);}
 const publishedPath='docs/evidence/rr105-034-archive-review/twenty-one-complete/'+row.name+'.zip';
 const container=git(current,'show','5e89a184ffc8a38539f5fb5e573f403066bcca17:'+publishedPath);
 const previous=unzipSync(container);
 assert(previous['after.pptx'],'Published actual candidate retained: '+row.name);
 const bytes=Buffer.from(previous['after.pptx']);assert.equal(hash(bytes),row.candidate);assert.equal(bytes.length,row.candidateBytes);
 const contents=unzipSync(bytes),names=Object.keys(contents).sort();assert.equal(names.length,row.candidateParts);parts+=names.length;
 const embedded=[];
 for(const name of names.filter(name=>/\.xlsx$/.test(name))){
  workbooks++;const wb=unzipSync(contents[name]),files=Object.keys(wb).sort();workbookParts+=files.length;
  embedded.push({file:name,bytes:contents[name].length,sha256:hash(contents[name]),parts:files.map(file=>({file,bytes:wb[file].length,sha256:hash(wb[file])}))});
 }
 rows.push({...row,publishedControl:{commit:'5e89a184ffc8a38539f5fb5e573f403066bcca17',path:publishedPath,containerSha256:hash(container),inner:'after.pptx',sha256:hash(bytes)},unchangedOutputRetention:'Maintained reviewer stores no new unchanged archive; current reported SHA equals immutable exact control',parts:names.map(file=>({file,bytes:contents[file].length,sha256:hash(contents[file])})),embeddedWorkbooks:embedded});
}
const priorProvenancePath='C:/opf-work/rr20-nine-review-20261109-01/provenance.json';
const prior=json(priorProvenancePath);
const producerSeals=[];
for(const [root,record]of[[baseline,prior.baseline],[current,prior.candidate]]){
 assert.equal(git(root,'rev-parse','HEAD').toString().trim(),record.head);assert.equal(git(root,'status','--porcelain').toString().trim(),'');
 for(const item of record.dist){const file=path.join(root,item.file),bytes=read(file);assert.equal(bytes.length,item.bytes);assert.equal(hash(bytes),item.sha256);}
 producerSeals.push({root,head:record.head,distFiles:record.dist.length,distManifestSha256:hash(Buffer.from(JSON.stringify(record.dist,null,2)+'\n')),matchesPriorNineBuild:true,sourceClean:true});
}
for(const name of ['baseline-build.log','baseline-build.exit.json','current-build.log','current-build.exit.json']){
 fs.writeFileSync(path.join(logs,name),read('C:/opf-work/rr20-nine-review-logs-20261109-01/'+name),{flag:'wx'});
}
fs.writeFileSync(path.join(logs,'producer-provenance-from-nine.json'),read(priorProvenancePath),{flag:'wx'});
const result={
 format:1,scope:'Actual21-family maintained bare caller review; existing interleaved baseline/candidate order, no promotion or native application acceptance',
 baseline:review.baselineHead,candidate:review.candidateHead,baselineExportRef:review.baselineExportRef,fixtureSha256:hash(fixtureBytes),
 vetoableDecision:{id:'RR54-MAINTAINED-INTERLEAVE',choice:'Run unchanged maintained21 command once in its per-row interleaved order; all21 baseline checks required; no all-baselines-first claim',coordinatorApproved:true},
 node:'v24.20.0',pnpm:'10.33.2',platform:'win32',maintainedInvocations:1,baselineExports:21,candidateExports:21,changedArchives:0,
 baselineChecks:{fullArchiveSha256:21,bytes:21,partCount:21,applicableNativeSlideSha256:nativeCount},
 generatedNewPptxFiles:0,retention:'Tool does not save unchanged archives. Exact immutable5e89 control references retained; no further generation or exporter instrumentation.',
 reportSha256:hash(read(path.join(output,'review.json'))),unpromotedCandidateFixtureSha256:hash(read(path.join(output,'candidate-fixture.json'))),
 originalEntriesAndHistoriesUnchanged:true,newSourceReviewHistoryOnly:true,sourceFixturesUnchanged:true,
 producerSeals,publishedControlParts:parts,embeddedWorkbooks:workbooks,nestedWorkbookParts:workbookParts,
 rows,fixturePromoted:false,officeCalls:0,full280SuiteRun:false
};
assert.equal(rows.length,21);assert.equal(json(path.join(logs,'review.exit.json')).exitCode,0);
fs.writeFileSync(path.join(logs,'twenty-one-audit.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({actual21Review:'PASS',baseline:result.baseline,candidate:result.candidate,changedArchives:0,fullShaChecks:21,applicableNativeSlideChecks:nativeCount,sourceBuildsStillSealed:true,publishedControlParts:parts,embeddedWorkbooks:workbooks,nestedParts:workbookParts,newPptxRetained:0,unpromotedCandidateFixtureSha256:result.unpromotedCandidateFixtureSha256}));


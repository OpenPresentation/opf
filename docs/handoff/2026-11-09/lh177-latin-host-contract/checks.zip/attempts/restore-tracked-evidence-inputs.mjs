import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const [repoArg,outArg]=process.argv.slice(2);
if(!repoArg||!outArg)throw Error('Usage: restore-tracked-evidence-inputs.mjs <repo> <fresh-receipt>');
const repo=path.resolve(repoArg),out=path.resolve(outArg);
if(!repo.replaceAll('\\','/').toLowerCase().startsWith('c:/opf-work/'))throw Error('Expected an OPF worktree');
if(fs.existsSync(out))throw Error('Fresh receipt path required');
const git=(args,opts={})=>execFileSync('git',args,{cwd:repo,maxBuffer:32<<20,...opts});
const head=git(['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const tree=git(['ls-tree','-rlz',head,'--','docs/evidence']).toString().split('\0').filter(Boolean).map(line=>{
 const m=/^\d+ blob ([a-f0-9]+)\s+(\d+)\t([\s\S]+)$/.exec(line);
 if(!m)throw Error('Unexpected tracked tree record');
 const dest=path.resolve(repo,m[3]);if(!dest.startsWith(repo+path.sep))throw Error('Outside worktree');
 return {oid:m[1],bytes:Number(m[2]),file:m[3],dest};
});
const missing=tree.filter(r=>(/\.(json|md|txt)$/.test(r.file)||r.file==='docs/evidence/rich-input-and-platform-ci-20260915/painting-Linux.json.gz')&&!fs.existsSync(r.dest));
const total=missing.reduce((n,r)=>n+r.bytes,0);if(total>160*1024*1024)throw Error('160 MiB restoration bound exceeded');
if(missing.length){
 const bytes=git(['cat-file','--batch'],{input:missing.map(r=>r.oid).join('\n')+'\n',maxBuffer:180<<20});
 let cursor=0;
 for(const r of missing){
  const end=bytes.indexOf(10,cursor);if(end<0||bytes.subarray(cursor,end).toString()!==r.oid+' blob '+r.bytes)throw Error('Git batch header mismatch');
  cursor=end+1;const data=bytes.subarray(cursor,cursor+r.bytes);
  if(crypto.createHash('sha1').update('blob '+r.bytes+'\0').update(data).digest('hex')!==r.oid)throw Error('Git blob mismatch');
  fs.mkdirSync(path.dirname(r.dest),{recursive:true});fs.writeFileSync(r.dest,data);
  if(!fs.readFileSync(r.dest).equals(data))throw Error('Restored file differs');
  cursor+=r.bytes+1;
 }
 if(cursor!==bytes.length)throw Error('Trailing Git batch bytes');
}
if(git(['rev-parse','HEAD'],{encoding:'utf8'}).trim()!==head)throw Error('Worktree head moved during restoration');
fs.writeFileSync(out,JSON.stringify({scope:'Missing exact tracked sparse JSON/Markdown/text inputs and the named compressed text fixture only; no generated substitutes or index changes',head,count:missing.length,bytes:total,files:missing.map(({dest,...r})=>r)},null,2)+'\n');
console.log(JSON.stringify({head,count:missing.length,bytes:total,receipt:out}));

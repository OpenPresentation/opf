import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {loadFonts} from '../../packages/render/dist/fonts-node.js';
import {FONT_COMPATIBILITY} from '../../packages/render/dist/font-compatibility.js';
import {isSymbolEncodedFamily, symbolPreviewFaces, symbolEncodingFamily, SYMBOL_SCRIPT} from '../../packages/render/dist/symbol-fonts.js';
import {expectedFace, latinFamilies, STYLES, runFace} from '../../packages/render/test/latin-family-fixture.mjs';
const git=(...args)=>execFileSync('git',args,{encoding:'utf8',env:{...process.env,GIT_NO_LAZY_FETCH:'1'}}).trim();
const baseline='9545016583ccfa151077cda4d51043ac6505a140';
const current=git('rev-parse','HEAD');
const mainSource=git('show',`${baseline}:packages/render/src/font-registry.js`);
const functionText=mainSource.slice(mainSource.indexOf('export function pickFace('),mainSource.indexOf('export function createFontRegistry(')).replace('export function','function');
const baselinePick=new Function('FONT_COMPATIBILITY','isSymbolEncodedFamily','symbolPreviewFaces','symbolEncodingFamily','SYMBOL_SCRIPT',`${functionText}; return pickFace;`)(FONT_COMPATIBILITY,isSymbolEncodedFamily,symbolPreviewFaces,symbolEncodingFamily,SYMBOL_SCRIPT);
const policyAt=sha=>JSON.parse(git('show',`${sha}:spec/reference/font-policy.json`));
const policyRows=sha=>policyAt(sha).families.filter(row=>['Segoe UI Light','Segoe UI Semilight'].includes(row.family));
assert.deepEqual(policyRows(baseline),policyRows(current),'same independent named-family policy rows');
assert.equal(git('rev-parse',`${baseline}:packages/render/test/latin-family-fixture.mjs`),git('rev-parse',`${current}:packages/render/test/latin-family-fixture.mjs`),'fixture unchanged from main');
const {registry}=await loadFonts({pack:'office',substitutionPolicy:'visual'});
const observed=[];
for(const family of ['Segoe UI Light','Segoe UI Semilight']){
 const entry=latinFamilies().find(row=>row.family===family);
 for(const [weight,italic] of STYLES){
  const style={fontFamily:family,fontWeight:weight,italic};
  const baselineFace=baselinePick(entry.faces.map(face=>({...face,familyGroup:face.family})),family,style,{policy:'visual'}).face;
  const resolved=registry.resolveFont(style);
  const model=expectedFace(entry,weight,italic).face;
  observed.push({family,weight,italic,mainSelector:[baselineFace.weight,!!baselineFace.italic],integratedPublicRegistry:[resolved.resolvedWeight,!!resolved.italic],unchangedFixture:[model.weight,!!model.italic]});
 }
 const defaultResolved=registry.resolveFont({fontFamily:family});
 assert.equal(defaultResolved.resolvedWeight,300);
}
const explicitParent=registry.resolveFont({fontFamily:'Red Hat Display',fontWeight:700});
assert.equal(explicitParent.resolvedWeight,700,'explicit parent-family bold stays 700');
console.log(JSON.stringify({baseline,current,baselineSelectorSourceSha256:createHash('sha256').update(functionText).digest('hex'),authority:'LH-177 existing public registry/SVG test plus recorded native modest-emphasis decision; baseline selector uses actual main source with identical policy rows',observed,explicitParent:{family:explicitParent.resolvedFamily,weight:explicitParent.resolvedWeight}},null,2));

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
const out='artifacts/golden1-audit',sha=b=>createHash('sha256').update(b).digest('hex');
const manifestPath='C:/opf-work/golden034-review/docs/handoff/2026-11-09/golden-42587651918-review/pair-manifest.json';
const manifestBytes=fs.readFileSync(manifestPath);assert.equal(sha(manifestBytes),'d14ecc9928da91da5e7c64ab77e4a653e1b17aed4ed2914a8e8928308f59a857');
const manifest=JSON.parse(manifestBytes),pair=manifest.pairs[0];assert.equal(pair.key,'inverted-pyramid 1 long');
const cases=[['before','C:/opf-work/golden1-audit',pair.before.expected.svg],['after','C:/opf-work/sh26-tie',pair.after.expected.svg]];
const output=[];
for(const[phase,root,expected]of cases){
 const fixture=await import(pathToFileURL(path.join(root,'packages/render/test/layout-template-fixture.mjs')));const renderer=await import(pathToFileURL(path.join(root,'packages/render/dist/index.js')));
 const{deck,keys}=fixture.templateDeck('inverted-pyramid'),index=keys.indexOf(pair.key);assert.equal(index,6);
 const svg=renderer.toSvg(deck,index+1,{trace:true});assert.equal(typeof svg,'string');const actual=sha(svg);fs.writeFileSync(`${out}/${phase}.svg`,svg);
 output.push({phase,root,sourceHead:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),expected,actual,matched:expected===actual,svg,deck,index,renderer});
}
const hashes=output.map(({phase,root,sourceHead,expected,actual,matched})=>({phase,root,sourceHead,expected,actual,matched}));fs.writeFileSync(`${out}/hash-gate.json`,JSON.stringify({key:pair.key,manifestSHA256:sha(manifestBytes),hashes},null,2)+'\n');console.log(JSON.stringify({key:pair.key,hashes}));
assert.ok(hashes.every(h=>h.matched),'Stop before deriving font facts unless BOTH reconstructed SVGs match official hashes');
const facts=output.map(({phase,svg,deck,index,renderer})=>{const geometry=renderer.resolvePresentation(deck).slides[index].geometry;return{phase,body:geometry.items.filter(item=>item.path.includes('.blocks.')).map(item=>({path:item.path,box:item.box,frameBox:item.frameBox,fontSize:item.text?.fontSize,lineHeight:item.text?.lineHeight,lines:item.text?.richLines?.map(line=>line.fragments.map(f=>f.text).join('')),columns:item.listColumns?.map(column=>({box:column.box,fontSize:column.text.fontSize,lineHeight:column.text.lineHeight,entries:column.text.listEntries.map(e=>({value:e.value,fontSize:e.text.fontSize,lineHeight:e.text.lineHeight,richLines:e.text.richLines}))}))})),textNodes:[...svg.matchAll(/<text\b([^>]*)>([\s\S]*?)<\/text>/g)].map(m=>({attributes:m[1],content:m[2]})),diagnostics:geometry.diagnostics};});fs.writeFileSync(`${out}/font-geometry-facts.json`,JSON.stringify({key:pair.key,hashGatePassed:true,facts},null,2)+'\n');console.log(JSON.stringify({matched:true,body:facts.map(f=>({phase:f.phase,body:f.body.map(b=>({font:b.fontSize,box:b.box,columns:b.columns?.map(c=>({font:c.fontSize,box:c.box,entryFonts:[...new Set(c.entries.map(e=>e.fontSize))]}))})),svgTextNodes:f.textNodes.length}))}));

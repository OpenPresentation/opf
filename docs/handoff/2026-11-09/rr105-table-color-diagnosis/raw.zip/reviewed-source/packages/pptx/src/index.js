import {nativeBodyReader, joinNativeParagraphs} from './body-text-import.js';
import {addNativeBody, nativeBodyDefaults, nativeTitleAutofit, nativeTitleWrapBox, planNativeBody} from './native-body.js';
import {autoNumScheme, deriveListNumbering, withDisplayedNumbers} from './numbered-list.js';
import {isFaceStyleSuffix} from './font-weights.js';
import {importTableFrames} from './table-import.js';
import {applyChartFonts, applyPitchFamilies, finalizeFontsUsed, fontPitchFamilies} from './package-fonts.js';
import {officeSafeTypeface, safeMeasurement, sameMetrics, typefaceClasses, unsafeTypefacesIn, writeSafeTypefaces} from './safe-typefaces.js';
import {PICTURE_SCALE, defaultSlideRasterizer, pictureDeck} from './picture-slides.js';
import {giveNotesMastersOwnThemes, giveSlidesScriptMasters} from './master-themes.js';
import {legacyVendorOutput} from './vendor-compat.js';
import {readChartCategoryHeading,writeChartCategoryHeading,writeChartWorkbookFormats,repairChartWorkbookRanges} from './chart-workbook.js';
import {applyChartNumberFormats,chartNumber,groupsThousands,excelCode,formattedColumns,inlineChartData,inlineTableData,isDatasetRef,numericRanges,resolveChartData} from './chart-data.js';
import {attachDataProvenance,chartDataRecord,chartEvidence,readDataTag,readDatasetsTag,restoreChartData,restoreTableData,tableDataRecord,tableCellEvidence,tableEnvironmentEvidence} from './data-provenance.js';
import {CHARTEX_FALLBACK,resolveChartType,chartTypeFromNative,applyChartConstruct,comboFromNative,NATIVE_CHART_ELEMENTS} from './chart-types.js';
import {attachChartexParts,chartFromChartex,CHARTEX_GRAPHIC_DATA_URI} from './chartex.js';
import {applyDoughnutRings,applyRingLabels,chartDrawPlan,chartFallbackAdaptation} from './chart-fallback.js';
import {applyFrameAlt,readFrameAlt,writeFrameAlt} from './frame-alt.js';
import {applyDataLabels,chartOptionsFromClassic,chartTargetFor,classicChartOptions,reportChartOptionDiagnostics,resolveChartOptionsFor} from './chart-options.js';
import {applyChartLayerLayout,chartEmphasisPlan,chartFocusPlan,chartLayerOptions,withoutLayerDefaults} from './chart-layer.js';
import {applyEndLabels,applySliceLabels,directLabelDefaults} from './chart-direct-labels.js';
import {addChartMarks,applyStackValueDeletes,attachChartMarkTags,importChartMarks} from './chart-marks.js';
import {addSteps,attachStepTags,importStepShapes,restoreStepNumbers} from './step-badges.js';
import {addArrangements,attachArrangementTags,attachSmartArt,attachSmartArtFallbacks,exportPaint,importArrangementShapes,importSmartArt,importSmartArtFallbacks,smartArtBleed,smartArtRegionSvg,smartArtSlideSvg,writeArrangementAdjustments} from './smart-art.js';
import {importSmartArtShapes} from './smart-art-import.js';
import {addIcons,attachIconTags,importIconShapes,restoreIcons} from './icons.js';
import {addTitleRule,attachTitleRuleTags,importTitleRules} from './title-rule.js';
import {attachCodeTags, attachTextTags, codeManifest, importCodeGroups, nativeShapeParagraphs, nativeTextShapes} from './code-provenance.js';
import {attachMetricTags,metricManifest,importMetricGroups} from './metric-provenance.js';
import {attachCardTags,importCardFrames} from './card-provenance.js';
import {attachMediaTags,importMediaGroups,mediaCaption,mediaFrameRecord,mediaTextFingerprint} from './media-provenance.js';
// RR-34: captions and footnote areas as tagged text boxes; citation markers round-trip through the tags and the marker runs.
import {addCaption, addFootnotes} from './annotation-export.js';
import {attachAnnotationTags, captionValue, importAnnotations, restoreCitations} from './annotation-provenance.js';
import {attachHeadingTags,importHeadingGroups} from './heading-provenance.js';
import {cleanBase,headingValue,joinRichLines} from './rich-heading.js';
import {attachPlainTextTags,importPlainTextGroups} from './text-provenance.js';
import {attachNativeLanguageTags,nativeLanguageReadView,onlyNativeLanguageTags} from './native-language-provenance.js';
import {attachTimelineTags,timelineManifest,importTimelineGroups} from './timeline-provenance.js';
import {attachImageCalloutTags,importImageCallouts} from './image-callout-provenance.js';
import {attachQuoteTags,quoteManifest,importQuoteGroups,quotePhotoName} from './quote-provenance.js';
import {attachFurnitureTags, furnitureManifest, importFurniture, logoShape, staticDateFallback, stampFurnitureImageKeys} from './furniture-provenance.js';
import {restoreRunColors} from './run-colors.js';
import {importNativeShape, importNativeConnectors, loadShapeGeometry, nativeColorResolver, nativeShapeNames, readDrawnShapes, settleLayers, shapeRole, shapeText} from './shape-import.js';
import {assembleOverlayShapes, restoreShapes} from './shape-restore.js';
import {joinWrappedText} from './content-topology.js';
import {applyDocumentProvenance, attachDocumentProvenance, documentProvenance, recordContentTopology, recordListRuns, recordListScalars, recordOverlays, opfSlideOwnership, restoreDocumentProvenance, joinAuthors, splitAuthors, slideListRecord, storedMetadata, DEFAULT_AUTHOR, DEFAULT_TITLE} from './document-provenance.js';
import {INVALID_XML_CHARACTER, nativeSections, writeSectionList} from './sections.js';
import {DEFAULT_DATE_FORMAT, attachFurnitureFields, dateFormatOfField, furniturePartFields, isBareSlideNumber, lineFields, nativeDateField, nativeFieldType} from './furniture-fields.js';
import {attachNativePlaceholders, defaultPlaceholderGeometry, nativeDateText, nativeFurnitureParts, nativePlaceholderForPart, writeNativeMasters} from './native-furniture.js';
import {liftMasterFurniture} from './master-furniture.js';
import {gallery} from '@openpresentation/gallery';
import {applyTemplateLayouts, deckTemplates, foreignLayoutReference, placeholderRegion, readLayoutTag, slideTemplate, writeTemplateLayouts} from './template-layouts.js';
import {importImageOrientation} from './image-import.js';
import {extractSignals, normalizeSignalOptions, themeFactsFor} from './import-signals.js';
import {recordableImageSource, placeImages, pictureFrame, importImages, importImagePlaceholders, isImagePlaceholderGroup, samePictureAspect, imageName, imageOverlayName, imagePlaceholderGroupName, backgroundImageName, backgroundOverlayName, IMAGE_TREATMENT_KEYS, BACKGROUND_IMAGE_KEYS, IMAGE_PLACEHOLDER_TAG} from './image-provenance.js';
import {dedupeMedia, mediaKey} from './media-dedupe.js';
import {placeWatermarks, importWatermark, importTextWatermark, tagTextWatermarks, watermarkName, watermarkTextName, watermarkBox, watermarkOpacity} from './watermark-provenance.js';
import {placeLogos, importLogo, importLogoPlaceholders, logoName, LOGO_TAG} from './logo-provenance.js';
import {nativeBackgroundFill, nativeImageBackgroundFill, nativePatternPreset} from './background.js';
import {importBackground, readSlideTheme} from './background-import.js';
import {chartHighlightPlan, applyChartHighlight} from './chart-highlight.js';
import {orderChartSeries} from './chart-order.js';
import {lineXml, linkShapeBlocks, shapeBlockRecord, writeShapeBlocks} from './shape-blocks.js';
import {connectorName, connectorRecord, writeConnectors} from './connectors.js';
import {themeSlotColors, schemeColorTable, addTransformedColors, writeSchemeColors, authoredLiteralColors, writeThemeColors, schemeColorValue, schemeBackgroundFill, schemeBackgroundValue, defaultTextSchemeValues, tableTextSchemeValue, solidColorXml, writeMasterBackground, inheritLayoutBackground, readThemeSlotColors, recoverColorScheme, recoverTheme, presentationThemePath, variantFromColorMap} from './theme-colors.js';
import {languageDiagnostics, leftToRightPieces, observeLanguage, observedRtl, partScriptFonts, physicalAlignment, planScriptFonts, planSlideThemes, reconcileLanguage, reportPerSlideNotesScriptFonts, runLanguageFonts, runLanguageTag, stripRunScriptFonts, themeEastAsianFromLatin} from './script-fonts.js';
import { webpToPng, svgToPng, readLocalFile, localFileReadable } from '#image-fallback';
import { prepareSvg, svgDataUriBytes, svgRasterScale, svgBlipRelationship, attachSvgPictures } from './svg-image.js';
import { DIAGRAM_UNAVAILABLE, diagramName, diagramPlaceholderName, importDiagramGroups, importDiagrams, tagDiagrams } from './diagram-provenance.js';
import { DIAGRAM_BASELINE_SHARE, DIAGRAM_MIN_PITCH, diagramShapes, writeDiagramGroups } from './diagram-shapes.js';
import { chartPaletteSchemes, applyChartSchemeColors } from './chart-scheme-colors.js';
import { rasterMetadata, pictureTransform, normalizeImageOrientation } from './image-geometry.js';
import {
  CHART_BAR_GAP_WIDTH, catalogRecords, clrMapAttributes, DIAGRAM_SHAPE_FAMILIES, diagramPalette, ensureDiagrams, ensureIcons, ensureShapes, groupsAxisTicks, groupsDataRange, GROUPED_LABEL_CODE, paintDiagram, ENGINE_DEFAULT_COLOR_SCHEME, normalizeColorVariant, chartSchemeSeries, chartSlicePlan, CHART_SLICE_SEPARATOR_PX, chartPaletteForFill, chartSeriesLabelColor, chartSoftColors, chartSeriesPalette, chartLayerDataLabels, chartTextSize as coreChartTextSize, codeHighlightBands, codeHighlightColors, codeHighlightLines, codeSyntaxPaletteForRoles, readableSchemeColor, codeLineNumbers, codeLineRuns, codeSyntaxPaletteForScheme, composeSlide, emphasisSurface,
  ENGINE_DEFAULT_FONT_SCHEME, bindNoBreak, unbindNoBreak, defaultSlideBackground, fitImage, fitText, layoutTable, layoutWatermark, metricPillFill, metricTrendMark, metricValueColor, resolveCanvasDimensions, resolveColorRoles, resolveFontFamilies,
  LIST_RULE_WIDTH, LIST_ACCENT_RULE_WIDTH, quoteLanguage, resolveChartColors, resolveReference, resolveScriptFonts, resolveTextStyle, shapeTextColor, textColorForFill, textWidthMeasurer, timelineMarkerShapes, timelineTextColor, tokenizeCode, tableHighlightColor, chartWaterfallColors
} from "@openpresentation/opf/composition";
import { colorContext, resolveColorRefValue, resolveExportColor, resolveVariableColors } from "./color-ref.js";
import PptxGenJS from "../vendor/pptxgenjs/pptxgen.es.js";
import { unzipSync, zipSync } from "fflate";
import { XMLParser } from "fast-xml-parser";
import {
  hasContentVariables,
  isTemplate,
  OPFCatalogsOptionError,
  resolveSlideContext as resolveCoreSlideContext,
  resolveSlideVariables,
  resolveVariables,
  validate
} from "@openpresentation/opf";
import {checkFormat, isValidFormat} from "./format-check.js";
import {OPFPptxError} from './errors.js';
import {readInputZip} from './input-safety.js';
export {OPFPptxError} from './errors.js';

export {checkTypefaces, inventoryTypefaces, packageFontsUsed, THEME_SCRIPT_SUPPLEMENTS} from './typeface-inventory.js';
export {OFFICE_SAFE_TYPEFACES, officeSafeTypeface} from './safe-typefaces.js';

/**
 * LH-28: the Latin text typefaces a finished PPTX names that are not Office-safe (on every Windows and macOS machine and
 * measured exactly by OPF): a viewer without one substitutes another font and can break lines differently. Export with
 * `typefaces: 'safe'` to write their Office-safe equivalents instead.
 */
export function typefacesNotOfficeSafe(input) {
  return unsafeTypefacesIn(readInputZip(input));
}

// LH-20: draw each slide with `options.slideRasterizer` (default: opf-render's toPng, an optional peer) and export the picture
// deck: no layout, fonts or provenance of the source deck reach the file, only the pictures, their alt text and the notes.
async function pictureSlidesPptx(presentation, options) {
  const scale = options.scale ?? PICTURE_SCALE, rasterizer = options.slideRasterizer ?? defaultSlideRasterizer;
  let deck;
  try {
    deck = await pictureDeck(presentation, slide => rasterizer(presentation, slide, {scale, fonts: options.fonts, catalogs: options.catalogs, date: options.date, onDiagnostic: options.onDiagnostic}));
  } catch (error) {
    if (error instanceof OPFPptxError) throw error;
    const code = error?.code === 'slide-rasterizer-unavailable' ? 'slide-rasterizer-unavailable' : 'slide-render-failed';
    throw new OPFPptxError(code, code === 'slide-rasterizer-unavailable' ? errorMessage(error) : `A slide could not be drawn for the pictures-only PPTX: ${errorMessage(error)}`, {cause: errorMessage(error), ...(error?.path ? {path: error.path} : {})});
  }
  const {as, scale: _scale, slideRasterizer, typefaces, variables, svgRasters, ...rest} = options;
  return toPptx(deck, {...rest, provenance: false, bodyText: undefined});
}
export {DEFAULT_SIGNAL_LIMITS, SIGNALS_VERSION, isMonospaceFamily} from './import-signals.js';

export const packageName = "@openpresentation/opf-pptx";

export const releaseLane = Object.freeze({
  githubRepository: "OpenPresentation/opf",
  directory: "packages/pptx",
  npmPackage: "@openpresentation/opf-pptx",
  compatibilityPackage: "@openpresentation/opf",
  rendererPackage: "@openpresentation/opf-render"
});

export const runtimePolicy = Object.freeze({
  hostedServiceInCriticalPath: false,
  telemetry: false,
  commercialSdkInCriticalPath: false,
  requiredAiDependency: false,
  requiredLibreOfficeDependency: false,
  requiredNetworkCalls: false,
  deterministicLocalExecution: true
});

const FIXED_TIMESTAMP = "1980-01-01T00:00:00Z";
// fflate derives the DOS zip date from local-time fields, so build this from
// local components: a UTC instant rolls back to 1979 west of UTC (below
// fflate's 1980 floor) and would otherwise yield timezone-dependent bytes.
const FIXED_ZIP_DATE = new Date(1980, 0, 1, 0, 0, 0);
// Explicit stamps overwrite these fields after ZIP generation. Keep the
// temporary instant well inside fflate's range even if the host changes TZ.
const EXPLICIT_ZIP_SENTINEL = new Date('2000-01-01T12:00:00Z');
const DEFAULT_SEED = 0x4f504658;
const CANONICAL_SCHEMA = "https://openpresentation.org/schema/opf/v1";
const EMUS_PER_INCH = 914400;

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "",
  textNodeName: "#text",
  parseAttributeValue: false,
  parseTagValue: false,
  trimValues: false
});
// Keep numeric character references (notably CR) in native core text. This is
// scoped to properties; the ordinary slide/relationship parser is unchanged.
const coreTextParser = new XMLParser({
  ignoreAttributes: false, attributeNamePrefix: "", textNodeName: "#text",
  parseAttributeValue: false, parseTagValue: false, trimValues: false, htmlEntities: true
});

const ROOT_PAYLOAD_FIELDS = [
  "text",
  "items",
  "bullets",
  "image",
  "video",
  "chart",
  "table",
  "code",
  "metric",
  "quote",
  "timeline",
  "diagram"
];

const PROMOTED_REGION_KEYS = [
  "left",
  "center",
  "right",
  "left+center",
  "center+right",
  "left+center+right",
  "top",
  "middle",
  "bottom",
  "top+middle",
  "middle+bottom",
  "top+middle+bottom",
  "top:left",
  "top:center",
  "top:right",
  "top:left+center",
  "top:center+right",
  "top:left+center+right",
  "middle:left",
  "middle:center",
  "middle:right",
  "middle:left+center",
  "middle:center+right",
  "middle:left+center+right",
  "bottom:left",
  "bottom:center",
  "bottom:right",
  "bottom:left+center",
  "bottom:center+right",
  "bottom:left+center+right",
  "top+middle:left",
  "top+middle:center",
  "top+middle:right",
  "top+middle:left+center",
  "top+middle:center+right",
  "top+middle:left+center+right",
  "middle+bottom:left",
  "middle+bottom:center",
  "middle+bottom:right",
  "middle+bottom:left+center",
  "middle+bottom:center+right",
  "middle+bottom:left+center+right",
  "top+middle+bottom:left",
  "top+middle+bottom:center",
  "top+middle+bottom:right",
  "top+middle+bottom:left+center",
  "top+middle+bottom:center+right",
  "top+middle+bottom:left+center+right"
];

const DIMENSION_PRESETS = Object.freeze({
  widescreen: Object.freeze({ widthInches: 13.333333, heightInches: 7.5 }),
  "16:9": Object.freeze({ widthInches: 13.333333, heightInches: 7.5 }),
  standard: Object.freeze({ widthInches: 10, heightInches: 7.5 }),
  "4:3": Object.freeze({ widthInches: 10, heightInches: 7.5 }),
  "16:10": Object.freeze({ widthInches: 10, heightInches: 6.25 }),
  letter: Object.freeze({ widthInches: 11, heightInches: 8.5 }),
  "1:1": Object.freeze({ widthInches: 7.5, heightInches: 7.5 }),
  "4:5": Object.freeze({ widthInches: 7.5, heightInches: 9.375 }),
  "9:16": Object.freeze({ widthInches: 7.5, heightInches: 40 / 3 }),
  a4: Object.freeze({ widthInches: 11.69, heightInches: 8.27 })
});

// The `catalogs` option is core's registered catalogs (`Catalog[]`). A value that is no array is core's
// OPFCatalogsOptionError (code `invalid-catalogs`) up front; core checks each entry where it resolves a reference.
function checkCatalogs(entry, catalogs) {
  if (catalogs !== undefined && !Array.isArray(catalogs)) throw new OPFCatalogsOptionError(entry, `got ${catalogs === null ? 'null' : typeof catalogs}`);
}

export async function toPptx(input, options = {}) {
  if (options.bodyText !== undefined && !['measured', 'native'].includes(options.bodyText)) {
    throw new OPFPptxError('invalid-body-text-mode', 'bodyText must be measured or native.', {path: 'options.bodyText'});
  }
  if (options.imageFormat !== undefined && !['compatible', 'preserve'].includes(options.imageFormat)) {
    throw new OPFPptxError('invalid-image-format', 'imageFormat must be compatible or preserve.', {path: 'options.imageFormat'});
  }
  if (options.slideNumberFields !== undefined && !['static', 'live'].includes(options.slideNumberFields)) {
    throw new OPFPptxError('invalid-slide-number-option', "slideNumberFields must be 'static' or 'live'.", {path: 'options.slideNumberFields'});
  }
  if (options.provenance !== undefined && !['full', 'references-only', false].includes(options.provenance)) {
    throw new OPFPptxError('invalid-provenance-option', "provenance must be 'full', 'references-only' or false.", {path: 'options.provenance'});
  }
  if (options.footerText !== undefined && !['native', 'shape'].includes(options.footerText)) {
    throw new OPFPptxError('invalid-footer-text-option', "footerText must be 'native' or 'shape'.", {path: 'options.footerText'});
  }
  if (options.typefaces !== undefined && !['selected', 'safe'].includes(options.typefaces)) {
    throw new OPFPptxError('invalid-typefaces-option', "typefaces must be 'selected' or 'safe'.", {path: 'options.typefaces'});
  }
  if (options.diagrams !== undefined && !['picture', 'shapes'].includes(options.diagrams)) {
    throw new OPFPptxError('invalid-diagrams-option', "diagrams must be 'picture' or 'shapes'.", {path: 'options.diagrams'});
  }
  if (options.as !== undefined && !['native', 'images'].includes(options.as)) {
    throw new OPFPptxError('invalid-as-option', "as must be 'native' or 'images'.", {path: 'options.as'});
  }
  if (options.scale !== undefined && (options.as !== 'images' || typeof options.scale !== 'number' || !(options.scale >= 0.1 && options.scale <= 8))) {
    throw new OPFPptxError('invalid-scale-option', "scale applies to as: 'images' and is a number from 0.1 to 8.", {path: 'options.scale'});
  }
  // OPF 0.15 (FA-23): the host's registered catalogs (core `Catalog[]`, matched by `source`, never fetched) reach every core
  // call that resolves a reference. Strict export (`strictReferences`, default `strictAssets`) fails on a reference that
  // resolves nowhere instead of composing automatically or drawing with the engine default.
  checkCatalogs('toPptx', options.catalogs);
  options = {...options, strictReferences: options.strictReferences ?? options.strictAssets === true};
  // The document as given, before the deck-wide variable pass: the furniture manifest records the authored header and footer text.
  const authored = parseInput(input);
  const presentation = resolveTemplateInput(authored, options);
  assertValidBoundary(presentation);
  // In a browser core loads each diagram type on demand: load the deck's before anything composes it (a no-op in Node).
  await ensureDiagrams(presentation);
  // SH-02: and the preset geometry when the deck has shapes (a no-op in Node); SH-07: and when it writes its diagrams as shapes.
  await ensureShapes(presentation, {diagrams: (options.diagrams ?? 'shapes') === 'shapes'});
  // LH-14: and the icon sets it names (the gallery loads each set on first use) and the SVG files of its icons, when the host reads files.
  await ensureIcons(presentation, {catalogs: options.catalogs, ...(options.readIconSource ? {readSource: options.readIconSource} : {})});
  // LH-20: a pictures-only PPTX is the picture deck of the drawn slides, exported like any deck (src/picture-slides.js).
  if (options.as === 'images') return pictureSlidesPptx(presentation, options);
  // `options.fonts` is the fonts handle (the renderer's loadFonts()); the exporter reads its measurement, wrapped so the package names the
  // chosen family (FF-31). Internally `options.textMeasurement` is that wrapped measurement; it is not a public option.
  options = {...options, textMeasurement: chosenFamilyMeasurement(options.fonts?.textMeasurement), svgRasters: new Map()};
  // LH-28: safe mode measures each Latin text family as the Office-safe family it is written as, so composition lays out the
  // text PowerPoint draws on any machine. The design class of a family (sans-serif, serif, monospace) comes from the font
  // scheme records the slides resolve.
  const safeTypeface = options.typefaces === 'safe' ? (() => {
    const classes = typefaceClasses(presentation.slides.flatMap((slide, index) => {
      const core = coreContext(presentation, index, {...options, textMeasurement: undefined});
      return [core.resolved.fontScheme, {code: core.options.fontFamilies?.code}];
    }));
    const cache = new Map(), replaced = new Map();
    const safe = family => {
      if (!cache.has(family)) {
        const target = officeSafeTypeface(family, classes);
        cache.set(family, target);
        if (target !== family && !/^(?:sans-serif|serif|monospace)$/i.test(family)) replaced.set(family, target);
      }
      return cache.get(family);
    };
    return Object.assign(safe, {replaced});
  })() : undefined;
  if (safeTypeface) options = {...options, safeTypeface, textMeasurement: safeMeasurement(options.textMeasurement, safeTypeface)};
  // The renderer remains optional for custom measurement providers. Its public script planner supplies the same
  // shaping/measurement segmentation as preview when installed; the selected native family wrapper stays outside it.
  if (options.textMeasurement) {
    try { options.createScriptFonts = (await import("@openpresentation/opf-render/fonts")).createScriptFonts; }
    catch (error) { if (error?.code !== "ERR_MODULE_NOT_FOUND") throw error; }
  }

  const context = resolvePresentationContext(presentation, {...options,textMeasurement:undefined});
  context.listMarkers = new Map();
  context.imagePlaceholders = new Map();
  // opf-pptx#221: the placeholder panels written as one native group, and the OPF_IMAGE_PLACEHOLDER_V1 records of image blocks.
  context.imagePlaceholderGroups = new Set();
  context.imagePlaceholderTags = new Map();
  context.imageCalloutTags = new Map();
  context.tableHeaders = new Map();
  context.tableCells = new Map();
  // FA-23: every exported image picture (image blocks, the alt-text form of an image background, timeline pictures) and
  // every image overlay shape, by object name (src/image-provenance.js).
  context.images = new Map();
  context.imageOverlays = new Map();
  // LH-02: the gradient scrims of each slide part, by shape name (attachScrims).
  context.scrims = {};
  context.svgPictures = new Map();
  context.pictureText = new Map();
  // Diagrams: every generated diagram picture and placeholder name, and their OPF_DIAGRAM_V1 records (full provenance only).
  context.diagrams = new Set();
  context.diagramTags = new Map();
  // SH-07: `diagrams: "shapes"`: each diagram group's children (src/diagram-shapes.js), by the name of the shape that stands in for it.
  context.diagramMode = options.diagrams ?? 'shapes';
  context.diagramGroups = new Map();
  context.watermarks = new Map();
  context.textWatermarks = new Map();
  context.logos = new Map();
  context.logoPlaceholderTags = new Map();
  context.bulletImages = new Map();
  context.backgroundFills = new Map();
  context.notesWithCarriageReturns = new Map();
  context.cardTags = new Map();
  context.mediaTags = new Map();
  context.provenanceMode = options.provenance ?? "full";
  context.headingTags = new Map();
  context.plainTextTags = new Map();
  context.nativeBodies = new Map();
  context.nativeTitles = new Set();
  context.timelineTags = new Map();
  // LH-108 to LH-110: the shapes a chart's value list, stacked names and reference marks are drawn with (src/chart-marks.js).
  context.chartMarkTags = new Map();
  // LH-07: the shapes of the step badges, connectors and flows of a layout's sequence regions (src/step-badges.js).
  context.stepTags = new Map();
  // SH-09: the pyramids and matrices of a layout's arrangement regions: live SmartArt frames and their tags, or native shapes (src/smart-art.js).
  context.smartArt = new Map();
  context.smartArtTags = new Map();
  context.arrangementTags = new Map();
  context.iconTags = new Map();
  // LH-130: the accent rule core sets above a cover's or section's title (src/title-rule.js).
  context.titleRuleTags = new Map();
  context.quoteTags = new Map();
  context.quotePhotos = new Map();
  context.furnitureTags = new Map();
  context.furnitureImages = new Map();
  context.furnitureFields = new Map();
  context.furnitureManifests = new Map();
  context.nativeFurniture = new Map();
  context.nativeFurnitureBands = new Map();
  context.nativeParts = new Map();
  context.footerText = options.footerText ?? 'native';
  // RR-72: each slide's furniture parts and the object names of their shapes, for the slide master and layouts.
  context.furnitureParts = [];
  // RR-81: the 0.19 template each slide uses (its native slide layout) and the objects bound to a region placeholder.
  context.templateSlides = [];
  // RR-102: 'live' is the default (the Slide number box is checked and PowerPoint renumbers); 'static' is for Keynote targets (RR-91).
  context.staticSlideNumbers = options.slideNumberFields === 'static';
  context.automaticSlides = [];
  context.placeholderBindings = new Map();
  context.hostDate = options.date;
  context.authored = authored;
  context.codeTags = new Map();
  context.captionTags = new Map();
  context.footnoteTags = new Map();
  context.metricTags = new Map();
  context.metricDescriptions = new Map();
  context.chartHeadings = new Map();
  context.frameAlts = new Map();
  context.chartFonts = new Map();
  context.chartPalettes = new Map();
  context.chartex = new Map();
  // RR-54: the authored data form of charts and tables (OPF_DATA_V1) and the datasets map (OPF_DATASETS_V1), `full` mode only.
  context.dataRecords = new Map();
  context.dataRecordPaths = new Map();
  context.datasets = presentation.datasets;
  context.reportDiagnostic = options.onDiagnostic;
  context.safeTypeface = safeTypeface;
  context.imageFormat = options.imageFormat ?? "compatible";
  // Chartex export mode (FF-22b): 'auto' (default) writes native chartex parts for the constructs the native PowerPoint
  // check confirmed (treemap, histogram, pareto, box-and-whisker, waterfall, funnel) and the clustered column fallback
  // for the unconfirmed map; 'native' writes every chartex part; 'fallback' writes clustered columns only.
  if (options.chartex !== undefined && !['auto', 'native', 'fallback'].includes(options.chartex)) {
    throw new OPFPptxError('invalid-chartex-mode', 'chartex must be auto, native or fallback.', {path: 'options.chartex'});
  }
  context.chartexMode = options.chartex ?? 'auto';
  // SH-09: 'live' (default) writes a pyramid or matrix as live SmartArt where PowerPoint draws it as the preview does; 'shapes' as native shapes.
  if (options.smartArt !== undefined && !['live', 'shapes'].includes(options.smartArt)) {
    throw new OPFPptxError('invalid-smart-art-mode', 'smartArt must be live or shapes.', {path: 'options.smartArt'});
  }
  context.smartArtMode = options.smartArt ?? 'live';
  Object.assign(context, exportTheme(presentation, context, options));
  context.reportedReferences = new Set();
  // Document references and metadata tags (FF-32, docs/document-roundtrip.md).
  context.documentProvenance = options.provenance === false ? null : documentProvenance(presentation, {
    mode: options.provenance ?? "full",
    // Core's provenance of each slide's resolved layout (resolveSlideContext().resolved.provenance.layout) with its record.
    layoutOf: index => {
      const {resolved} = coreContext(presentation, index, options);
      return resolved.provenance?.layout && resolved.layout ? {...resolved.provenance.layout, record: resolved.layout} : undefined;
    },
    report: diagnostic => options.onDiagnostic?.(diagnostic)
  });
  context.scriptFonts = planScriptFonts(presentation, options.onDiagnostic, {catalogs: options.catalogs});
  // RR-102: the deck language every run is written in (lang); a date field that shows English words says en-US instead.
  context.deckLang = context.scriptFonts?.lang ?? 'en-US';
  // Slide section labels become PowerPoint's native section list (src/sections.js).
  // A label is an XML attribute: the characters text runs reject are rejected here too.
  context.sections = presentation.slides.map((slide, index) => {
    if (typeof slide.section !== 'string') return undefined;
    const invalid = INVALID_XML_CHARACTER.exec(slide.section);
    if (invalid) throw new OPFPptxError('invalid-text', `Text contains U+${invalid[0].codePointAt(0).toString(16).toUpperCase().padStart(4, '0')} at UTF-16 offset ${invalid.index}, which DrawingML XML cannot represent.`, {path: `slides.${index}.section`});
    return slide.section;
  });
  context.masterBackground = masterBackground(context);
  // RR-96: the master's clrMap is the deck variant's map (a dark deck is the dark map, not hand-inverted colors); a slide whose variant
  // differs writes its own override (exportSlideContext).
  context.clrMap = context.roles.map ? clrMapAttributes(context.roles.map) : undefined;
  context.clrMapOverrides = new Map();
  // RR-96: the scheme-derived colors of the deck (master and layouts) and of each slide (its parts and charts), rewritten to schemeClr in the finished parts.
  const authoredLiterals = authoredLiteralColors(presentation.variables, {...presentation.design, colorScheme: undefined, theme: undefined});
  context.deckSchemeColors = {table: schemeColorTable(context), keep: authoredLiterals};
  context.slideSchemeColors = [];
  // SH-02: the native parts of each shape block, by object name (src/shape-blocks.js), written into the finished slide parts.
  context.shapeBlocks = new Map();
  context.shapeSchemeColors = new Map();
  // SH-04: the native connectors of the slides' overlays, by object name (src/connectors.js), written into the finished slide parts.
  context.connectors = new Map();
  context.linkSentinels = linkSentinels(presentation);
  const pptx = new PptxGenJS();
  configurePresentation(pptx, presentation, {...context,fonts:exportSlideContext(presentation,0,context,options).fonts});

  for (let index = 0; index < presentation.slides.length; index += 1) {
    await addSlide(pptx, presentation, presentation.slides[index], index, context, options);
  }

  // RR-81: when a slide uses a template, every template the deck reaches gets its native layout (registered catalogs, then embedded).
  // A template's placeholders are composed with the options of the first slide that uses it; a template no slide uses, with the
  // options of a slide that would (the deck's header and footer, the template's own design) and no placed-image band.
  const reachableTemplates = deckTemplates(presentation, options.catalogs, reference => resolveReference(presentation, 'layouts', reference, options.catalogs !== undefined ? {catalogs: options.catalogs} : {}));
  if (context.templateSlides.some(Boolean) || reachableTemplates.length || context.automaticSlides.some(Boolean)) {
    const plans = context.templateSlides.filter(Boolean), first = plans[0] ?? context.automaticSlides.find(Boolean) ?? {areaOptions: context.firstSlideOptions};
    const reachable = reachableTemplates;
    for (const plan of plans) if (!reachable.some(template => template.key === plan.template.key)) reachable.push(plan.template);
    context.deckTemplates = reachable.map(template => {
      const used = plans.find(plan => plan.template.key === template.key);
      const colorMap = layoutColorMap(presentation, template, context, options);
      if (used) return {...template, ...(colorMap ? {colorMap} : {}), areaOptions: used.areaOptions};
      const core = coreContext({...presentation, slides: [{layout: template.reference}]}, 0, options).options;
      return {...template, ...(colorMap ? {colorMap} : {}), areaOptions: {...core, fontFamilies: first.areaOptions.fontFamilies, textRasterPadding: options.textRasterPadding, placements: []}};
    });
  }

  // FF-08: pitchFamily per exported family, from each slide's resolved scheme, then the font schemes the document embeds
  // and the registered catalogs its groups name (core catalogRecords).
  context.fontPitch = fontPitchFamilies(presentation.slides.map((slide, index) => exportSlideContext(presentation, index, context, options).fonts),
    catalogRecords(presentation, "fontSchemes", {catalogs: options.catalogs}).map(entry => entry.record));

  let raw;
  try {
    // The package is unzipped and re-zipped by normalizePptxZip, so the intermediate ZIP is stored uncompressed.
    raw = await withDeterministicRandom(context.seed, () => pptx.write({
      outputType: "uint8array"
    }));
  } catch (error) {
    throw new OPFPptxError("pptxgen-failed", "PPTX generation failed.", {
      cause: errorMessage(error)
    });
  }

  return normalizePptxZip(asUint8Array(raw), context);
}

export async function fromPptx(input, options = {}) {
  // Opt-in raw shape signals (import-signals.js). Validated first so a bad option fails before any work.
  const signalLimits = normalizeSignalOptions(options.signals, (code, message, details) => new OPFPptxError(code, message, details));
  // OPF 0.15 (FA-23): catalogs the host registered (core `Catalog[]`, never fetched). Theme and colour-scheme recovery and
  // stored layout ids resolve against them; with none, a colour scheme imports inline and no theme id is recovered.
  checkCatalogs('fromPptx', options.catalogs);
  const entries = readPptxZip(input);
  const presentationDoc = parseRequiredXml(entries, "ppt/presentation.xml");
  const presentationRoot = presentationDoc["p:presentation"];
  if (!presentationRoot) {
    throw new OPFPptxError("invalid-pptx", "PPTX is missing ppt/presentation.xml.");
  }

  const presentationRels = parseRelationships(entries, "ppt/presentation.xml");
  const slidePaths = resolveSlidePaths(entries, presentationRoot, presentationRels);
  if (slidePaths.length === 0) {
    throw new OPFPptxError("invalid-pptx", "PPTX does not contain any slides.");
  }

  const core = readCoreProperties(entries);
  const dimensions = dimensionsFromPresentation(presentationRoot);
  let imported = {
    $schema: options.schema ?? CANONICAL_SCHEMA,
    name: core.title || options.fallbackName || "Imported PPTX",
    slides: []
  };

  // FF-07: the language the runs carry. A stored FF-32 reference can still win below.
  const languageThemePath = presentationThemePath(presentationRoot, presentationRels, path => parseRelationships(entries, path), entries);
  // opf-pptx#168: each slide's theme, through its layout and master (several masters carry per-slide script fonts).
  const relatedPart = (path, type) => path ? [...parseRelationships(entries, path).values()].find(rel => rel.type?.endsWith(`/${type}`) && rel.path && entries[rel.path])?.path : undefined;
  // Preserve the legacy package-level inline-code font gate; language votes use
  // the independently validated current-slide ownership below.
  const hasOpfTags = Object.keys(entries).some(path => /^ppt\/tags\/opf/i.test(path));
  const ownedSlides = opfSlideOwnership(entries, slidePaths);
  const nativeLanguages = nativeLanguageReadView(entries, parseRelationships, options.onDiagnostic);
  const observedLanguage = observeLanguage({
    preferBaseRuns: ownedSlides,
    slides: slidePaths.map(path => decodeText(nativeLanguages.get(path) ?? entries[path])),
    theme: languageThemePath && entries[languageThemePath] ? decodeText(entries[languageThemePath]) : null,
    themePath: languageThemePath,
    slideThemes: slidePaths.map(path => {
      const theme = relatedPart(relatedPart(relatedPart(path, 'slideLayout'), 'slideMaster'), 'theme');
      return theme ? {path: theme, xml: decodeText(entries[theme])} : null;
    }),
    catalogs: options.catalogs
  });
  if (observedLanguage.language !== undefined) imported.language = observedLanguage.language;
  if (core.description) imported.description = core.description;
  if (core.author) imported.author = splitAuthors(core.author);
  const themeDesign = importThemeDesign(entries, presentationRoot, presentationRels, options.catalogs);
  const design = {...themeDesign.design, ...(dimensions ? {dimensions} : {})};
  if (Object.keys(design).length) imported.design = design;

  // Layouts and the master are read once however many slides inherit a placeholder from them (RR-11).
  const cached = read => { const memo = new Map(); return path => { if (!memo.has(path)) memo.set(path, read(path)); return memo.get(path); }; };
  const cachedRelationships = cached(path => parseRelationships(entries, path)), cachedPart = cached(path => parseOptionalXml(entries, path));
  // RR-72: the furniture a slide shows from its layout and slide master (src/master-furniture.js), read once per part.
  const inheritedParts = new Map();
  const inheritedPart = path => {
    if (!path) return undefined;
    if (!inheritedParts.has(path)) {
      const element = /slideMaster/.test(path) ? 'p:sldMaster' : 'p:sldLayout', root = cachedPart(path)?.[element];
      const tree = root?.['p:cSld']?.['p:spTree'];
      inheritedParts.set(path, root ? {path, root, relationships: cachedRelationships(path), shapes: nativeTextShapes(tree), pictures: nativePictures(tree),
        paragraphs: nativeShapeParagraphs(decodeText(entries[path]), element)} : undefined);
    }
    return inheritedParts.get(path);
  };
  const relatedPath = (path, type) => path ? [...cachedRelationships(path).values()].find(rel => rel.type === `http://schemas.openxmlformats.org/officeDocument/2006/relationships/${type}` && rel.targetMode !== 'External' && entries[rel.path])?.path : undefined;
  // RR-81: the OPF_LAYOUT_V1 tag of each slide's layout (a 0.19 template layout), read once per layout part.
  const layoutTags = new Map();
  const layoutTagOf = (layoutPath, index) => {
    if (!layoutPath) return undefined;
    if (!layoutTags.has(layoutPath)) layoutTags.set(layoutPath, readLayoutTag(entries, layoutPath, message => options.onDiagnostic?.({code: 'invalid-layout-provenance', path: `slides.${index}.layout`, message})));
    return layoutTags.get(layoutPath);
  };
  const furnitureContexts = slidePaths.map((slidePath, index) => {
    const root = parseRequiredXml(entries, slidePath)['p:sld'];
    if (!root) throw new OPFPptxError('invalid-pptx', `PPTX slide is not a PresentationML slide: ${slidePath}.`, {path: slidePath});
    const tree = root['p:cSld']?.['p:spTree'], relationships = parseRelationships(entries, slidePath);
    const layoutPath = relatedPath(slidePath, 'slideLayout'), layoutTag = layoutTagOf(layoutPath, index);
    return {root, relationships, shapes: nativeTextShapes(tree), pictures: nativePictures(tree), layoutTag, foreignLayout: layoutTag ? undefined : foreignLayoutReference(cachedPart(layoutPath)?.['p:sldLayout'], options.catalogs),
      // RR-81: a region placeholder typed into in PowerPoint has no xfrm of its own; it sits where the template layout puts it.
      layoutBounds: layoutTag ? shape => {
        const ph = shape?.['p:nvSpPr']?.['p:nvPr']?.['p:ph'];
        if (ph?.idx === undefined) return undefined;
        const match = asArray(cachedPart(layoutPath)?.['p:sldLayout']?.['p:cSld']?.['p:spTree']?.['p:sp']).find(candidate => candidate?.['p:nvSpPr']?.['p:nvPr']?.['p:ph']?.idx === ph.idx);
        return match ? shapeBounds(match['p:spPr']?.['a:xfrm']) ?? undefined : undefined;
      } : undefined,
      // RR-11: native footer placeholders resolve their position through the layout and master.
      path: slidePath, slideWidth: Number(presentationRoot['p:sldSz']?.cx), slideHeight: Number(presentationRoot['p:sldSz']?.cy), defaultTextStyle: presentationRoot['p:defaultTextStyle'], relationshipsOf: cachedRelationships, readPart: cachedPart,
      paragraphs: nativeShapeParagraphs(decodeText(entries[slidePath])),
      readPicture: picture => importPicture(entries, picture, slidePath, relationships,
        diagnostic => options.onDiagnostic?.({...diagnostic, path: `slides.${index}.design`})),
      inherited: () => {
        const layout = relatedPath(slidePath, 'slideLayout'), master = relatedPath(layout, 'slideMaster');
        return Object.fromEntries([['layout', inheritedPart(layout)], ['master', inheritedPart(master)]].filter(([, part]) => part).map(([on, part]) => [on, {...part,
          readPicture: picture => importPicture(entries, picture, part.path, part.relationships, diagnostic => options.onDiagnostic?.({...diagnostic, path: `slides.${index}.design`}))}]));
      }};
  });
  // Native sections (PowerPoint's own section list, `Default Section` = none) name each slide's `{{slide.section}}` for the footer text check
  // and, after the slides, are reconciled with the stored value in restoreDocumentProvenance.
  const slideSections = nativeSections(presentationRoot, slideIdsInOrder(presentationRoot, presentationRels, entries, slidePaths));
  const stored = storedMetadata(entries, presentationRoot, presentationRels);
  // A stored zone text with built-in variables is drawn from the document's own metadata, as toPptx resolved it: the stored record
  // (organization, speaker ...) and the observed name, description and author (a default the exporter writes is no value).
  const importedMetadata = {
    ...(imported.name && imported.name !== DEFAULT_TITLE ? {name: imported.name} : {}),
    ...(imported.description ? {description: imported.description} : {}),
    ...(imported.author && joinAuthors(imported.author) !== DEFAULT_AUTHOR ? {author: imported.author} : {}),
    ...(stored.organization !== undefined ? {organization: stored.organization} : {}),
    ...(stored.speaker !== undefined ? {speaker: stored.speaker} : {}),
  };
  const furniture = importFurniture(furnitureContexts, entries, options.onDiagnostic, {sections: slideSections ?? [], organizations: asArray(stored.organization).filter(item => isPlainObject(item) && typeof item.id === 'string' && typeof item.name === 'string').map(item => ({id: item.id, name: item.name, ...(typeof item.role === 'string' ? {role: item.role} : {}), ...(logoShape(item.logo) !== undefined ? {logo: logoShape(item.logo)} : {})})),
    draw: (template, {index, count, section}) => drawFurnitureText(template, {index, count, section}, importedMetadata)});
  if (Object.keys(furniture.design).length) imported.design = {...imported.design, ...furniture.design};
  if (furniture.organization) imported.organization = furniture.organization;

  // RR-54: the datasets recorded at export (OPF_DATASETS_V1). Chart and table frames restore their dataset references against
  // them, so the document carries them before document provenance validates the restored document.
  const datasets = readDatasetsTag(entries, presentationRoot, presentationRels, options.onDiagnostic);
  const mediaRegistry = Object.create(null);
  // SH-05: shape readers are synchronous; the preset geometry they read (SH-01) loads here, when a slide has a shape other than a rectangle.
  // SH-08: a SmartArt's drawing (ppt/diagrams/drawingN.xml) is read as shapes when its layout has no OPF form.
  if (slidePaths.some(path => /<a:prstGeom\s+prst="(?!rect")|<a:custGeom\b/.test(decodeText(entries[path]))) || Object.keys(entries).some(path => /^ppt\/diagrams\/drawing\d+\.xml$/.test(path))) await loadShapeGeometry();
  for (let index = 0; index < slidePaths.length; index += 1) {
    furnitureContexts[index].mediaRegistry = mediaRegistry;
    const slideLanguage = observedLanguage.slides?.[index] ?? observedLanguage;
    imported.slides.push(importSlide(entries, slidePaths[index], index, dimensions, {...options, nativeLanguages, rtlDeck: observedRtl(slideLanguage), deckLang: slideLanguage.lang, codeFamily: hasOpfTags ? importedCodeFamily(imported, options.catalogs) : undefined, dataProvenance: {datasets}}, furniture.slides[index], furnitureContexts[index]));
    if (slideLanguage.language !== undefined && slideLanguage.language !== observedLanguage.language) imported.slides[index].language = slideLanguage.language;
  }
  if (datasets) imported.datasets = datasets;
  // A watermark carried identically by every slide is the deck's design.watermark.
  const carried = imported.slides.map(slide => slide.design?.watermark);
  if (carried.length && carried[0] && carried.every(value => JSON.stringify(value) === JSON.stringify(carried[0]))) {
    imported.design = {...imported.design, watermark: carried[0]};
    for (const slide of imported.slides) { delete slide.design.watermark; if (!Object.keys(slide.design).length) delete slide.design; }
  }
  // Conflicting media asset IDs fall back to their current native URLs during import.
  for (const context of furnitureContexts) for (const [id, asset] of Object.entries(context.mediaAssets ?? {})) if (!Object.hasOwn(imported.assets ?? {}, id)) imported.assets = {...imported.assets, [id]: asset};
  // Report after the slides so slide diagnostics keep their established order.
  // A theme name FF-24 could not verify is not reported when the stored reference restores the theme.
  for (const diagnostic of themeDesign.diagnostics) if (diagnostic.code !== "theme-unverified") options.onDiagnostic?.(diagnostic);

  // Catalog references, layout ids and authoring metadata recorded at export
  // (FF-32). Stored references win while the package still matches them;
  // otherwise the observed values (including FF-24's theme recovery) stay and
  // a diagnostic names the reference. A restored field that does not validate
  // is dropped on its own.
  const report = diagnostic => options.onDiagnostic?.(diagnostic);
  // Per slide: {layout, structure: 'match' | 'changed' | 'untagged', record, catalogRecord}.
  // Layout-structure recovery (FF-29) reads the stored OPF_SLIDE_V1 record from
  // here instead of writing a second slide tag.
  let slideProvenance = slidePaths.map(() => ({structure: "untagged"}));
  let restoredGroups = [];
  try {
    const restored = restoreDocumentProvenance(imported, {entries, presentationRoot, presentationRels,
      // Stored layout ids also resolve in the host's registered catalogs (FA-23).
      catalogs: options.catalogs,
      nativeSections: slideSections,
      // An importer `schema` option names the document's $schema, so an absent source $schema does not remove it (RR-59).
      schemaOption: options.schema !== undefined,
      slides: slidePaths.map((path, index) => ({path, root: furnitureContexts[index].root, relationships: furnitureContexts[index].relationships, contentBounds: furnitureContexts[index].contentBounds}))}, report);
    // The stored language wins while the runs still carry its tag (FF-07).
    restored.groups = reconcileLanguage(restored.groups, observedLanguage, report);
    imported = applyDocumentProvenance(imported, restored, checkFormat, report);
    slideProvenance = restored.slides;
    restoredGroups = restored.groups;
  } catch (error) {
    report({code: "invalid-document-provenance", path: "", message: `${errorMessage(error)} Ordinary import keeps the values observed in the PPTX.`});
  }
  if (slideProvenance.length !== imported.slides.length) throw new OPFPptxError("invalid-import-opf", "Slide provenance does not match the imported slides.");
  // RR-81: a slide on a 0.19 template layout takes that layout's reference (a slide added in PowerPoint, Change Layout), and a
  // block read from a region placeholder keeps its region with a pin where plain binding would move it (src/template-layouts.js).
  // Every tagged layout of the package, used or not: an embedded template no slide uses comes back from its tag.
  const packageLayoutTags = Object.keys(entries).filter(path => /^ppt\/slideLayouts\/slideLayout\d+\.xml$/.test(path)).sort((a, b) => Number(a.match(/\d+/)[0]) - Number(b.match(/\d+/)[0]))
    .map(path => layoutTagOf(path, 0)).filter(Boolean);
  if (packageLayoutTags.length) {
    const restoredContent = new Set(restoredGroups.filter(group => group.applied && group.contentPaths).map(group => group.contentPaths.slide));
    applyTemplateLayouts(imported, furnitureContexts.map((context, index) => ({tag: context.layoutTag, blockRegions: context.blockRegions, restored: restoredContent.has(index), preservedAutomatic: slideProvenance[index]?.structure !== 'untagged', storedLayout: slideProvenance[index]?.layout})),
      index => resolveCoreSlideContext(imported, index, options.catalogs !== undefined ? {catalogs: options.catalogs} : {}).resolved.layout, report, packageLayoutTags);
  }
  for (const [index, context] of furnitureContexts.entries()) {
    // SH-09: an untagged slide whose content is a Basic Pyramid, Basic Matrix or (SH-18) Basic Cycle SmartArt takes the pyramid, matrix or cycle layout.
    if (!context.layoutTag && context.smartArtLayout !== undefined && imported.slides[index].layout === undefined) context.foreignLayout = context.smartArtLayout;
    if (!context.layoutTag && slideProvenance[index]?.structure === 'untagged' && context.foreignLayout !== undefined && imported.slides[index].layout === undefined)
      {
        if (context.foreignLayout.startsWith('default:')) {
          const found = resolveReference({}, 'layouts', context.foreignLayout, {catalogs: options.catalogs ?? [gallery]});
          const existing = imported.catalogs?.default;
          if (existing === false || (existing?.source !== undefined && existing.source !== found?.source)) continue;
          if (found?.source) imported.catalogs = {...imported.catalogs, default: {...imported.catalogs?.default, source: found.source}};
        }
        imported.slides[index].layout = context.foreignLayout;
      }
  }
  // RR-34: marker runs become cite/footnote on the runs before them, and the references list is rebuilt
  // from the stored record and the footnote boxes (an edited note keeps its edited text).
  restoreCitations(imported, furnitureContexts.map(context => context.annotations?.notes ?? []), report);
  restoreLogoFallback(imported, furnitureContexts);
  // The overlay joins its slide before the run colors, so the text of its shapes is settled with the rest.
  applyShapes(imported, furnitureContexts, restoredGroups, slideProvenance, options.onDiagnostic);
  applyRunColors(imported, slideProvenance, restoredGroups, report, options, furnitureContexts);
  settleShapes(imported, furnitureContexts, options);
  restoreSlotFills(imported, slideProvenance, options);
  dropImpliedVariants(imported, options);
  applyNativeImageFits(imported, furnitureContexts, restoredGroups, options);
  // LH-14: each tagged icon's reference goes back on the entry, metric or group it marked (src/icons.js).
  restoreIcons(imported, new Map(furnitureContexts.flatMap(context => [...(context.iconReferences ?? [])])));
  if (imported.design?.theme === undefined) for (const diagnostic of themeDesign.diagnostics) if (diagnostic.code === "theme-unverified") report(diagnostic);
  languageDiagnostics(imported, observedLanguage, options.onDiagnostic && report);

  const validation = checkFormat(imported);
  if (!validation.valid) {
    throw new OPFPptxError("invalid-import-opf", "Imported PPTX did not produce valid OPF.", {
      findings: validation.findings.filter(finding => finding.severity === "error"),
      report: validation
    });
  }

  if (!signalLimits) return imported;
  // Where document provenance rebuilt the authored structure, flat block indexes map to their rebuilt paths.
  const contentPaths = slidePaths.map(() => null);
  for (const group of restoredGroups) if (group.applied && group.contentPaths?.paths) contentPaths[group.contentPaths.slide] = group.contentPaths.paths;
  const archive = {part: (path, parser) => parseRequiredXml(entries, path, parser), relationships: path => parseRelationships(entries, path), bytes: path => entries[path]};
  const signals = extractSignals({archive, presentationRoot, slidePaths, themeFacts: themeFactsFor(slidePaths[0], archive), limits: signalLimits,
    recorded: furnitureContexts.map(context => context.signalSources), slideProvenance, contentPaths});
  return {presentation: imported, signals};
}

// RR-08: run colours named by a ColorRef (variable, scheme slot, role) come back as that name where the document's own
// colour resolution still gives the run's colour; see run-colors.js.
function applyRunColors(imported, slideProvenance, restoredGroups, report, options, contexts) {
  const restoredContent = new Set(restoredGroups.filter(group => group.applied && group.contentPaths).map(group => group.contentPaths.slide));
  const info = slideProvenance.map((entry, index) => entry.structure === "untagged" ? undefined : {record: entry.record, structure: entry.structure === "match", content: restoredContent.has(index), scalars: contexts?.[index]?.listScalars});
  restoreRunColors(imported.slides, info, colorResolver(imported, options), report);
}

// The color a ColorRef is in a slide of the imported document ('#RRGGBB', or undefined), through the document's own color resolution.
function colorResolver(imported, options) {
  const contexts = new Map();
  return (slide, name) => {
    try {
      const key = slide.design ?? imported.design ?? null;
      if (!contexts.has(key)) contexts.set(key, resolvePresentationContext(slide.design ? {...imported, design: {...imported.design, ...slide.design}} : imported, options));
      return resolveColorRefValue(name, colorContext(contexts.get(key)));
    } catch {
      return undefined;
    }
  };
}

// SH-05: the overlay shapes and connectors of each slide join it, in the order they were drawn.
function applyShapes(imported, furnitureContexts, restoredGroups, slideProvenance, report) {
  const restoredContent = new Set(restoredGroups.filter(group => group.applied && group.contentPaths).map(group => group.contentPaths.slide));
  // The stored ids and anchors of the overlay count while the slide's native structure is as it was exported (an edited slide keeps what PowerPoint now shows).
  const paths = imported.slides.map(() => null);
  for (const group of restoredGroups) if (group.applied && group.contentPaths?.paths) paths[group.contentPaths.slide] = group.contentPaths.paths;
  assembleOverlayShapes(imported, furnitureContexts, imported.slides.map((_, index) => restoredContent.has(index)), slideProvenance.map(entry => entry.structure === 'match' ? entry.record?.overlays : undefined), paths, report);
}

// SH-05: what only the theme style gave a shape (its fill, line, shadow and text color) is not the shape's own.
function settleShapes(imported, furnitureContexts, options) {
  const fallback = colorResolver(imported, options);
  restoreShapes(imported, (slide, index) => furnitureContexts[index]?.shapeImport?.resolve ?? (name => fallback(slide, name)));
}

// RR-96: the variant a color map imports as is dropped where the document's own design already gives that map: core picks light1 or dark1 from the
// slide background (a dark theme is the dark map), so a deck that is dark by its theme, and a slide that is dark by its own background, need no `variant`.
function dropImpliedVariants(imported, options) {
  // LH-01: a slide's implied variant includes its layout's (a section imports its accent clrMapOvr as a variant its layout already gives).
  // LH-164: a message-only slide's accent surface is implied by its content (and by the slide before it), so the slide is resolved inside the imported deck.
  const rolesVariant = (design, slide = {}, at) => {
    try {
      const slides = at === undefined ? [slide] : imported.slides.map((other, index) => index === at ? slide : other);
      return JSON.stringify(coreContext({...imported, design, slides}, at ?? 0, {...options, textMeasurement: undefined}).resolved.roles?.variant);
    } catch { return undefined; }
  };
  const withoutVariant = design => { const {variant, ...rest} = design ?? {}; return rest; };
  if (imported.design?.variant !== undefined) {
    const implied = rolesVariant(withoutVariant(imported.design));
    if (implied !== undefined && implied === JSON.stringify(normalizeColorVariant(imported.design.variant))) {
      const {variant, ...rest} = imported.design;
      if (Object.keys(rest).length) imported.design = rest; else delete imported.design;
    }
  }
  for (const [index, slide] of imported.slides.entries()) {
    if (slide.design?.variant === undefined) continue;
    const rest = withoutVariant(slide.design);
    const implied = rolesVariant(imported.design, {...slide, design: rest}, index);
    if (implied !== undefined && implied === JSON.stringify(normalizeColorVariant(slide.design.variant))) {
      if (Object.keys(rest).length) slide.design = rest; else delete slide.design;
    }
  }
}

// RR-96: a fill that is exactly a slot of the slide's color scheme comes back as that slot (`accent1`, `light2`, ...), the way a PowerPoint scheme
// fill is a theme color. Table cell and column fills only; a literal that is not a slot stays a literal.
const FILL_SLOT_ORDER = ['accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6', 'dark1', 'light1', 'dark2', 'light2'];
function restoreSlotFills(imported, slideProvenance, options) {
  const names = new Map();
  const slotsOf = slide => {
    const key = slide.design ?? imported.design ?? null;
    if (!names.has(key)) {
      let table = new Map();
      try {
        const context = resolvePresentationContext(slide.design ? {...imported, design: {...imported.design, ...slide.design}} : imported, options);
        const slots = themeSlotColors(context.colorScheme);
        for (const slot of FILL_SLOT_ORDER) if (slots[slot] && !table.has(slots[slot])) table.set(slots[slot], slot);
      } catch { table = new Map(); }
      names.set(key, table);
    }
    return names.get(key);
  };
  const visit = (value, table) => {
    if (Array.isArray(value)) { value.forEach(item => visit(item, table)); return; }
    if (!isPlainObject(value)) return;
    if (typeof value.fill === 'string') {
      const hex = value.fill.match(/^#([0-9a-f]{6})$/i)?.[1]?.toUpperCase();
      const slot = hex && table.get(hex);
      if (slot) value.fill = slot;
    }
    for (const child of Object.values(value)) visit(child, table);
  };
  // A slide restored from provenance keeps its authored values (a literal that happens to equal a slot stays the literal).
  for (const [index, slide] of imported.slides.entries()) {
    if (slideProvenance[index]?.structure !== 'untagged') continue;
    const containers = [slide.table, ...asArray(slide.blocks).map(block => block?.table), ...Object.values(slide).flatMap(region => isPlainObject(region) ? [region.table] : [])].filter(Boolean);
    if (containers.length) { const table = slotsOf(slide); if (table.size) containers.forEach(container => visit(container, table)); }
  }
}

// A consumed logo picture (OPF_LOGO_V1) never becomes content. Its own image restores the organization's logo only when the
// stored document did not (RR-71: logos live on the organization), so a package exported without provenance still keeps its
// logo: on the primary organization, else on a new one named after the deck. The picture is one drawn asset, so it becomes the
// organization's single logo for every shape.
function restoreLogoFallback(imported, contexts) {
  const organizations = asArray(imported.organization);
  if (organizations.some(item => item?.logo !== undefined)) return;
  const image = contexts.map(context => context.logoFallback?.image).find(Boolean);
  if (!image) return;
  const primary = organizations.find(item => item?.role === 'primary') ?? organizations[0];
  if (!primary) { imported.organization = {id: 'brand', name: imported.name ?? 'Brand', logo: image}; return; }
  const index = organizations.indexOf(primary), withLogo = {...primary, logo: image};
  imported.organization = Array.isArray(imported.organization) ? imported.organization.map((item, at) => at === index ? withLogo : item) : withLogo;
}

function readPptxZip(input) {
  let bytes;
  if (input instanceof Uint8Array) {
    bytes = input;
  } else if (input instanceof ArrayBuffer) {
    bytes = new Uint8Array(input);
  } else {
    throw new OPFPptxError("invalid-input", "PPTX input must be a Uint8Array or ArrayBuffer.");
  }

  try {
    return readInputZip(bytes);
  } catch (error) {
    if (error instanceof OPFPptxError) throw error;
    throw new OPFPptxError("invalid-pptx", "PPTX input is not a readable ZIP archive.", {
      cause: errorMessage(error)
    });
  }
}

function parseRequiredXml(entries, path, parser = xmlParser) {
  const bytes = entries[path];
  if (!bytes) {
    throw new OPFPptxError("invalid-pptx", `PPTX is missing ${path}.`, { path });
  }
  try {
    return parser.parse(decodeText(bytes));
  } catch (error) {
    throw new OPFPptxError("invalid-pptx", `PPTX XML part could not be parsed: ${path}.`, {
      path,
      cause: errorMessage(error)
    });
  }
}

function parseOptionalXml(entries, path) {
  if (!entries[path]) return null;
  return parseRequiredXml(entries, path);
}

function parseRelationships(entries, sourcePartPath) {
  const relsPath = relationshipsPathForPart(sourcePartPath);
  const doc = parseOptionalXml(entries, relsPath);
  const relationships = asArray(doc?.Relationships?.Relationship);
  const map = new Map();
  for (const relationship of relationships) {
    if (!relationship?.Id) continue;
    map.set(relationship.Id, {
      id: relationship.Id,
      type: relationship.Type ?? "",
      target: relationship.Target ?? "",
      targetMode: relationship.TargetMode ?? "Internal",
      path: resolveRelationshipTarget(sourcePartPath, relationship.Target ?? "")
    });
  }
  return map;
}

function relationshipsPathForPart(partPath) {
  const slash = partPath.lastIndexOf("/");
  const dir = slash >= 0 ? partPath.slice(0, slash + 1) : "";
  const file = slash >= 0 ? partPath.slice(slash + 1) : partPath;
  return `${dir}_rels/${file}.rels`;
}

function resolveRelationshipTarget(sourcePartPath, target) {
  if (!target || /^https?:\/\//i.test(target)) return target;
  const raw = target.startsWith("/")
    ? target.slice(1)
    : `${sourcePartPath.slice(0, sourcePartPath.lastIndexOf("/") + 1)}${target}`;
  const parts = [];
  for (const part of raw.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      parts.pop();
    } else {
      parts.push(part);
    }
  }
  return parts.join("/");
}

// A header or footer text as the exporter drew it for one slide: deck-wide built-ins resolved from `metadata` (core
// resolveVariables), then the slide-scoped tokens for the slide's position, count and section. undefined when core refuses.
function drawFurnitureText(template, {index, count, section}, metadata) {
  try {
    const slide = resolveVariables({...metadata, slides: [{...(section !== undefined ? {section} : {}), text: template}]}).presentation.slides[0];
    return resolveSlideVariables(slide, {slideNumber: index + 1, slideCount: count}).text;
  } catch {
    return undefined;
  }
}

function resolveSlidePaths(entries, presentationRoot, relationships) {
  const slideIds = asArray(presentationRoot["p:sldIdLst"]?.["p:sldId"]);
  const paths = [];
  for (const slideId of slideIds) {
    const relId = slideId?.["r:id"];
    const relationship = relationships.get(relId);
    if (relationship?.type.endsWith("/slide") && entries[relationship.path]) {
      paths.push(relationship.path);
    }
  }

  if (paths.length > 0) return paths;
  return Object.keys(entries)
    .filter((path) => /^ppt\/slides\/slide\d+\.xml$/.test(path))
    .sort(compareSlidePaths);
}

// The `p:sldId` ids of the imported slides, aligned with `slidePaths`; empty
// when the slides were listed from the package rather than `p:sldIdLst`.
function slideIdsInOrder(presentationRoot, relationships, entries, slidePaths) {
  const ids = [];
  for (const slideId of asArray(presentationRoot["p:sldIdLst"]?.["p:sldId"])) {
    const relationship = relationships.get(slideId?.["r:id"]);
    if (relationship?.type.endsWith("/slide") && entries[relationship.path]) ids.push(String(slideId?.id ?? ""));
  }
  return ids.length === slidePaths.length ? ids : slidePaths.map(() => "");
}

function compareSlidePaths(left, right) {
  return slideNumber(left) - slideNumber(right) || (left < right ? -1 : left > right ? 1 : 0);
}

function slideNumber(path) {
  return Number(path.match(/slide(\d+)\.xml$/)?.[1] ?? 0);
}

function readCoreProperties(entries) {
  const doc = entries["docProps/core.xml"] ? parseRequiredXml(entries, "docProps/core.xml", coreTextParser) : null;
  const core = doc?.["cp:coreProperties"] ?? {};
  return {
    title: scalarText(core["dc:title"]),
    description: scalarText(core["dc:description"] ?? core["dc:subject"]),
    author: scalarText(core["dc:creator"])
  };
}

// FA-13: the code family of the imported design's font scheme (a run in it is an inline code run). The scheme's own `code` role,
// else that of the record the reference resolves to (in the imported document or the host's registered catalogs), else the
// engine default's; heading and body families are never code. Only a package the exporter wrote (it carries OPF tag parts) is
// read this way; a deck from another tool keeps its runs' font families as they are.
function importedCodeFamily(imported, catalogs) {
  const reference = imported.design?.fontScheme;
  const id = referenceId(reference);
  const found = id ? resolveReference(imported, "fontSchemes", id, {catalogs: catalogs ?? []}) : undefined;
  return resolveFontFamilies({...(found ? found.record : ENGINE_DEFAULT_FONT_SCHEME), ...(isPlainObject(reference) ? reference : {})}).code;
}

function dimensionsFromPresentation(presentationRoot) {
  const size = presentationRoot["p:sldSz"];
  const width = emuToInches(size?.cx);
  const height = emuToInches(size?.cy);
  if (!width || !height) return null;
  return {
    widthInches: width,
    heightInches: height
  };
}

function importSlide(entries, slidePath, slideIndex, presentationDimensions, options, furniture, nativeContext) {
  const slideRoot = nativeContext.root;
  const relationships = nativeContext.relationships;
  const dimensions = presentationDimensions ?? DIMENSION_PRESETS.widescreen;
  const slide = {};
  if (slideRoot.show === "0") slide.hidden = true;

  const background = importBackground(slidePath, resolveCanvasDimensions(dimensions), {
    part: (path, parser) => parseRequiredXml(entries, path, parser), relationships: path => parseRelationships(entries, path), bytes: path => entries[path]
  }, diagnostic => options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}.design.background`}));
  // FA-23: tagged image pictures and overlays (OPF_IMAGE_V1, OPF_IMAGE_OVERLAY_V1). An unchanged full-slide back picture is
  // the slide's image background (its native fill is then only the canvas colour); an unchanged overlay of a native image
  // background fill joins that background; an unchanged image block picture returns its treatment and placement.
  const images = importImages({pictures: nativeContext.pictures, shapes: nativeContext.shapes, relationships, entries, slideIndex,
    readPicture: picture => importPicture(entries, picture, slidePath, relationships, diagnostic => {
      // The recorded crop, fit and focus are re-derived from the restored background.
      if (diagnostic.code !== 'unsupported-image-crop') options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}.design.background`});
    }),
    mediaKeyOf: picture => { const bytes = entries[relationships.get(picture?.['p:blipFill']?.['a:blip']?.['r:embed'])?.path]; return bytes ? mediaKey(bytes) : undefined; },
    valid: (kind, value) => isValidFormat({slides: [kind === 'background' ? {design: {background: value}} : {blocks: [value]}]}),
    report: diagnostic => options.onDiagnostic?.(diagnostic)});
  const imageBackground = images.background ?? (background?.type === 'image' && images.backgroundOverlay ? {...background, overlay: images.backgroundOverlay} : background);
  if (images.backgroundOverlay && imageBackground === background) {
    images.consumedShapes.delete(images.backgroundOverlayShape);
    options.onDiagnostic?.({code: 'invalid-image-provenance', path: `slides.${slideIndex}.design.background.overlay`, message: 'The tagged OPF background overlay no longer sits on an image background; it was imported as an ordinary shape.'});
  }
  // RR-96, LH-02: core's automatic scrims of a picture background are no content; under RR-96's name it restores the background's tone.
  let toned = imageBackground;
  if (imageBackground?.type === 'image') {
    const opfSlide = `slides.${slideIndex}`;
    nativeContext.shapes.forEach((shape, index) => {
      const name = shape['p:nvSpPr']?.['p:cNvPr']?.name;
      if (typeof name !== 'string') return;
      if (isScrimName(name, scrimName(opfSlide))) images.consumedShapes.add(index);
      for (const tone of ['dark', 'light']) if (isScrimName(name, toneScrimName(opfSlide, tone))) { images.consumedShapes.add(index); toned = {...imageBackground, tone}; }
    });
  }
  if (toned) slide.design = {background: toned};
  // RR-96: a slide's own color map override (accents included) is its variant. An override that is the master's map imports nothing, one that is
  // the default map on a dark master is the explicit `light1`.
  {
    const {mapping, masterMapping} = readSlideTheme(slidePath, {
      part: (path, parser) => parseRequiredXml(entries, path, parser), relationships: path => parseRelationships(entries, path), bytes: path => entries[path]
    });
    const sameMap = [...new Set([...Object.keys(mapping), ...Object.keys(masterMapping)])].every(key => mapping[key] === masterMapping[key]);
    if (!sameMap) {
      const mapped = variantFromColorMap(mapping, {explicit: true});
      // The variant a tone names is the tone's, not a second statement of it.
      const tone = slide.design?.background?.tone, impliedByTone = tone && mapped.variant === (tone === 'dark' ? 'dark1' : 'light1');
      if (impliedByTone) { /* the tone names this variant */ }
      else if (mapped.variant) slide.design = {...slide.design, variant: mapped.variant};
      else if (mapped.unsupported) options.onDiagnostic?.({code: "unsupported-color-map", path: `slides.${slideIndex}.design.variant`, message: "The slide's color map override is not a variant OPF can name, so slides[n].design.variant was not imported."});
    }
  }
  if (Object.keys(furniture.design).length) slide.design = {...slide.design, ...furniture.design};
  const callouts = importImageCallouts({shapes: nativeContext.shapes, paragraphs: nativeContext.paragraphs, pictures: nativeContext.pictures, relationships, entries, validPictures: images.blocks, report: diagnostic => options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}.image.callouts`})});
  for (const index of callouts.consumed) images.consumedShapes.add(index);
  nativeContext.imageCallouts = callouts.values;
  nativeContext.imageBlocks = images.blocks;
  nativeContext.imageSources = images.sources;
  nativeContext.imagePictures = images.consumed;
  // An overlay of a background that was not recovered stays an ordinary shape.
  nativeContext.imageShapes = images.consumedShapes;
  const watermarkPath = `slides.${slideIndex}.design.watermark`;
  // FA-13: a text watermark is a tagged native text box; it is not content and never imports as a text block.
  const textWatermark = importTextWatermark(nativeContext.shapes, nativeContext.paragraphs.map(shapeParagraphs => shapeParagraphs.map(paragraph => ({text: paragraph.text}))), relationships, entries, slideIndex,
    diagnostic => options.onDiagnostic?.({...diagnostic, path: watermarkPath}));
  if (textWatermark.design) slide.design = {...slide.design, ...textWatermark.design};
  nativeContext.watermarkShapes = textWatermark.consumed;
  const watermark = importWatermark(nativeContext.pictures, relationships, entries, slideIndex,
    picture => importPicture(entries, picture, slidePath, relationships, diagnostic => {
      // The recorded fit is re-derived from design.watermark.
      if (diagnostic.code !== 'unsupported-image-crop') options.onDiagnostic?.({...diagnostic, path: watermarkPath});
    }),
    diagnostic => options.onDiagnostic?.({...diagnostic, path: watermarkPath}));
  if (watermark.design) slide.design = {...slide.design, ...watermark.design};
  nativeContext.watermarkPictures = watermark.consumed;
  // The generated cover logo picture is not content; the logo returns from the stored organization (or, without one, from the picture).
  const logoPath = `slides.${slideIndex}.design.logo`;
  const logo = importLogo(nativeContext.pictures, relationships, entries, slideIndex,
    picture => importPicture(entries, picture, slidePath, relationships, diagnostic => {
      if (diagnostic.code !== 'unsupported-image-crop') options.onDiagnostic?.({...diagnostic, path: logoPath});
    }),
    diagnostic => options.onDiagnostic?.({...diagnostic, path: logoPath}));
  nativeContext.logoPictures = logo.consumed;
  nativeContext.logoPlaceholderShapes = importLogoPlaceholders(nativeContext.shapes, relationships, entries, slideIndex);
  nativeContext.logoFallback = logo.fallback;

  const items = collectSlideItems(entries, slideRoot, slidePath, relationships, dimensions, options, slideIndex, furniture, nativeContext)
    .sort(comparePositionedItems);
  // Complete OPF heading roles are authoritative. Nearby body lines must not
  // fill an absent role by geometry; explicit native placeholders still apply.
  const inferHeadings = !items.some(item => item.heading||item.sourceText);
  const heading = field => {const index=items.findIndex(item=>item.heading===field);return index<0?null:items.splice(index,1)[0];};
  // FA-10: a heading is its plain text, or TextRun[] when its native runs are formatted differently from one another (the way
  // body text reads current native runs). A tagged line group brings its own value; one native shape (a title placeholder, or the
  // shape the importer took for the title) is read through the native body reader.
  const headingText = item => {
    const key = item.sources?.length === 1 ? /^sp:(\d+)$/.exec(item.sources[0]) : null;
    const parts = item.richText === undefined && key ? joinRichLines([{index: Number(key[1])}], nativeContext.readBody, () => '') : undefined;
    const value = item.richText ?? (parts ? headingValue(parts) : undefined);
    // Only when it reads as the same words as the plain path: the native text is authoritative.
    return Array.isArray(value) && value.map(run => typeof run === 'string' ? run : run.text).join('') === item.text ? value : item.text;
  };
  const tagItem=heading('tag');
  if(tagItem)slide.tag=headingText(tagItem);
  const titleItem = heading('title')??takeTitleItem(items, dimensions, inferHeadings);
  if (titleItem) slide.title = headingText(titleItem);
  const subtitleItem = heading('subtitle')??takeSubtitleItem(items, titleItem, dimensions, inferHeadings);
  if (subtitleItem) slide.subtitle = headingText(subtitleItem);

  // Heading inference keeps its existing scalar/native metrics. Only remaining
  // ordinary body shapes gain current rich values; tagged recovery is separate.
  for (const item of items) if (item.readNativeBody) {
    const current = item.readNativeBody();
    if (current) {
      item.paragraphs = withDisplayedNumbers(current.map((paragraph, index) => ({...item.paragraphs[index], ...paragraph})));
      item.text = current.map(paragraph => paragraph.text).join('\n');
      if (item.paragraphs.some(paragraph => paragraph.bullet) && item.paragraphs.some(paragraph => !paragraph.bullet))
        options.onDiagnostic?.({code: 'mixed-body-paragraphs', path: `slides.${slideIndex}`, message: 'A native body mixes bulleted and plain paragraphs; current text is retained as list entries because OPF has no mixed-paragraph body model.'});
    }
  }
  const listRecord = slideListRecord(entries, slidePath, slideRoot, relationships, diagnostic => options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}`}));
  nativeContext.listScalars = listRecord.scalars;
  const content = mergeAdjacentBulletShapes(restoreStepNumbers(mergeOpfListShapes(items, listRecord.breaks, diagnostic => options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}`}), listRecord.runs, listRecord.roles), nativeContext.stepNumbers))
    .map((item) => ({payload: payloadFromSlideItem(item, diagnostic => options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}`})), bounds: item.visualBounds ?? item.bounds, sources: item.sources ?? [], inferredStretch: item.inferredStretch}))
    .filter((entry) => entry.payload);
  const blocks = content.map((entry) => entry.payload);
  // RR-81: the region of each block read from one region placeholder of the slide's 0.19 template layout (its p:ph idx).
  if (nativeContext.layoutTag) {
    const frames = asArray(slideRoot['p:cSld']?.['p:spTree']?.['p:graphicFrame']);
    const nodeOf = source => {
      const [kind, position] = source.split(':');
      return kind === 'sp' ? nativeContext.shapes[position] : kind === 'pic' ? nativeContext.pictures[position] : kind === 'frame' ? frames[position] : undefined;
    };
    nativeContext.blockRegions = content.map(entry => {
      const regions = new Set(entry.sources.map(source => placeholderRegion(nodeOf(source), nativeContext.layoutTag)));
      return regions.size === 1 ? [...regions][0] : undefined;
    });
  }
  // RR-34: a tagged caption re-attaches to the block whose native media shape it names (never by position).
  const annotations = nativeContext.annotations;
  if (annotations?.captions.size) {
    const tree = slideRoot['p:cSld']?.['p:spTree'];
    const shapeName = node => scalarText(node?.['p:nvSpPr']?.['p:cNvPr']?.name ?? node?.['p:nvPicPr']?.['p:cNvPr']?.name ?? node?.['p:nvGraphicFramePr']?.['p:cNvPr']?.name).trim();
    const keyByName = new Map();
    nativeContext.shapes.forEach((shape, index) => keyByName.set(shapeName(shape), `sp:${index}`));
    nativeContext.pictures.forEach((picture, index) => keyByName.set(shapeName(picture), `pic:${index}`));
    asArray(tree?.['p:graphicFrame']).forEach((frame, index) => keyByName.set(shapeName(frame), `frame:${index}`));
    asArray(tree?.['mc:AlternateContent']).forEach((alternate, index) => { for (const node of [...asArray(alternate?.['mc:Choice']), ...asArray(alternate?.['mc:Fallback'])]) if (node?.['p:graphicFrame']) keyByName.set(shapeName(node['p:graphicFrame']), `alt:${index}`); });
    for (const [mediaName, caption] of annotations.captions) {
      const key = keyByName.get(mediaName);
      const entry = key === undefined ? undefined : content.find(item => item.sources.includes(key));
      if (!entry || !['image', 'chart', 'table', 'video', 'diagram'].includes(inferPayloadKind(entry.payload))) {
        options.onDiagnostic?.({code: 'caption-detached', path: `slides.${slideIndex}`, message: `The caption of ${caption.path} no longer has its media shape (${mediaName}); its text is imported as an ordinary text block.`});
        blocks.push({type: 'text', text: caption.value});
        continue;
      }
      entry.payload.caption = captionValue(caption);
    }
  }
  if (blocks.length > 0) slide.blocks = blocks;
  // Native bounds of each block in reference px, for content topology matching (document provenance).
  // Which native shapes fed each field and block (import signals); never part of the document.
  nativeContext.signalSources = {tag: tagItem?.sources ?? [], title: titleItem?.sources ?? [], subtitle: subtitleItem?.sources ?? [],
    blocks: content.map(entry => ({sources: entry.sources, type: entry.payload.type})), roles: nativeContext.signalRoles ?? new Map()};
  nativeContext.inferredImageFits = content.flatMap((entry,index)=>entry.inferredStretch?[index]:[]);
  nativeContext.contentBounds = content.map((entry) => entry.bounds ? {x: entry.bounds.x * 96, y: entry.bounds.y * 96, width: entry.bounds.w * 96, height: entry.bounds.h * 96} : null);

  const notes = readSlideNotes(entries, relationships);
  if (notes) slide.notes = notes;

  return slide;
}

const nativePictures = tree => [...asArray(tree?.['p:pic']), ...asArray(tree?.['p:grpSp']).flatMap(nativePictures)];

function collectSlideItems(entries, slideRoot, slidePath, relationships, dimensions, options, slideIndex, furniture, nativeContext) {
  const tree = slideRoot["p:cSld"]?.["p:spTree"];
  const items = [];
  const shapes = nativeContext.shapes;
  // opf-pptx#221: an exported image placeholder group (identity transform) is not a reflow risk.
  const paragraphs = nativeContext.paragraphs;
  // FF-45: OMML equations (a14:m math zones) have no OPF model. Their fallback text is imported as plain text; the equation
  // layout (fractions, radicals, limits, matrices) is lost, and that loss is diagnosed per shape instead of passing silently.
  paragraphs.forEach((list, index) => {
    const zones = list.reduce((count, paragraph) => count + (paragraph.math?.zones ?? 0), 0);
    if (zones) options.onDiagnostic?.({code: 'math-equation-flattened', path: `slides.${slideIndex}`, message: `Native shape ${index} holds ${zones} OMML equation${zones === 1 ? '' : 's'} (a14:m); OPF has no equation model, so its fallback text is imported as plain text and the equation layout is not represented.`});
  });
  // Native shape keys (indexes in nativeTextShapes / nativePictures / frame order) for import signals.
  const shapeKeys = new Map(shapes.map((shape, index) => [shape, `sp:${index}`]));
  const sourcesOf = group => group.flatMap(shape => shapeKeys.has(shape) ? [shapeKeys.get(shape)] : []);
  const roles = new Map();
  nativeContext.signalRoles = roles;
  const readBody = nativeBodyReader(slidePath, {
    part: (path, parser) => options.nativeLanguages?.has(path) ? parser.parse(decodeText(options.nativeLanguages.get(path))) : parseRequiredXml(entries, path, parser), relationships: path => parseRelationships(entries, path), bytes: path => entries[path]
  }, relationships, diagnostic => options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}.${diagnostic.path}`}), {deckLang: options.deckLang, codeFamily: options.codeFamily, rtlDeck: options.rtlDeck === true});
  const code = importCodeGroups(shapes, paragraphs, relationships, entries, diagnostic => options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}.code`}));
  const metric = importMetricGroups(shapes, paragraphs, relationships, entries, diagnostic => options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}.metric`}));
  const cards = importCardFrames(shapes, paragraphs, relationships, entries, diagnostic => options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}`}));
  const media = importMediaGroups(shapes, paragraphs, relationships, entries, slideIndex, diagnostic => options.onDiagnostic?.(diagnostic), nativeContext.mediaRegistry);
  nativeContext.mediaAssets = media.assets;
  nativeContext.readBody=readBody;
  const headings=importHeadingGroups(shapes,paragraphs,relationships,entries,diagnostic=>options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}`}),readBody);
  const plainText=importPlainTextGroups(shapes,paragraphs,relationships,entries,diagnostic=>options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}`}),readBody);
  const timelines=importTimelineGroups(shapes,paragraphs,relationships,entries,diagnostic=>options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}`}));
  // LH-108 to LH-110: a chart's value list, stacked names and reference marks are its defaults, not content.
  const chartMarks=importChartMarks(shapes,relationships,entries);
  // LH-07: a sequence region's badges, connectors, chips and arrows are its layout's drawing, not content.
  const stepShapes=importStepShapes(shapes,relationships,entries);
  nativeContext.stepNumbers=stepShapes.numbers;
  // SH-09: a pyramid's or matrix's native nodes (OPF_ARRANGEMENT_V1) are its layout's drawing, not content.
  const arrangementShapes=importArrangementShapes(shapes,relationships,entries);
  // LH-14: an icon's chip, glyph and picture are the drawing of its `icon`, not content; the references go back on the document.
  const iconShapes=importIconShapes([...shapes,...(nativeContext.pictures??[])],relationships,entries);
  nativeContext.iconReferences=iconShapes.references;
  // LH-130: a cover's or section's title rule is its layout's drawing, not content.
  const titleRules=importTitleRules(shapes,relationships,entries);
  const quotes=importQuoteGroups(shapes,paragraphs,relationships,entries,diagnostic=>options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}.quote`}),nativeContext.pictures,
    picture=>importPicture(entries,picture,slidePath,relationships,diagnostic=>{
      // The recorded crop is re-derived from the circular frame of the quote photo.
      if(diagnostic.code!=='unsupported-image-crop')options.onDiagnostic?.({...diagnostic,path:`slides.${slideIndex}.quote.photo`});
    }),readBody);
  // RR-34: tagged caption and footnote lines are not content; captions re-attach to their media block and notes rebuild cite/footnote.
  const annotations=importAnnotations({shapes,paragraphs,relationships,entries,slideIndex,readBody,report:diagnostic=>options.onDiagnostic?.(diagnostic)});
  nativeContext.annotations=annotations;
  for(const group of [...headings.items,...plainText.items]) {
    const item=importShape(group.shapes[0],dimensions,group.paragraphs,true);
    if(item){
      const bounds=group.shapes.map(shape=>shapeBounds(shape['p:spPr']?.['a:xfrm'])).filter(Boolean);
      if(bounds.length){const x=Math.min(...bounds.map(b=>b.x)),y=Math.min(...bounds.map(b=>b.y));item.bounds={x,y,w:Math.max(...bounds.map(b=>b.x+b.w))-x,h:Math.max(...bounds.map(b=>b.y+b.h))-y};}
      items.push({...item,heading:group.field,sourceText:!group.field,sources:sourcesOf(group.shapes),...(group.richText!==undefined?{richText:group.richText}:{})});
    }
  }
  for(const group of timelines.items){
    const bounds=group.shapes.map(shape=>shapeBounds(shape['p:spPr']?.['a:xfrm'])).filter(Boolean);
    let union;for(const bound of bounds){if(!union)union={...bound};else{const x=Math.min(union.x,bound.x),y=Math.min(union.y,bound.y);union={x,y,w:Math.max(union.x+union.w,bound.x+bound.w)-x,h:Math.max(union.y+union.h,bound.y+bound.h)-y};}}
    items.push({kind:'timeline',sourceText:true,bounds:union,payload:group.payload,sources:sourcesOf(group.shapes)});
  }
  for(const group of quotes.items){
    const bounds=[...group.shapes.map(shape=>shapeBounds(shape['p:spPr']?.['a:xfrm'])),...group.pictures.map(picture=>shapeBounds(picture['p:spPr']?.['a:xfrm']))].filter(Boolean);
    let union;for(const bound of bounds){if(!union)union={...bound};else{const x=Math.min(union.x,bound.x),y=Math.min(union.y,bound.y);union={x,y,w:Math.max(union.x+union.w,bound.x+bound.w)-x,h:Math.max(union.y+union.h,bound.y+bound.h)-y};}}
    items.push({kind:'quote',bounds:union,payload:group.payload,sources:[...sourcesOf(group.shapes),...group.pictures.map(picture=>`pic:${nativeContext.pictures.indexOf(picture)}`)]});
  }
  for (const item of code.items) items.push({kind:'code',bounds:shapeBounds(item.shape['p:spPr']?.['a:xfrm']),payload:item.payload,sources:sourcesOf([item.shape])});
  for (const item of metric.items) items.push({kind:'metric',bounds:shapeBounds(item.shape['p:spPr']?.['a:xfrm']),payload:item.payload,sources:sourcesOf([item.shape])});
  for (const item of media.items) items.push({kind:'media',sourceText:item.payload.type==='text',bounds:shapeBounds(item.shape['p:spPr']?.['a:xfrm']),payload:item.payload,sources:sourcesOf([item.shape])});
  // opf-pptx#221: a tagged unavailable-image placeholder is its image block again; its panel and label shapes are consumed.
  const placeholders = importImagePlaceholders({shapes, relationships, entries, slideIndex, valid: payload => isValidFormat({slides: [{blocks: [payload]}]}), report: diagnostic => options.onDiagnostic?.(diagnostic)});
  for (const item of placeholders.items) {
    for (const member of item.members) roles.set(`sp:${member}`, 'image');
    items.push({kind: 'image', bounds: shapeBounds(shapes[item.panel]['p:spPr']?.['a:xfrm']), payload: item.payload, sources: item.members.map(member => `sp:${member}`)});
  }
  // A tagged, unchanged diagram picture (or an intact unavailable-diagram placeholder) is its diagram block again (OPF_DIAGRAM_V1).
  const diagrams = importDiagrams({pictures: nativeContext.pictures, shapes, paragraphs, relationships, entries, slideIndex,
    valid: payload => isValidFormat({slides: [{blocks: [payload]}]}), report: diagnostic => options.onDiagnostic?.(diagnostic)});
  for (const [index, payload] of diagrams.shapes) {
    items.push({kind: 'diagram', bounds: shapeBounds(shapes[index]['p:spPr']?.['a:xfrm']), payload, sources: [`sp:${index}`]});
  }
  // SH-05: the drawn shapes in z order, with their frames on the slide (groups flattened); shapes and connectors the importer keeps as OPF shapes.
  const drawnAll = readDrawnShapes(decodeText(entries[slidePath]));
  const drawnShapes = new Map(drawnAll.filter(entry => entry.tag === 'p:sp').map(entry => [entry.index, entry]));
  const slideTheme = readSlideTheme(slidePath, {part: (path, parser) => parseRequiredXml(entries, path, parser), relationships: path => parseRelationships(entries, path), bytes: path => entries[path]});
  const shapeContext = {width: nativeContext.slideWidth, height: nativeContext.slideHeight, scale: Math.min(nativeContext.slideWidth, nativeContext.slideHeight) / 9525 / 720, rtl: options.rtlDeck === true,
    mapping: slideTheme.mapping, format: slideTheme.format, relationships, report: diagnostic => options.onDiagnostic?.(diagnostic), slideIndex, state: nativeContext.shapeImport = {overlays: [], connectors: [], resolve: nativeColorResolver(slideTheme), ...nativeShapeNames(shapes, nativeContext.pictures ?? [])}};
  // SH-07: an intact diagram group (diagrams: "shapes") is its diagram block again; its member shapes are its drawing, not content.
  const diagramMembers = new Set(), intactDiagramGroups = new Set();
  for (const {group, payload} of importDiagramGroups({groups: asArray(tree?.['p:grpSp']), relationships, entries, slideIndex,
    valid: candidate => isValidFormat({slides: [{blocks: [candidate]}]}), report: diagnostic => options.onDiagnostic?.(diagnostic)})) {
    intactDiagramGroups.add(group);
    const members = nativeTextShapes(group);
    for (const member of members) { diagramMembers.add(member); roles.set(shapeKeys.get(member), 'diagram'); }
    items.push({kind: 'diagram', bounds: shapeBounds(group['p:grpSpPr']?.['a:xfrm']), payload, sources: sourcesOf(members)});
  }
  for (const [index,shape] of shapes.entries()) {
    const role = furniture.text.has(index) ? 'furniture' : nativeContext.imageShapes?.has(index) ? 'image-overlay' : nativeContext.watermarkShapes?.has(index) ? 'watermark' : nativeContext.logoPlaceholderShapes?.has(index) ? 'logo' : cards.has(shape) ? 'card-frame'
      : code.consumed.has(shape) ? 'code' : metric.consumed.has(shape) ? 'metric' : media.consumed.has(shape) ? 'media' : timelines.consumed.has(shape) ? 'timeline' : quotes.consumed.has(shape) ? 'quote' : undefined;
    if (role) roles.set(shapeKeys.get(shape), role);
    if (furniture.text.has(index) || nativeContext.imageShapes?.has(index) || nativeContext.watermarkShapes?.has(index) || nativeContext.logoPlaceholderShapes?.has(index) || placeholders.consumed.has(index) || diagrams.shapes.has(index) || diagramMembers.has(shape)) continue;
    if (annotations.consumed.has(shape)) { roles.set(shapeKeys.get(shape), 'annotation'); continue; }
    if (chartMarks.consumed.has(shape)) { roles.set(shapeKeys.get(shape), 'chart-mark'); continue; }
    if (stepShapes.consumed.has(shape)) { roles.set(shapeKeys.get(shape), 'step-badge'); continue; }
    if (arrangementShapes.has(shape)) { roles.set(shapeKeys.get(shape), 'arrangement'); continue; }
    if (iconShapes.consumed.has(shape)) { roles.set(shapeKeys.get(shape), 'icon'); continue; }
    if (titleRules.has(shape)) { roles.set(shapeKeys.get(shape), 'title-rule'); continue; }
    if (code.consumed.has(shape)||metric.consumed.has(shape)||cards.has(shape)||media.consumed.has(shape)||headings.consumed.has(shape)||plainText.consumed.has(shape)||timelines.consumed.has(shape)||quotes.consumed.has(shape)) continue;
    // RR-81: a placeholder with no text (no runs, or only empty paragraphs) is PowerPoint's prompt ("Click to add text" on a slide
    // added from a layout), not content. A picture, chart or table in a placeholder is a p:pic or p:graphicFrame, read below.
    if (shape['p:nvSpPr']?.['p:nvPr']?.['p:ph'] !== undefined && !(paragraphs[index] ?? []).some(paragraph => paragraph.text)) { roles.set(shapeKeys.get(shape), 'prompt'); continue; }
    // SH-05: a shape that draws something (or that the exporter wrote as a shape block or overlay) is an OPF shape, not text.
    const drawnShape = drawnShapes.get(index);
    const shapeKind = drawnShape ? shapeRole(drawnShape, {hasText: (paragraphs[index] ?? []).some(paragraph => paragraph.text)}) : 'text';
    if (shapeKind !== 'text') {
      const imported = importNativeShape(drawnShape, shapeKind, {...shapeContext, text: shapeText(readBody(index), diagnostic => options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}.shapes.${index}.text`}))});
      roles.set(shapeKeys.get(shape), shapeKind === 'block' ? 'shape' : 'overlay');
      if (imported) items.push({...imported, sources: [`sp:${index}`]});
      continue;
    }
    const ordinaryBody = Object.hasOwn(shape, 'p:txBody') && (!shape['p:nvSpPr']?.['p:nvPr']?.['p:custDataLst']?.['p:tags'] || onlyNativeLanguageTags(shape, relationships, entries));
    const item = importShape(shape, dimensions, paragraphs[index], ordinaryBody || furniture.taggedText.has(index) || media.captionShapes.has(shape));
    if (item && ordinaryBody) {
      const currentBody = readBody(index, {onlyScaled: true});
      item.readNativeBody = () => currentBody ?? readBody(index);
      // A saved scale also governs native heading/list size comparisons. Only
      // scaled bodies use resolved sizes here; ordinary classification is unchanged.
      if (currentBody?.some(paragraph => paragraph.nativeFontScale !== undefined)) {
        const pointSize = paragraph => Math.max(0, ...asArray(paragraph?.richText).filter(run => run && typeof run === 'object' && run.text?.trim()).map(run => run.fontSize ?? 0));
        item.paragraphs = item.paragraphs.map((paragraph, paragraphIndex) => ({...paragraph, maxFontSize: pointSize(currentBody[paragraphIndex])}));
        item.maxFontSize = Math.max(0, ...item.paragraphs.map(paragraph => paragraph.maxFontSize));
      }
    }
    if (item && !item.bounds && nativeContext.layoutBounds) item.bounds = nativeContext.layoutBounds(shape) ?? item.bounds;
    // A damaged/edited furniture group falls back to current native text,
    // including cleared text boxes, without inventing a title or shape label.
    if (item && (furniture.taggedText.has(index) || media.captionShapes.has(shape))) item.sourceText = true;
    if (item) items.push({...item, sources: [`sp:${index}`]});
  }

  // SH-07 with SH-05: the glued edges of an intact diagram group are the diagram's drawing, not overlay connectors.
  const intactDiagramIndexes = new Set([...intactDiagramGroups].map(group => asArray(tree?.['p:grpSp']).indexOf(group)));
  const drawnOutsideDiagrams = drawnAll.filter(entry => entry.group === undefined || !intactDiagramIndexes.has(entry.group));
  importNativeConnectors(drawnOutsideDiagrams, shapeContext);
  // SH-05: an overlay shape PowerPoint drew behind a text box or a picture is in the back layer.
  settleLayers(drawnOutsideDiagrams.flatMap(entry => {
    if (entry.tag === 'p:pic' || entry.tag === 'p:graphicFrame') return [{z: entry.z, frame: entry.frame, name: entry.tag === 'p:pic' ? 'picture' : 'table or chart'}];
    const index = entry.tag === 'p:sp' ? entry.index : undefined;
    return index !== undefined && (paragraphs[index] ?? []).some(paragraph => paragraph.text) && shapeRole(entry, {hasText: true}) === 'text' ? [{z: entry.z, frame: entry.frame, name: String(entry.props?.['p:nvSpPr']?.['p:cNvPr']?.name ?? 'text')}] : [];
  }), shapeContext);
  // opf-pptx#221, SH-05: an exported image placeholder group (identity transform) is not a reflow risk, and nor is a group of shapes and connectors, which are
  // imported with their transforms applied; grouped text and pictures keep their untransformed bounds.
  const groupAtRisk = group => !['p:sp', 'p:cxnSp', 'p:pic', 'p:graphicFrame', 'p:grpSp'].some(tag => asArray(group?.[tag]).length) || ['p:pic', 'p:graphicFrame'].some(tag => asArray(group?.[tag]).length) || asArray(group?.['p:sp']).some(member => {
    const index = shapes.indexOf(member), drawnMember = drawnShapes.get(index);
    return !drawnMember || shapeRole(drawnMember, {hasText: (paragraphs[index] ?? []).some(paragraph => paragraph.text)}) === 'text';
  }) || asArray(group?.['p:grpSp']).some(groupAtRisk);
  if (asArray(tree?.['p:grpSp']).some(group => !isImagePlaceholderGroup(group) && !intactDiagramGroups.has(group) && groupAtRisk(group))) options.onDiagnostic?.({code:'grouped-text-reflow',path:`slides.${slideIndex}`,message:'Grouped native text and pictures are retained, but group transforms and unsupported group members are not reconstructed; review the reflowed OPF.'});
  const frames = asArray(tree?.["p:graphicFrame"]);
  // RR-35: what a chart's axis titles, legend and data labels cannot express in OPF is reported on the chart's path.
  const chartReport = label => diagnostic => options.onDiagnostic?.({code: 'chart-option-adapted', ...diagnostic, path: `slides.${slideIndex}.${label}.${diagnostic.option}`});
  const tables = frames.some(frame => frame['a:graphic']?.['a:graphicData']?.['a:tbl'])
    ? importTableFrames(slidePath, {
      part: (path, parser) => parseRequiredXml(entries, path, parser), relationships: path => parseRelationships(entries, path), bytes: path => entries[path]
    }, relationships, (frame, cell, code, message) => options.onDiagnostic?.({code, message, path: `slides.${slideIndex}.tables.${frame}${cell ? '.' + cell : ''}`}), dimensions, {rtlDeck: options.rtlDeck === true}) : [];
  // RR-54: chart and table data records (OPF_DATA_V1) restore against the stored datasets; their diagnostics name the frame.
  const dataContext = label => ({datasets: options.dataProvenance?.datasets, markedCharts: chartMarks.charts, report: (kind, diagnostic) => options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}.${kind === 'table' ? 'tables' : 'charts'}.${label}`})});
  // SH-09: a Basic Pyramid or Basic Matrix SmartArt (OPF's or PowerPoint's) is its list again, on the pyramid or matrix layout (src/smart-art.js);
  // SH-08: any SmartArt is a list (an arrangement's layout, the list or the process layout), a Mermaid hierarchy, or its drawing as overlay shapes.
  const smartArt = importSmartArt({frames, relationships, entries, slideIndex, report: diagnostic => options.onDiagnostic?.(diagnostic)});
  const addSmartArt = (found, xfrm, source) => {
    if (found.type === 'list') {
      if (!nativeContext.layoutTag && nativeContext.smartArtLayout === undefined) nativeContext.smartArtLayout = found.layout;
      items.push({kind: 'list', bounds: shapeBounds(xfrm), payload: found.payload, sources: [source]});
    } else if (found.type === 'diagram') items.push({kind: 'diagram', bounds: shapeBounds(xfrm), payload: found.payload, sources: [source]});
    else if (found.type === 'shapes') {
      // The drawing takes the frame's place in the slide's z order.
      const at = drawnAll.find(entry => entry.tag === 'p:graphicFrame' && entry.frame && ['x', 'y', 'cx', 'cy'].every(key => entry.frame[key] === found.frame[key]));
      importSmartArtShapes(found, {context: shapeContext, z: at?.z ?? Math.max(0, ...drawnAll.map(entry => entry.z)) + 1});
    }
  };
  for (const [index, frame] of frames.entries()) {
    if (smartArt.has(index)) {
      roles.set(`frame:${index}`, 'smartart');
      addSmartArt(smartArt.get(index), frame['p:xfrm'], `frame:${index}`);
      continue;
    }
    const item = importGraphicFrame(entries, frame, slidePath, relationships, tables[index], chartReport(`charts.${index}`), dataContext(index));
    if (item) items.push({...item, sources: [`frame:${index}`]});
  }
  // A chartex chart is an mc:AlternateContent: the choice frame references the cx:chartSpace part; the fallback is a classic chart frame
  // (this exporter) or a text shape (PowerPoint). The choice is read first and the fallback only when it names no OPF chart type.
  for (const [alternateIndex, alternate] of asArray(tree?.["mc:AlternateContent"]).entries()) {
    const choice = asArray(alternate?.["mc:Choice"]).map((node) => node?.["p:graphicFrame"]).find(Boolean);
    // SH-16: a SmartArt frame wrapped with its fallback picture is read from the mc:Choice, as an unwrapped frame (SH-09).
    const wrapped = choice ? importSmartArt({frames: [choice], relationships, entries, slideIndex, report: diagnostic => options.onDiagnostic?.(diagnostic)}).get(0) : undefined;
    if (wrapped) {
      roles.set(`alt:${alternateIndex}`, 'smartart');
      addSmartArt(wrapped, choice['p:xfrm'], `alt:${alternateIndex}`);
      continue;
    }
    const fallback = asArray(alternate?.["mc:Fallback"]).map((node) => node?.["p:graphicFrame"]).find(Boolean);
    const chosen = choice ? importGraphicFrame(entries, choice, slidePath, relationships, undefined, chartReport(`charts.alt${alternateIndex}`), dataContext(`alt${alternateIndex}`)) : null;
    const item = chosen?.payload?.type === "chart" ? chosen : fallback ? importGraphicFrame(entries, fallback, slidePath, relationships, undefined, chartReport(`charts.alt${alternateIndex}`), dataContext(`alt${alternateIndex}`)) : chosen;
    if (item && item.kind !== "unknown") items.push({...item, sources: [`alt:${alternateIndex}`]});
  }

  // SH-16: a SmartArt's fallback picture without its frame (a file another app saved) is its list again, through its OPF_SMARTART_V1 record.
  const smartArtPictures = importSmartArtFallbacks({pictures: nativeContext.pictures, relationships, entries, slideIndex, report: diagnostic => options.onDiagnostic?.(diagnostic)});
  for (const [index, picture] of nativeContext.pictures.entries()) {
    if (smartArtPictures.has(index)) {
      const found = smartArtPictures.get(index);
      roles.set(`pic:${index}`, 'smartart');
      if (!nativeContext.layoutTag && nativeContext.smartArtLayout === undefined) nativeContext.smartArtLayout = found.layout;
      items.push({kind: 'list', bounds: shapeBounds(found.frame), payload: found.payload, sources: [`pic:${index}`]});
      continue;
    }
    const pictureRole = furniture.pictures.has(index) ? 'furniture' : nativeContext.imagePictures?.has(index) ? 'background' : nativeContext.watermarkPictures?.has(index) ? 'watermark' : nativeContext.logoPictures?.has(index) ? 'logo' : quotes.consumedPictures.has(picture) ? 'quote' : iconShapes.consumed.has(picture) ? 'icon' : undefined;
    if (pictureRole) { roles.set(`pic:${index}`, pictureRole); continue; }
    if (diagrams.pictures.has(index)) {
      items.push({kind: 'diagram', bounds: shapeBounds(picture['p:spPr']?.['a:xfrm']), visualBounds: visualBounds(picture['p:spPr']?.['a:xfrm']), payload: diagrams.pictures.get(index), sources: [`pic:${index}`]});
      continue;
    }
    // A tagged, unchanged image block brings back its own fields (fit, focus, treatment, placement); its crop is theirs.
    const treatment = nativeContext.imageBlocks?.get(index);
    const report = diagnostic => { if (!(treatment && diagnostic.code === 'unsupported-image-crop')) options.onDiagnostic?.({...diagnostic, path: `slides.${slideIndex}.pictures.${index}`}); };
    const item = importPicture(entries, picture, slidePath, relationships, report);
    if (item?.payload && treatment) item.payload = {...item.payload, ...structuredClone(treatment), ...(nativeContext.imageSources?.has(index) ? {image: {...item.payload.image, src: nativeContext.imageSources.get(index)}} : {})};
    else if (item?.nativeStretch) { item.payload.fit='stretch'; item.inferredStretch=true; }
    else if (item?.nativeFitUnsupported) report({code:'unsupported-image-fit',message:'Native picture tiling or an offset stretch fill is not represented by the imported image block; review the reflowed image.'});
    if (item?.payload && nativeContext.imageCallouts?.has(index)) item.payload.image = {...item.payload.image, callouts: nativeContext.imageCallouts.get(index)};
    if (item) items.push({...item, sources: [`pic:${index}`]});
  }

  return items;
}

function importShape(shape, dimensions, paragraphs = readParagraphs(shape["p:txBody"]), allowEmptyText = false) {
  const text = paragraphs.map((paragraph) => paragraph.text).join("\n");
  const placeholder = shapePlaceholderType(shape);
  const bounds = shapeBounds(shape["p:spPr"]?.["a:xfrm"]);
  const name = scalarText(shape["p:nvSpPr"]?.["p:cNvPr"]?.name).trim();

  if (text || allowEmptyText) {
    return {
      kind: "text",
      text,
      paragraphs,
      bounds,
      placeholder,
      name,
      maxFontSize: Math.max(0, ...paragraphs.map((paragraph) => paragraph.maxFontSize))
    };
  }

  if (placeholder || !bounds || isFullSlide(bounds, dimensions)) return null;
  return {
    kind: "unknown",
    bounds,
    name,
    text: `PowerPoint shape: ${name || "unsupported shape"}`
  };
}

function importGraphicFrame(entries, frame, slidePath, relationships, importedTable, report, data = {}) {
  const bounds = shapeBounds(frame["p:xfrm"]);
  const name = scalarText(frame["p:nvGraphicFramePr"]?.["p:cNvPr"]?.name).trim();
  const graphicData = frame["a:graphic"]?.["a:graphicData"];
  const table = graphicData?.["a:tbl"];
  // RR-54: the frame's chart or table data record (src/data-provenance.js); an unreadable record is reported and ignored.
  const record = kind => {
    try {
      const value = readDataTag(entries, frame, relationships);
      return value?.kind === kind ? value : undefined;
    } catch (error) {
      data.report?.(kind, {code: 'invalid-data-provenance', message: `${errorMessage(error)} The ${kind} imports the values it shows.`});
      return undefined;
    }
  };
  // A record that passed its checks but cannot be restored (it fails validation in a way that throws) is reported too.
  const restore = (kind, imported, apply) => {
    try {
      return apply();
    } catch (error) {
      data.report?.(kind, {code: 'invalid-data-provenance', message: `${errorMessage(error)} The ${kind} imports the values it shows.`});
      return imported;
    }
  };
  if (table) {
    const stored = importedTable && record('table');
    const restoredTable = stored ? restore('table', importedTable, () => restoreTableData(importedTable, stored, {evidence: tableCellEvidence(table, relationships), olderEvidence: [tableCellEvidence(table, relationships, {form: 'raw'}), tableCellEvidence(table, relationships, {form: 'saved'})], environment: tableEnvironmentEvidence(entries), datasets: data.datasets, report: diagnostic => data.report?.('table', diagnostic)})) : importedTable;
    // FA-27: the frame's descr (or PowerPoint's decorative marker) is the table's text alternative.
    const alt = restoredTable && typeof restoredTable === 'object' ? readFrameAlt(frame["p:nvGraphicFramePr"]?.["p:cNvPr"]) : undefined;
    return {
      kind: "table",
      bounds,
      name,
      payload: {
        type: "table",
        // RR-59: an authored table restored from provenance takes its alt from the frame too, so an alt removed in PowerPoint stays removed.
        table: restoredTable && typeof restoredTable === 'object' ? (({alt: _recorded, ...rest}) => alt === undefined ? rest : {...rest, alt})(restoredTable) : restoredTable
      }
    };
  }

  const chartExRelId = graphicData?.uri === CHARTEX_GRAPHIC_DATA_URI ? graphicData?.["cx:chart"]?.["r:id"] : undefined;
  const chartRelId = graphicData?.["c:chart"]?.["r:id"] ?? chartExRelId;
  if (chartRelId) {
    const imported = chartExRelId
      ? chartexFromRelationship(entries, relationships, chartExRelId, report)
      : chartFromRelationship(entries, slidePath, relationships, chartRelId, report, {marked: data.markedCharts?.has(name) === true});
    const stored = imported && record('chart');
    const part = relationships.get(chartRelId)?.path;
    const restored = stored && part && entries[part]
      ? restore('chart', imported, () => restoreChartData(imported, stored, chartEvidence(decodeText(entries[part])), {datasets: data.datasets, report: diagnostic => data.report?.('chart', diagnostic)}))
      : imported;
    const chart = restored?.type === 'combo' ? elideComboDefault(restored, data.datasets) : restored;
    // FA-09: the frame's descr (or PowerPoint's decorative marker) is the chart's text alternative.
    const alt = chart ? readFrameAlt(frame["p:nvGraphicFramePr"]?.["p:cNvPr"]) : undefined;
    return {
      kind: "chart",
      bounds,
      name,
      payload: chart
        ? { type: "chart", chart: alt === undefined ? chart : { ...chart, alt } }
        : { type: "text", text: `PowerPoint chart: ${name || chartRelId}` }
    };
  }

  return {
    kind: "unknown",
    bounds,
    name,
    text: `PowerPoint object: ${name || "unsupported object"}`
  };
}

// The box a quarter-turned picture occupies on the slide: `a:xfrm` describes the
// frame before rotation, so a 90 or 270 degree turn swaps its width and height
// around the same centre. Content topology matching compares this visual box.
function visualBounds(xfrm) {
  const bounds = shapeBounds(xfrm);
  const rotation = Number(xfrm?.rot ?? 0);
  if (!bounds || !Number.isFinite(rotation) || ((rotation % 10800000) + 10800000) % 10800000 !== 5400000) return bounds;
  return { x: bounds.x + bounds.w / 2 - bounds.h / 2, y: bounds.y + bounds.h / 2 - bounds.w / 2, w: bounds.h, h: bounds.w };
}

function importPicture(entries, picture, slidePath, relationships, report) {
  const bounds = shapeBounds(picture["p:spPr"]?.["a:xfrm"]);
  const name = scalarText(picture["p:nvPicPr"]?.["p:cNvPr"]?.name).trim();
  // PptxGenJS (and so exports before this fix) wrote `preencoded.<ext>` for a picture with no alt text; that is no authored description.
  const authoredAlt = scalarText(picture["p:nvPicPr"]?.["p:cNvPr"]?.descr);
  const alt = /^preencoded\.[a-z0-9]+$/i.test(authoredAlt.trim()) ? "" : authoredAlt;
  const title = scalarText(picture["p:nvPicPr"]?.["p:cNvPr"]?.title);
  const relId = picture["p:blipFill"]?.["a:blip"]?.["r:embed"];
  const relationship = relationships.get(relId);
  let bytes = relationship?.path ? entries[relationship.path] : null;
  // A picture PowerPoint stores as SVG carries the SVG beside its PNG fallback: the SVG is the image.
  let svg = null;
  const svgRelationship = relationships.get(svgBlipRelationship(picture["p:blipFill"]?.["a:blip"]));
  if (svgRelationship && svgRelationship.targetMode !== "External" && entries[svgRelationship.path]) {
    const prepared = prepareSvg(entries[svgRelationship.path]);
    if (prepared.error) report({code: "invalid-svg-image", message: `A picture's SVG was not imported (${prepared.error.message}); its PNG fallback was imported instead (none: the picture has no image).`});
    else {
      svg = prepared.bytes;
      if (prepared.removed.length) report({code: "svg-sanitized", message: `The SVG had ${prepared.removed.join(", ")} removed on import.`});
    }
  }
  // PowerPoint can save an SVG picture with no PNG fallback at all (an a:blip with no r:embed): the SVG alone is the image.
  if (!bytes && !svg) {
    return {
      kind: "unknown",
      bounds,
      name,
      text: `PowerPoint image: ${alt || name || "unresolved image"}`
    };
  }

  const crop = picture["p:blipFill"]?.["a:srcRect"];
  if (crop && ['l','r','t','b'].some(key => Number(crop[key] ?? 0) !== 0)) {
    report({code: 'unsupported-image-crop', message: 'Native picture crop is not represented by the imported OPF asset; the full image was retained.'});
  }
  bytes = importImageOrientation(svg ?? bytes, picture["p:spPr"]?.["a:xfrm"], report);

  return {
    kind: "image",
    nativeStretch: nativePictureStretch(picture, bytes, bounds, Boolean(svg)),
    nativeFitUnsupported: picture['p:blipFill']?.['a:tile']!==undefined || ['l','r','t','b'].some(key=>Number(picture['p:blipFill']?.['a:stretch']?.['a:fillRect']?.[key]??0)!==0),
    bounds,
    visualBounds: visualBounds(picture["p:spPr"]?.["a:xfrm"]),
    name,
    payload: {
      type: "image",
      image: {
        src: `data:${svg ? "image/svg+xml" : rasterMetadata(bytes)?.mediaType ?? mediaTypeForPath(relationship?.path)};base64,${bytesToBase64(bytes)}`,
        ...(alt ? { alt } : {}),
        ...(title && alt ? { title } : {})
      }
    }
  };
}

// A full-source native stretch is distinguishable from cover only when the
// intrinsic aspect differs from its frame. No crop, tile, offset fill or turn is
// inferred; those require their existing diagnostics/separate fidelity review.
function nativePictureStretch(picture,bytes,bounds,svg) {
  const fill=picture['p:blipFill'],crop=fill?.['a:srcRect'],stretch=fill?.['a:stretch'];
  const rect=stretch?.['a:fillRect'],transform=picture['p:spPr']?.['a:xfrm'];
  const metadata=svg?null:rasterMetadata(bytes);
  if(!bounds||!(bounds.w>0&&bounds.h>0)||!metadata||!(metadata.width>0&&metadata.height>0)||metadata.orientation>1) return false;
  if(stretch===undefined||fill?.['a:tile']!==undefined||Number(transform?.rot??0)!==0) return false;
  if([crop,rect].some(value=>value&&['l','r','t','b'].some(key=>Number(value[key]??0)!==0)))return false;
  // Compare the current raster and current native frame, including only the
  // exporter's representable rounding cells (not a visual geometry tolerance).
  const ext=transform?.['a:ext'];
  const cx=Number(ext?.cx),cy=Number(ext?.cy);
  if(!Number.isFinite(cx)||!Number.isFinite(cy))return false;
  return !samePictureAspect(cx,cy,metadata.width,metadata.height);
}

// Provenance may rebuild flat blocks into groups or scalar fields. Remove only
// our inferred fit when restored design already supplies stretch, preserving an
// unchanged authored default rather than adding an unsolicited block override.
function applyNativeImageFits(imported,contexts,groups,options) {
  for(const [slideIndex,context] of contexts.entries()) {
    if(!context.inferredImageFits?.length)continue;
    const slide=imported.slides[slideIndex];
    const resolved=resolveCoreSlideContext(imported,slideIndex,options.catalogs!==undefined?{catalogs:options.catalogs}:{}).resolved;
    const fit=slide.design?.imageFit??imported.design?.imageFit??resolved.theme?.design?.imageFit??resolved.layout?.design?.imageFit??'cover';
    const restored=groups.find(group=>group.applied&&group.contentPaths?.slide===slideIndex)?.contentPaths?.paths;
    for(const index of context.inferredImageFits) {
      const path=restored?.get(index)??`blocks.${index}`;
      const value=path.split('.').reduce((item,key)=>item?.[key],slide);
      if(value&&typeof value==='object'&&value.image!==undefined) {
        if(fit==='stretch')delete value.fit;
        else value.fit='stretch';
      }
    }
  }
}

function readParagraphs(txBody) {
  return withDisplayedNumbers(asArray(txBody?.["a:p"])
    .map((paragraph) => {
      // FF-45: an a14:m math zone (OMML equation) inside mc:AlternateContent has no OPF model; its mc:Fallback runs are read as
      // text (or, without them, the equation's m:t text), and `math` records the zones so the importer can diagnose the loss.
      const alternates = asArray(paragraph?.["mc:AlternateContent"]);
      const zones = alternates.flatMap(alternate => asArray(alternate?.["mc:Choice"])).filter(choice => choice?.["a14:m"] !== undefined);
      const fallbackRuns = alternates.flatMap(alternate => asArray(alternate?.["mc:Fallback"])).flatMap(fallback => [...asArray(fallback?.["a:r"]), ...asArray(fallback?.["a:fld"])]);
      const runs = [
        ...asArray(paragraph?.["a:r"]),
        ...asArray(paragraph?.["a:fld"]),
        ...fallbackRuns
      ];
      const texts = [];
      const sizes = [];
      for (const run of runs) {
        const text = scalarText(run?.["a:t"]);
        if (text) texts.push(text);
        const size = Number(run?.["a:rPr"]?.sz);
        if (Number.isFinite(size)) sizes.push(size / 100);
      }
      const linear = zones.map(choice => keyedMathText(choice["a14:m"])).join("");
      if (zones.length && !fallbackRuns.some(run => scalarText(run?.["a:t"]))) texts.push(linear);
      return {
        // LH-11: a no-break space the exporter wrote where core's line breaker never breaks is the space again.
        text: unbindNoBreak(texts.join("")),
        bullet: asArray(paragraph?.["a:pPr"]).some(props => props?.["a:buChar"] !== undefined || props?.["a:buBlip"] !== undefined || props?.["a:buAutoNum"] !== undefined),
        level: Number(asArray(paragraph?.["a:pPr"])[0]?.lvl ?? 0),
        maxFontSize: sizes.length > 0 ? Math.max(...sizes) : 0,
        ...(zones.length ? {math: {zones: zones.length, text: linear}} : {}),
        ...autoNumberOf(asArray(paragraph?.["a:pPr"])[0])
      };
    }));
}
// RR-33: the native auto-number of a paragraph's properties, when its last bullet element is one.
function autoNumberOf(properties) {
  if (properties?.["a:buAutoNum"] === undefined) return {};
  const attributes = asArray(properties["a:buAutoNum"])[0] ?? {};
  return {autoNum: {type: attributes.type, startAt: attributes.startAt}};
}
/** The m:t text of a keyed OMML tree (an a14:m zone) in document order: the equation's linear reading without its layout. */
function keyedMathText(node) {
  if (Array.isArray(node)) return node.map(keyedMathText).join("");
  if (!node || typeof node !== "object") return "";
  return Object.entries(node).map(([key, value]) => key === "m:t" ? asArray(value).map(scalarText).join("") : keyedMathText(value)).join("");
}

function shapePlaceholderType(shape) {
  return shape["p:nvSpPr"]?.["p:nvPr"]?.["p:ph"]?.type ?? null;
}

function shapeBounds(xfrm) {
  if (!xfrm) return null;
  const x = emuToInches(xfrm["a:off"]?.x);
  const y = emuToInches(xfrm["a:off"]?.y);
  const w = emuToInches(xfrm["a:ext"]?.cx);
  const h = emuToInches(xfrm["a:ext"]?.cy);
  if ([x, y, w, h].some((value) => value === null)) return null;
  return { x, y, w, h };
}

function takeTitleItem(items, dimensions, inferHeadings) {
  const explicitIndex = items.findIndex((item) => ["title", "ctrTitle"].includes(item.placeholder));
  if (explicitIndex >= 0) return items.splice(explicitIndex, 1)[0];
  if (!inferHeadings) return null;

  const titleLimit = dimensions.heightInches * 0.28;
  const candidateIndex = items.findIndex((item) => {
    if (item.heading || item.placeholder === 'body' || item.kind !== "text" || !item.text || item.paragraphs.some(p=>p.bullet)) return false;
    const y = item.bounds?.y ?? 0;
    return y <= titleLimit && (item.maxFontSize >= 20 || /^title\b/i.test(item.name ?? ""));
  });
  if (candidateIndex >= 0) return items.splice(candidateIndex, 1)[0];
  return null;
}

function takeSubtitleItem(items, titleItem, dimensions, inferHeadings) {
  const explicitIndex = items.findIndex((item) => item.placeholder === "subTitle");
  if (explicitIndex >= 0) return items.splice(explicitIndex, 1)[0];
  if (!inferHeadings || !titleItem) return null;

  const titleBottom = (titleItem.bounds?.y ?? 0) + (titleItem.bounds?.h ?? 0);
  const subtitleLimit = Math.min(dimensions.heightInches * 0.34, 1.45);
  const candidateIndex = items.findIndex((item) => {
    if (item.heading || item.placeholder === 'body' || item.kind !== "text" || !item.text || item.paragraphs.some(p=>p.bullet)) return false;
    const y = item.bounds?.y ?? 0;
    const h = item.bounds?.h ?? 0;
    return y >= titleBottom - 0.05
      && y <= subtitleLimit
      && h <= 0.75
      && item.paragraphs.length === 1
      && item.maxFontSize <= Math.max(22, titleItem.maxFontSize);
  });
  if (candidateIndex >= 0) return items.splice(candidateIndex, 1)[0];
  return null;
}

// The export writes every native line of a list as its own shape named "OPF list <path> line N". The lines of one list
// import as one list: a bulleted line starts an entry, an unbulleted line of the entry's own size continues it (a wrapped
// entry) and a smaller one is its description. Without a bulleted first line the shapes stay as they are.
const richRuns = value => typeof value === 'string' ? [{text: value}] : value;
function joinRich(a, b) {
  if (typeof a === 'string' && typeof b === 'string') return a + b;
  const runs = [...richRuns(a), ...richRuns(b)], joined = [];
  for (const run of runs) {
    const last = joined.at(-1);
    if (last && JSON.stringify({...last, text: ''}) === JSON.stringify({...run, text: ''})) last.text += run.text;
    else joined.push({...run});
  }
  return joined;
}
// `breaks` (slideListRecord) holds the whitespace of the hard breaks the export recorded, by list path and line number: the
// continuation line after a break joins with it, so a newline inside an item (or a description) returns. A blank line is a
// native shape with no text: it is never a description. Without a record the lines join without a separator, as before.
// `runs` (opf-pptx#212) holds the look export wrote on every run of a list ({text, description?}): a run value still equal to
// it is inherited formatting, not authored run style, and is removed (as for a tagged heading), so an untouched round trip
// adds no explicit sizes, families or colours; a value edited in PowerPoint differs and is kept. Without it runs are as read.
function mergeOpfListShapes(items, breaks = null, report = () => {}, runs = null, roles = null) {
  const lists = new Map();
  for (const item of items) {
    const match = /^OPF list (.+) line (\d+)$/.exec(item.name ?? '');
    if (match && item.kind === 'text' && item.paragraphs?.length === 1) {
      if (!lists.has(match[1])) lists.set(match[1], []);
      lists.get(match[1]).push({item, line: Number(match[2])});
    }
  }
  const merged = new Map(), consumed = new Set();
  for (const [path, entries] of lists) {
    entries.sort((a, b) => a.line - b.line);
    const expectedRoles = roles?.get(path);
    // design.listBullet: none writes no bullet at all (a:buNone): the list is unambiguous only through its recorded roles, whose
    // first lines start the entries. Without that record the shapes stay as they are.
    const unbulleted = entries.every(({item}) => !item.paragraphs[0].bullet);
    if (!entries[0].item.paragraphs[0].bullet && !(unbulleted && expectedRoles?.[0]?.[2])) continue;
    const validRoles = expectedRoles && expectedRoles.length === entries.length && entries.every(({item, line}, index) => line === index && (unbulleted || Boolean(item.paragraphs[0].bullet) === expectedRoles[index][2]));
    const lineRoles = validRoles ? expectedRoles : null;
    if (expectedRoles && !validRoles) report({code: 'list-line-role-changed', message: `The line topology of ${path} changed; list roles were not restored.`});
    if (unbulleted && !validRoles) continue;
    const look = runs?.get(path), textLook = cleanBase(look?.text), descriptionLook = cleanBase(look?.description);
    // The line's runs without the inherited look, or the paragraph's own richText when there is no record for this kind of line.
    // Each run is cleaned on its own and none merge, so the runs stay the slots the run colour record counts (src/run-colors.js);
    // they stay run objects until the lines are joined (as before), then `plain` gives the authored form back.
    const own = (paragraph, base) => {
      if (!base) return paragraph.richText;
      return richRuns(paragraph.richText ?? paragraph.text).flatMap(run => {
        const value = headingValue([run], base);
        const parts = value === '' ? [] : typeof value === 'string' ? [{text: value}] : value.map(part => typeof part === 'string' ? {text: part} : part);
        // A removed colour stays known until the run colour references are restored (restoreRunColors): an authored `text`
        // role equals the inherited colour natively.
        if (typeof run === 'object' && typeof run.color === 'string' && parts.length === 1 && parts[0].color === undefined) parts[0]._opfInherited = run.color;
        return parts;
      });
    };
    const plain = value => {
      if (!Array.isArray(value)) return value;
      const runs = value.map(run => typeof run === 'object' && Object.keys(run).length === 1 ? run.text : run);
      return runs.length === 0 ? '' : runs.length === 1 && typeof runs[0] === 'string' ? runs[0] : runs;
    };
    const paragraphs = [];
    const recorded = breaks?.get(path), applied = new Set();
    let bounds, size = 0;
    for (const {item, line} of entries) {
      const [paragraph] = item.paragraphs, current = paragraphs.at(-1);
      const gap = recorded?.get(line);
      const join = (a, b) => gap === undefined ? joinRich(a, b) : joinWrappedText([a, b], [gap]);
      if (unbulleted ? lineRoles?.[line][2] : paragraph.bullet) { paragraphs.push({...paragraph, bullet: true, richText: own(paragraph, textLook)}); size = paragraph.maxFontSize; }
      else if (paragraph.text === '') { /* a blank line of the entry: no text, no description */ }
      else if (lineRoles ? lineRoles[line][1] === 'description' : paragraph.maxFontSize < size - 0.01) {
        const text = own(paragraph, descriptionLook) ?? paragraph.text;
        if (current.description === undefined) current.description = text;
        else { current.description = join(current.description, text); applied.add(line); }
      } else {
        const before = current.text, rich = own(paragraph, textLook);
        current.text += (gap === undefined ? '' : Array.isArray(gap) ? gap[0] : gap) + paragraph.text;
        if (current.richText !== undefined || rich !== undefined) current.richText = join(current.richText ?? before, rich ?? paragraph.text);
        applied.add(line);
      }
      const b = item.visualBounds ?? item.bounds;
      if (b) {
        const x = Math.min(bounds?.x ?? b.x, b.x), y = Math.min(bounds?.y ?? b.y, b.y);
        bounds = {x, y, w: Math.max((bounds ? bounds.x + bounds.w : -Infinity), b.x + b.w) - x, h: Math.max((bounds ? bounds.y + bounds.h : -Infinity), b.y + b.h) - y};
      }
      consumed.add(item);
    }
    if (recorded && [...recorded.keys()].some(line => !applied.has(line))) report({code: 'list-line-break-changed', message: `A hard line break recorded at export inside the list ${path} no longer has the continuation line it belonged to (a line was edited away, or became an entry), so that break was not restored; the list keeps the lines it has.`});
    if (textLook) for (const paragraph of paragraphs) paragraph.richText = plain(paragraph.richText);
    if (descriptionLook) for (const paragraph of paragraphs) if (paragraph.description !== undefined) paragraph.description = plain(paragraph.description);
    const first = entries[0].item;
    merged.set(first, {...first, paragraphs, text: paragraphs.map(paragraph => paragraph.text).join('\n'), bounds, visualBounds: undefined, sources: entries.flatMap(({item}) => item.sources ?? [])});
    // LH-08: the hairlines the export drew between the rows of this list (`OPF list rule <path> N`, no text) are part of its drawing,
    // not content: the export draws them again from the list.
    const rulePrefix = `OPF list rule ${path} `;
    for (const other of items) if (other.kind === 'unknown' && other.name?.startsWith(rulePrefix) && /^\d+$/.test(other.name.slice(rulePrefix.length))) consumed.add(other);
  }
  return items.flatMap(item => merged.has(item) ? [merged.get(item)] : consumed.has(item) ? [] : [item]);
}

// Adjacent native bullet boxes on the same text column form one imported list.
// This is a geometry heuristic, not a lossless reconstruction of arbitrary PPTX.
// LH-133: two lists the export named (`OPF list <path> line N`, merged by mergeOpfListShapes) are the lists their names say, so they
// stay apart however close they sit (one-question blocks of a FAQ stacked as ruled rows).
function mergeAdjacentBulletShapes(items) {
  const result=[];
  const named=value=>/^OPF list (.+) line \d+$/.test(value?.name??'');
  for(const item of items){
    const previous=result.at(-1);
    const bullets=value=>value?.kind==='text'&&value.paragraphs.length&&value.paragraphs.every(p=>p.bullet);
    if(bullets(previous)&&bullets(item)&&!(named(previous)&&named(item))&&previous.bounds&&item.bounds
      &&Math.abs(previous.bounds.x-item.bounds.x)<.05
      &&item.bounds.y>=previous.bounds.y+previous.bounds.h-.02
      &&item.bounds.y-(previous.bounds.y+previous.bounds.h)<.3){
      previous.paragraphs.push(...item.paragraphs);
      previous.text+='\n'+item.text;
      previous.sources=[...(previous.sources??[]),...(item.sources??[])];
      previous.bounds.h=item.bounds.y+item.bounds.h-previous.bounds.y;
    }else result.push({...item,paragraphs:item.paragraphs?[...item.paragraphs]:undefined,bounds:item.bounds?{...item.bounds}:undefined});
  }
  return result;
}

function payloadFromSlideItem(item, report) {
  if (item.payload) return item.payload;
  if (item.kind === "text") {
    if (item.paragraphs.some(p=>p.bullet)) {
      // RR-33: native auto-numbers come back as `numbering` and the entry `start` values that restore their numbers.
      const {numbering, starts, diagnostics} = deriveListNumbering(item.paragraphs);
      for (const diagnostic of diagnostics) report?.(diagnostic);
      return {
        type: "list",
        items: item.paragraphs.map((paragraph, index) => {
          const start = starts.get(index) === undefined ? {} : {start: starts.get(index)};
          return paragraph.level > 0
            ? { text: paragraph.richText ?? paragraph.text, level: paragraph.level, ...(paragraph.description !== undefined ? {description: paragraph.description} : {}), ...start }
            : paragraph.description !== undefined ? { text: paragraph.richText ?? paragraph.text, description: paragraph.description, ...start }
            : start.start !== undefined ? { text: paragraph.richText ?? paragraph.text, ...start } : (paragraph.richText ?? paragraph.text);
        }),
        ...(numbering !== undefined ? {numbering} : {})
      };
    }
    return { type: "text", text: joinNativeParagraphs(item.paragraphs) };
  }
  if (item.kind === "unknown" && item.text) return { type: "text", text: item.text };
  return null;
}

function chartFromRelationship(entries, slidePath, relationships, relId, report, {marked = false} = {}) {
  const relationship = relationships.get(relId);
  if (!relationship?.path || !entries[relationship.path]) return null;
  const doc = parseRequiredXml(entries, relationship.path);
  const plotArea = doc["c:chartSpace"]?.["c:chart"]?.["c:plotArea"];
  if (!plotArea) return null;

  // FA-15: a clustered column group with one or two line groups is a combo chart; its series are read in c:order.
  const combo = comboFromNative(plotArea);
  const comboSeries = combo ? comboSeriesOf(combo) : undefined;
  const chartNode = combo ? {node: combo.bar, type: 'combo'} : firstChartNode(plotArea);
  if (!chartNode) return null;
  const series = comboSeries ? comboSeries.map(entry => entry.ser) : asArray(chartNode.node["c:ser"]);
  if (series.length === 0) return null;
  if (series.length > MAX_CHART_CACHE_POINTS) {
    throw new OPFPptxError('invalid-chart-cache', 'Chart cache exceeds the 100,000-series import limit; reduce its series before importing.', {path: relationship.path});
  }

  const budget = { cells: 0 };
  const cachePath = (index, role) => `${relationship.path}#c:ser[${index}]/${role}`;
  // RR-54: each series' number format code (c:numCache or c:numLit formatCode); core maps the codes it can back to column formats.
  const valueCodes = series.map(entry => cacheFormatCode(entry?.["c:val"] ?? entry?.["c:yVal"]));
  const xCode = chartNode.type === 'scatter' ? cacheFormatCode(series[0]?.["c:xVal"]) : undefined;
  // RR-35: axis titles, legend position and data labels read back into the chart's option fields.
  // LH-81: what an export of the header row left in the part: a caption title or a top legend at a manual position.
  const nativeLegend = doc["c:chartSpace"]?.["c:chart"]?.["c:legend"];
  const headerLegend = nativeLegend?.["c:legendPos"]?.val === 't' && nativeLegend?.["c:layout"]?.["c:manualLayout"] !== undefined;
  const headerCaption = doc["c:chartSpace"]?.["c:chart"]?.["c:title"]?.["c:layout"]?.["c:manualLayout"] !== undefined;
  const withOptions = chart => {
    // LH-105: series names at the line ends or category names on the slices, without a legend, are the default direct labels.
    // LH-109: a stacked chart's values inside its segments are the default whether its names stand beside it or its legend stayed.
    // LH-108, LH-109: a chart whose value list or series names were drawn as tagged shapes (`marked`) has no legend by default.
    const stacked = {'stacked-column': 'bar', '100pct-stacked-column': 'bar', 'stacked-area': 'area', '100pct-stacked-area': 'area'}[chartNode.type];
    const direct = marked || ((!nativeLegend || stacked !== undefined) && directLabelDefaults(chartNode.node, stacked ?? (String(chartNode.type).includes('line') ? 'line' : chartNode.type)));
    const {options, notes} = chartOptionsFromClassic(doc["c:chartSpace"], {layer: {header: headerCaption || headerLegend, headerLegend, direct},chartNode: chartNode.node, target: chartTargetFor(chartNode.type), seriesCount: series.length, circular: chartNode.type === 'pie' || chartNode.type === 'doughnut', scatter: chartNode.type === 'scatter', seriesFormats: valueCodes,
      ...(combo ? {combo: {lineNode: combo.lines[0]?.node, secondaryValueAxis: secondaryValueAxisOf(plotArea, combo)}} : {})});
    for (const note of notes) report?.(note);
    if (budget.rejected?.length) report?.({code: 'chart-value-not-numeric', option: 'data', message: `${budget.rejected.length} cached chart ${budget.rejected.length === 1 ? 'value is' : 'values are'} not a number (first at ${budget.rejected[0]}) and ${budget.rejected.length === 1 ? 'imports as a gap' : 'import as gaps'}, never as a guessed value.`});
    // LH-03: the value labels an export of a small chart writes by default are not an option. LH-105: every chart area is unfilled now, so
    // the small chart is told by its deleted value axis (a small chart whose value axis has a title keeps its labels as an option).
    const unfilled = asArray(plotArea?.["c:valAx"])[0]?.["c:delete"]?.val === '1' || asArray(plotArea?.["c:valAx"])[0]?.["c:delete"]?.val === 1;
    return chart && Object.keys(options).length ? withoutLayerDefaults({...chart, ...options}, {unfilled}) : chart;
  };
  if (chartNode.type === 'scatter') return withOptions(scatterFromSeries(entries, relationship.path, series, budget, cachePath, {codes: valueCodes, xCode, report}));
  const labels = cachedValues(series[0]?.["c:cat"], cachePath(0, 'c:cat'), budget);
  const names = series.map((entry, index) => firstCachedValue(entry?.["c:tx"], cachePath(index, 'c:tx'), budget) ?? `Series ${index + 1}`);
  // RR-86: explicit current line paint has no per-series OPF field. Report the native locator without
  // inferring semantic highlight, rewriting the theme or claiming that these colors differ visually.
  for (const [index, entry] of series.entries()) {
    const line = comboSeries ? comboSeries[index].role === 'line' : asArray(plotArea['c:lineChart']).includes(chartNode.node);
    const solid = line && entry?.['c:spPr']?.['a:ln']?.['a:solidFill'];
    if (solid && ['a:srgbClr', 'a:schemeClr', 'a:sysClr', 'a:prstClr', 'a:scrgbClr', 'a:hslClr'].some(color => Object.hasOwn(solid, color))) {
      report?.({option: `series.${index}.line.color`, message: `Line series '${names[index]}' has explicit native solid paint that is not retained as per-series formatting in OPF; imported chart colors follow its design and semantic highlight.`});
    }
  }
  const values = series.map((entry, index) => {
    const role = entry?.["c:val"] !== undefined ? 'c:val' : 'c:yVal';
    return cachedValues(entry?.[role], cachePath(index, role), budget, strictCacheValue(budget));
  });
  const rowCount = values.reduce((count, row) => Math.max(count, row.length), labels.length);
  if (rowCount === 0) return null;
  if (rowCount * (series.length + 1) > MAX_CHART_CACHE_CELLS) {
    throw new OPFPptxError('invalid-chart-cache', 'Chart cache exceeds the 1,000,000-cell import limit; reduce its rows or series before importing.', {path: relationship.path});
  }

  const rows = [];
  for (let index = 0; index < rowCount; index += 1) {
    rows.push([
      labels[index] ?? null,
      ...values.map((row) => row[index] ?? null)
    ]);
  }

  return withOptions({
    type: chartNode.type,
    data: {
      columns: formattedColumns([readChartCategoryHeading(entries,relationship.path) ?? "Category", ...names], [undefined, ...valueCodes], report),
      rows
    },
    ...(comboSeries ? comboFields(comboSeries, names, report) : {})
  });
}

// FA-15: the series of a combo plot area with their role and axis, in c:order (document order breaks ties).
function comboSeriesOf(combo) {
  const entries = [
    ...asArray(combo.bar["c:ser"]).map(ser => ({ser, role: 'bar', secondary: false})),
    ...combo.lines.flatMap(group => asArray(group.node["c:ser"]).map(ser => ({ser, role: 'line', secondary: group.secondary}))),
  ];
  const order = (entry, index) => {
    const value = Number(entry.ser?.["c:order"]?.val);
    return Number.isFinite(value) ? value : index;
  };
  return entries.map((entry, index) => ({...entry, key: order(entry, index), index})).sort((a, b) => a.key - b.key || a.index - b.index);
}

// The c:valAx a secondary line group plots against (its axis that the column group does not use), or undefined.
function secondaryValueAxisOf(plotArea, combo) {
  const group = combo.lines.find(entry => entry.secondary);
  if (!group) return undefined;
  const ids = new Set(asArray(group.node["c:axId"]).map(axis => String(axis?.val)));
  return asArray(plotArea["c:valAx"]).find(axis => ids.has(String(axis?.["c:axId"]?.val)));
}

// `line` and `secondaryAxis` of an imported combo chart by series name (elideComboDefault drops a `line` that is the default).
// Combo lines always draw markers in OPF; a native line without markers is reported, never silently changed.
function comboFields(comboSeries, names, report) {
  const line = names.filter((_, index) => comboSeries[index].role === 'line');
  const secondaryAxis = names.filter((_, index) => comboSeries[index].secondary);
  const unmarked = names.filter((_, index) => comboSeries[index].role === 'line' && comboSeries[index].ser?.["c:marker"]?.["c:symbol"]?.val === 'none');
  if (unmarked.length) report?.({option: 'line', message: `The combo chart's line ${unmarked.length === 1 ? 'series' : 'series'} ${unmarked.map(name => `'${name}'`).join(', ')} ${unmarked.length === 1 ? 'has' : 'have'} no markers; OPF combo lines always draw markers, so ${unmarked.length === 1 ? 'it imports' : 'they import'} with markers.`});
  if (new Set(line).size !== line.length || new Set(names).size !== names.length) {
    report?.({option: 'line', message: 'Two series of the combo chart share a name, so which of them is a line cannot be said by name; the chart imports with its default line (the last series).'});
    return {};
  }
  return {...(line.length ? {line} : {}), ...(secondaryAxis.length ? {secondaryAxis} : {})};
}

// An imported combo chart writes `line` only when it differs from the default (the last plotted series), judged on the final
// data (a restored data record can order the columns differently from the native series).
function elideComboDefault(chart, datasets) {
  if (!Array.isArray(chart.line)) return chart;
  const {line, ...rest} = chart;
  const resolved = resolveChartData(rest, {datasets: datasets ?? {}});
  if (!resolved.ok || !Array.isArray(resolved.combo)) return chart;
  const defaults = resolved.columns.slice(1).filter((_, index) => resolved.combo[index]?.role === 'line');
  return defaults.length === line.length && defaults.every(name => line.includes(name)) ? rest : chart;
}

// The format code of a numeric cache (c:numRef/c:numCache or c:numLit), or undefined.
function cacheFormatCode(node) {
  const cache = node?.["c:numRef"]?.["c:numCache"] ?? node?.["c:numLit"];
  const code = cache?.["c:formatCode"];
  return code === undefined ? undefined : scalarText(code);
}

// RR-54: a cached value is a number in strict decimal syntax (core chartNumber) or another XML number form (a leading '+',
// leading zeros, '.5'); anything else is a gap, counted for one chart-value-not-numeric diagnostic. Exponent tokens keep their
// own range checks (numericCacheValue).
function strictCacheValue(budget) {
  return (value, path) => {
    const number = numericCacheValue(value, path);
    if (number === null && value !== null && value.trim() !== '') (budget.rejected ??= []).push(path);
    return number;
  };
}

// Scatter charts share X values (c:xVal) across Y series (c:yVal). OPF keeps
// them category-major: [point label, X, Y1, Y2, ...]; native charts carry no
// point labels, so points are numbered.
function scatterFromSeries(entries, chartPart, series, budget, cachePath, {codes = [], xCode, report} = {}) {
  // The same cache helpers as every other chart: bounded, indexed by c:pt@idx, with gaps kept as null (never plotted as 0).
  const xRole = series[0]?.["c:xVal"];
  const xs = cachedValues(xRole, cachePath(0, "c:xVal"), budget, strictCacheValue(budget));
  const names = series.map((entry, index) => firstCachedValue(entry?.["c:tx"], cachePath(index, "c:tx"), budget) ?? `Series ${index + 1}`);
  const values = series.map((entry, index) => cachedValues(entry?.["c:yVal"], cachePath(index, "c:yVal"), budget, strictCacheValue(budget)));
  const rowCount = values.reduce((count, row) => Math.max(count, row.length), xs.length);
  if (rowCount === 0) return null;
  if (rowCount * (series.length + 2) > MAX_CHART_CACHE_CELLS) {
    throw new OPFPptxError('invalid-chart-cache', 'Chart cache exceeds the 1,000,000-cell import limit; reduce its rows or series before importing.', {path: chartPart});
  }
  const rows = [];
  // A chart without c:xVal plots against 1..n natively; a c:xVal gap stays a gap.
  for (let index = 0; index < rowCount; index += 1) rows.push([String(index + 1), xRole === undefined ? index + 1 : xs[index] ?? null, ...values.map((row) => row[index] ?? null)]);
  return { type: "scatter", data: { columns: formattedColumns(["Point", readChartCategoryHeading(entries, chartPart) ?? "X", ...names], [undefined, xCode, ...codes], report), rows } };
}

// A chartex part (cx:chartSpace): the series layoutIds name the kept OPF chart
// type and the cached dimensions restore the category-major data, under the
// same bounds as the classic chart cache.
function chartexFromRelationship(entries, relationships, relId, report) {
  const relationship = relationships.get(relId);
  if (!relationship?.path || !entries[relationship.path]) return null;
  const doc = parseRequiredXml(entries, relationship.path);
  return chartFromChartex(doc, {
    heading: readChartCategoryHeading(entries, relationship.path),
    limits: {points: MAX_CHART_CACHE_POINTS, cells: MAX_CHART_CACHE_CELLS},
    path: relationship.path,
    report,
    invalid: (message, location) => {
      throw new OPFPptxError('invalid-chart-cache', `Invalid chart cache: ${message}. Repair the chart data before importing.`, {path: location ?? relationship.path});
    }
  });
}

function firstChartNode(plotArea) {
  // Map the native construct back to the kept OPF chart type id (FF-22).
  for (const element of NATIVE_CHART_ELEMENTS) {
    const node = asArray(plotArea[`c:${element}`])[0];
    if (node) return { node, type: chartTypeFromNative(element, node) };
  }
  return null;
}

const MAX_CHART_CACHE_POINTS = 100_000;
const MAX_CHART_CACHE_CELLS = 1_000_000;

// Import complete decimal exponent tokens with their range checks. RR-54: every other token is an XML decimal (xsd:double
// without an exponent: a leading '+', leading zeros, '.5', '5.', and any number of digits, so 1e20, which the exporter
// writes as "100000000000000000000", reads back); anything else is a gap, never a stripped or guessed value.
function numericCacheValue(value, path) {
  if (value === null || value.trim() === '') return null;
  const token = value.trim();
  const exponent = /^([+-]?(?:\d+(?:\.\d*)?|\.\d+))[eE][+-]?\d+$/.exec(token);
  if (!exponent) {
    const number = /^[+-]?(?:\d+\.?\d*|\.\d+)$/.test(token) ? Number(token) : NaN;
    return Number.isFinite(number) ? number : null;
  }
  const parsed = Number(token);
  if (!Number.isFinite(parsed) || (parsed === 0 && /[1-9]/.test(exponent[1]))) {
    const reason = Number.isFinite(parsed) ? 'underflows to zero' : 'overflows';
    throw new OPFPptxError('unsupported-chart-cache', `Scientific-notation chart value is outside the supported finite numeric range (${reason}); use a representable value before importing.`, {path});
  }
  return parsed;
}

// c:pt is sparse and its XML order does not determine the data row. Keep
// explicit empty strings distinct from missing points, and bound native
// metadata before allocating a dense OPF table. Only numeric roles convert values.
function cachedValues(node, path, budget, readValue) {
  const invalid = (message, suffix = '') => {
    throw new OPFPptxError('invalid-chart-cache', `Invalid chart cache: ${message}. Repair the chart data before importing.`, {path: path + suffix});
  };
  const single = (value, location) => {
    if (value !== undefined && value !== '' && (!value || typeof value !== 'object' || Array.isArray(value))) {
      invalid('cache container must be a single element', location);
    }
  };
  single(node, '');
  for (const reference of ['c:strRef', 'c:numRef', 'c:multiLvlStrRef']) single(node?.[reference], `/${reference}`);
  const candidates = [
    ['c:strRef/c:strCache', node?.['c:strRef']?.['c:strCache']],
    ['c:numRef/c:numCache', node?.['c:numRef']?.['c:numCache']],
    ['c:multiLvlStrRef/c:multiLvlStrCache', node?.['c:multiLvlStrRef']?.['c:multiLvlStrCache']],
    ['c:numLit', node?.['c:numLit']],
    ['c:strLit', node?.['c:strLit']],
  ].filter(([, cache]) => cache !== undefined);
  if (candidates.length === 0) return [];
  if (candidates.length > 1) invalid('multiple competing cache sources');
  const [kind, cache] = candidates[0];
  path += `/${kind}`;
  if (cache !== '' && (!cache || typeof cache !== 'object' || Array.isArray(cache))) invalid('cache must be a single element');
  const integer = (raw, limit, location) => {
    // XML Schema unsigned integers allow an optional sign and whitespace;
    // their value must still be nonnegative, integral and bounded.
    if (typeof raw !== 'string' || !/^[+-]?\d+$/.test(raw.trim())) invalid('expected an unsigned integer', location);
    const value = Number(raw.trim());
    if (!Number.isSafeInteger(value) || value < 0 || value > limit) invalid(`integer exceeds the supported range 0–${limit}`, location);
    return value;
  };
  const count = cache?.['c:ptCount'] === undefined ? undefined
    : integer(cache['c:ptCount']?.val, MAX_CHART_CACHE_POINTS, '/c:ptCount@val');
  let data = cache;
  if (kind.startsWith('c:multiLvlStrRef')) {
    const levels = asArray(cache?.['c:lvl']);
    if (levels.length > 1) {
      throw new OPFPptxError('unsupported-chart-cache', 'Hierarchical chart category caches cannot be flattened without losing labels; use a single category level before importing.', {path});
    }
    data = levels[0];
  }
  const points = asArray(data?.['c:pt']);
  if (points.length > MAX_CHART_CACHE_POINTS) invalid('too many points');
  const indexed = new Map();
  let extent = count ?? 0;
  for (const [position, point] of points.entries()) {
    const location = `/c:pt[${position}]@idx`;
    const index = integer(point?.idx, MAX_CHART_CACHE_POINTS - 1, location);
    if (count !== undefined && index >= count) invalid('point index is outside its declared count', location);
    if (indexed.has(index)) invalid('duplicate point index', location);
    if (Array.isArray(point?.['c:v'])) invalid('point has multiple values', `/c:pt[${position}]/c:v`);
    indexed.set(index, point?.['c:v'] === undefined ? null : scalarText(point['c:v']));
    extent = Math.max(extent, index + 1);
  }
  if (budget.cells + extent > MAX_CHART_CACHE_CELLS) invalid('combined caches exceed the 1,000,000-cell import limit');
  budget.cells += extent;
  const result = new Array(extent).fill(null);
  for (const [index, value] of indexed) {
    result[index] = readValue ? readValue(value, `${path}/c:pt[@idx="${index}"]/c:v`) : value;
  }
  return result;
}

// SeriesText is a choice between a cached reference and a direct c:v string.
// Current literal text must not fall back to the old OPF/workbook header.
function firstCachedValue(node, path, budget) {
  const values = cachedValues(node, path, budget);
  const literal = node?.['c:v'];
  if (literal === undefined) return values.find(value => value !== null);
  const invalid = message => {
    throw new OPFPptxError('invalid-chart-cache', `Invalid chart cache: ${message}. Repair the chart data before importing.`, {path: path + '/c:v'});
  };
  if (['c:strRef', 'c:numRef', 'c:multiLvlStrRef', 'c:numLit', 'c:strLit'].some(key => node[key] !== undefined)) invalid('multiple competing series-name sources');
  if (typeof literal !== 'string' && (literal === null || typeof literal !== 'object' || Array.isArray(literal)
    || Object.keys(literal).some(key => key !== '#text' && key !== 'xml:space' && key !== 'xmlns' && !key.startsWith('xmlns:'))
    || (literal['#text'] !== undefined && typeof literal['#text'] !== 'string'))) invalid('literal series name must be one simple text value');
  if (budget.cells + 1 > MAX_CHART_CACHE_CELLS) invalid('combined caches exceed the 1,000,000-cell import limit');
  budget.cells += 1;
  return scalarText(literal);
}

function readSlideNotes(entries, relationships) {
  const notesRel = [...relationships.values()].find((relationship) => relationship.type.endsWith("/notesSlide"));
  if (!notesRel?.path || !entries[notesRel.path]) return "";
  const doc = parseRequiredXml(entries, notesRel.path);
  const shapes = nativeTextShapes(doc["p:notes"]?.["p:cSld"]?.["p:spTree"]);
  const paragraphs = nativeShapeParagraphs(decodeText(entries[notesRel.path]), 'p:notes');
  return shapes.flatMap((shape, index) => shapePlaceholderType(shape) === "body"
    ? paragraphs[index].map(paragraph => paragraph.text) : []).join("\n");
}

function comparePositionedItems(left, right) {
  const leftY = left.bounds?.y ?? Number.MAX_SAFE_INTEGER;
  const rightY = right.bounds?.y ?? Number.MAX_SAFE_INTEGER;
  const leftX = left.bounds?.x ?? Number.MAX_SAFE_INTEGER;
  const rightX = right.bounds?.x ?? Number.MAX_SAFE_INTEGER;
  return leftY - rightY || leftX - rightX;
}

function firstLine(value) {
  return String(value ?? "").split(/\r?\n/).find((line) => line.trim())?.trim() ?? "";
}

function mediaTypeForPath(path) {
  const ext = path.toLowerCase().split(".").pop();
  if (ext === "jpg" || ext === "jpeg") return "image/jpeg";
  if (ext === "gif") return "image/gif";
  if (ext === "webp") return "image/webp";
  if (ext === "svg") return "image/svg+xml";
  return "image/png";
}

function isFullSlide(bounds, dimensions) {
  return bounds.x <= 0.02
    && bounds.y <= 0.02
    && bounds.w >= dimensions.widthInches - 0.04
    && bounds.h >= dimensions.heightInches - 0.04;
}

function emuToInches(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return null;
  // Keep native precision through layout/rendering. Rounding inches to six
  // decimals turns a 1280-pixel canvas into 1279.999968 and changes raster edges.
  return number / EMUS_PER_INCH;
}

function asArray(value) {
  if (value === undefined || value === null) return [];
  return Array.isArray(value) ? value : [value];
}

function scalarText(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return value.map(scalarText).join("");
  if (typeof value === "object" && value["#text"] !== undefined) return scalarText(value["#text"]);
  return "";
}

function parseInput(input) {
  if (typeof input === "string") {
    try {
      return JSON.parse(input);
    } catch (error) {
      throw new OPFPptxError("invalid-json", "OPF input is not valid JSON.", {
        cause: errorMessage(error)
      });
    }
  }

  if (input instanceof Uint8Array) {
    return parseInput(new TextDecoder().decode(input));
  }

  if (input && typeof input === "object" && !Array.isArray(input)) {
    return input;
  }

  throw new OPFPptxError("invalid-input", "OPF input must be a parsed object, JSON string, or Uint8Array.");
}

// Template variables (core resolveVariables, RR-32): a deck that uses content variables, or a template, is resolved to a
// concrete deck before export, so the PPTX holds exactly the text, numbers, dates and images the preview shows. A template
// exports with each unfilled variable's example (reported as variable-example-used); a normal deck with an unfilled
// required variable is refused. Decks without content variables are returned untouched. The package stores the resolved
// deck, not the template form, so fromPptx returns the filled deck.
function resolveTemplateInput(presentation, options) {
  if (!isPlainObject(presentation)) return presentation;
  const values = options.variables;
  if (values !== undefined && !isPlainObject(values)) {
    throw new OPFPptxError("invalid-variables", "The variables option must be an object keyed by variable id.", {path: "options.variables"});
  }
  const template = isTemplate(presentation);
  if (!template && !hasContentVariables(presentation) && !(values && Object.keys(values).length)) return presentation;
  const result = resolveVariables(presentation, values ?? {}, {examples: template});
  const errors = result.diagnostics.filter(entry => entry.severity === "error");
  if (errors.length) {
    throw new OPFPptxError(errors.some(entry => entry.code === "variable-unfilled") ? "unfilled-variables" : "invalid-variables", errors[0].message, {findings: errors, path: errors[0].path});
  }
  for (const entry of result.diagnostics) {
    if (entry.code === "variable-example-used" || entry.code === "variable-builtin-missing") options.onDiagnostic?.({code: entry.code, path: entry.path, message: entry.message, id: entry.id});
  }
  return result.presentation;
}

function assertValidBoundary(presentation) {
  const report = checkFormat(presentation);
  if (!report.valid) {
    throw new OPFPptxError("invalid-opf", "OPF validation failed.", {
      findings: report.findings.filter(finding => finding.severity === "error"),
      report
    });
  }
}

// RR-55: what a slide (or, for the deck level, an empty slide) resolves to in core, the one chain every engine shares: canvas,
// layout, font families, alignment and content box as composeSlide's options, plus the theme, colour scheme and font scheme
// records they came from. `diagnostics` names references that matched no record.
// Core's slide context with the host's registered catalogs. Under strict export core throws OPFUnresolvedReferenceError for a
// reference that resolves nowhere; the export fails with `unresolved-reference` naming the first one (its path and every diagnostic).
function coreContext(presentation, index, options) {
  try {
    return resolveCoreSlideContext(presentation, index, {fonts: options.textMeasurement ? {textMeasurement: options.textMeasurement} : undefined, date: options.date,
      ...(options.catalogs !== undefined ? {catalogs: options.catalogs} : {}), strictReferences: options.strictReferences === true});
  } catch (error) {
    if (error?.name !== "OPFUnresolvedReferenceError" || !Array.isArray(error.diagnostics)) throw error;
    const [first] = error.diagnostics;
    throw new OPFPptxError("unresolved-reference", `Strict export: ${error.message}`, {path: first?.path, diagnostics: error.diagnostics});
  }
}

// The families composition and the package use: core's, with the measurement provider's own resolution of the chosen family
// (FF-31) applied to the three roles the exporter writes.
function exportFonts(core, textMeasurement) {
  const {fontFamilies} = core.options, scheme = core.resolved.fontScheme;
  const fonts = {id: scheme.id, ...fontFamilies, scheme: {type: scheme.type, major: scheme.major, minor: scheme.minor}};
  for (const role of ["heading", "body", "code"]) fonts[role] = resolveTextStyle({fontFamily: fonts[role], fontWeight: role === "heading" ? 700 : 400}, textMeasurement).fontFamily;
  return fonts;
}

function resolvePresentationContext(presentation, options, core = coreContext({...presentation, slides: [{}]}, 0, {...options, textMeasurement: undefined})) {
  const design = presentation.design ?? {};
  // `core` defaults to the deck level: the resolution of a slide that sets nothing of its own.
  // The theme and colour scheme records come from core, which falls back to the engine defaults (reporting unresolved-reference)
  // for a reference that resolves nowhere.
  const {theme, colorScheme} = core.resolved;
  const dimensions = {widthInches: core.options.width / 96, heightInches: core.options.height / 96};
  const variables = resolveVariableColors(presentation.variables);
  const definition = design.background ?? theme?.background;
  const fonts = exportFonts(core, options.textMeasurement);
  // One resolution for every color role, shared with the SVG preview and the audit: core's, which maps the roles through the slide's
  // variant (RR-96: bg1, tx1, bg2, tx2 and the accent order over the one scheme, the neutrals as slot plus luminance transform).
  // A core older than the variants has no `resolved.roles`; its roles are resolved from the background as before.
  let background = resolveBackground(definition, colorScheme, variables);
  let roles = core.resolved.roles ?? resolveColorRoles(colorScheme, {background: `#${background}`});
  // A single-color background is the slide's bg1 under its variant, which can differ from the background definition (a deck
  // variant hides the theme's background); a picture, gradient or pattern keeps its own base color.
  // A theme-slot background (the theme's own, or a slot name) with no variant keeps the slot's color: the scheme's `background` role does not
  // restyle it, as the preview draws it.
  const slotBackground = design.variant === undefined && (typeof definition === 'string' || definition?.type === 'theme');
  // A picture's base color is the variant's bg1 too, as the preview's canvas (its contrast backdrop, and the color of the automatic scrim, LH-02):
  // the tag and an eyebrow are judged against it, so a section on a photo writes the tag in the color the preview draws.
  if (core.resolved.roles && (isSingleColorBackground(definition) || definition?.type === 'image') && !slotBackground) background = normalizeHex(roles.background);
  else if (slotBackground && roles.background !== `#${background}`) roles = {...roles, background: `#${background}`};
  const textColor = normalizeHex(roles.text);

  return {
    seed: Number.isInteger(options.seed) ? options.seed : DEFAULT_SEED,
    timestamp: options.timestamp ?? FIXED_TIMESTAMP,
    zipDate: options.zipDate === undefined ? FIXED_ZIP_DATE : EXPLICIT_ZIP_SENTINEL,
    zipDateStamp: resolveZipDateStamp(options.zipDate),
    compressionLevel: Number.isInteger(options.compressionLevel) ? options.compressionLevel : 6,
    layoutName: "OPF_CANVAS",
    dimensions,
    theme,
    colorScheme,
    backgroundDefinition: design.background ?? theme?.background,
    fonts,
    // The color roles a ColorRef names (primary, secondary, accent, background, surface, text, textSecondary, hyperlink).
    roles,
    colors: {
      background,
      text: textColor,
      mutedText: normalizeHex(roles.textSecondary),
      // The primary color, which the exporter draws accent fills (table headers, tag, media badge) in. The `accent` ColorRef role is roles.accent.
      accent: normalizeHex(roles.primary),
      surface: normalizeHex(roles.surface),
      border: normalizeHex(roles.border)
    },
    variables
  };
}

function exportColor(entry, context, fallback) {
  return resolveExportColor(entry, colorContext(context, fallback));
}

// PptxGenJS color for a document color reference: a theme scheme value when the
// reference names a scheme slot or role that the deck theme holds exactly,
// otherwise the resolved literal RRGGBB. Alpha stays in the caller's transparency.
function nativeColor(reference, hex, context, fallback) {
  if (fallback !== undefined && (reference === undefined || reference === null || reference === '')) return pptxColor(fallback);
  const value = schemeColorValue(reference, hex, context, {vendor: true});
  if (value) return value;
  // PptxGenJS cannot write hlink or folHlink: a reserved literal stands in and
  // is rewritten to the scheme color in the finished slide part.
  const link = schemeColorValue(reference, hex, context);
  return (link && context.linkSentinels?.[link]) ?? normalizeHex(hex);
}

// FF-59: the slide tag is the eyebrow label. It is written in the deck primary color, the scheme accent1 slot the
// preview draws it from: a:schemeClr accent1 where the deck theme holds that exact color, the literal otherwise.
// FF-61: unless that primary is under 4.5:1 (WCAG 2.x) against the slide background, in which case the tag takes the
// slide text color, the value the title and body text get (the scheme text slot where the theme holds it). opf-render
// applies the same rule with the same arithmetic (test/tag-colour.mjs in both repositories pins the same color pairs).
const TAG_MIN_CONTRAST = 4.5;
function relativeLuminance(hex) {
  const [red, green, blue] = [0, 2, 4].map(offset => {
    const value = Number.parseInt(normalizeHex(hex).slice(offset, offset + 2), 16) / 255;
    return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return red * 0.2126 + green * 0.7152 + blue * 0.0722;
}
function contrastRatio(first, second) {
  const a = relativeLuminance(first), b = relativeLuminance(second);
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}
// The tag's color as a literal (the one tagColor writes, resolved).
function tagHex(context) {
  return contrastRatio(context.colors.accent, context.colors.background) < TAG_MIN_CONTRAST ? context.colors.text : context.colors.accent;
}

// The defaults a rich heading or quote body is exported with on every run (weight, color, size, family). The tag records them so that
// import can tell the heading's own look from run formatting the author chose.
function richBase(fit, style, color) {
  const font = nativeFontOptions(style);
  return {bold: font.bold === true, color: `#${normalizeHex(color)}`, fontSize: Math.round(fit.fontSize * .75 * 100) / 100, fontFamily: font.fontFace};
}

function tagColor(context) {
  if (contrastRatio(context.colors.accent, context.colors.background) < TAG_MIN_CONTRAST) return context.textColor;
  return nativeColor('primary', context.colors.accent, context);
}
// LH-50: a label core draws as an eyebrow (item.eyebrow) takes the tag's color on its backdrop: the card's fill when it is on one.
function eyebrowColor(context) {
  const backdrop = context.cardFill ? normalizeHex(context.cardFill) : context.colors.background;
  if (contrastRatio(context.colors.accent, backdrop) < TAG_MIN_CONTRAST) return context.textColor;
  return nativeColor('primary', context.colors.accent, context);
}
// LH-133: the literal of eyebrowColor (a glossary's term, an accent rule), for the run look import compares with and for line shapes.
function eyebrowHex(context) {
  const backdrop = context.cardFill ? normalizeHex(context.cardFill) : context.colors.background;
  return contrastRatio(context.colors.accent, backdrop) < TAG_MIN_CONTRAST ? context.colors.text : context.colors.accent;
}
const sameBox = (a, b) => !!a && !!b && a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;

// A link run with no color of its own is written in the theme hyperlink color (a:schemeClr hlink where the deck theme
// holds that exact color, else the literal), underlined by PowerPoint, as the preview draws it. A run color is kept.
function linkColor(run, color, context) {
  const link = typeof run?.link === 'string' && /^(https?:|mailto:|tel:)/i.test(run.link);
  if (!link || !(run.color === undefined || run.color === null || run.color === '')) return color;
  return nativeColor('hyperlink', normalizeHex(context.roles.hyperlink), context);
}

// FF-24c: two literals no document color uses stand in for hlink and folHlink
// (see nativeColor). When the document uses every candidate, those colors stay literal.
const LINK_SENTINELS = [['FE01A0', 'FE01A1'], ['FE02B0', 'FE02B1'], ['FE03C0', 'FE03C1']];
function linkSentinels(presentation) {
  const text = JSON.stringify(presentation).toUpperCase();
  const pair = LINK_SENTINELS.find(hexes => hexes.every(hex => !text.includes(hex)));
  return pair ? {hlink: pair[0], folHlink: pair[1]} : {};
}

function writeLinkSentinels(xml, sentinels) {
  const values = Object.entries(sentinels ?? {});
  if (!values.length) return xml;
  return xml.replace(/<a:srgbClr val="([0-9A-F]{6})"(\/>|>[\s\S]*?<\/a:srgbClr>)/g, (node, hex, rest) => {
    const link = values.find(([, value]) => value === hex)?.[0];
    return link ? `<a:schemeClr val="${link}"${rest.replace(/<\/a:srgbClr>$/, '</a:schemeClr>')}` : node;
  });
}

// LH-96: the color map of a template's layout variant, as clrMap attributes: the roles of a slide that only names the layout (core's
// resolved.layoutVariant is set where the layout names a variant and the deck draws no fixed background, LH-103). Undefined where the
// layout has none or its map is the master's, so the layout stays as it was.
function layoutColorMap(presentation, template, context, options) {
  const {resolved} = coreContext({...presentation, slides: [{layout: template.reference}]}, 0, {...options, textMeasurement: undefined});
  const attributes = resolved.layoutVariant && resolved.roles?.map ? clrMapAttributes(resolved.roles.map) : undefined;
  return attributes && JSON.stringify(attributes) !== JSON.stringify(context.clrMap) ? attributes : undefined;
}

// RR-96: the master's clrMap from the deck variant's map (core clrMapAttributes: bg1, tx1, bg2, tx2, the six accents and the two link slots).
function writeColorMap(xml, attributes) {
  return xml.replace(/<p:clrMap\b[^>]*\/>/, `<p:clrMap${Object.entries(attributes).map(([role, slot]) => ` ${role}="${slot}"`).join('')}/>`);
}

// PptxGenJS color option: a scheme value it can emit (tx1, bg2, ...) or RRGGBB.
function pptxColor(value) {
  return /^(?:tx[12]|bg[12]|accent[1-6])$/.test(value) ? value : normalizeHex(value);
}

// Deck-level background for the slide master, so slides added in PowerPoint match. The vendored layout already uses bg1, so a theme
// background on another slot (dark themes, light2, accents) changes the master, and so does a fixed background (LH-139): a hex color, a
// gradient or a pattern is the same native fill the slides write (a slide's own background still overrides it), and a picture is a picture
// fill of the media a slide of the deck embeds (`image`, completed at packaging by masterPictureBackground). The layouts then inherit the
// master's background; a layout variant (LH-01) writes its own bg1 background after this pass and stays per layout.
function masterBackground(context) {
  const deck = {...context, schemeOverride: false}, definition = deck.backgroundDefinition;
  const text = defaultTextSchemeValues(deck).text ?? normalizeHex(context.colors.text);
  if (definition?.type === 'image') return {fill: undefined, image: true, text};
  const value = schemeBackgroundValue(definition, deck);
  if (value === 'bg1' || definition === undefined) return null;
  if (value) {
    const fill = schemeBackgroundFill(definition, deck);
    return !fill || fill.includes('<a:alpha') ? null : {fill, text};
  }
  const fill = nativeBackgroundFill(definition, {width: context.dimensions.widthInches, height: context.dimensions.heightInches}, deck.colors.background, deck.colors.text,
    (reference, hex) => schemeColorValue(reference, hex, deck), reference => resolveBackgroundColorRef(reference, deck.colorScheme, deck.variables));
  return fill ? {fill, text} : null;
}

// LH-139: the picture fill of the master for a deck whose background is a picture (masterBackground `image`). It reuses the media the first slide
// that draws the deck's picture embeds (its native background fill, or the full-slide picture of one with alt text), related to the master too,
// with the same fit, focus, opacity and recolor. A deck whose picture no slide drew (it could not be read) keeps the master as it was.
function masterPictureBackground(entries, context, imageMetadata) {
  const wanted = context.masterBackground, picture = context.masterPicture;
  if (!wanted?.image) return;
  context.masterBackground = null;
  const master = 'ppt/slideMasters/slideMaster1.xml', rels = 'ppt/slideMasters/_rels/slideMaster1.xml.rels';
  if (!picture || !entries[master] || !entries[rels]) return;
  const xml = decodeText(entries[picture.part]);
  const shape = picture.name ? xml.match(/<p:pic>[\s\S]*?<\/p:pic>/g)?.find(pic => pic.match(/<p:cNvPr\b[^>]*\bname="([^"]*)"/)?.[1] === picture.name) : xml.match(/<p:bg>[\s\S]*?<\/p:bg>/)?.[0];
  const embed = shape?.match(/<a:blip\b[^>]*r:embed="([^"]+)"/)?.[1];
  const target = embed && parseRelationships(entries, picture.part).get(embed)?.path, metadata = target && imageMetadata.get(target);
  if (!metadata) return;
  const relsXml = decodeText(entries[rels]);
  const id = `rId${Math.max(0, ...[...relsXml.matchAll(/\bId="rId(\d+)"/g)].map(match => Number(match[1]))) + 1}`;
  entries[rels] = encodeText(relsXml.replace('</Relationships>', `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../${target.slice('ppt/'.length)}"/></Relationships>`));
  context.masterBackground = {fill: nativeImageBackgroundFill(id, metadata, {...picture.fit, fitImage}), text: wanted.text};
}

// The theme part carries the deck-level scheme (slide overrides stay literal)
// and, for a theme reference that resolves (embedded or in a registered catalog), that theme's name, which import
// recovery matches against the registered catalogs (FF-24). Without an authored theme,
// brand the generated theme: PowerPoint uses it for the Home > Layout category.
function exportTheme(presentation, context, options) {
  const reference = presentation.design?.theme;
  const theme = typeof reference === "string" ? resolveReference(presentation, "themes", reference, {catalogs: options.catalogs}) : undefined;
  const scheme = context.colorScheme;
  return {
    themeColors: themeSlotColors(scheme),
    schemeName: scheme.name ?? scheme.id ?? "OpenPresentation",
    themeName: theme ? theme.record.name ?? theme.id : "pptx.gallery"
  };
}

// FF-24 recovery against the host's registered catalogs (FA-23). Only the first registered catalog, the host default, can be
// named by a bare id in a document that declares no catalogs, so only its records are matched: an exact match imports as
// that bare id. Everything else (no catalog registered, a scheme from another registered catalog, no exact match) imports
// as an inline colour scheme, and no theme id is recovered.
function hostDefaultRecords(kind, catalogs) {
  return catalogRecords({}, kind, {catalogs: catalogs ?? []}).filter(entry => entry.group === "default").map(entry => ({...entry.record, id: entry.id}));
}

function importThemeDesign(entries, presentationRoot, presentationRels, catalogs) {
  const diagnostics = [], design = {};
  const report = (code, path, message) => diagnostics.push({code, path, message});
  // RR-96: the first slide master's clrMap is the deck's variant (a dark deck is bg1 on dk1 and tx1 on lt1), as design.variant: the background slot
  // alone, or {background, accents} when the map re-points the accents. The default map imports nothing.
  const masterId = asArray(presentationRoot?.["p:sldMasterIdLst"]?.["p:sldMasterId"]).map(node => node?.["r:id"]).find(id => presentationRels.get(id)?.type?.endsWith("/slideMaster"));
  const masterPart = masterId ? presentationRels.get(masterId).path : undefined;
  const masterMap = masterPart && entries[masterPart] ? parseOptionalXml(entries, masterPart)?.["p:sldMaster"]?.["p:clrMap"] : undefined;
  if (masterMap) {
    const mapped = variantFromColorMap(masterMap);
    if (mapped.variant) design.variant = mapped.variant;
    else if (mapped.unsupported) report("unsupported-color-map", "design.variant", "The slide master's color map is not a variant OPF can name (a background and text on the light and dark slots, with an accent order that is a permutation of accent1 to accent6), so design.variant was not imported.");
  }
  const themePath = presentationThemePath(presentationRoot, presentationRels, path => parseRelationships(entries, path), entries);
  const theme = themePath ? parseOptionalXml(entries, themePath)?.["a:theme"] : undefined;
  const elements = theme?.["a:themeElements"];
  const clrScheme = elements?.["a:clrScheme"];
  if (!clrScheme || Array.isArray(clrScheme)) {
    report("unsupported-theme-colors", "design.colorScheme", "The PPTX has no readable theme color scheme, so design.colorScheme was not imported.");
    return {design, diagnostics};
  }
  const {colors, unreadable} = readThemeSlotColors(clrScheme);
  const records = hostDefaultRecords("colorSchemes", catalogs);
  if (Object.keys(colors).length) design.colorScheme = recoverColorScheme({colors, unreadable, name: scalarText(clrScheme.name)}, records).value;
  if (unreadable.length) report("unsupported-theme-colors", "design.colorScheme", `Theme color slot(s) ${unreadable.join(", ")} do not resolve to an opaque sRGB color and were not imported.`);
  const latin = font => scalarText(elements?.["a:fontScheme"]?.[font]?.["a:latin"]?.typeface);
  // A theme's own colour and font scheme references resolve in the theme's group first (core resolveReference).
  const themeReference = (kind, reference) => {
    const id = referenceId(reference);
    const found = id ? resolveReference({}, kind, id, {catalogs: catalogs ?? [], group: "default"}) : undefined;
    return found ? {...found.record, ...(isPlainObject(reference) ? reference : {})} : null;
  };
  const recoveredTheme = recoverTheme({themeName: scalarText(theme?.name), colors, majorFont: latin("a:majorFont"), minorFont: latin("a:minorFont")}, {
    themes: hostDefaultRecords("themes", catalogs),
    colorScheme: record => themeReference("colorSchemes", record.colorScheme),
    fontFamilies: record => {
      const scheme = themeReference("fontSchemes", record.fontScheme);
      return scheme ? resolveFontFamilies(scheme) : null;
    }
  });
  if (recoveredTheme.unverified) report("theme-unverified", "design.theme", `The native theme has the name of OPF catalog theme '${recoveredTheme.unverified}', but neither its color scheme nor its heading/body fonts match that theme, so design.theme was not set.`);
  return {design: recoveredTheme.id ? {theme: recoveredTheme.id, ...design} : design, diagnostics};
}

function configurePresentation(pptx, presentation, context) {
  pptx.defineLayout({
    name: context.layoutName,
    width: context.dimensions.widthInches,
    height: context.dimensions.heightInches
  });
  pptx.layout = context.layoutName;
  pptx.author = normalizeAuthor(presentation.author) ?? DEFAULT_AUTHOR;
  pptx.company = "OpenPresentation";
  pptx.subject = presentation.description ?? "";
  pptx.title = presentation.name ?? presentation.filename ?? "OPF Presentation";
  pptx.revision = "1";
  pptx.theme = {
    headFontFace: context.fonts.heading,
    bodyFontFace: context.fonts.body
  };
}

async function addSlide(pptx, presentation, authoredSlide, slideIndex, context, options) {
  options = {...options, textMeasurement: slideTextMeasurement(presentation, slideIndex, options)};
  const slide = pptx.addSlide();
  const slideContext = exportSlideContext(presentation, slideIndex, context, options);
  // FA-31: the slide is composed and drawn with its slide-scoped variables substituted ({{slide.number}}, {{slide.section}},
  // {{deck.slideCount}} for this position in the exported deck, in body text as fixed text). The authored slide still holds the
  // tokens: header and footer text is substituted by core's furniture layout (a slide number stays a native field), and the
  // furniture manifest records the authored text.
  const opfSlide = slideContext.core.slide;
  const { widthInches, heightInches } = slideContext.dimensions;
  // A slide with no layout, or one whose layout resolves nowhere, is composed with no layout record (automatic composition),
  // as in the preview; core reports the reference as unresolved-reference.
  // Core's resolved options (canvas, layout, families, alignment, content box, darkBackground), with the exporter's own additions:
  // the families after the measurement provider's resolution of the chosen family and the raster padding. Core formats socials
  // handles from its own SOCIAL_PLATFORMS vocabulary.
  const composeOptions = { ...slideContext.core.options, fontFamilies: slideContext.composeFonts, textRasterPadding:options.textRasterPadding, ...(typeof options.pictureLuminance === "function" ? {pictureLuminance: options.pictureLuminance} : {}) };
  // Core resolves every shared design key once (slide design, deck design, then the layout record's design): the text alignment of
  // each item (item.alignment), and each image item's own fit and treatment (item.image).
  const geometry = composeSlide(opfSlide, composeOptions);
  if (slideIndex === 0) context.firstSlideOptions = composeOptions;
  // RR-81: a list core broke into columns (listColumns) is drawn as one measured list whose lines sit in their columns: each line
  // is its own shape at core's geometry, as in every list, and line names, numbering and provenance run across the columns.
  // Core's item.text is the whole list (every entry at its column's position); the lines are taken from listColumns, which replace
  // the entries rather than add to them, so each entry is drawn once.
  for (const item of geometry.items) if (item.listColumns?.length > 1 && item.text?.listEntries) item.text = {...item.text, listEntries: item.listColumns.flatMap(column => column.text?.listEntries ?? [])};
  // RR-81: a slide on a 0.19 template uses that template's native slide layout (src/template-layouts.js), whose placeholders
  // core composes with this slide's options (canvas, the deck's header and footer, direction) and its placed-image bands.
  let template = slideTemplate(slideContext.core);
  // LH-91: a slide recomposed at the readability floor (LH-83, geometry.recomposed) is drawn as the automatic grid and has no
  // regions, so its native body is planned as an automatic slide's is. It keeps its template's slide layout (the layout tag is
  // what import reads the slide's layout from), in a variant whose Body placeholder sits at the recomposed body's box.
  const recomposed = template !== undefined && geometry.recomposed !== undefined;
  const automatic = opfSlide.layout === undefined || opfSlide.layout === 'auto' || recomposed;
  const nativeBody = options.bodyText === 'native' ? planNativeBody(opfSlide, geometry, {automatic, report: options.onDiagnostic, textMeasurement: options.textMeasurement}) : undefined;
  if (template && nativeBody) template = recomposed
    ? {...template, key: `${template.key}\u0000recomposed-native-body`, recomposedBody: {box: nativeBody.box, anchor: nativeBody.anchor, style: {...nativeBody.item.textStyle, fontSize: nativeBody.item.text.fontSize, alignment: nativeBody.item.alignment}}}
    : {...template, key: `${template.key}\u0000native-body:${nativeBody.region}`, nativeBodyRegion: nativeBody.region};
  if (template) context.templateSlides[slideIndex] = {template, areaOptions: {...composeOptions, placements: placedImageBands(opfSlide)}};
  else if (automatic) context.automaticSlides[slideIndex] = {areaOptions: composeOptions, title: geometry.items.find(item => item.field === 'title'), ...(nativeBody ? {nativeBody} : {})};
  // The default footer band (date left, text center, number right): where a footer added natively lands (RR-11).
  if (slideIndex === 0) context.defaultFooterOptions = composeOptions;
  slideContext.zoneBand = zoneBands(composeOptions);
  slide.background = { color: slideContext.colors.background };
  // An image background is core's geometry.backgroundImage (slide, deck, then theme background); every other kind is the
  // effective design or theme background definition.
  const backgroundDefinition = geometry.backgroundImage ? undefined : slideContext.backgroundDefinition;
  const backgroundPath = `${opfSlide.design?.background !== undefined ? `slides.${slideIndex}.` : ''}design.background`;
  const backgroundFill = backgroundDefinition === undefined ? null : schemeBackgroundFill(backgroundDefinition, slideContext) ?? nativeBackgroundFill(backgroundDefinition, {
    width: slideContext.dimensions.widthInches, height: slideContext.dimensions.heightInches
  }, slideContext.colors.background, slideContext.colors.text, (reference, hex) => schemeColorValue(reference, hex, slideContext), reference => resolveBackgroundColorRef(reference, slideContext.colorScheme, slideContext.variables));
  if (backgroundFill) context.backgroundFills.set(`ppt/slides/slide${slideIndex + 1}.xml`, backgroundFill);
  if (backgroundDefinition?.type === 'pattern' && !nativePatternPreset(backgroundDefinition.pattern?.preset)) {
    options.onDiagnostic?.({code: 'unsupported-pattern', path: `${backgroundPath}.pattern.preset`, message: `Pattern ${backgroundDefinition.pattern?.preset} has no DrawingML preset; only its background color was exported.`});
  } else if (backgroundDefinition?.type === 'pattern' && nativePatternPreset(backgroundDefinition.pattern?.preset) !== backgroundDefinition.pattern?.preset) {
    // LH-29: an engine-defined preset the preview draws itself exports as its closest DrawingML preset.
    const preset = backgroundDefinition.pattern.preset, native = nativePatternPreset(preset);
    options.onDiagnostic?.({code: 'export-lossy', feature: 'pattern-preset', path: `${backgroundPath}.pattern.preset`, message: `Pattern ${preset} has no DrawingML preset and exports as the closest one, ${native}, whose marks can differ in size and spacing from the preview.`});
  }
  slide.color = slideContext.textColor;
  if (opfSlide.hidden === true) slide.hidden = true;

  for (const diagnostic of geometry.diagnostics) options.onDiagnostic?.(diagnostic);
  // The content topology (groups, regions, root form, block ids) with the leaf boxes this geometry draws.
  const nativePlans = nativeBody ? [nativeBody, ...nativeBody.others] : [];
  recordContentTopology(context.documentProvenance, opfSlide, slideIndex, nativeBody ? geometry.items.map(item => { const plan = nativePlans.find(plan => plan.item === item); return plan ? {...item, box: plan.box, text: undefined} : item; }) : geometry.items);
  recordOverlays(context.documentProvenance, authoredSlide, slideIndex);
  // Paint order, as in the preview (FA-22 contract): canvas colour, the background picture and its overlay, design.watermark,
  // the logo, then the items in core's order: the headings, the placed image blocks at their bands, then the flowed body.
  if (geometry.backgroundImage) await addBackgroundImage(slide, presentation, geometry.backgroundImage, slideIndex, slideContext, context, options);
  // RR-34: a captioned image's caption band follows its picture as tagged text boxes linked to the picture by name.
  const drawImage = async (item, itemContext) => {
    const name = await addImageItem(slide, presentation, item, slideIndex, itemContext, options);
    if (item.caption) addCaption(slide, item, name, itemContext, exportHelpers, (code, message) => new OPFPptxError(code, message, {path: item.caption.path}));
  };
  await addWatermark(slide, presentation, opfSlide, slideIndex, slideContext, context, options, geometry.surface !== undefined);
  // Cover and section slides: the deck logo core composed at the top-left of the free area, after the watermark and before content.
  if (geometry.logo) await addLogo(slide, presentation, geometry.logo, slideIndex, slideContext, context, options);
  // SH-04: the back layer of the overlay, after the background, watermark and logo and before every content shape, as the preview draws it.
  addOverlayShapes(slide, geometry, slideIndex, slideContext, context, 'back');
  const emphasisContext = geometry.emphasis ? emphasisExportContext(slideContext, emphasisSurface(slideContext.colorScheme, slideContext.roles)) : undefined;
  let emphasisDrawn = false, previousFrame;
  // LH-07: core's step badges, connectors and flows, under the text they number (src/step-badges.js).
  addSteps(slide, geometry.steps, {...slideContext, stepNumeral: tagColor(slideContext)}, context.stepTags, geometry.direction === 'rtl');
  // SH-09: core's pyramids and matrices, under their entries: live SmartArt (the entries are its nodes) or native shapes (src/smart-art.js).
  // SH-16: each live frame's fallback picture is cut from this slide's preview, drawn once.
  let preview;
  const liveArrangements = await addArrangements(slide, geometry.arrangements, {context: {...slideContext, direction: geometry.direction, deckLang: context.scriptFonts?.slides?.[slideIndex]?.lang ?? context.deckLang}, mode: context.smartArtMode, items: geometry.items, slideIndex,
    records: context.smartArt, tags: context.arrangementTags, smartArtTags: context.smartArtTags, provenance: context.provenanceMode, report: options.onDiagnostic, fontOf: nativeFontOptions,
    fallback: (arrangement, picture) => smartArtFallback(slide, arrangement, picture, () => (preview ??= smartArtSlideSvg(presentation, slideIndex + 1, options)), context, options)});
  const arranged = new Set((geometry.arrangements ?? []).map(arrangement => arrangement.path));
  // LH-130: core's accent rule above the title, in the tag's color (src/title-rule.js).
  addTitleRule(slide, geometry.titleRule, tagColor(slideContext), context.titleRuleTags);
  for (const [itemIndex, item] of geometry.items.entries()) {
    // RR-81: the lone picture, chart or table of a `none` region binds to that region's placeholder on the slide layout. A captioned
    // object or one drawn on a card stays a free shape: Change Layout would move it away from its caption or card.
    const boundRegion = template && item.region !== undefined && ['image', 'chart', 'table'].includes(item.field) && !item.caption && !item.frameBox
      ? geometry.regions?.find(region => region.name === item.region && region.flow === 'none' && region.content?.length === 1 && !region.overflow?.length) : undefined;
    // RR-88: under bodyText 'native' a plain-string title that wraps is one native text box (native wrap, no autofit) at its measured
    // block, so it can bind to the Title placeholder like a one-line title (Keynote reports `title showing` only for a bound title).
    const wantsNativeTitle = options.bodyText === 'native' && (template || context.automaticSlides[slideIndex]) && isNativeTitle(item);
    const titleFace = wantsNativeTitle ? nativeFontOptions(item.textStyle) : undefined;
    const nativeTitle = wantsNativeTitle ? nativeTitleWrapBox(item, geometry, options.textMeasurement, {
      nativeStyle: {fontFamily: options.safeTypeface ? options.safeTypeface(titleFace.fontFace) : titleFace.fontFace, fontWeight: titleFace.bold ? 700 : 400, italic: titleFace.italic === true},
      report: reason => options.onDiagnostic?.({
      code: 'native-body-fallback', path: item.path, reason,
      message: reason === 'font-metrics' ? 'Native title export uses a visual font substitute for measurement, so native line breaks cannot be verified; the authored font and size were retained as measured lines.'
        : 'Native title export cannot preserve the measured line breaks with a wrap margin inside its title area; the measured lines were exported.'
    })}) : undefined;
    if ((template || context.automaticSlides[slideIndex]) && item.field === 'title' && typeof item.value === 'string' && (item.text?.lines?.length === 1 || nativeTitle) && !item.text.overflow && !item.text.richLines)
      context.placeholderBindings.set(`OPF heading ${item.path} line 0`, {slide: slideIndex, region: 'Title', object: 'title'});
    const drawnBefore = boundRegion && {images: context.images.size, placeholders: context.imagePlaceholders.size, charts: context.chartHeadings.size, tables: context.tableHeaders.size};
    // Card text sits on a literal card fill, not the slide background: keep it literal.
    // LH-54: the card fill is core's card neutral (a filled surface on a dark slide whose scheme surface is the background), which a metric is coloured against.
    const cardNeutral = slideContext.roles.neutrals?.card;
    // LH-06: an item on the emphasis surface is colored with the surface's roles (literal, as card text is), and the surface, a tagged
    // card frame in core's fill and radius with no line, is drawn under the first of them, as the preview draws it.
    const itemContext = item.emphasis && emphasisContext ? emphasisContext : item.frameBox ? {...slideContext, textColor: slideContext.colors.text, mutedColor: slideContext.colors.mutedText, ...(cardNeutral ? {cardFill: cardNeutral.hex} : {})} : slideContext;
    if (item.emphasis && emphasisContext && !emphasisDrawn) {
      emphasisDrawn = true;
      const {box, radius, path: emphasisPath} = geometry.emphasis;
      context.cardTags.set(`OPF card ${emphasisPath}`, emphasisPath);
      slide.addShape('roundRect', {x: box.x / 96, y: box.y / 96, w: box.width / 96, h: box.height / 96, rectRadius: radius / 96,
        fill: {color: emphasisContext.colors.background, transparency: 0}, line: {type: 'none'}, objectName: `OPF card ${emphasisPath}`});
      // LH-131: a featured before and after pair's arrow, drawn and tagged as LH-07's flow arrows are (OPF_STEPS_V1, consumed on import:
      // the layout's drawing, not content), in the accent where core placed it, with the surface as the preview draws it.
      const arrow = geometry.emphasis.arrow;
      if (arrow) {
        const objectName = `OPF steps ${emphasisPath} arrow`;
        slide.addShape(arrow.direction === 'left' ? 'leftArrow' : 'rightArrow', {x: arrow.box.x / 96, y: arrow.box.y / 96, w: arrow.box.width / 96, h: arrow.box.height / 96,
          fill: {color: normalizeHex(slideContext.colors.accent)}, line: {type: 'none'}, objectName});
        context.stepTags.set(objectName, {v: 1, path: emphasisPath, form: 'pair', sequence: 0, role: 'arrow'});
      }
    }
    const region = { x: item.box.x / 96, y: item.box.y / 96, w: item.box.width / 96, h: item.box.height / 96 };
    // LH-50: a label drawn as an eyebrow shares its paragraph's card (the same frameBox): the card is drawn once, under the eyebrow, and
    // named for the paragraph (the next item), whose block it is.
    const sharedCard = sameBox(item.frameBox, previousFrame);
    previousFrame = item.frameBox;
    if (item.frameBox && !sharedCard) {
      const frame=item.frameBox, owner=item.eyebrow&&sameBox(geometry.items[itemIndex+1]?.frameBox,frame)?geometry.items[itemIndex+1]:item;
      context.cardTags.set(`OPF card ${owner.path}`,owner.path);
      const paint=value=>({color:normalizeHex(value),transparency:/^#[0-9a-f]{8}$/i.test(value)?(1-parseInt(value.slice(7),16)/255)*100:0});
      const surface=cardNeutral?.hex??itemContext.colorScheme.surface??itemContext.colorScheme[itemContext.roles.dark?'dark2':'light2']??`#${itemContext.colors.surface}`;
      slide.addShape('roundRect',{x:frame.x/96,y:frame.y/96,w:frame.width/96,h:frame.height/96,
        rectRadius:8*Math.min(widthInches,heightInches)/720,
        fill:paint(surface),line:{...paint(itemContext.roles.neutrals?.cardBorder?.hex??`#${itemContext.colors.border}`),width:.75},objectName:`OPF card ${owner.path}`});
    }
    if (nativeTitle) {
      addNativeTitle(slide, item, itemContext, options, context, nativeTitle);
    } else if (nativePlans.some(plan => plan.item === item)) {
      // RR-88: the first native body is the Body placeholder; every further one is an ordinary native text box at its region.
      const plan = nativePlans.find(plan => plan.item === item);
      const body = addNativeBody(slide, plan, itemContext, options, {textBoxOptions, nativeFontOptions, exportColor, nativeColor, linkColor, langOptions, solidColorXml});
      context.nativeBodies.set(body.objectName, body.defaults);
      if (plan === nativeBody && !plan.carded) context.placeholderBindings.set(body.objectName, {slide: slideIndex, region: nativeBody.region, object: 'body'});
    } else if(['text','title','subtitle','tag'].includes(item.field)&&(item.text?.placement||item.text?.sourceLines)&&!item.text.richLines) {
      addMeasuredPayloadText(slide,item.value,item.box,itemContext,options,{path:item.path,fit:item.text,textStyle:item.textStyle,sourceText:item.field==='text'&&!!item.text.sourceLines,align:item.alignment,diagnosticsHandled:true,heading:['title','subtitle','tag'].includes(item.field)?(item.titleSplit?'title':item.field):undefined,headingLines:titleSplitLines(item,geometry.items,opfSlide.title),color:item.field==='tag'?tagColor(itemContext):item.eyebrow?eyebrowColor(itemContext):itemContext.textColor});
    } else if (["title", "subtitle", "tag"].includes(item.field) && !item.text?.richLines) {
      // Estimated-font headings use one native text box, which still needs a
      // role tag. Role recovery must not depend on outline measurement support.
      const split = titleSplitLines(item, geometry.items, opfSlide.title), objectName = `OPF heading ${item.path} line ${split?.offset ?? 0}`;
      context.headingTags.set(objectName,{v:1,group:item.path,field:split?'title':item.field,line:split?.offset??0,count:split?.count??1});
      slide.addText(item.text.lines.join("\n"), {
        ...textBoxOptions(region, itemContext, item.text.fontSize * 0.75),
        ...nativeFontOptions(item.textStyle), ...eyebrowOptions(item.textStyle, item.text.fontSize),
        color: item.field === "tag" ? tagColor(itemContext) : itemContext.textColor,
        align: physicalAlignment(item.alignment, item.text.directions?.[0]),
        ...(item.text.directions?.[0] === 'rtl' ? {rtlMode: true} : {}),
        objectName,
        breakLine: false
      });
    } else if ((item.field === "items" || item.field === "bullets") && item.text?.listEntries && liveArrangements.has(item.path)) {
      // SH-09: the entries are the live SmartArt's nodes.
    } else if ((item.field === "items" || item.field === "bullets") && item.text?.listEntries && arranged.has(item.path)) {
      // SH-09: a pyramid's or matrix's entries on its native shapes, as core placed them.
      // On its node in the color that reads on the primary, centered; beside a level or on a card in the slide's text color, at the start edge.
      const arrangement = geometry.arrangements.find(entry => entry.path === item.path), text = exportPaint(itemContext).text.hex.slice(1);
      const lineContext = arrangement.text === 'node' ? {...itemContext,colors:{...itemContext.colors,text},textColor:text} : itemContext;
      await addMeasuredList(slide,item.text,lineContext,item.path,item.bulletImage,presentation,slideIndex,options,false,arrangement.align === 'center' ? 'center' : undefined,['org-chart','hierarchy'].includes(arrangement.kind));
      if(item.textStyle){
        const look = listRunLook(item.text,item.textStyle,itemContext);
        recordListRuns(context.documentProvenance,slideIndex,item.path,look);
        if(look?.text)recordListScalars(context.documentProvenance,slideIndex,item.path,scriptSplitListScalars(item.text,itemContext));
      }
    } else if ((item.field === "items" || item.field === "bullets") && item.text?.listEntries) {
      // LH-168: a list numbered by core's step badges carries its numbers on the badges, not as list markers.
      const badgeNumbered=(geometry.steps??[]).some(step=>step.badges?.some(badge=>badge.list?.path===item.path));
      await addMeasuredList(slide,item.text,itemContext,item.path,item.bulletImage,presentation,slideIndex,options,item.payload?.numbering!==undefined&&!badgeNumbered);
      // opf-pptx#212: the look every run of the list is written with where its source states none (full provenance only).
      if(item.textStyle){
        const look = listRunLook(item.text,item.textStyle,itemContext);
        recordListRuns(context.documentProvenance,slideIndex,item.path,look);
        if(look?.text)recordListScalars(context.documentProvenance,slideIndex,item.path,scriptSplitListScalars(item.text,itemContext));
      }
    } else if (["text", "title", "subtitle", "tag"].includes(item.field) && item.text?.richLines) {
      // FA-10: a TextRun[] heading draws and exports like rich body text; its lines are named and tagged as a heading (the body's are not).
      const heading = item.field !== 'text';
      addRichFitLines(slide, item.text, item.box, itemContext, {
        value: item.runs ?? item.value, path: item.path, alignment: item.text.placement?.alignment ?? item.alignment ?? 'left',
        fallback: item.field === 'tag' ? tagColor(itemContext) : item.eyebrow ? eyebrowColor(itemContext) : itemContext.textColor,
        ...(heading ? {
          objectName: index => `OPF heading ${item.path} line ${index}`,
          tag: (name, index, count, boundary) => context.headingTags.set(name, {v: 1, group: item.path, field: item.field, line: index, count, ...boundary, base: richBase(item.text, item.textStyle, item.field === 'tag' ? tagHex(itemContext) : itemContext.colors.text)})
        } : {}),
        // LH-63: a run-in heading's bold run is core's, not the author's: the lines are tagged as plain text (as an unformatted body's are), so an
        // unchanged export imports back as the authored string.
        ...(item.runs ? {objectName: index => `OPF text ${item.path} line ${index}`, tag: (name, index, count, boundary) => context.plainTextTags.set(name, {v: 1, group: item.path, line: index, count, ...boundary}), keepEmpty: true} : {})
      });
    } else if (item.field === "text" && typeof item.value === "string") {
      slide.addText(item.text.lines.join("\n"), {...textBoxOptions(region, itemContext, item.text.fontSize * 0.75),...nativeFontOptions(item.textStyle),...eyebrowOptions(item.textStyle, item.text.fontSize),...(item.eyebrow ? {color: pptxColor(eyebrowColor(itemContext))} : {}),align:physicalAlignment(item.alignment, item.text.directions?.[0])});
    } else if (item.field === "shape" && item.shape) {
      addShapeItem(slide, item, slideIndex, itemContext, context);
    } else if (item.field === "image" && item.image) {
      await drawImage(item, itemContext);
    } else if (item.field === "diagram") {
      // A diagram is one native SVG picture over its PNG fallback (or the unavailable-diagram placeholder); its caption follows it.
      const name = await addDiagramItem(slide, item, slideIndex, itemContext, options);
      if (item.caption) addCaption(slide, item, name, itemContext, exportHelpers, (code, message) => new OPFPptxError(code, message, {path: item.caption.path}));
    } else {
      // RR-34: a captioned item draws its media in item.box; the caption band follows as tagged text boxes linked to the media shape by name.
      const mediaNames = item.caption ? new Set([...context.images.keys(), ...context.imagePlaceholders.keys(), ...context.chartHeadings.keys(), ...context.tableHeaders.keys()]) : undefined;
      await addPayload(slide, presentation, item.payload, region, item.path, { ...itemContext, composition: item.composition, contentAlignment: item.alignment ?? "left", tableAlignment: geometry.design.contentAlignment, direction: geometry.direction, tableGrowth: item.tableGrowth, tableHighlight: item.tableHighlight }, options, item.quoteLayout, item.codeLayout,item.metricLayout,item.timelineLayout, item.chart);
      if (item.caption) {
        const mediaName = item.field === 'video' ? `OPF media ${item.path} frame` : [...context.images.keys(), ...context.imagePlaceholders.keys(), ...context.chartHeadings.keys(), ...context.tableHeaders.keys()].find(name => !mediaNames.has(name));
        addCaption(slide, item, mediaName, itemContext, exportHelpers, (code, message) => new OPFPptxError(code, message, {path: item.caption.path}));
      }
    }
    if (drawnBefore) {
      const added = (map, size) => [...map.keys()].slice(size);
      const names = item.field === 'image' ? (context.imagePlaceholders.size === drawnBefore.placeholders ? added(context.images, drawnBefore.images) : [])
        : item.field === 'chart' ? added(context.chartHeadings, drawnBefore.charts).filter(name => !context.chartex.has(name)) : added(context.tableHeaders, drawnBefore.tables);
      if (names.length === 1) context.placeholderBindings.set(names[0], {slide: slideIndex, region: boundRegion.name, object: item.field === 'image' ? 'picture' : item.field});
    }
  }
  // LH-14: core's icons on their chips, over the cards and surfaces they sit on (src/icons.js). A multicolor icon is an SVG picture with its
  // PNG fallback, contained in the chip's square at the SVG's own aspect, as an SVG image block is.
  await addIcons(slide, geometry.icons, slideContext, context.iconTags, async (icon, box, name) => {
    const aspect = icon.picture.width / icon.picture.height, w = aspect >= 1 ? box.w : box.h * aspect, h = aspect >= 1 ? box.w / aspect : box.h;
    const area = {x: box.x + (box.w - w) / 2, y: box.y + (box.h - h) / 2, w, h}, outcome = {box: area};
    const resolved = await resolveSvgImage(encodeText(icon.picture.svg), options, icon.path, outcome);
    if (!resolved) return false;
    if (outcome.svg) context.svgPictures.set(name, outcome.svg);
    slide.addImage({...resolved, objectName: name, ...area, altText: ''});
    return true;
  });
  // RR-34: the footnote area core reserved above the footer band (rule plus one tagged text box per listed line).
  addFootnotes(slide, geometry.footnotes, slideIndex, slideContext, exportHelpers, (code, message) => new OPFPptxError(code, message, {path: `slides.${slideIndex}`}));
  // Core composes furniture above all content and opf-render paints it last, so
  // spTree order (PowerPoint's z-order) matches: header/footer parts come after
  // every content item, and an overlapping footer stays visible over content.
  await addFurniture(slide,presentation,authoredSlide,geometry.furniture,slideContext,options,slideIndex);
  // SH-04: the slide's overlay (core geometry.overlayShapes) over everything else, in array order, as the preview draws it.
  addOverlayShapes(slide, geometry, slideIndex, slideContext, context, 'front');

  if (opfSlide.notes) {
    const notes = String(opfSlide.notes);
    slide.addNotes(notes);
    if (notes.includes('\r')) context.notesWithCarriageReturns.set(`ppt/notesSlides/notesSlide${slideIndex + 1}.xml`, notes);
  }
}

// LH-06: the export context of an item on the emphasis surface (core's emphasisSurface): the surface fill is its background and the surface's
// roles its colors, written literal (a slide-scheme color they equal becomes a scheme color again in writeSchemeColors).
function emphasisExportContext(context, surface) {
  const roles = surface.roles, fill = normalizeHex(surface.fill);
  const colors = {...context.colors, background: fill, text: normalizeHex(roles.text), mutedText: normalizeHex(roles.textSecondary), accent: normalizeHex(roles.primary), surface: normalizeHex(roles.surface), border: normalizeHex(roles.border)};
  return {...context, schemeOverride: true, roles, colors, textColor: colors.text, mutedColor: colors.mutedText, cardFill: `#${fill}`};
}

// RR-81: the placed-image bands of a slide (its image blocks with a `placement`), which a template layout reserves as the slide does.
function placedImageBands(slide) {
  return (Array.isArray(slide?.blocks) ? slide.blocks : [])
    .filter(block => isPlainObject(block) && isPlainObject(block.placement) && typeof block.placement.edge === 'string' && (block.image !== undefined || block.type === 'image'))
    .map(({placement}) => ({edge: placement.edge, ...(placement.size !== undefined ? {size: placement.size} : {}), ...(placement.inset !== undefined ? {inset: placement.inset} : {})}));
}

// One slide's export context: core's resolveSlideContext (`core`: composeSlide's options, the records and the diagnostics) and
// the exporter's colours and measurement-resolved families derived from it.
// RR-97: the deck's own background stays literal on a slide whose picture background is unreadable and falls back to it (useFallbackBackground).
const geometryFallbackBackground = presentation => presentation.design?.background;

function exportSlideContext(presentation, slideIndex, baseContext, options) {
  const slide = presentation.slides[slideIndex];
  const core = coreContext(presentation, slideIndex, options);
  // LH-01: a layout's variant (core's resolved.layoutVariant, set only where the slide names neither a variant nor a background) replaces
  // the deck's variant and hides the deck's background, as a slide variant over the theme's does.
  const layoutVariant = core.resolved.layoutVariant;
  const effective = { ...presentation, design: { ...presentation.design, ...(layoutVariant ? {variant: layoutVariant, background: undefined} : {}), ...slide.design } };
  const resolved = resolvePresentationContext(effective, options, core);
  // A reference that matched no record is reported once per place it is written.
  for (const diagnostic of core.diagnostics) {
    if (baseContext.reportedReferences?.has(diagnostic.path)) continue;
    baseContext.reportedReferences?.add(diagnostic.path);
    options.onDiagnostic?.(diagnostic);
  }
  if (Math.abs(resolved.dimensions.widthInches - baseContext.dimensions.widthInches) > 1e-6
    || Math.abs(resolved.dimensions.heightInches - baseContext.dimensions.heightInches) > 1e-6) {
    throw new OPFPptxError("mixed-slide-dimensions", "PowerPoint requires one canvas size per presentation. Set dimensions on the deck or export this slide separately.");
  }
  const slideContext = { ...baseContext, slideIndex, core, composeFonts: {...core.options.fontFamilies, heading: resolved.fonts.heading, body: resolved.fonts.body, code: resolved.fonts.code}, backgroundDefinition: resolved.backgroundDefinition, colorScheme: resolved.colorScheme, fonts: resolved.fonts, colors: resolved.colors, roles: resolved.roles, variables: resolved.variables };
  // RR-96: a slide whose variant differs from the deck's writes its own clrMapOvr (accent order included).
  if (resolved.roles.map && baseContext.clrMap) {
    const attributes = clrMapAttributes(resolved.roles.map);
    if (JSON.stringify(attributes) !== JSON.stringify(baseContext.clrMap)) baseContext.clrMapOverrides.set(`ppt/slides/slide${slideIndex + 1}.xml`, attributes);
  }
  // A slide-level color scheme (directly or through a slide theme) pins every
  // named color on that slide to literal sRGB; see schemeColorValue().
  const slideScheme = themeSlotColors(resolved.colorScheme), deckScheme = baseContext.themeColors ?? {};
  slideContext.schemeOverride = slide.design?.colorScheme !== undefined
    || Object.keys({...slideScheme, ...deckScheme}).some(slot => slideScheme[slot] !== deckScheme[slot]);
  // Default and muted text follow the theme only where the background does.
  const text = defaultTextSchemeValues(slideContext);
  slideContext.textColor = text.text ?? resolved.colors.text;
  slideContext.mutedColor = text.muted ?? resolved.colors.mutedText;
  // SH-02: the slide's lighter and darker ColorRefs are written as their base with a:lumMod and a:lumOff.
  const slideTable = addTransformedColors(schemeColorTable(slideContext), reference => exportColor(reference, slideContext, slideContext.colors?.text), slide, effective.design?.background);
  baseContext.slideSchemeColors[slideIndex] = {table: slideTable, keep: authoredLiteralColors(slide, presentation.variables, {...effective.design, colorScheme: undefined, theme: undefined}, geometryFallbackBackground(presentation))};
  return slideContext;
}

function fieldToType(field) {
  return field === "items" || field === "bullets" ? "list" : field;
}

async function addPayload(slide, presentation, payload, region, path, context, options, quoteLayout, codeLayout,metricLayout,timelineLayout,chartLayout) {
  const kind = inferPayloadKind(payload);
  switch (kind) {
    case "text":
      addTextPayload(slide, payload.text ?? payload.bullets, region, context, path);
      break;
    case "list":
      addListPayload(slide, payload.items ?? payload.bullets, region, context);
      break;
    case "image":
      await addImagePayload(slide, presentation, payload.image, region, path, context, options);
      break;
    case "video":
      addMediaPayload(slide, presentation, payload.video, region, path, context, options);
      break;
    case "chart":
      addChartPayload(slide, payload.chart, region, context, options, path, presentation, chartLayout);
      break;
    case "table":
      addTablePayload(slide, payload.table, region, context, options, path, presentation);
      break;
    case "code":
      addCodePayload(slide, payload.code, codeLayout, region, context, path, options);
      break;
    case "metric":
      addMetricPayload(slide, payload.metric,metricLayout,context,path,options,presentation);
      break;
    case "quote":
      await addQuotePayload(slide, presentation, payload.quote, quoteLayout, context, options, path);
      break;
    case "timeline":
      addTimelinePayload(slide, payload.timeline, timelineLayout, context, options, path);
      break;
    case "diagram":
      // Core draws every diagram item (item.diagram, handled before addPayload); a payload reaching here has no drawing.
      options.onDiagnostic?.({code: "content-placeholder", path, reason: "diagram-unavailable", message: "The diagram has no drawing; the unavailable-diagram placeholder stands in for it."});
      addDiagramPlaceholder(slide, region, context, undefined);
      break;
    default:
      options.onDiagnostic?.({code: "content-placeholder", path, reason: "unsupported-payload", message: "This content has no PowerPoint export; a placeholder frame stands in for it."});
      addPlaceholderPayload(slide, "Unsupported content", "This content has no PowerPoint export.", region, context);
  }
}

function inferPayloadKind(payload) {
  if (payload?.type === "list") return "list";
  if (payload?.type && ROOT_PAYLOAD_FIELDS.includes(payload.type)) return fieldToType(payload.type);
  if (payload?.items !== undefined) return "list";
  for (const field of ROOT_PAYLOAD_FIELDS) {
    if (payload?.[field] !== undefined) return fieldToType(field);
  }
  return "unknown";
}

function addTextPayload(slide, value, region, context, path) {
  if (Array.isArray(value)) {
    slide.addText(textRuns(value, context, 18, path), textBoxOptions(region, context, 18));
    return;
  }
  if (Array.isArray(value?.bullets)) {
    addListPayload(slide, value.bullets, region, context);
    return;
  }
  slide.addText(stringifyText(value), textBoxOptions(region, context, 18));
}

// opf-pptx#212: the look (richBase) the runs of a measured list are written with where the source states none: {text,
// description?}, or undefined when its entries do not share one (import then reads every run value as observed).
// LH-77: the entry of a heading list is written bold, so its look is the style core gave a run that states no weight of its own.
function listRunLook(fit,style,context){
  // LH-08: the label of a ruled row with a description is written bold, as a heading list's entry is.
  const entryStyle=(entry,kind)=>kind==='text'&&(entry.heading||entry.text.richLines.some(line=>line.fragments.some(fragment=>fragment.run?.bold===undefined&&fragment.style.fontWeight!==style.fontWeight)))?entry.text.richLines.flatMap(line=>line.fragments).find(fragment=>fragment.run?.bold===undefined)?.style??{...style,fontWeight:700}:style;
  // LH-133: a glossary's term is written in the accent (eyebrowHex), so that is its look.
  const looks=kind=>new Set(fit.listEntries.filter(entry=>entry[kind]).map(entry=>JSON.stringify(richBase(entry[kind],entryStyle(entry,kind),kind==='text'?entry.accent?eyebrowHex(context):context.colors.text:context.colors.mutedText))));
  const text=looks('text'),description=looks('description');
  if(text.size!==1||description.size>1)return undefined;
  return {text:JSON.parse([...text][0]),...(description.size?{description:JSON.parse([...description][0])}:{})};
}
// Follow the same paragraph direction and LTR ranges as native bidi splitting.
// No source strings or flags for ordinary LTR/rich values enter the record.
function scriptSplitListScalars(fit, context) {
  const plan = context.scriptFonts?.slides?.[context.slideIndex ?? 0] ?? context.scriptFonts?.deck;
  if (!plan?.rtl) return undefined;
  const result = [];
  fit.listEntries.forEach((entry, item) => {
    for (const [role, value] of [['text', entry.value], ['description', entry.descriptionValue]]) {
      if (typeof value !== 'string' || !entry[role]) continue;
      const text = entry[role], split = text.richLines.some((line, index) => {
        if ((text.directions?.[index] ?? entry.direction) !== 'rtl') return false;
        return line.fragments.some(fragment => {
          const ranges = leftToRightPieces(fragment.text);
          return ranges.length > 0 && (line.fragments.length > 1 || ranges.some(([from, to]) => from > 0 || to < fragment.text.length));
        });
      });
      if (split) result.push([item, role]);
    }
  });
  return result.length ? result : undefined;
}
function richLineRuns(line,color,native,context,path) {
  const fallback=color.replace(/^#/,'');
  return line.fragments.map(fragment=>{
    assertXmlText(fragment.run.text ?? fragment.text, path);
    const runColor=exportColor(fragment.run.color,context,fallback),color=nativeColor(fragment.run.color,runColor,context,native);
    return {text:fragment.text,options:{...nativeFontOptions(fragment.style),fontSize:(fragment.nominalSize??fragment.fontSize)*.75,color:linkColor(fragment.run,color,context),underline:fragment.run.underline?{style:'sng',color:linkColor(fragment.run,color,context)}:undefined,strike:fragment.run.strikethrough?'sngStrike':undefined,baseline:fragment.baselineShift?-fragment.baselineShift/(fragment.nominalSize??fragment.fontSize)*2000:undefined,hyperlink:fragment.run.link&&/^(https?:|mailto:|tel:)/i.test(fragment.run.link)?{url:fragment.run.link}:undefined,...langOptions(context,fragment.style.lang)}};
  });
}
// Every native line of a list, marker paragraph or not, is named for the list's
// composed path (`OPF list <path> line N`, N counting across the whole list) like
// the other measured text shapes. A reader maps lines to their list by name, not
// by geometry, so lines of an overflowing list that fall below its box still
// belong to it.
// design.listBullet: image (core's item.bulletImage, the deck's icon logo) makes every entry marker a native picture bullet.
// PptxGenJS embeds the media and its relationship through one picture per slide (OPF bullet image); packaging removes
// that picture and points each marker paragraph at the relationship with a:buBlip. An icon that cannot be embedded
// keeps the character bullets, as the preview does.
async function addMeasuredList(slide,fit,context,path,bulletImage,presentation,slideIndex,options,numbered=false,align,keepLevels=false) {
  // RR-33: a numbered list writes native auto-numbers (a:buAutoNum) at core's marker geometry. Core older than the numbering
  // release composes bullet markers, so nothing numbered can be written; say so instead of exporting bullets silently.
  if(numbered&&!fit.listEntries.some(entry=>entry.marker.number))options.onDiagnostic?.({code:'numbering-unsupported-core',path,message:'The installed @openpresentation/opf does not compose numbered lists (numbering), so the list is exported with bullets. Use a core release that supports numbering.'});
  let picture=false;
  if(bulletImage){
    const part=`ppt/slides/slide${slideIndex+1}.xml`;
    if(context.bulletImages.has(part))picture=context.bulletImages.get(part);
    else{
      // A picture bullet (a:buBlip) can only reference a raster: an SVG icon is its PNG fallback.
      const outcome={box:{w:.5,h:.5}};
      const resolved=await resolveImage(bulletImage.source,presentation,options,bulletImage.path,outcome);
      if(resolved){
        slide.addImage({...resolved,objectName:bulletImageName(),x:0,y:0,w:.1,h:.1,altText:''});
        picture=true;
        // LH-29: the preview draws the SVG icon as vectors; PowerPoint's picture bullet is that PNG.
        if(outcome.svg)options.onDiagnostic?.({code:'export-lossy',feature:'svg-rasterized',path:bulletImage.path,message:'A picture bullet can only be a raster in PowerPoint (a:buBlip), so the SVG icon exports as its PNG; it can look soft when the slide is enlarged.'});
      }else if(!outcome.reported)options.onDiagnostic?.({code:'unresolved-asset',path:bulletImage.path,message:'A picture bullet needs an embedded raster, a declared asset or a host imageResolver; the character bullets were exported instead.'});
      context.bulletImages.set(part,picture);
    }
  }
  let lineNumber=0;
  for(const entry of fit.listEntries){
    const addLines=(text,box,color,native,withBullet)=>{
      text.richLines.forEach((line,index)=>{
        // design.listBullet: none (entry.marker.none): the first line has no marker, no inset and no hanging indent (a:buNone); core
        // already moved a nested level's text box, so the paragraph carries no indent level.
        const first=withBullet&&index===0,markerless=first&&entry.marker.none===true,level=Math.min(8,entry.level),inset=first&&!markerless?entry.marker.indent*(level+1):0;
        // Right to left (RR-05): the bullet column is at the right, so the first line's box extends right to hold it and the paragraph
        // is rtl with its text aligned to the right; marL/indent are the start-side margin and hanging indent in PowerPoint.
        const entryRtl=entry.direction==='rtl';
        const lineDirection=(text.directions?.[index])??entry.direction;
        // SH-09: a centered line (an entry on a pyramid's or matrix's node) is its own width, centered in the entry's box, as core measured it
        // without the space it broke at; it starts at its start edge.
        const centered=align==='center'&&!inset,offset=centered?Math.max(0,(box.width-line.width)/2):0;
        const region=centered?{x:(box.x+offset)/96,y:(box.y+line.y)/96,w:Math.max(1,line.width)/96,h:line.height/96}:{x:(entryRtl?box.x:box.x-inset)/96,y:(box.y+line.y)/96,w:(box.width+inset)/96,h:line.height/96};
        const lineAlign=physicalAlignment('left',lineDirection);
        const objectName=`OPF list ${path} line ${lineNumber++}`;
        const number=first?entry.marker.number:undefined;
        if(first&&!markerless)context.listMarkers.set(objectName,{fontFamily:entry.marker.style.fontFamily,fontSize:entry.marker.fontSize*.75,color:pptxColor(context.textColor),picture:number?false:picture});
        const paragraph=first&&!markerless?{bullet:number?{type:'number',style:autoNumScheme(number.style,number.suffix),startAt:number.value,indent:entry.marker.indent*.75}:{characterCode:entry.marker.text.codePointAt(0).toString(16).padStart(4,'0'),indent:entry.marker.indent*.75},indentLevel:level}:{bullet:false,...(keepLevels?{indentLevel:level}:{})};
        const runs=richLineRuns(line,color,native,context,path);
        if(!runs.length)runs.push({text:'',options:{}});
        // Keep paragraph intent identical across runs. ZIP normalization below
        // removes the duplicate paragraph-property nodes emitted by PptxGenJS.
        for(const run of runs)Object.assign(run.options,paragraph,lineDirection==='rtl'?{rtlMode:true}:{});
        slide.addText(runs,{...textBoxOptions(region,context,text.fontSize*.75),fontFace:nativeFontOptions(entry.marker.style).fontFace,objectName,align:lineAlign,fit:'none',wrap:false,lineSpacingMultiple:1,...paragraph});
      });
    };
    // LH-133: a glossary's term (entry.accent) is written in the tag's color on its backdrop, as the preview draws it.
    if(entry.accent)addLines(entry.text,entry.textBox,eyebrowHex(context),eyebrowColor(context),true);
    else addLines(entry.text,entry.textBox,context.colors.text,context.textColor,true);
    if(entry.description)addLines(entry.description,entry.descriptionBox,context.colors.mutedText,context.mutedColor,false);
  }
  // LH-08: a list drawn as ruled rows (design.listStyle: rows): core's hairlines between its rows as native lines, LIST_RULE_WIDTH thick in
  // the scheme's border neutral, as the preview draws them. The export draws them again from the list, so import reads them as no content.
  // LH-133: an accent rule (over a cell of a grid of questions) is LIST_ACCENT_RULE_WIDTH thick in the tag's color on its backdrop.
  if(fit.rules?.length){
    const scale=Math.min(context.dimensions.widthInches,context.dimensions.heightInches)*96/720,color=normalizeHex(context.roles?.neutrals?.border?.hex??`#${context.colors.border}`);
    // LH-136: the accent rule over a display heading is a native line of core's thickness; LH-133's accent rules over question cells are
    // LIST_ACCENT_RULE_WIDTH thick. Both are in the tag's color on their backdrop.
    fit.rules.forEach((rule,index)=>slide.addShape('line',{x:rule.x/96,y:rule.y/96,w:rule.width/96,h:0,line:{color:rule.accent?normalizeHex(eyebrowHex(context)):color,width:(rule.thickness??(rule.accent?LIST_ACCENT_RULE_WIDTH:LIST_RULE_WIDTH)*scale)*.75},objectName:`OPF list rule ${path} ${index}`}));
  }
}

function addListPayload(slide, items, region, context) {
  const list = Array.isArray(items) ? items : [];
  if (list.length === 0) {
    slide.addText("", textBoxOptions(region, context, 16));
    return;
  }

  const runs = [];
  for (let index = 0; index < list.length; index += 1) {
    const item = list[index];
    const level = isPlainObject(item) && Number.isInteger(item.level) ? item.level : 0;
    runs.push({
      text: stringifyText(isPlainObject(item) ? item.text : item),
      options: {
        bullet: { type: "bullet", indent: 14 + level * 14 },
        breakLine: index < list.length - 1 || Boolean(isPlainObject(item) && item.description),
        color: context.textColor,
        fontFace: context.fonts.body,
        fontSize: 15,
        hanging: 4 + level * 10
      }
    });
    if (isPlainObject(item) && item.description) {
      runs.push({
        text: stringifyText(item.description),
        options: {
          breakLine: index < list.length - 1,
          color: context.mutedColor,
          fontFace: context.fonts.body,
          fontSize: 11,
          margin: [0, 0, 0, 18 + level * 14]
        }
      });
    }
  }

  slide.addText(runs, textBoxOptions(region, context, 15));
}

// A content picture outside an image block (a timeline event image): one native picture contained in its region.
// Generated furniture is never grouped (src/master-furniture.js), so a furniture part passes {group: false}.
async function addImagePayload(slide, presentation, asset, region, path, context, options, {group = true} = {}) {
  const name = await addImagePicture(slide, presentation, asset, region, path, context, options, {fit: 'contain'});
  if (!name) addImagePlaceholder(slide, presentation, asset, region, path, context, options, {group});
  return name;
}

// One native image picture at `box` (inches), fitted at packaging (src/image-provenance.js placeImages). `treatment` is
// what OPF_IMAGE_V1 stores (the authored block fields); without it the picture is untagged. Returns the picture's object
// name, or undefined when the source could not be embedded (the caller draws the unavailable-image panel).
async function addImagePicture(slide, presentation, asset, box, path, context, options, {fit, focus, effects = null, shrink = true, treatment, alt, role = 'block', objectName, src} = {}) {
  const outcome = { box, cover: fit === 'cover' };
  const resolved = await resolveImage(asset, presentation, options, path, outcome);
  if (!resolved) {
    // RR-59 (AUTO-26): a content picture never vanishes silently. A background names its own fallback (the slide colour).
    if (!outcome.reported) options.onDiagnostic?.(role === 'background' ? backgroundUnresolved(path) : {code: "unresolved-asset", path, reason: "unresolved-source", message: "The image needs an embedded raster, a declared asset or a host imageResolver; the image exports as the unavailable-image placeholder. Remote images are never fetched."});
    return undefined;
  }
  const name = objectName ?? imageName(1 + [...context.images.keys()].filter(key => /^OPF image \d+$/.test(key)).length);
  // PowerPoint applies opacity (a:alphaModFix), grayscale (a:grayscl) and the border (a:ln) to an SVG picture (native check
  // 2026-10-01). A duotone recolor and a non-rectangular mask are not confirmed on an SVG picture, and a tiled picture fill
  // cannot carry an SVG: with any of them the SVG stays its PNG raster, so the effect applies as in the preview.
  if (outcome.svg) {
    const treated = [effects?.recolor?.type === 'duotone' && 'duotone recolor', effects?.shape && effects.shape.preset !== 'rect' && 'shape', fit === 'tile' && 'tile fit'].filter(Boolean);
    if (treated.length) options.onDiagnostic?.({ code: 'export-lossy', feature: 'svg-rasterized', path, message: `An SVG image with ${treated.join(', ')} exports as its PNG raster, so the effect applies as in the preview; PowerPoint has not been confirmed to apply it to an SVG picture.` });
    else context.svgPictures.set(name, outcome.svg);
  }
  const text = alt !== undefined ? alt : assetAlt(asset, presentation);
  // RR-94: the authored relative path or URL is recorded with the picture's media key; an SVG imports from its own part, so it is not.
  context.images.set(name, { slide: context.slidePath, role, path, box, fit, focus, shrink, effects, ...(treatment !== undefined ? {treatment} : {}), ...(src !== undefined && !outcome.svg ? {src} : {}) });
  context.pictureText.set(name, pictureText(text, asset, presentation));
  slide.addImage({ ...resolved, objectName: name, x: box.x, y: box.y, w: box.w, h: box.h, altText: text });
  return name;
}

// The native effects of an image treatment, resolved in the slide's colour context: core's mask (item.image.shape), the
// stroke (SH-02: every stroke property, src/shape-blocks.js lineXml), opacity and recolor.
function imageEffects(image, context) {
  const paint = (entry, fallback) => {
    const raw = exportColor(entry, context, fallback).replace(/^#/, '');
    return { hex: normalizeHex(raw, fallback), alpha: /^[0-9a-f]{8}$/i.test(raw) ? parseInt(raw.slice(6), 16) / 255 : 1 };
  };
  return {
    shape: image.shape ?? null,
    strokeXml: image.stroke ? lineXml(image.stroke, shapePaint(context), shapePalette(context), image.box) : null,
    opacity: image.opacity ?? null,
    recolor: image.recolor?.type === 'grayscale' ? { type: 'grayscale' }
      : image.recolor?.type === 'duotone' ? { type: 'duotone', dark: paint(image.recolor.dark, '000000'), light: paint(image.recolor.light, 'FFFFFF') } : null,
    paint
  };
}

const sixDigit = value => typeof value === 'string' && /^#?[0-9a-f]{6}$/i.test(value.trim()) ? value.trim().replace(/^#/, '').toUpperCase() : undefined;
const THEME_SLOT_VALUES = Object.freeze({dark1: 'dk1', light1: 'lt1', dark2: 'dk2', light2: 'lt2'});
// SH-02: a ColorRef as a shape's or picture line's DrawingML color: its RRGGBB and alpha, and the slide's scheme value where the reference
// names a slot or role the deck theme holds exactly (schemeColorValue), so it is written as a theme color.
function shapePaint(context) {
  return (entry, fallback) => {
    const raw = exportColor(entry, context, fallback).replace(/^#/, ''), hex = normalizeHex(raw.slice(0, 6), fallback);
    const alpha = /^[0-9a-f]{8}$/i.test(raw) ? parseInt(raw.slice(6), 16) / 255 : 1;
    // A slot the slide's color map does not reach (dark1 on a dark variant's slide) is written by its own name (dk1), which PowerPoint
    // reads from the theme directly, where the deck theme holds exactly that color.
    const slot = typeof entry === 'string' && !context.schemeOverride ? THEME_SLOT_VALUES[entry.trim()] : undefined;
    const scheme = typeof entry === 'string' ? schemeColorValue(entry, `#${hex}`, context) ?? (slot && sixDigit(context.themeColors?.[entry.trim()]) === hex && sixDigit(themeSlotColors(context.colorScheme)[entry.trim()]) === hex ? slot : undefined) : undefined;
    return { hex, alpha, ...(scheme ? {scheme} : {}) };
  };
}

// SH-02: the colors a shape's drawing falls back to: the primary (a style's accent1), the slide background and the neutral line.
function shapePalette(context) {
  return { primary: normalizeHex(context.roles?.primary ?? context.colors.accent), background: normalizeHex(context.colors.background), border: normalizeHex(context.roles?.neutrals?.border?.hex ?? `#${context.colors.border}`) };
}

// SH-02: a shape block (core ComposedItem.shape) as one native shape (src/shape-blocks.js): PptxGenJS writes the shape and its runs at
// core's fitted size, centered, with the text color that reads on the drawn fill; writeShapeBlocks then writes core's geometry, fill,
// line, style and text body. The style's derived colors (a darker accent line, a lighter fill) are written as theme colors with
// a:lumMod and a:lumOff, as the authored ones are.
function addShapeItem(slide, item, slideIndex, context, deck) {
  const shape = item.shape, name = `OPF shape ${item.path}`, palette = shapePalette(context);
  const paint = shapePaint(context);
  // The slide's table is built again with its context, so the shape's derived colors are kept apart and merged when the part is written.
  const table = deck.slideSchemeColors?.[slideIndex]?.table;
  if (table) {
    const own = deck.shapeSchemeColors.get(slideIndex) ?? new Map(), view = new Map([...table, ...own]);
    addTransformedColors(view, reference => exportColor(reference, context, '000000'), shape.fill, shape.stroke, shape.styleRef, shape.textColor, shape.textBackdrop, shape.effects);
    for (const [hex, entry] of view) if (!table.has(hex)) own.set(hex, entry);
    deck.shapeSchemeColors.set(slideIndex, own);
  }
  const backdrop = shape.textBackdrop === undefined ? `#${normalizeHex(context.colors.background)}` : `#${paint(shape.textBackdrop, palette.background).hex}`;
  const preferred = `#${paint(shape.textColor, normalizeHex(context.colors.text)).hex}`, slideText = `#${normalizeHex(context.colors.text)}`, slideBackground = `#${normalizeHex(context.colors.background)}`;
  const drawn = shapeTextColor(backdrop, preferred, slideText, slideBackground);
  // The color as a theme color where the reference names one (the style's, else the slide's text or background role).
  const textHex = nativeColor(drawn === preferred ? shape.textColor : drawn === slideText ? 'text' : 'background', drawn, context);
  const fit = item.text, size = fit ? fit.fontSize * .75 : 18;
  const lineHeight = fit ? (fit.richLines?.[0]?.height ?? fit.lineHeight ?? fit.fontSize * 1.22) * .75 : undefined;
  const value = item.payload?.text, runs = [];
  const style = item.textStyle ?? {fontFamily: context.fonts.body, fontWeight: 400};
  const base = {...nativeFontOptions(style), ...(shape.textBold ? {bold: true} : {}), fontSize: size, color: textHex};
  const push = (text, run = {}) => {
    const lines = String(text).split(/\r\n|\r|\n/);
    lines.forEach((line, index) => {
      const own = {...base, ...(run.bold !== undefined ? {bold: run.bold} : {}), ...(run.italic !== undefined ? {italic: run.italic} : {}), ...(run.underline ? {underline: {style: 'sng'}} : {}), ...(run.strikethrough ? {strike: 'sngStrike'} : {}),
        ...(run.color !== undefined && run.color !== '' ? {color: exportColor(run.color, context, textHex).slice(0, 6)} : {}), ...(typeof run.link === 'string' ? {hyperlink: {url: run.link}, color: linkColor(run, run.color !== undefined && run.color !== '' ? exportColor(run.color, context, textHex).slice(0, 6) : textHex, context)} : {}),
        ...(typeof run.fontFamily === 'string' ? {fontFace: run.fontFamily} : {}), ...(typeof run.fontSize === 'number' ? {fontSize: run.fontSize} : {}), ...(run.superscript ? {superscript: true} : {}), ...(run.subscript ? {subscript: true} : {}),
        ...(index < lines.length - 1 ? {breakLine: true} : {})};
      // LH-11: a space core's line breaker never breaks at ("16 px") is written as a no-break space, so PowerPoint wraps the shape's text as the preview does.
      runs.push({text: bindNoBreak(line), options: own});
    });
  };
  if (typeof value === 'string') push(value);
  else if (Array.isArray(value)) for (const run of value) typeof run === 'string' ? push(run) : push(run?.text ?? '', run ?? {});
  if (runs.length) assertXmlText(runs.map(run => run.text).join(''), `${item.path}.text`);
  const box = shape.box;
  slide.addText(runs.length ? runs : '', {x: box.x / 96, y: box.y / 96, w: box.width / 96, h: box.height / 96, objectName: name, ...base, align: 'center', valign: 'middle', margin: 0, paraSpaceAfter: 0, paraSpaceBefore: 0,
    ...(lineHeight ? {lineSpacing: Math.round(lineHeight * 100) / 100} : {}), fit: 'none'});
  deck.shapeBlocks.set(name, {...shapeBlockRecord(shape, paint, palette), ...(shape.link ? {link: shape.link} : {})});
  return name;
}

// SH-04: one layer of the slide's overlay. An overlay shape is a shape block item (core ComposedOverlayShape), written as one: `OPF shape slides.N.shapes.I`.
// A connector (core ComposedConnector) is a placeholder line named `OPF connector slides.N.shapes.I` that writeConnectors replaces by its
// p:cxnSp in the finished slide part, glued to the native shapes at its ends (src/connectors.js).
function addOverlayShapes(slide, geometry, slideIndex, context, deck, layer) {
  // The back layer (overlay shapes with layer back) goes before the content shapes in the shape tree; the front layer and every connector after.
  for (const entry of (geometry.overlayShapes ?? []).filter(entry => (entry.kind === 'shape' && entry.layer === 'back' ? 'back' : 'front') === layer)) {
    if (entry.kind === 'shape') { addShapeItem(slide, entry, slideIndex, context, deck); continue; }
    if (!entry.paths?.length) continue;
    const name = connectorName(entry.path), paint = shapePaint(context), palette = shapePalette(context);
    const table = deck.slideSchemeColors?.[slideIndex]?.table;
    if (table) {
      const own = deck.shapeSchemeColors.get(slideIndex) ?? new Map(), view = new Map([...table, ...own]);
      addTransformedColors(view, reference => exportColor(reference, context, '000000'), entry.stroke);
      for (const [hex, value] of view) if (!table.has(hex)) own.set(hex, value);
      deck.shapeSchemeColors.set(slideIndex, own);
    }
    deck.connectors.set(name, connectorRecord(entry, paint, palette, {from: connectorGlue(entry.from, geometry, slideIndex, deck), to: connectorGlue(entry.to, geometry, slideIndex, deck)}));
    slide.addShape('line', {x: entry.box.x / 96, y: entry.box.y / 96, w: entry.box.width / 96, h: entry.box.height / 96, objectName: name, line: {color: '000000', width: 1}});
  }
}

// SH-04: the native shape a connector end glues to (its object name and core's site index): an overlay shape or shape block, a block's
// picture, or the card of a block drawn on one; a group, or a block drawn as several native shapes (a text's line boxes), glues to none.
function connectorGlue(end, geometry, slideIndex, deck) {
  if (end.target === 'shape') return {name: `OPF shape ${end.ref}`, site: end.site};
  if (end.target !== 'block') return undefined;
  const block = end.ref.slice(0, end.ref.lastIndexOf('.')), items = geometry.items.filter(item => item.path.startsWith(`${block}.`) && !item.path.slice(block.length + 1).startsWith('blocks.'));
  const item = items.length === 1 ? items[0] : undefined;
  if (!item) return undefined;
  if (item.shape) return {name: `OPF shape ${item.path}`, site: end.site};
  if (item.frameBox) return {name: `OPF card ${item.path}`, site: end.site};
  if (item.image) {
    const name = [...deck.images].find(([, record]) => record.slide === `slides.${slideIndex}` && record.path === item.path)?.[0];
    return name === undefined ? undefined : {name, site: end.site};
  }
  return undefined;
}

// An overlay (core ComposedOverlay) as one native shape directly above its picture: the frame's shape, or an edge band.
function addImageOverlay(slide, overlay, authored, name, owner, context, effects) {
  const {hex, alpha} = effects.paint(overlay.color, context.colors.text);
  context.imageOverlays.set(name, { slide: context.slidePath, owner, box: overlay.box, shape: overlay.shape, hex, alpha, opacity: overlay.opacity, overlay: authored });
  slide.addShape('rect', { x: overlay.box.x / 96, y: overlay.box.y / 96, w: overlay.box.width / 96, h: overlay.box.height / 96, objectName: name, fill: { color: hex } });
}

// The authored value at an OPF path the composition names (`slides.N.blocks.I`, `slides.N.design.background`,
// `design.background`); `theme` is the resolved theme record's background.
function authoredAt(presentation, path, slideContext) {
  if (path === 'theme') return slideContext.core?.resolved?.theme?.background;
  let value = presentation;
  for (const key of path.split('.')) value = value?.[/^\d+$/.test(key) ? Number(key) : key];
  return value;
}

// An image block (core ComposedItem.image): the picture at core's frame with its fit, focus and treatment, then its
// overlay directly above. An unchanged picture and overlay import back as the same block (OPF_IMAGE_V1).
async function addImageItem(slide, presentation, item, slideIndex, context, options) {
  const image = item.image;
  const box = { x: image.box.x / 96, y: image.box.y / 96, w: image.box.width / 96, h: image.box.height / 96 };
  const block = isPlainObject(item.payload) ? item.payload : {};
  const treatment = Object.fromEntries(IMAGE_TREATMENT_KEYS.filter(key => key !== 'overlay' && block[key] !== undefined).map(key => [key, structuredClone(block[key])]));
  const effects = imageEffects(image, context);
  const treated = Boolean(effects.strokeXml || effects.opacity !== null || effects.recolor || image.overlay || (effects.shape && effects.shape.preset !== 'rect'));
  // RR-94: every image block is tagged (an empty treatment when it has none), so an unchanged picture re-imports without a crop
  // diagnostic, and one authored from a relative path or URL records that source to give it back.
  const source = recordableImageSource(item.value);
  // A plain contained picture in the flow is framed by the picture itself (0.14 content images); a treated or placed one
  // keeps core's frame (0.14 slide images), so its mask, line and overlay apply to that frame.
  const name = await addImagePicture(slide, presentation, item.value, box, item.path, { ...context, slidePath: `slides.${slideIndex}` }, options, {
    fit: image.fit, focus: image.focus, effects: treated ? effects : null, shrink: !treated && !image.placement, treatment, src: source
  });
  if (!name) {
    const panel = addImagePlaceholder(slide, presentation, item.value, box, item.path, context, options);
    // opf-pptx#221: in full mode the panel records the authored image and the block's own fields, so import restores the block.
    if (context.provenanceMode === 'full') {
      const fields = Object.fromEntries(IMAGE_TREATMENT_KEYS.filter(key => block[key] !== undefined).map(key => [key, structuredClone(block[key])]));
      context.imagePlaceholderTags.set(panel, {v: 1, slide: `slides.${slideIndex}`, path: item.path, image: structuredClone(item.value), ...(Object.keys(fields).length ? {treatment: fields} : {})});
    }
    // Unavailable pixels have no trustworthy native picture owner. Keep labels as ordinary editable text, without stale source restoration.
    const recorded = context.imagePlaceholderTags.get(panel);
    if (recorded?.image && typeof recorded.image === 'object') delete recorded.image.callouts;
    addImageCalloutItems(slide, item, undefined, context, options);
    return panel;
  }
  if (image.overlay) addImageOverlay(slide, image.overlay, structuredClone(block.overlay), imageOverlayName(name), name, { ...context, slidePath: `slides.${slideIndex}` }, effects);
  addImageCalloutItems(slide, item, name, context, options);
  return name;
}

// Text panels are independent native rectangles and measured line boxes, painted above the picture mask/overlay.
function addImageCalloutItems(slide, item, owner, context, options) {
  for (const [index, callout] of (item.image.callouts ?? []).entries()) {
    const objectName = `OPF image callout ${owner ?? item.path} ${index}`;
    const box = callout.box;
    slide.addShape('rect', {x: box.x / 96, y: box.y / 96, w: box.width / 96, h: box.height / 96, fill: {color: pptxColor(context.colors.background)}, line: {transparency: 100}, objectName});
    if (owner) {
      const source = item.value.callouts[index];
      context.imageCalloutTags.set(objectName, {v: 1, owner, index, total: item.image.callouts.length, role: 'panel', frame: {x: source.x, y: source.y, width: source.width, height: source.height}, lines: callout.fit.lines.length});
    }
    addMeasuredPayloadText(slide, callout.text, callout.textBox, context, options, {color: context.colors.text, path: callout.path + '.text', fit: callout.fit, textStyle: callout.textStyle, align: 'center', keepEmpty: true, diagnosticsHandled: true, objectName, ...(owner ? {imageCallout: {owner, index}} : {})});
  }
}

// The palette a diagram is painted in: core's diagramPalette from the slide's resolved design, with the inputs opf-render's
// slideDiagramPalette uses, so the picture has the preview's colors: the surface it stands on (its card's fill, else the slide
// background, or the emphasis surface), the slide's text and muted text, the scheme and the variant's accent order, the scheme's
// dark1 and light1, and the body and code families the slide was composed in.
function exportDiagramPalette(item, context) {
  const scheme = context.colorScheme ?? {};
  const card = item.frameBox ? context.roles?.neutrals?.card?.hex : undefined;
  return diagramPalette({
    surface: card ?? context.cardFill ?? `#${normalizeHex(context.colors.background)}`,
    text: `#${normalizeHex(context.colors.text)}`, mutedText: `#${normalizeHex(context.colors.mutedText)}`, colorScheme: scheme,
    context: {accents: context.roles?.map?.accents, roles: context.roles, variables: context.variables},
    dark: scheme.dark1 ?? ENGINE_DEFAULT_COLOR_SCHEME.dark1, light: scheme.light1 ?? ENGINE_DEFAULT_COLOR_SCHEME.light1,
    fonts: {body: context.fonts.body, code: context.fonts.code ?? context.fonts.body}
  });
}

// A diagram item (core ComposedItem.diagram): core's drawing painted by paintDiagram in the slide's palette, sized to the drawn box,
// as one native SVG picture over its PNG fallback (resolveSvgImage, the SVG picture path images use) with the diagram's alt text as
// its description. A diagram core could not draw, or one whose fallback could not be rasterized, is the unavailable-diagram
// placeholder, as the preview draws it. Returns the object name (a caption names its media by it).
async function addDiagramItem(slide, item, slideIndex, context, options) {
  const diagram = item.diagram, area = diagram?.box ?? item.box;
  const box = {x: area.x / 96, y: area.y / 96, w: area.width / 96, h: area.height / 96};
  // Full provenance: OPF_DIAGRAM_V1 records the authored value, so import gives back the source (src/diagram-provenance.js).
  const record = context.provenanceMode === 'full' ? {v: 1, slide: `slides.${slideIndex}`, path: item.path, diagram: structuredClone(item.value)} : undefined;
  if (!diagram?.svg || diagram.issue) {
    const reason = diagram?.issue?.message;
    options.onDiagnostic?.({code: "content-placeholder", path: item.path, reason: "diagram-unavailable", message: `The diagram cannot be drawn${reason ? ` (${reason})` : ""}; the unavailable-diagram placeholder stands in for it.`});
    return addDiagramPlaceholder(slide, box, context, record);
  }
  // SH-07: with `diagrams: "shapes"` a diagram of a family that passed its PowerPoint comparison is native shapes and connectors.
  if (context.diagramMode === 'shapes') {
    const name = addDiagramShapes(slide, item, slideIndex, context, options, record);
    if (name) return name;
  }
  const svg = paintDiagram(diagram, exportDiagramPalette(item, context), {width: area.width, height: area.height});
  const outcome = {box};
  // resolveSvgImage reports an SVG it cannot export (no rasterizer for the fallback) as an image; this one is a diagram.
  const onDiagnostic = options.onDiagnostic && (entry => options.onDiagnostic(entry.code === "unresolved-asset" ? {...entry, message: entry.message.replace(/An SVG image needs/, "A diagram needs").replace(/The image exports as the unavailable-image placeholder\.$/, "The diagram exports as the unavailable-diagram placeholder.")} : entry));
  const resolved = await resolveSvgImage(encodeText(svg), {...options, onDiagnostic}, item.path, outcome);
  if (!resolved) return addDiagramPlaceholder(slide, box, context, record);
  const name = diagramName(1 + [...context.diagrams].filter(entry => /^OPF diagram \d+$/.test(entry)).length);
  context.diagrams.add(name);
  context.svgPictures.set(name, outcome.svg);
  context.pictureText.set(name, {alt: diagram.alt || undefined});
  if (record) context.diagramTags.set(name, {...record, alt: diagram.alt ?? ""});
  slide.addImage({...resolved, objectName: name, x: box.x, y: box.y, w: box.w, h: box.h, altText: diagram.alt ?? ""});
  return name;
}

// SH-16: the fallback picture of a live SmartArt frame, for every app that does not lay SmartArt out: OPF's preview of the frame
// (smartArtRegionSvg of the slide's preview) as an SVG picture over its PNG raster, the diagram picture's path (resolveSvgImage, 192 dpi
// of the frame). Returns the function that places it after the frame's placeholder (and returns its bleed), or why it cannot be drawn (the arrangement is then
// native shapes, smartart-unavailable).
async function smartArtFallback(slide, arrangement, {name, alt}, preview, context, options) {
  // The frame grown by the preview's ink outside it (the nodes' outlines and miters), so the picture draws all the preview draws.
  const {frame} = arrangement, bleed = smartArtBleed(arrangement);
  const box = {x: (frame.x - bleed) / 96, y: (frame.y - bleed) / 96, w: (frame.width + 2 * bleed) / 96, h: (frame.height + 2 * bleed) / 96};
  const unavailable = reason => `no fallback picture can be drawn for apps without SmartArt (${reason})`;
  let svg;
  try {
    svg = smartArtRegionSvg(await preview(), arrangement, bleed);
  } catch (error) {
    return unavailable(errorMessage(error));
  }
  const outcome = {box}, problems = [];
  const resolved = await resolveSvgImage(encodeText(svg), {...options, strictAssets: false, onDiagnostic: entry => problems.push(entry)}, arrangement.path, outcome);
  if (!resolved) return unavailable(problems.find(entry => entry.code === 'unresolved-asset')?.message.replace(/ The image exports as the unavailable-image placeholder.$/, '') ?? 'its SVG could not be drawn');
  return () => {
    context.svgPictures.set(name, outcome.svg);
    slide.addImage({...resolved, objectName: name, ...box, altText: alt});
    return bleed;
  };
}

// SH-07: a diagram as one group of native shapes (src/diagram-shapes.js), built from the drawing the preview shows (paintDiagram in the
// slide's palette, pele's classes kept). Only a family in core's DIAGRAM_SHAPE_FAMILIES (each passed its comparison of PowerPoint's drawing
// with the preview) is written so, and only when every part of its drawing has a native form; otherwise the diagram stays the picture
// and reports diagram-shapes-unavailable (info). A rectangle stands in for the group until the slide part is written (writeDiagramGroups).
// Returns the group's name, or undefined for the picture.
function addDiagramShapes(slide, item, slideIndex, context, options, record) {
  const diagram = item.diagram, area = diagram.box ?? item.box;
  const family = diagram.type;
  const unavailable = reason => {
    options.onDiagnostic?.({code: 'diagram-shapes-unavailable', path: item.path, family, message: `The ${family} diagram exports as a picture: ${reason}.`});
    return undefined;
  };
  if (!DIAGRAM_SHAPE_FAMILIES.includes(family)) return unavailable('its native shapes have not passed the comparison with the preview in PowerPoint yet');
  const svg = paintDiagram(diagram, exportDiagramPalette(item, context), {width: area.width, height: area.height}, {classes: true});
  const name = diagramName(1 + [...context.diagrams].filter(entry => /^OPF diagram \d+$/.test(entry)).length);
  const measurers = new Map();
  const styleOf = (family, bold, italic) => resolveTextStyle({fontFamily: family, fontWeight: bold ? 700 : 400, italic, path: item.path}, options.textMeasurement);
  const converted = diagramShapes(svg, {
    box: area, name, alt: diagram.alt ?? '', lang: context.deckLang,
    measure: (text, size, style) => {
      const key = `${style.family}|${style.bold}|${style.italic}`;
      if (!measurers.has(key)) measurers.set(key, textWidthMeasurer(styleOf(style.family, style.bold, style.italic), options.textMeasurement));
      return measurers.get(key)(text, size);
    },
    font: (family, bold, italic) => nativeFontOptions(styleOf(family, bold, italic)),
  });
  if (converted.unsupported) return unavailable(`its drawing uses ${converted.unsupported}, which has no native form`);
  context.diagrams.add(name);
  context.diagramGroups.set(name, {...converted, box: area, alt: diagram.alt ?? ''});
  if (record) context.diagramTags.set(name, {...record, alt: diagram.alt ?? '', shapes: true});
  slide.addShape('rect', {x: area.x / 96, y: area.y / 96, w: area.width / 96, h: area.height / 96, objectName: name});
  return name;
}

// The unavailable-diagram placeholder, as the preview draws it: an unfilled dashed outline in the border neutral at the drawn box,
// reading "Diagram unavailable" centered in the muted text color at 20 reference px. One native shape, so it moves as one object.
function addDiagramPlaceholder(slide, box, context, record) {
  const name = diagramPlaceholderName(1 + [...context.diagrams].filter(entry => /^OPF diagram placeholder \d+$/.test(entry)).length);
  context.diagrams.add(name);
  if (record) context.diagramTags.set(name, {...record, alt: ""});
  const scale = Math.min(context.dimensions.widthInches, context.dimensions.heightInches) * 96 / 720;
  slide.addText(DIAGRAM_UNAVAILABLE, {
    shape: "rect", x: box.x, y: box.y, w: box.w, h: box.h, objectName: name, margin: 0,
    line: {color: normalizeHex(context.roles?.neutrals?.border?.hex ?? `#${context.colors.border}`), width: scale * .75, dashType: "dash"},
    fontFace: context.fonts.body, fontSize: 20 * scale * .75, color: context.mutedColor, align: "center", valign: "middle"
  });
  return name;
}

// LH-02: core's automatic scrims of a picture background (backgroundImage.scrims). They keep RR-96's name on a picture that names its
// tone, which import reads the tone back from; any other picture's scrims are named for the slide alone. The second and third (the
// header's and the footer's) add their number. None is content.
const toneScrimName = (slidePath, tone) => `OPF background tone ${tone} ${slidePath}`;
const scrimName = slidePath => `OPF background scrim ${slidePath}`;
const isScrimName = (name, base) => name === base || name === `${base} 2` || name === `${base} 3`;

// An image background (core SlideComposition.backgroundImage). With alt text it is a full-slide picture at the back of
// the slide over the canvas colour, carrying the alt text as its descr; without alt it is the native slide background
// fill (written at packaging). Its overlay is one shape directly above the picture.
async function addBackgroundImage(slide, presentation, background, slideIndex, slideContext, context, options) {
  const slidePath = `slides.${slideIndex}`, part = `ppt/slides/slide${slideIndex + 1}.xml`;
  const box = { x: 0, y: 0, w: slideContext.dimensions.widthInches, h: slideContext.dimensions.heightInches };
  const authored = authoredAt(presentation, background.path, slideContext);
  const effects = imageEffects({ opacity: background.opacity, recolor: background.recolor }, slideContext);
  let owner = 'background', overlayName = backgroundOverlayName(slidePath);
  // Only the background's own alt text makes it meaningful (FA-22): a referenced asset's alt does not count.
  const alt = background.alt;
  if (typeof alt === 'string' && alt) {
    const treatment = isPlainObject(authored) ? Object.fromEntries(BACKGROUND_IMAGE_KEYS.filter(key => key !== 'overlay' && authored[key] !== undefined).map(key => [key, structuredClone(authored[key])])) : {};
    const name = await addImagePicture(slide, presentation, background.src, box, background.path, { ...slideContext, slidePath }, options, {
      fit: background.fit, focus: background.focus, effects: background.opacity === undefined && !background.recolor ? null : effects, shrink: false,
      treatment, alt, role: 'background', objectName: backgroundImageName(slidePath)
    });
    // addImagePicture reported the unresolved source once (opf-pptx#210).
    if (!name) { useFallbackBackground(slide, presentation, background, slideIndex, slideContext, context, options); return; }
    owner = name;
    overlayName = imageOverlayName(name);
    recordMasterPicture(context, background, part, effects, box, name);
  } else {
    // An SVG background is its PNG raster at the slide's size: a slide background picture fill carries no SVG.
    const outcome = { box, cover: background.fit === 'cover' };
    const resolved = await resolveImage(background.src, presentation, options, background.path, outcome);
    if (!resolved) {
      if (!outcome.reported) options.onDiagnostic?.(backgroundUnresolved(background.path));
      useFallbackBackground(slide, presentation, background, slideIndex, slideContext, context, options);
      return;
    }
    // PptxGenJS embeds the raster and its relationship; packaging replaces its stretched fill with the fitted native fill.
    slide.background = { ...resolved };
    context.backgroundFills.set(part, { image: {
      fit: background.fit, focus: background.focus, opacity: background.opacity ?? 1, recolor: effects.recolor, path: background.path,
      width: box.w * 96, height: box.h * 96, report: options.onDiagnostic
    } });
    recordMasterPicture(context, background, part, effects, box);
  }
  // LH-02: core's automatic scrims under the text (no overlay of the author's): each one native rectangle in the slide background color (bg1 of the
  // slide's variant once scheme colors are written), whose fill packaging turns into a linear gradient with alpha stops (attachScrims)
  // unless it is a band of one opacity. It replaces RR-96's 40% scrim of a picture that names its tone, whose name it keeps.
  const tone = isPlainObject(authored) ? authored.tone : undefined;
  if (!background.overlay) (background.scrims ?? []).forEach((scrim, index) => {
    const base = tone === 'dark' || tone === 'light' ? toneScrimName(slidePath, tone) : scrimName(slidePath), name = index ? `${base} ${index + 1}` : base;
    slide.addShape('rect', { x: scrim.box.x / 96, y: scrim.box.y / 96, w: scrim.box.width / 96, h: scrim.box.height / 96, objectName: name, fill: { color: normalizeHex(scrim.color), transparency: Math.round(100 - scrim.opacity * 100) }, line: { type: 'none' } });
    if (scrim.stops.some(stop => stop.opacity !== scrim.opacity)) (context.scrims[`ppt/slides/slide${slideIndex + 1}.xml`] ??= new Map()).set(name, scrim);
  });
  if (background.overlay) addImageOverlay(slide, background.overlay, structuredClone(isPlainObject(authored) ? authored.overlay : undefined) ?? {color: background.overlay.color, opacity: background.overlay.opacity}, overlayName, owner, { ...slideContext, slidePath }, effects);
}

// LH-139: the first slide that draws the deck's own picture background (not a slide's) is the media the slide master's picture fill reuses.
function recordMasterPicture(context, background, part, effects, box, shapeName) {
  if (context.masterPicture || !context.masterBackground?.image || /^slides\./.test(background.path ?? '')) return;
  context.masterPicture = {part, name: shapeName,
    fit: {fit: background.fit, focus: background.focus, opacity: background.opacity ?? 1, recolor: effects.recolor, width: box.w * 96, height: box.h * 96}};
}

// LH-02: a gradient scrim's solid fill becomes a linear gradient along core's axis (90 degrees down a vertical scrim, 0 across a
// horizontal one) whose stops carry the scrim color at each stop's alpha, the stops the preview's SVG gradient draws. The color stays as
// the solid fill wrote it (a scheme color, bg1, once scheme colors are written), so the gradient follows the slide's color map.
function attachScrims(entries, scrims) {
  for (const [part, shapes] of Object.entries(scrims)) {
    if (!entries[part]) continue;
    const xml = decodeText(entries[part]).replace(/<p:sp>(?:(?!<\/p:sp>)[\s\S])*<\/p:sp>/g, shape => {
      const scrim = shapes.get(shape.match(/<p:cNvPr\b[^>]*\bname="([^"]+)"/)?.[1]);
      if (!scrim) return shape;
      return shape.replace(/<a:solidFill><a:(srgbClr|schemeClr) val="([^"]+)">[\s\S]*?<\/a:\1><\/a:solidFill>/, (_fill, kind, value) => {
        const stops = scrim.stops.map(stop => `<a:gs pos="${Math.round(stop.position * 100000)}"><a:${kind} val="${value}"><a:alpha val="${Math.round(stop.opacity * 100000)}"/></a:${kind}></a:gs>`).join('');
        return `<a:gradFill rotWithShape="1"><a:gsLst>${stops}</a:gsLst><a:lin ang="${scrim.axis === 'vertical' ? 5400000 : 0}" scaled="0"/></a:gradFill>`;
      });
    });
    entries[part] = encodeText(xml);
  }
}

// RR-97: a background picture that cannot be read leaves the background the slide would have without it: the deck's own
// background (or the theme's) when the slide's was the picture, and the variant's bg1 when the picture is the only background,
// written as the same native fill (a scheme color through the slide's map, a solid color, a gradient or a pattern) a slide with
// that background has. It is not the literal canvas color core falls back to for a picture, which is the light default and so
// white behind the light text of a dark variant. A picture that comes from the theme's own background keeps that canvas color.
// Only the fill is replaced: the text color was chosen for the picture and is unchanged.
function useFallbackBackground(slide, presentation, background, slideIndex, slideContext, context, options) {
  const without = design => Object.fromEntries(Object.entries(design ?? {}).filter(([key]) => key !== 'background'));
  let twin;
  if (/^slides\.\d+\.design\.background(\.|$)/.test(background.path ?? '')) twin = {...presentation, slides: presentation.slides.map((entry, index) => index === slideIndex ? {...entry, design: without(entry.design)} : entry)};
  else if (/^design\.background(\.|$)/.test(background.path ?? '')) twin = {...presentation, design: without(presentation.design)};
  if (!twin) return;
  const effective = {...twin, design: {...twin.design, ...twin.slides[slideIndex].design}};
  const resolved = resolvePresentationContext(effective, options, coreContext(twin, slideIndex, options));
  const fallback = {...slideContext, backgroundDefinition: resolved.backgroundDefinition, colors: resolved.colors, roles: resolved.roles, colorScheme: resolved.colorScheme, variables: resolved.variables};
  slide.background = {color: resolved.colors.background};
  const definition = resolved.backgroundDefinition;
  const fill = definition === undefined ? null : schemeBackgroundFill(definition, fallback) ?? nativeBackgroundFill(definition, {
    width: slideContext.dimensions.widthInches, height: slideContext.dimensions.heightInches
  }, resolved.colors.background, resolved.colors.text, (reference, hex) => schemeColorValue(reference, hex, fallback), reference => resolveBackgroundColorRef(reference, resolved.colorScheme, resolved.variables));
  if (fill) context.backgroundFills.set(`ppt/slides/slide${slideIndex + 1}.xml`, fill);
}

const backgroundUnresolved = path => ({code: 'unresolved-asset', path, reason: 'unresolved-source', message: 'The background image needs an embedded raster, a declared asset or a host imageResolver; the slide background color was exported instead.'});

// design.watermark: one native picture per slide, added after the slide image
// (and its overlay) and before all content, the preview's paint order. The
// slide's own design.watermark replaces the deck's, and false suppresses it.
// Frame, fit and opacity are written after PptxGenJS embeds the bytes.
// LH-164: on the accent surface of a message-only slide an image watermark is drawn in the slide's text color (a duotone of one color on the
// blip, the preview's feColorMatrix), so a mark made for the deck's plain surface still reads there.
async function addWatermark(slide, presentation, opfSlide, slideIndex, slideContext, context, options, onSurface = false) {
  const local = opfSlide.design?.watermark !== undefined;
  const watermark = local ? opfSlide.design.watermark : presentation.design?.watermark;
  if (watermark === undefined || watermark === null || watermark === false) return;
  const path = local ? `slides.${slideIndex}.design.watermark` : 'design.watermark';
  // The schema requires exactly one of src and text, so there is no source-less watermark to report.
  const asset = watermark;
  const {widthInches, heightInches} = slideContext.dimensions;
  // FA-13: a text watermark is one native text box with the opacity as text alpha, centered and rotated as core's layoutWatermark says.
  if (isPlainObject(asset) && typeof asset.text === 'string') {
    addTextWatermark(slide, asset, slideIndex, {width: widthInches * 96, height: heightInches * 96}, slideContext, context, options, path);
    return;
  }
  const box = watermarkBox(widthInches, heightInches);
  const outcome = {box};
  const resolved = await resolveImage(asset, presentation, options, path, outcome);
  if (!resolved) {
    if (!outcome.reported) options.onDiagnostic?.({code: 'unresolved-asset', path, message: 'The watermark image needs an embedded raster, a declared asset or a host imageResolver; no watermark was exported for this slide.'});
    return;
  }
  const opacity = watermarkOpacity(watermark);
  context.watermarks.set(`ppt/slides/slide${slideIndex + 1}.xml`, {slide: `slides.${slideIndex}`, box, opacity, path, ...(onSurface ? {recolor: normalizeHex(slideContext.colors.text)} : {})});
  // Opacity is an a:alphaModFix on the blip, which PowerPoint applies to an SVG picture (native check 2026-10-01).
  if (outcome.svg) context.svgPictures.set(`ppt/slides/slide${slideIndex + 1}.xml|${watermarkName()}`, outcome.svg);
  slide.addImage({...resolved, objectName: watermarkName(), ...box, altText: assetAlt(asset, presentation) ?? 'Watermark'});
}

// The stamp takes the slide's own resolved fonts and default text color (readable on that slide's background), as the preview does.
function addTextWatermark(slide, watermark, slideIndex, size, slideContext, context, options, path) {
  const layout = layoutWatermark(watermark.text, size, {fontFamily: slideContext.fonts.heading, fontWeight: 700, textMeasurement: options.textMeasurement});
  // The schema requires text, so this is null only for text that draws nothing (the preview draws nothing either).
  if (!layout) return;
  const opacity = watermarkOpacity(watermark);
  const {box} = layout;
  slide.addText(layout.text, {
    ...textBoxOptions({x: box.x / 96, y: box.y / 96, w: box.width / 96, h: box.height / 96}, slideContext, layout.fontSize * .75),
    ...nativeFontOptions(layout.style), bold: true,
    color: slideContext.textColor, transparency: Math.round((1 - opacity) * 100000) / 1000,
    align: 'center', valign: 'middle', fit: 'none', wrap: false, lineSpacingMultiple: 1,
    rotate: (layout.rotation + 360) % 360, objectName: watermarkTextName()
  });
  context.textWatermarks.set(`ppt/slides/slide${slideIndex + 1}.xml`, {slide: `slides.${slideIndex}`, text: layout.text, opacity});
}

// The deck logo (design.logo, a slide's own logo or the primary organization's) on a cover or section slide: one native
// picture per slide at core's geometry.logo box, fitted without cropping, anchored left and vertically centered, after
// the watermark and before content (the preview's paint order). The frame and the provenance tag are written after
// PptxGenJS embeds the bytes. An unresolved source draws the preview's "Image unavailable" panel in the logo box.
async function addLogo(slide, presentation, logo, slideIndex, slideContext, context, options) {
  const region = {x: logo.box.x / 96, y: logo.box.y / 96, w: logo.box.width / 96, h: logo.box.height / 96};
  const outcome = {box: region};
  const resolved = await resolveImage(logo.source, presentation, options, logo.path, outcome);
  if (!resolved) {
    if (!outcome.reported) options.onDiagnostic?.({code: 'unresolved-asset', path: logo.path, message: 'The logo needs an embedded raster, a declared asset or a host imageResolver; the logo panel shows "Image unavailable" instead.'});
    const prefix = addImagePlaceholder(slide, presentation, logo.source, region, logo.path, slideContext, options, {logo: true});
    if (prefix) context.logoPlaceholderTags.set(prefix, {v: 1, role: 'placeholder', slide: `slides.${slideIndex}`, path: logo.path});
    return;
  }
  context.logos.set(`ppt/slides/slide${slideIndex + 1}.xml`, {slide: `slides.${slideIndex}`, box: region, path: logo.path, variant: logo.variant, anchor: logo.anchor ?? 'left'});
  if (outcome.svg) context.svgPictures.set(`ppt/slides/slide${slideIndex + 1}.xml|${logoName()}`, outcome.svg);
  slide.addImage({...resolved, objectName: logoName(), ...region, altText: assetAlt(logo.source, presentation) ?? 'Logo'});
}

// FF-62, RR-90: chart text is one size, core's `chartTextSize` for the chart's box: 20 px at the 1280 x 720 reference (15 pt on a 13.33 x 7.5 in
// slide), shrunk only when the box is small (at most 1/18 of its height and 1/30 of its width, whole pixels) and never below
// `composition.minFontSize` (default 16), scaled by the slide's shorter side over 720 px. The preview (opf-render charts.js) and core's value-axis
// density call the same function with the same inputs, so the axis core composed matches the text drawn. The export writes the size in hundredths
// of a point (DrawingML `sz`) on core's 0.01 pt grid, as core composes every font size (RR-16): the request rounds down, never below the
// grid-rounded floor (core `gridFontSize`, `snapFontSizeUp(floor)` against `snapFontSizeDown(request)`).
function chartTextHundredths(context, region) {
  const scale = Math.min(context.dimensions.widthInches, context.dimensions.heightInches) * 96 / 720;
  const floor = context.composition?.minFontSize ?? 16;
  const px = coreChartTextSize({width: region.w * 96, height: region.h * 96, scale, minFontSize: floor});
  return Math.max(Math.ceil(floor * scale * 75 - 1e-6), Math.floor(px * scale * 75 + 1e-6));
}

// Every c:txPr of a generated classic chart carries the chart text size: PptxGenJS writes no size on the legend (PowerPoint's
// 18 pt default) and hardcodes 18 pt on pie and doughnut data labels. Only the size changes; faces and colours stay as written.
function applyChartTextSize(xml, size) {
  return xml.replace(/<c:txPr>[\s\S]*?<\/c:txPr>/g, properties => properties.replace(/<a:defRPr\b([^>]*?)(\/?)>/g, (match, attributes, close) =>
    `<a:defRPr${/\bsz="[^"]*"/.test(attributes) ? attributes.replace(/\bsz="[^"]*"/, `sz="${size}"`) : `${attributes} sz="${size}"`}${close}>`));
}

function addChartPayload(slide, chart, region, context, options = {}, path = "chart", presentation, chartLayout) {
  const chartData = toPptxChartData(chart, context.chartexMode, presentation, path);
  if (!chartData.series) {
    // Never lose a chart silently: the placeholder frame stands in for it, and a diagnostic names the reason.
    options.onDiagnostic?.({code: "chart-data-unplottable", path, message: chartData.message, reason: chartData.reason});
    addPlaceholderPayload(slide, "Chart", chartData.summary, region, context);
    return;
  }
  // RR-54: one strict-number diagnostic per chart, and core's mapping warnings (chart-mapping-adapted) on the chart's path.
  if (chartData.notNumeric) options.onDiagnostic?.({code: "chart-value-not-numeric", path, message: chartData.notNumeric.message, count: chartData.notNumeric.count});
  for (const entry of chartData.diagnostics ?? []) options.onDiagnostic?.({code: entry.code, path, message: entry.message, pointer: entry.path});
  for (const {adaptation, message} of chartData.adaptations ?? []) options.onDiagnostic?.({code: "chart-data-adapted", path, message, adaptation});
  // RR-35: axis titles, legend position and data labels (core resolves them against what the chart type can show).
  // LH-03, LH-81: the chart layer composition decided (src/chart-layer.js); a small chart's default value labels count as data labels.
  // LH-107: a waterfall's layer (roles, labels, caption) belongs to the native waterfall; its clustered-column fallback takes none of it.
  const layer = chartData.chartex || chartLayout?.layer?.waterfall ? undefined : chartLayout?.layer;
  const authoredOptions = resolveChartOptionsFor(chart);
  reportChartOptionDiagnostics(authoredOptions, path, options.onDiagnostic);
  let chartOptions = chartLayerDataLabels(authoredOptions, layer, chartTargetFor(chart.type)?.kind);
  // LH-160: a histogram or Pareto chart whose data labels would not fit beside each other draws none (core `layer.histogram`), in the classic fallback too.
  const histogram = chartLayout?.layer?.histogram;
  if (histogram?.valueLabels === false) chartOptions = {...chartOptions, dataLabels: undefined};
  // LH-109: a stacked column or area chart labels its segments with their values by default (in the middle of a column; an area point
  // has no position); the values that do not fit are hidden per point after the labels are written (src/chart-marks.js).
  const stackLabels = Boolean(layer?.stack?.values.some(row => row.some(Boolean)) && !chartOptions.dataLabels);
  if (stackLabels) chartOptions = {...chartOptions, active: true, dataLabels: {content: ['value'], position: chartTargetFor(chart.type)?.kind === 'area' ? null : 'center', separator: ', '}};

  // LH-03, LH-105: no chart has a panel (the chart and plot areas are unfilled); its colours are judged against the card or the slide
  // background it stands on, as the preview does.
  const panelFill = context.cardFill ?? `#${normalizeHex(context.colors.background)}`;
  // RR-96: chart text, gridlines and axis lines are core's scheme-derived neutrals (tx1 mixed into bg1 at 65%, 15% and 25%), which the finished
  // part writes as schemeClr with lumMod/lumOff, so a variant or background style change in PowerPoint recolors them.
  const neutrals = context.roles.neutrals;
  const labelColor = normalizeHex(textColorForFill(panelFill, neutrals?.chartText?.hex ?? `#${context.colors.text}`));
  // Data labels and highlighted marks contrast with their own mark, from the full text colour (the chart-text neutral is for axes and legends).
  const markLabelColor = normalizeHex(textColorForFill(panelFill, `#${context.colors.text}`));
  const gridColor = normalizeHex(neutrals?.gridline?.hex ?? `#${context.colors.border}`), axisLineColor = normalizeHex(neutrals?.axisLine?.hex ?? `#${context.colors.border}`);
  const transparency = /^#[0-9a-f]{8}$/i.test(panelFill) ? (1 - parseInt(panelFill.slice(7), 16) / 255) * 100 : 0;
  // LH-105: no chart has a panel; the chart area (and a chartex chart's) is unfilled.
  const fill = {color:null,transparency};
  const objectName = `OPF chart ${context.chartHeadings.size + 1}`;
  const circular = chartData.type === 'pie' || chartData.type === 'doughnut';
  const textSize = chartTextHundredths(context, region);
  // RR-54: the columns' number formats (Excel codes per exported series) for the caches, labels, value axis and workbook.
  // The value axis shows the first plotted series' format (General when it has none), as the preview does.
  // A combo chart's secondary value axis shows its first series' format (FA-15).
  const secondaryIndex = chartData.combo?.findIndex((entry) => entry.axis === 'secondary') ?? -1;
  // LH-141: a value axis with no format whose ticks (core's composed axis) are whole numbers of four digits takes `#,##0`, as the preview groups them.
  // LH-153: the axes core does not compose (a combo chart's two, a scatter chart's X and Y) decide from their data (core `groupsDataRange`, as the preview does); a scatter chart's X axis only over a span of 1000 or more, so years stay years.
  const numbers = (entry) => entry.values.map(chartNumber);
  const comboValues = chartData.spec.family === 'combo' && chartData.combo?.length === chartData.series.length ? (axis) => chartData.series.flatMap((entry, index) => chartData.combo[index].axis === axis ? numbers(entry) : []) : undefined;
  const scatterGroups = chartData.spec.family === 'xy' && chartData.series.length > 1;
  const axisGroups = !chartData.chartex && chartData.spec.grouping !== 'percentStacked' && chartData.formats?.series?.[0] === undefined && (comboValues ? groupsDataRange(comboValues('primary'), {zeroBased: chartData.combo.some((entry) => entry.role === 'bar')})
    : scatterGroups ? groupsDataRange(chartData.series.slice(1).flatMap(numbers), {zeroBased: false})
    : chartLayout?.valueAxis && groupsAxisTicks(chartLayout.valueAxis));
  const secondaryGroups = comboValues && secondaryIndex >= 0 && chartData.formats?.series?.[secondaryIndex] === undefined && groupsDataRange(comboValues('secondary'), {zeroBased: false});
  const xAxisGroups = scatterGroups && chartData.resolved?.hasX && chartData.formats?.x === undefined && groupsDataRange(numbers(chartData.series[0]), {zeroBased: false, minRange: 1000});
  const numberFormats = (chartData.formats ?? (axisGroups || secondaryGroups || xAxisGroups ? {series: []} : undefined)) && {...(chartData.formats ?? {series: []}), axis: chartData.spec.grouping === 'percentStacked' ? undefined : axisGroups ? GROUPED_LABEL_CODE : chartData.formats.series[0],
    ...(secondaryIndex >= 0 && (chartData.formats || secondaryGroups) ? {secondaryAxis: secondaryGroups ? GROUPED_LABEL_CODE : chartData.formats.series[secondaryIndex]} : {}),
    ...(xAxisGroups ? {xAxis: GROUPED_LABEL_CODE} : {}),
    labels: !chartOptions?.dataLabels?.content?.includes('percent'), scatter: chartData.type === 'scatter'};
  context.chartHeadings.set(objectName,{heading:chartData.type === 'scatter' ? undefined : chartData.heading,labelColor,markLabelColor,spec:chartData.spec,textSize,
    options:chartOptions,kind:chartTargetFor(chart.type)?.kind,pointCount:chartData.pointCount,numberFormats});
  // Synthetic row-number categories are a native adaptation, not an authored
  // data column. Full provenance restores the source form only on unchanged caches.
  recordPayloadData(context, objectName, 'chart', presentation, path, undefined, {rowNumbers: chart.data?.columns?.length === 1 && chartData.adaptations?.some(entry => entry.adaptation === 'row-numbers') === true,
    fallback: chartData.adaptations?.some(entry => entry.adaptation === 'chart-fallback') === true});
  context.chartFonts.set(objectName,{heading:context.fonts.heading,body:context.fonts.body});
  // FA-09: the chart's text alternative (the frame's descr; the empty string is PowerPoint's decorative marker), applied before the chartex frame copies the head.
  if (typeof chart.alt === 'string') context.frameAlts.set(objectName, chart.alt);
  // RR-89: the series colours are core's chartSeriesPalette (accent1 to accent6 of the deck scheme, then their tints, with the chart's own
  // `colors` over them), adjusted for the chart panel like the preview does. A colour that is still an unadjusted theme accent (or a
  // `chart.colors` scheme slot or role) is written as a schemeClr, so re-theming in PowerPoint recolours the series.
  const colorContext = {roles: context.roles, variables: context.variables, accents: context.roles.map?.accents};
  const preferredPalette = chartSeriesPalette(context.colorScheme, chart.colors, colorContext);
  // WI-5 (P18, D3) and LH-55: every series from the scheme reaches 4.5:1 on a dark panel, as the preview draws it; a lifted colour is written as srgbClr.
  // LH-105: ordinary series are softened towards the backdrop (core softenChartPalette), written as srgbClr; the full-strength palette is
  // kept for the emphasis and the names at the line ends.
  const legibleSeries = chartSchemeSeries(chart.colors, context.colorScheme, colorContext);
  const adjustedPalette = chartPaletteForFill(panelFill, preferredPalette, {legible: legibleSeries, soften: true});
  const strongPalette = chartPaletteForFill(panelFill, preferredPalette, {legible: legibleSeries}).map(color=>normalizeHex(color));
  // LH-161: a pie's or doughnut's last slice is moved off the first (at most 20 L*) when they would read as one tone, else every slice gets a
  // surface-colored border (core chartSlicePlan), as the preview draws it; a moved color is an sRGB literal, never the scheme accent it came from.
  const slicePlan = circular ? chartSlicePlan(panelFill, adjustedPalette, chartData.pointCount, {legible: legibleSeries}) : undefined;
  const slicePalette = slicePlan?.colors ?? adjustedPalette;
  const palette = slicePalette.map(color=>normalizeHex(color));
  const paletteSchemes = chartPaletteSchemes(chart.colors, preferredPalette, strongPalette.map(hex => `#${hex}`), (reference, hex) => schemeColorValue(reference, `#${hex}`, context), context.roles.map?.accents,
    chartSoftColors(panelFill, preferredPalette, {legible: legibleSeries}));
  slicePalette.forEach((color, index) => { if (color !== adjustedPalette[index]) paletteSchemes[index] = undefined; });
  Object.assign(context.chartHeadings.get(objectName), {palette, paletteSchemes, circular, ...(layer?.rings ? {ringNames: layer.rings} : {}),
    // LH-105: the series names at the line ends and the category names on the slices (src/chart-direct-labels.js).
    ...(layer?.slices && !chartOptions.dataLabels ? {sliceLabels: layer.slices} : {}),
    ...(stackLabels ? {stackValues: layer.stack.values} : {}),
    // LH-125: a stacked area runs edge to edge (the value axis crosses on the tick marks).
    ...(layer?.stack?.edge ? {stackEdge: true} : {})});
  // LH-60: a doughnut of several series (core's nested rings) gets its further rings after PptxGenJS wrote the first.
  if (chartData.type === 'doughnut' && chartData.series.length > 1) context.chartHeadings.get(objectName).rings = chartData.series.map((entry) => ({name: entry.name, values: [...entry.values]}));
  // FA-14: chart.highlight. A highlighted chart writes accent and muted colours over the series palette, and its data labels
  // contrast with those colours (src/chart-highlight.js).
  const highlight = chartData.chartex ? undefined : chartHighlightPlan({options: chartOptions, data: chartData.resolved, kind: chartTargetFor(chart.type)?.kind, panelFill, labelColor: markLabelColor, primary: `#${context.colors.accent}`,
    schemeFor: hex => schemeColorValue('primary', hex, context)}) ?? chartFocusPlan({layer, data: chartData.resolved, kind: chartTargetFor(chart.type)?.kind, panelFill, labelColor: markLabelColor, strong: strongPalette}) ?? chartEmphasisPlan({layer, data: chartData.resolved, panelFill, palette, strong: strongPalette, schemes: paletteSchemes});
  context.chartPalettes.set(objectName,highlight ? highlight.seriesFills : palette);
  if (highlight) context.chartHeadings.get(objectName).highlight = highlight;
  // LH-105: each series named at its line end in its colour (the highlight's, else full strength) made legible as text, as the preview does.
  if (layer?.endLabels) {
    const fills = highlight ? highlight.seriesFills : strongPalette;
    context.chartHeadings.get(objectName).endLabels = {...layer.endLabels, region, rtl: context.direction === 'rtl',
      colors: layer.endLabels.entries.map(entry => normalizeHex(chartSeriesLabelColor(panelFill, `#${fills[entry.series % fills.length]}`)))};
  }
  if (chartData.chartex) {
    // The native chartex part is added when the package is normalized (attachChartexParts); the classic chart below becomes its fallback.
    // PptxGenJS rewrites the series it is given (labels become nested levels), so the chartex part keeps its own copy.
    const series = chartData.series.map((entry) => ({name: entry.name, labels: [...entry.labels], values: [...entry.values]}));
    // LH-107: core's waterfall roles, signed labels, dropped value axis and caption (src/chartex.js), in the role colors the preview draws.
    const waterfall = chartLayout?.layer?.waterfall;
    const waterfallInfo = waterfall ? {...waterfall, connector: axisLineColor, caption: chartLayout.layer.header?.caption?.text, colors: waterfall.colors
      ? Object.fromEntries(Object.entries(chartWaterfallColors(panelFill, `#${strongPalette[0]}`, `#${markLabelColor}`, context.colorScheme?.dark2, {labeled: waterfall.labels})).map(([role, color]) => [role, normalizeHex(color)])) : undefined} : undefined;
    context.chartex.set(objectName, {spec: chartData.chartex, series, hasCategories: chartData.hasCategories, fill, labelColor, markLabelColor, markLabelBackground: normalizeHex(`#${context.colors.background}`), gridColor, font: context.fonts.body, palette, textSize, options: chartOptions, ...(histogram ? {histogram} : {}), ...(chartLayout?.layer?.numericAxes ? {numericAxes: chartLayout.layer.numericAxes} : {}), ...(numberFormats ? {formats: numberFormats.series, groups: numberFormats.groups} : {}), ...(waterfallInfo ? {waterfall: waterfallInfo, rtl: context.direction === 'rtl'} : {})});
    if (chartData.chartex.layoutId === 'regionMap') {
      options.onDiagnostic?.({code: "chart-map-geodata", path, message: `The '${stringifyText(chart.type)}' chart is exported as a native PowerPoint map (chartex regionMap) without cached geography (no cx:geoCache; provider data is never fabricated): PowerPoint must fetch the region shapes from its online map service when the deck is opened, and until it does it shows "There was a problem getting the information for your map chart" and draws nothing. The clustered column fallback shows the same values in readers without chartex support.`});
    }
  }
  const percent = chartData.spec.grouping === 'percentStacked';
  // RR-36: a series has one colour, as the preview draws it (opf-render paints series j with palette colour j; only pie,
  // doughnut and treemap slices take a colour per category). PptxGenJS writes a c:dPt per point, cycling the palette, for a
  // bar chart with one series whenever chartColors is a custom array of more than one colour, so PowerPoint drew each
  // column of a single-series column or bar chart in a different colour. One colour for that series writes no c:dPt.
  const chartColors = chartData.type === 'bar' && chartData.series.length === 1 ? palette.slice(0, 1) : palette;
  const scale = Math.min(context.dimensions.widthInches, context.dimensions.heightInches) * 96 / 720;
  const layerXml = chartLayerOptions(layer, {region, scale, textSize, labelColor: markLabelColor, font: context.fonts.body, chart, rtl: context.direction === 'rtl'});
  if (Object.keys(layerXml.layout).length) context.chartHeadings.get(objectName).layerLayout = layerXml.layout;
  const chartOptionsXml = {
    objectName,
    x: region.x,
    y: region.y,
    w: region.w,
    h: region.h,
    // LH-105: a line chart that names its series at the line ends and a pie that names its slices draw no legend.
    // LH-108, LH-109: nor does a pie with its value list, or a stacked chart that names its series beside the last column.
    showLegend: !layer?.endLabels && !(layer?.slices && !chartOptions.dataLabels) && !layer?.valueList && !layer?.stack?.names && (circular || chartData.series.length > (chartData.type === 'scatter' ? 2 : 1)),
    ...classicChartOptions(chartOptions, {labelColor, font: context.fonts.body, textSize}),
    showTitle: false,
    chartColors,
    chartArea: {fill:{color:null},roundedCorners:false},
    // Paint alpha once in the chart area, rather than stacking two alpha fills.
    plotArea: {fill:{color:null}},
    catAxisLabelFontFace: context.fonts.body,
    catAxisLabelFontSize: textSize / 100,
    catAxisLabelColor: labelColor,
    valAxisLabelFontFace: context.fonts.body,
    valAxisLabelFontSize: textSize / 100,
    valAxisLabelColor: labelColor,
    legendColor: labelColor,
    legendFontFace: context.fonts.body,
    legendFontSize: textSize / 100,
    dataLabelColor: markLabelColor,
    dataLabelFontSize: textSize / 100,
    showValue: false,
    ...(circular ? {dataBorder: slicePlan?.bordered ? {color: normalizeHex(panelFill).slice(0, 6), pt: CHART_SLICE_SEPARATOR_PX * 0.75} : {color: normalizeHex(neutrals?.outline?.hex ?? `#${context.colors.background}`), pt: 0.75}} : {}),
    valGridLine: { color: gridColor, size: 1 },
    // LH-105: no tick marks: the gridlines carry the value scale and the category labels name their bands (Few: few gridlines and ticks).
    catAxisMajorTickMark: 'none',
    valAxisMajorTickMark: 'none',
    catAxisLineColor: axisLineColor,
    valAxisLineColor: axisLineColor,
    // Magnitude bars/columns/areas must not let Office auto-truncate a near-equal range.
    ...(chartData.spec.family === "category" && ["bar", "area"].includes(chartData.type) && chartData.spec.grouping !== "percentStacked" ? {
      ...(chartData.series.every(entry => entry.values.every(value => value == null || value >= 0)) ? {valAxisMinVal: 0} : {}),
      ...(chartData.series.some(entry => entry.values.some(value => value < 0)) && chartData.series.every(entry => entry.values.every(value => value == null || value <= 0)) ? {valAxisMaxVal: 0} : {})
    } : {}),
    // RR-92: the value axis core composed (column, bar, line and area charts), as the preview draws it: PowerPoint and Keynote
    // otherwise choose their own bounds and major unit. A 100% stacked chart's axis is a fraction.
    ...(chartLayout?.valueAxis ? {valAxisMinVal: chartLayout.valueAxis.min, valAxisMaxVal: chartLayout.valueAxis.max, valAxisMajorUnit: chartLayout.valueAxis.majorUnit} : {}),
    barDir: chartData.barDir,
    barGrouping: chartData.barGrouping,
    // LH-176: core's gap width (clustered 150%, stacked 50%), the preview's bar geometry (chartBarGeometry), written explicitly.
    ...(chartData.type === "bar" ? {barGapWidthPct: /tacked/.test(chartData.barGrouping ?? "") ? CHART_BAR_GAP_WIDTH.stacked : CHART_BAR_GAP_WIDTH.clustered} : {}),
    // Right to left (RR-05): column, line and area charts reverse their categories (c:catAx orientation maxMin), which also moves the
    // value axis to the right, as the preview draws them. Bar charts keep their vertical category axis.
    ...(context.direction === 'rtl' && ((chartData.type === 'bar' && chartData.barDir === 'col') || chartData.type === 'line' || chartData.type === 'area') ? { catAxisOrientation: 'maxMin' } : {}),
    // LH-59: a horizontal bar chart lists its categories top to bottom in data order, as the preview draws it: the category axis runs
    // from the top (c:catAx orientation maxMin) and the value axis crosses it at the last category (c:valAx crosses max), so the value
    // labels stay at the bottom.
    // LH-125: its value labels sit next to that axis (the bottom), not 'low' (PptxGenJS's default for a bar chart), which on a reversed category axis is the top.
    // LH-93: preview category names sit at the low-value edge. On a negative range Office's nextTo default attaches them to zero.
    // Low moves only the labels to the reserved gutter; it preserves the axis crossing, numeric bounds, data and authored options.
    ...(chartData.type === 'bar' && chartData.barDir === 'bar' ? { catAxisOrientation: 'maxMin', catAxisCrossesAt: 'max', valAxisLabelPos: 'nextTo',
      ...(chartLayout?.valueAxis?.min < 0 ? {catAxisLabelPos: 'low'} : {}) } : {}),
    ...(percent ? { valAxisLabelFormatCode: '0%' } : {}),
    ...(chartData.spec.markers === undefined ? {} : { lineDataSymbol: chartData.spec.markers ? 'circle' : 'none' }),
    ...(chartData.spec.radarStyle ? { radarStyle: chartData.spec.radarStyle } : {}),
    // ScatterWithMarkers: markers only, no connecting line.
    ...(chartData.type === 'scatter' ? { lineSize: 0, lineDataSymbol: 'circle', catGridLine: {style: 'none'},
      ...(chartLayout?.layer?.numericAxes ? {valAxisMinVal: chartLayout.layer.numericAxes.value.min, valAxisMaxVal: chartLayout.layer.numericAxes.value.max, valAxisMajorUnit: chartLayout.layer.numericAxes.value.majorUnit,
        catAxisMinVal: chartLayout.layer.numericAxes.category.min, catAxisMaxVal: chartLayout.layer.numericAxes.category.max, catAxisMajorUnit: chartLayout.layer.numericAxes.category.majorUnit} : {})} : {}),
    // LH-03, LH-81: no chart area fill, no value axis or gridlines, the caption and the header legend (their positions are written below).
    ...layerXml.options
  };
  if (chartData.combo?.length && chartData.combo.length === chartData.series.length) {
    slide.addChart(...comboChart(chartData, chartOptionsXml, {palette, chartOptions, labelColor, font: context.fonts.body, textSize}));
    return;
  }
  // LH-108 to LH-110: the period band under the chart frame, then the chart, then its reference lines, value list and stacked names over it.
  const marks = layer && (layer.references || layer.valueList || layer.doughnut || layer.stack?.names || layer.stack?.ends) ? {chart: objectName, font: context.fonts.body, size: textSize / 100, scale, rtl: context.direction === 'rtl', tags: context.chartMarkTags,
    paint: {text: markLabelColor, chartText: labelColor, grid: gridColor, surface: panelFill.slice(0, 7),
      slice: row => (highlight?.pointFills(0) ?? palette)[row % (highlight?.pointFills(0) ?? palette).length],
      series: index => (highlight ? highlight.seriesFills : palette)[index % (highlight ? highlight.seriesFills : palette).length],
      // LH-125: the text over a series' fill (an area's end values), and the focused slice's value in a doughnut's hole in its color made legible.
      onSeries: index => normalizeHex(textColorForFill(`#${(highlight ? highlight.seriesFills : palette)[index % (highlight ? highlight.seriesFills : palette).length]}`, `#${markLabelColor}`)),
      hole: row => normalizeHex(chartSeriesLabelColor(panelFill, `#${(highlight?.pointFills(0) ?? palette)[row % (highlight?.pointFills(0) ?? palette).length]}`))}} : undefined;
  if (marks) addChartMarks(slide, layer, 'under', marks);
  slide.addChart(chartData.type, chartData.series, chartOptionsXml);
  if (marks) addChartMarks(slide, layer, 'over', marks);
}

// FA-15: a combo chart is one PptxGenJS multi-type chart: a clustered column c:barChart on the primary axes, a c:lineChart with
// markers for the primary-axis lines, and one for the secondary-axis lines on a second c:valAx (at the right, crossing at the
// maximum of a deleted second c:catAx). Each series keeps its palette colour by its index in the whole chart (PptxGenJS restarts
// the colour cycle per chart type), and the embedded workbook holds every series. The secondary axis has no gridlines and only
// its own title; applyComboConstruct puts the line groups into schema order afterwards.
function comboChart(chartData, options, {palette, chartOptions, labelColor, font, textSize}) {
  const series = chartData.series.map((entry, index) => ({...entry, color: palette[index % palette.length]}));
  const part = (role, axis) => series.filter((_, index) => chartData.combo[index].role === role && (role === 'bar' || chartData.combo[index].axis === axis));
  const bars = part('bar'), primaryLines = part('line', 'primary'), secondaryLines = part('line', 'secondary');
  const lineOptions = {lineDataSymbol: 'circle'};
  const types = [
    // The column group's own colour list: with one column series, a longer list would make PptxGenJS colour each column (c:dPt, RR-36).
    ...(bars.length ? [{type: 'bar', data: bars, options: {barDir: 'col', barGrouping: 'clustered', chartColors: bars.map((entry) => entry.color)}}] : []),
    ...(primaryLines.length ? [{type: 'line', data: primaryLines, options: lineOptions}] : []),
    ...(secondaryLines.length ? [{type: 'line', data: secondaryLines, options: {...lineOptions, secondaryValAxis: true, secondaryCatAxis: true}}] : []),
  ];
  // A gap in a line series breaks the line, as the preview draws it (PptxGenJS defaults to span).
  const {barGrouping: _grouping, ...rest} = options;
  const shared = {...rest, displayBlanksAs: 'gap'};
  if (!secondaryLines.length) return [types, {...shared, barDir: 'col'}];
  const title = chartOptions?.axisTitles?.secondary;
  const secondaryValue = {valGridLine: {style: 'none'}, showValAxisTitle: Boolean(title), ...(title ? {valAxisTitle: title, valAxisTitleColor: labelColor, valAxisTitleFontFace: font, valAxisTitleFontSize: textSize / 100} : {})};
  return [types, {...shared, barDir: 'col', valAxes: [{}, secondaryValue], catAxes: [{}, {catAxisHidden: true, showCatAxisTitle: false}]}];
}

// RR-54: a chart or table that uses a dataset, DataColumn objects, a mapping, a data source or number formats records its
// authored data form on its native frame (src/data-provenance.js), in `full` provenance mode only. `path` is the composed
// item's path ("slides.0.blocks.1.chart"), which names the authored value (composition hands over the inline copy).
function recordPayloadData(context, objectName, kind, presentation, path, layout, chartRecordOptions) {
  if (context.provenanceMode !== 'full' || !context.dataRecords || !presentation) return;
  let authored = presentation;
  for (const key of String(path).split('.')) authored = authored !== null && typeof authored === 'object' ? authored[Array.isArray(authored) ? Number(key) : key] : undefined;
  const record = kind === 'chart' ? chartDataRecord(authored, presentation.datasets, chartRecordOptions) : tableDataRecord(authored, layout);
  if (record) {
    context.dataRecords.set(objectName, record);
    context.dataRecordPaths.set(objectName, String(path));
  }
}

function addTablePayload(slide, authoredTable, region, context, options, path, presentation) {
  // RR-54: a dataset-backed table is laid out as its inline copy (composition normally hands that over already); core's
  // layout gives each body cell its display text (a number with a format becomes its formatted text) and each DataColumn
  // header its name.
  const table = inlineTableData(authoredTable, presentation);
  const scale = Math.min(context.dimensions.widthInches * 96, context.dimensions.heightInches * 96) / 720;
  const hasHeaders = Array.isArray(table?.columns) && table.columns.length > 0;
  const sourceRows = [...(hasHeaders ? [table.columns] : []), ...(table?.rows ?? [])];
  if (sourceRows.length === 0) {
    options?.onDiagnostic?.({code: "content-placeholder", path, reason: "table-has-no-rows", message: "The table has no rows and no header; a placeholder frame stands in for it."});
    addPlaceholderPayload(slide, "Table", "The table has no rows.", region, context);
    return;
  }

  const layout = layoutTable(table, {x:region.x*96,y:region.y*96,width:region.w*96,height:region.h*96}, {
    scale, minFontSize:context.composition?.minFontSize, fontFamily:context.fonts.body, textMeasurement:options.textMeasurement, path, alignment:context.tableAlignment,
    ...(context.direction === 'rtl' ? {direction: 'rtl'} : {}), ...(presentation ? {presentation} : {}),
    // LH-48: a lone table that composition grew is laid out at the same growth as the preview.
    ...(context.tableGrowth ? {growth: context.tableGrowth} : {}),
    // LH-113: the highlighted body rows composition gave the table (table.highlight, or the rows the slide's texts name).
    ...(context.tableHighlight ? {highlight: context.tableHighlight} : {})
  });
  const columnCount = layout.columnCount;
  // LH-113: a highlighted row's cells take the accent tint of the surface the preview draws (core tableHighlightColor), an sRGB literal;
  // their text keeps the body text's theme color where it is the same color as on the surface.
  const highlightHex = layout.rows.some(row => row.cells.some(cell => cell.highlighted)) ? tableHighlightColor(`#${context.colors.surface}`, `#${context.colors.accent}`, `#${context.colors.text}`).replace(/^#/, '').toUpperCase() : undefined;
  const rows = layout.rows.map(row => row.cells.map(cell => {
    const {header,rich,fit} = cell;
    const cellStyle = cell.style ?? {};
    const tinted = cell.highlighted && cellStyle.fill === undefined && highlightHex !== undefined;
    const defaultFillHex = header ? context.colors.accent : tinted ? highlightHex : context.colors.surface;
    const baseFill = exportColor(cellStyle.fill ?? defaultFillHex, context, defaultFillHex);
    // FF-24c: engine chrome resolves from scheme roles (header accent1, body surface), so it follows the deck theme like a named fill.
    const fillReference = cellStyle.fill ?? (header ? 'accent1' : tinted ? `#${highlightHex}` : 'surface');
    const keepsText = tinted && textColorForFill(`#${highlightHex}`, `#${context.colors.text}`) === textColorForFill(`#${context.colors.surface}`, `#${context.colors.text}`);
    const fillValue = schemeColorValue(keepsText ? 'surface' : fillReference, keepsText ? context.colors.surface : baseFill, context);
    // RR-96: header text is the role (bg1 or tx1) that reads better on the fill, as the preview chooses it (core readableSchemeColor).
    const inheritedText = header && context.roles ? readableSchemeColor(`#${baseFill}`, context.roles).hex : textColorForFill(`#${baseFill}`, header ? "#FFFFFF" : `#${context.colors.text}`);
    const baseColor = exportColor(cellStyle.color ?? inheritedText.replace(/^#/, ""), context, inheritedText.replace(/^#/, ""));
    // Default cell text follows the theme only with a theme-referenced fill: paired slot on a light or dark fill, light1/dark1 on an accent fill.
    const defaultText = cellStyle.color === undefined ? tableTextSchemeValue(fillValue, baseColor, context) : undefined;
    const alpha = value => value.length === 8 ? (1 - parseInt(value.slice(6), 16) / 255) * 100 : 0;
    const text = stringifyText(cell.value), style = cell.textStyle;
    assertXmlText(text, cell.path ?? path);
    const fragments = rich ? fit.richLines.flatMap(line => line.fragments) : [];
    const runs = rich ? cell.value.flatMap((value, index) => {
      const run = typeof value === 'string' ? {text:value} : value;
      const fragment = fragments.find(item => item.runIndex === index);
      const runStyle = fragment?.style ?? resolveTextStyle({...style,fontFamily:run.fontFamily ?? style.fontFamily,fontWeight:run.bold === undefined ? style.fontWeight : run.bold ? 700 : 400,italic:run.italic ?? style.italic}, options.textMeasurement);
      const rawColor = run.color !== undefined && run.color !== '' ? exportColor(run.color, context, baseColor) : baseColor;
      const color = nativeColor(run.color !== undefined && run.color !== '' ? run.color : cellStyle.color, rawColor, context, defaultText), transparency = rawColor.length === 8 ? (1 - parseInt(rawColor.slice(6), 16) / 255) * 100 : 0;
      const runOptions = {
        ...nativeFontOptions(runStyle),fontSize:fragment ? fragment.fontSize * .75 : fit.fontSize * .75,
        underline:run.underline ? {style:'sng',color:linkColor(run,color,context)} : undefined,strike:run.strikethrough ? 'sngStrike' : undefined,
        color:linkColor(run,color,context),transparency,baseline:fragment?.baselineShift ? -fragment.baselineShift / fragment.fontSize * 2000 : undefined,
        hyperlink:run.link && /^(https?:|mailto:|tel:)/i.test(run.link) ? {url:run.link} : undefined,
      };
      // PptxGenJS marks every part of a newline-containing run as a paragraph
      // break, including its final part. Split explicitly so the next styled
      // run stays on that final line, and preserve empty/trailing lines.
      // LH-11: PowerPoint wraps a table cell itself, so the spaces core's line breaker never breaks at are no-break spaces (import writes them back).
      const parts = bindNoBreak(run.text).split(/\r*\n/);
      return parts.map((text, part) => ({text,options:{...runOptions,breakLine:part < parts.length - 1}}));
    }) : null;
    return {
      // Keep native wrapping and the original cell value: inserting measured
      // soft wraps into the text would change a later import or copy operation.
      text: rich ? runs : bindNoBreak(text),
      options: {
        ...nativeFontOptions(style),
        fontSize: fit.fontSize * 0.75,
        // PptxGenJS fills falsy run options from cell defaults. Rich runs
        // carry their resolved weight, so a bold header default must not turn
        // an explicit bold:false run back on.
        ...(rich ? {bold:false,italic:false} : {}),
        lineSpacing: fit.lineHeight * 0.75,
        paraSpaceAfter: 0,
        align: physicalAlignment(cell.alignment, cell.direction),
        valign: cellStyle.verticalAlign ?? 'top',
        ...(cell.colSpan > 1 ? {colspan:cell.colSpan} : {}),
        ...(cell.rowSpan > 1 ? {rowspan:cell.rowSpan} : {}),
        color: nativeColor(cellStyle.color, baseColor, context, defaultText),
        // Rich runs carry resolved alpha. A translucent cell default would
        // overwrite an explicit opaque run because PptxGenJS inherits falsy 0.
        ...(cellStyle.color && !rich ? {transparency:alpha(baseColor)} : {}),
        fill: { color: tinted ? highlightHex : nativeColor(fillReference, baseFill, context), ...(cellStyle.fill ? {transparency:alpha(baseFill)} : {}) },
      },
    };
  }));
  const objectName = `OPF table ${context.tableHeaders.size + 1}`;
  context.tableHeaders.set(objectName, hasHeaders);
  recordPayloadData(context, objectName, 'table', presentation, path, layout);
  // FA-27: the table's text alternative (the frame's descr; the empty string is PowerPoint's decorative marker).
  if (typeof authoredTable?.alt === 'string') context.frameAlts.set(objectName, authoredTable.alt);
  if (layout.rows.some(row => row.cells.some(cell => Object.keys(cell.style ?? {}).length))) context.tableCells.set(objectName, {layout, scale, context, defaultBorder:{color:`#${context.colors.border}`,width:1/scale}, hiddenBorder:{color:'#000000',width:0}});
  // LH-29: the preview draws a dotted cell border as dots one line width long and two apart; PowerPoint has no such preset and
  // its square dot (sysDot) is one on, one off. A dashed border (four on, three off) is PowerPoint's dash exactly.
  if (layout.rows.some(row => row.cells.some(cell => Object.values(cell.style?.borders ?? {}).some(border => border?.dash === 'dot' && border.width > 0))))
    options.onDiagnostic?.({code: 'export-lossy', feature: 'border-dot', path, message: 'A dotted table border exports as PowerPoint\'s square dot, one line width on and one off; the preview leaves two widths between dots, so the dots sit closer together in PowerPoint.'});
  slide.addTable(rows, {
    objectName,
    x: region.x,
    y: region.y,
    w: region.w,
    // PowerPoint derives a table's height from its rows, and the preview draws
    // the rows (layout.height, never more than the composed box). The declared
    // frame height is the row total so the XML matches what both engines draw.
    h: layout.height / 96,
    rowH: layout.rows.map(row => row.box.height / 96),
    // WI-5 (P20): the column widths core sized from content, the same ones the preview draws (logical column order, as a:tblGrid lists them).
    colW: layout.columnWidths.map(width => width / 96),
    autoPage: false,
    fontFace: context.fonts.body,
    fontSize: 15 * scale * 0.75,
    color: context.colors.text,
    // WI-5 (P20): horizontal rules only (top and bottom of every cell), as the preview draws them; an explicit cell border is written over this.
    border: [{ type: "solid", color: context.colors.border, pt: 0.75 }, { type: "none" }, { type: "solid", color: context.colors.border, pt: 0.75 }, { type: "none" }],
    margin: [6 * scale, 7.5 * scale, 3 * scale, 7.5 * scale],
    valign: "top"
  });
}

function pixelBox(region) {
  return {x: region.x * 96, y: region.y * 96, width: region.w * 96, height: region.h * 96};
}

// One native text box per laid-out rich line (core's richLines), each carrying its runs: run color, size, weight, underline, strike,
// super/subscript (a citation marker is a baseline run) and http(s)/mailto links. The body's lines stay untagged; a heading or quote
// body passes `objectName` and `tag`, which name and tag every line with the boundary between wrapped lines (a soft wrap inserts
// nothing, a hard line break keeps its separator), recovered from the flattened text. `fallback` is the color of runs without one.
function addRichFitLines(slide, fit, box, context, {value, path, alignment: logicalAlignment, fallback, objectName, tag, keepEmpty = false}) {
  const region = {x: box.x / 96, y: box.y / 96, w: box.width / 96, h: box.height / 96};
  const runText = run => typeof run === 'string' ? run : run.text;
  const whole = typeof value === 'string' ? value : value.map(runText).join('');
  assertXmlText(whole, path);
  const count = fit.richLines.length;
  let cursor = 0;
  for (const [index, line] of fit.richLines.entries()) {
    const runs = line.fragments.map(fragment => {
      const runColor = exportColor(fragment.run.color, context, context.colors.text);
      const color = nativeColor(fragment.run.color, runColor, context, fallback);
      return {text: fragment.text, options: {...nativeFontOptions(fragment.style), ...eyebrowOptions(fragment.style, fragment.nominalSize ?? fragment.fontSize), fontSize: (fragment.nominalSize ?? fragment.fontSize) * .75, color: linkColor(fragment.run, color, context), underline: fragment.run.underline ? {style: 'sng', color: linkColor(fragment.run, color, context)} : undefined, strike: fragment.run.strikethrough ? 'sngStrike' : undefined, baseline: fragment.baselineShift ? -fragment.baselineShift / (fragment.nominalSize ?? fragment.fontSize) * 2000 : undefined, hyperlink: fragment.kind !== 'marker' && fragment.run.link && /^(https?:|mailto:|tel:)/i.test(fragment.run.link) ? {url: fragment.run.link} : undefined, ...langOptions(context, fragment.style.lang)}};
    });
    // Logical alignment (RR-05): a right-to-left paragraph starts at the right edge; every wrapped line shares its paragraph's direction.
    const placed = fit.placement?.lines[index], alignment = placed?.alignment ?? physicalAlignment(logicalAlignment, fit.directions?.[index]), factor = alignment === 'right' ? 1 : alignment === 'center' ? .5 : 0;
    const area = placed ? {...region, x: (placed.x + line.width * factor - box.width * factor) / 96, y: placed.y / 96, h: placed.height / 96} : {...region, y: region.y + line.y / 96, h: line.height / 96};
    // PptxGenJS reads the paragraph direction from the first run's options, not from the shape options.
    if (fit.directions?.[index] === 'rtl') for (const run of runs) run.options.rtlMode = true;
    let name;
    if (tag) {
      const text = fit.lines[index] ?? '', end = cursor + text.length;
      const newline = index < count - 1 && whole.startsWith(text, cursor) ? /^(\r\n|\r|\n)/.exec(whole.slice(end)) : null;
      name = objectName(index);
      tag(name, index, count, {boundary: index === count - 1 ? 'end' : newline ? 'hard' : 'soft', separator: newline ? newline[0] : ''});
      cursor = end + (newline ? newline[0].length : 0);
    }
    // LH-12: an untagged body line is still named for its block (`OPF text <path> line N`), never PowerPoint's generic "Text N".
    // LH-63: a plain-text group has a shape for every line, a blank one included (keepEmpty), as an unformatted body's lines do.
    if (runs.length || keepEmpty) slide.addText(runs.length ? runs : '', {...textBoxOptions(area, context, fit.fontSize * .75), align: alignment, fit: 'none', wrap: false, ...smallRunSpacing(line, placed), objectName: name ?? `OPF text ${path} line ${index}`});
  }
}

// RR-105 (opf#1091): core puts a rich line's baseline one fit size below its top (the role size, say a title's 54 px) even when every run
// is smaller, as an eyebrow-like title of 20 pt runs is. At single spacing PowerPoint takes the first baseline from the runs it draws, so
// such a line drew about 22 pt above the preview. With exact spacing PowerPoint puts the first baseline DIAGRAM_BASELINE_SHARE of the pitch
// below the top whatever the runs (SH-07's measurement, valid from DIAGRAM_MIN_PITCH sizes), so the line gets the pitch that puts it on
// core's baseline. A line whose largest run is the fit size (nearly every line) keeps single spacing, byte for byte.
function smallRunSpacing(line, placed) {
  const ascent = placed ? placed.baseline - placed.y : line.baseline - line.y;
  const largest = Math.max(0, ...line.fragments.map(fragment => fragment.nominalSize ?? fragment.fontSize));
  const pitch = ascent / DIAGRAM_BASELINE_SHARE;
  return largest > 0 && pitch >= DIAGRAM_MIN_PITCH * largest ? {lineSpacing: pitch * .75, lineSpacingMultiple: undefined} : {lineSpacingMultiple: 1};
}

function assertXmlText(text, path) {
  const invalid=/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/u.exec(String(text??''));
  if(invalid)throw new OPFPptxError('invalid-text',`Text contains U+${invalid[0].codePointAt(0).toString(16).toUpperCase().padStart(4,'0')} at UTF-16 offset ${invalid.index}, which DrawingML XML cannot represent.`,{path});
}

// LH-76: core draws a "Topic: qualifier" title that would wrap as two items with the title's path (`titleSplit`): the topic as the
// title and the qualifier as a subtitle. Their lines are tagged as one title group, the topic's first, its last line joined to the
// qualifier by the authored colon (boundary `split`), so import restores the whole authored title. The Title placeholder holds the topic.
function titleSplitLines(item, items, title) {
  if (!item.titleSplit || typeof title !== 'string') return undefined;
  const part = name => items.find(other => other.path === item.path && other.titleSplit?.part === name);
  const topic = part('topic'), qualifier = part('qualifier');
  if (!topic?.text?.lines || !qualifier?.text?.lines) return undefined;
  const count = topic.text.lines.length + qualifier.text.lines.length;
  return item === topic ? {offset: 0, count, join: {boundary: 'split', separator: title.slice(topic.titleSplit.end, qualifier.titleSplit.start)}} : {offset: topic.text.lines.length, count};
}

// Match the published renderer's payload geometry and shared core text fitting.
// Each fitted line remains native editable text, without PowerPoint rewrapping it.
// RR-88: a plain-string title that wraps over several lines, with no hard break, overflow, rich runs or right-to-left line.
function isNativeTitle(item) {
  return item.field === 'title' && typeof item.value === 'string' && item.value.length > 0 && !/[\r\n\u2028\u2029]/.test(item.value) && item.text?.lines?.length > 1
    && !item.text.overflow && !item.text.richLines && !item.text.directions?.includes('rtl') && !item.text.sourceLines?.some(line => line.boundary === 'hard' || line.segments?.some(segment => segment.kind === 'tab'));
}

// RR-88: the wrapped title as one native text box: the whole string, native wrap, no autofit, at the block its measured lines fill
// (top of the first line to the bottom of the last), with the measured line pitch as exact spacing. Tagged as one heading line,
// so import reads the current words as the title. The caller binds it to the Title placeholder.
function addNativeTitle(slide, item, context, options, deckContext, wrap) {
  const fit = item.text, box = {...item.box, x: wrap.x, width: wrap.width}, lines = fit.placement?.lines;
  const tops = fit.lines.map((_, index) => lines?.[index] ? lines[index].baseline - fit.fontSize : box.y + index * fit.lineHeight);
  const bottoms = fit.lines.map((_, index) => lines?.[index] ? lines[index].baseline - fit.fontSize + lines[index].height : box.y + (index + 1) * fit.lineHeight);
  const top = Math.min(...tops), height = Math.max(...bottoms) - top;
  const objectName = `OPF heading ${item.path} line 0`;
  deckContext.headingTags.set(objectName, {v: 1, group: item.path, field: 'title', line: 0, count: 1, boundary: 'end', separator: ''});
  deckContext.nativeTitles.add(objectName);
  const style = item.textStyle ?? resolveTextStyle({fontFamily: context.fonts.body, fontWeight: 400, path: item.path}, options.textMeasurement);
  slide.addText(bindNoBreak(item.value), {
    ...textBoxOptions({x: box.x / 96, y: top / 96, w: box.width / 96, h: height / 96}, context, fit.fontSize * .75),
    ...nativeFontOptions(style),
    color: pptxColor(context.textColor), align: physicalAlignment(fit.placement?.alignment ?? item.alignment ?? 'left', fit.directions?.[0]),
    objectName, fit: 'none', wrap: true, lineSpacing: fit.lineHeight * .75, lineSpacingMultiple: undefined
  });
}

function addMeasuredPayloadText(slide, text, box, context, options, config) {
  assertXmlText(text, config.path);
  const scale = Math.min(context.dimensions.widthInches, context.dimensions.heightInches) * 96 / 720;
  const style = config.textStyle ?? resolveTextStyle({fontFamily: config.fontFamily ?? context.fonts.body, fontWeight: config.fontWeight ?? 400, path: config.path}, options.textMeasurement);
  const fit = config.fit ?? fitText(String(text ?? ''), box, config.fontSize * scale, (context.composition?.minFontSize ?? 16) * scale, textWidthMeasurer(style, options.textMeasurement));
  if (fit.overflow && !config.diagnosticsHandled) {
    const diagnostic = {code: 'text-overflow', path: config.path, message: 'Text exceeds its cell at the minimum font size; shorten it, increase its space, or split the slide.'};
    options.onDiagnostic?.(diagnostic);
    if (context.composition?.overflow === 'error') throw new OPFPptxError('layout-overflow', diagnostic.message, {path: config.path, diagnostics: [diagnostic]});
  }
  // Generated socials carry one link per explicit source line; wrapped lines share it.
  let sourceLineIndex = 0;
  for (const [index, line] of fit.lines.entries()) {
    const link = config.links?.[sourceLineIndex];
    if (fit.sourceLines?.[index]?.boundary === 'hard') sourceLineIndex += 1;
    if (!line&&!config.heading&&!config.sourceText&&!config.timeline&&!config.quote&&!config.keepEmpty) continue;
    // Logical alignment (RR-05): a right-to-left line starts at the right edge; furniture and metrics pass physical alignments and report no line directions.
    const placed=fit.placement?.lines[index],alignment=placed?.alignment??physicalAlignment(fit.placement?.alignment??config.align??context.contentAlignment??'left',fit.directions?.[index]),factor=alignment==='right'?1:alignment==='center'?.5:0;
    const sourceLine=fit.sourceLines?.[index],boundary=sourceLine?{boundary:sourceLine.boundary,separator:String(text).slice(sourceLine.end,sourceLine.nextStart)}:{};
    const headingLine=(config.headingLines?.offset??0)+index,headingBoundary=config.headingLines?.join&&index===fit.lines.length-1?config.headingLines.join:boundary;
    const objectName=config.heading?`OPF heading ${config.path} line ${headingLine}`:config.timeline?`OPF timeline ${config.timeline.group} part ${config.timeline.part} line ${index}`:config.quote?`OPF quote ${config.quote.group} part ${config.quote.part} line ${index}`:config.sourceText?`OPF text ${config.path} line ${index}`:config.objectName?`${config.objectName} line ${index}`:undefined;
    if(config.imageCallout)context.imageCalloutTags.set(objectName,{v:1,...config.imageCallout,role:'text',line:index,count:fit.lines.length,...boundary});
    else if(config.heading)context.headingTags.set(objectName,{v:1,group:config.path,field:config.heading,line:headingLine,count:config.headingLines?.count??fit.lines.length,...headingBoundary});
    else if(config.timeline)context.timelineTags.set(objectName,{v:1,role:'text',group:config.timeline.group,part:config.timeline.part,line:index,count:fit.lines.length,...boundary,...(config.timeline.part===0&&index===0?{anchor:config.timeline.anchor}:{})});
    else if(config.quote)context.quoteTags.set(objectName,{v:1,role:'text',group:config.quote.group,part:config.quote.part,line:index,count:fit.lines.length,...boundary,...(config.quote.part===0&&index===0?{anchor:config.quote.anchor}:{})});
    else if(config.furniture){
      context.furnitureTags.set(objectName,{v:1,role:'text',...config.furniture,line:index,count:fit.lines.length,...boundary});
      if(config.liveFields?.[index]?.length)context.furnitureFields.set(objectName,{text:line,fields:config.liveFields[index]});
    }
    else if(config.media&&context.provenanceMode!==false)context.mediaTags.set(objectName,{v:1,role:'caption',path:config.path,line:index,count:fit.lines.length,boundary:sourceLine?.boundary??'end',...(context.provenanceMode==='full'?{fingerprint:mediaTextFingerprint(line),...boundary}:{})});
    else if(config.sourceText)context.plainTextTags.set(objectName,{v:1,group:config.path,line:index,count:fit.lines.length,...boundary});
    const area=placed?{x:(placed.x+placed.width*factor-box.width*factor)/96,y:(placed.baseline-fit.fontSize)/96,w:box.width/96,h:placed.height/96}:{x:box.x/96,y:(box.y+index*fit.lineHeight)/96,w:box.width/96,h:fit.lineHeight/96};
    // A run-level link keeps the muted, non-underlined furniture look of the preview (hlinkClr=tx, u=none).
    const lineColor = pptxColor(config.color ?? context.textColor);
    slide.addText(link?.href && line ? [{text: line, options: {hyperlink: {url: link.href}, color: lineColor, underline: {style: 'none'}}}] : line, {
      ...textBoxOptions(area, context, fit.fontSize * .75),
      ...nativeFontOptions(style), ...eyebrowOptions(style, fit.fontSize), ...langOptions(context, config.lang),
      color: lineColor, align: alignment,
      ...(fit.directions?.[index]==='rtl'?{rtlMode:true}:{}),
      // Reuse the frame's existing relationship to cover blank caption boxes.
      // PptxGenJS also inherits it into runs; keep their native text styling.
      hyperlink: config.hyperlink,
      underline: config.hyperlink ? {style: 'none'} : undefined,
      tabStops:sourceLine?.segments.filter(segment=>segment.kind==='tab').map(segment=>({position:(segment.x+segment.width)/96,alignment:'l'})),
      objectName,
      fit: 'none', wrap: false, lineSpacingMultiple: 1,
    });
  }
}

// The default footer band core composes for a deck with no footer of its own: where a footer added natively lands.
function defaultFooterParts(composeOptions) {
  try {
    const slide = {design: {footer: {left: {date: '2026-01-01'}, center: {text: 'Footer'}, right: {text: '{{slide.number}}'}}}};
    // Only the zone boxes and line height are used, and they do not depend on text widths: estimated measurement keeps the host's measurer (and its call count) out of this.
    return (composeSlide(slide, {...composeOptions, textMeasurement: undefined}).furniture?.parts ?? []).filter(part => part.kind === 'footer' && part.type === 'text');
  } catch {
    return undefined;
  }
}

// The band core gives a lone text part in a zone (x and width in pixels): where a footer added natively sits.
function zoneBands(composeOptions) {
  let bands;
  return zone => (bands ??= new Map((defaultFooterParts(composeOptions) ?? []).map(part => [part.zone, {x: part.box.x, width: part.box.width}]))).get(zone);
}

// RR-102: where Insert > Header & Footer puts a date, footer text or slide number a slide does not have yet: the slide master's
// placeholders (the layouts inherit them). Each sits where core draws that part if the author added it to the deck's footer (the
// deck's own, else the first slide's): a type the footer already has is composed where it is; a missing one is added to the first
// empty zone in PowerPoint's order for it, else (a date) to the first zone's row that takes it clear of what the slides draw, or
// one gap after the start zone's words, so turning it on never covers a part.
// All three share one baseline (the deck's own date, footer text or number, in that order) and take the slide shapes' box from
// core's line placement; a part in a row is as wide as its words and does not wrap (`noWrap`), and a text in a zone with a picture spans the
// zone (RR-71). Returns {geometry: Map<'dt'|'ftr'|'sldNum', {x, y, cx, cy, algn, noWrap, sz}> in EMU, present: the deck footer's own
// native parts by type}, or undefined when core cannot compose it.
const ADD_ZONES = {dt: ['left', 'center', 'right'], ftr: ['center', 'left', 'right'], sldNum: ['right', 'center', 'left']};
// The widest digits of the year, for the width of a date placed beside other parts.
const SAMPLE_DATE = '2026-12-28';
const EMU_PER_PIXEL = 9525;
const plainObject = value => value && typeof value === 'object' && !Array.isArray(value) ? value : undefined;
// The footer a slide added in PowerPoint would have: the deck's, else the first slide's own.
const deckFooter = presentation => plainObject(presentation?.design?.footer) ?? (Array.isArray(presentation?.slides) ? presentation.slides : []).map(slide => plainObject(slide?.design?.footer)).find(Boolean) ?? {};
// The date pattern of the deck footer's date (the default when it has none or a literal one).
const deckDateFormat = footer => Object.values(footer).map(plainObject).find(zone => zone && (zone.date === true || typeof zone.date === 'string') && typeof zone.dateFormat === 'string')?.dateFormat ?? DEFAULT_DATE_FORMAT;
function masterFooterGeometry(composeOptions, {staticNumbers, dateFormat}) {
  const presentation = composeOptions?.presentation;
  if (!presentation) return undefined;
  const base = deckFooter(presentation);
  const footer = Object.fromEntries(['left', 'center', 'right'].filter(zone => plainObject(base[zone])).map(zone => [zone, {...base[zone]}]));
  const filled = item => item !== undefined && (item.image !== undefined || (typeof item.text === 'string' ? item.text.trim() !== '' : item.text !== undefined) || item.socials === true || item.date === true || typeof item.date === 'string');
  // Text widths matter only beside other parts: a deck without a footer (every part alone in its zone) keeps the host's measurer,
  // and its call count, out of this.
  const measurement = Object.keys(footer).length ? composeOptions.textMeasurement : undefined;
  const compose = value => (composeSlide({design: {footer: value}}, {...composeOptions, textMeasurement: measurement}).furniture?.parts ?? []).filter(part => part.kind === 'footer');
  const typed = parts => new Map([...nativeFurnitureParts({parts}, {staticNumbers})].map(([index, ph]) => [ph, parts[index]]));
  try {
    // The deck footer as drawn (a type it has sits there), then with the missing types added (where they would go).
    const drawnParts = compose(footer), present = typed(drawnParts);
    // What a part covers across the slide: its first line's ink (else its words), a picture its box.
    const span = part => {
      if (part.type === 'image') return [part.box.x, part.box.x + part.box.width];
      const placed = part.fit.placement?.lines?.[0];
      if (placed?.outline) return [placed.outline.x, placed.outline.x + placed.outline.width];
      if (placed) return [placed.x, placed.x + placed.width];
      const width = part.fit.sourceLines?.[0]?.width ?? part.box.width, factor = part.alignment === 'right' ? 1 : part.alignment === 'center' ? .5 : 0;
      const x = part.box.x + (part.box.width - width) * factor;
      return [x, x + width];
    };
    const clear = ([start, end]) => drawnParts.every(other => { const [left, right] = span(other); return end <= left || start >= right; });
    const dateFields = zone => ({...footer[zone], date: SAMPLE_DATE, dateFormat});
    const datePart = parts => parts.find(part => part.type === 'text' && part.field === 'date');
    let dateAt;
    for (const ph of ['dt', 'ftr', 'sldNum']) {
      if (present.has(ph)) continue;
      let zone = ADD_ZONES[ph].find(candidate => !filled(footer[candidate]));
      if (!zone && ph === 'dt') {
        // Every zone holds a part: the first zone whose row takes the date without it touching what the slides draw. In a narrow
        // zone (a 4:3 deck) the row would wrap the text beside it instead: the date then follows the start zone's words, one gap
        // after their ink, where nothing is drawn.
        const zones = ADD_ZONES.dt.filter(candidate => footer[candidate]?.date === undefined);
        // A date that would wrap beside the words is still the date part (one line once it has the room after them).
        const trials = zones.map(candidate => ({zone: candidate, part: datePart(compose({...footer, [candidate]: dateFields(candidate)}))}));
        const fits = trials.find(trial => trial.part && trial.part.fit.lines.length === 1 && clear(span(trial.part)));
        zone = fits?.zone ?? zones[0];
        const first = trials[0]?.part;
        if (!fits && first) {
          const start = drawnParts.filter(part => part.zone === first.zone && part.type === 'text');
          const width = span(first)[1] - span(first)[0], gap = 12 * Math.min(composeOptions.width ?? 1280, composeOptions.height ?? 720) / 720;
          const x = first.alignment === 'right' ? Math.min(...start.map(part => span(part)[0])) - gap - width : Math.max(...start.map(part => span(part)[1])) + gap;
          if (start.length && clear([x, x + width])) dateAt = {x: x - (span(first)[0] - first.box.x), width: first.box.width, algn: first.alignment === 'right' ? 'r' : 'l'};
        }
      } else if (!zone) zone = ADD_ZONES[ph].find(candidate => footer[candidate]?.text === undefined);
      if (!zone) continue;
      footer[zone] = ph === 'dt' ? dateFields(zone) : {...footer[zone], text: ph === 'ftr' ? 'Footer' : '{{slide.number}}'};
    }
    const addedParts = compose(footer), added = typed(addedParts);
    // The box the slide's shape for the part's first line has (addMeasuredPayloadText): core's placed line when outlines are measured.
    const area = part => {
      const placed = part.fit.placement?.lines?.[0];
      if (!placed) return {x: part.box.x, y: part.box.y, width: part.box.width, height: part.fit.lineHeight};
      const alignment = placed.alignment ?? part.fit.placement.alignment, factor = alignment === 'right' ? 1 : alignment === 'center' ? .5 : 0;
      return {x: placed.x + placed.width * factor - part.box.width * factor, y: placed.baseline - part.fit.fontSize, width: part.box.width, height: placed.height};
    };
    // One baseline: the deck's own date, footer text or number, in that order (a date added beside the footer text then lines up
    // with it), else the first added one.
    const reference = ['dt', 'ftr', 'sldNum'].map(ph => present.get(ph)).find(Boolean) ?? ['dt', 'ftr', 'sldNum'].map(ph => added.get(ph)).find(Boolean);
    const line = reference && area(reference);
    const geometry = new Map();
    for (const ph of ['dt', 'ftr', 'sldNum']) {
      const own = present.has(ph), part = own ? present.get(ph) : added.get(ph) ?? (ph === 'dt' && dateAt ? datePart(addedParts) : undefined);
      if (!part) continue;
      const parts = own ? drawnParts : addedParts, row = parts.filter(other => other.zone === part.zone);
      let box = area(part), noWrap = row.length > 1;
      if (noWrap && ph !== 'dt' && row.some(other => other.type === 'image')) {
        // RR-71: beside a logo the footer text is as wide as its words on the slide; the master placeholder spans the zone.
        const alone = compose({...footer, [part.zone]: {text: part.text}}).find(other => other.zone === part.zone && other.type === 'text');
        if (alone) { box = {...box, x: area(alone).x, width: area(alone).width}; noWrap = false; }
      }
      if (ph === 'dt' && !own && dateAt) { box = {...box, x: dateAt.x, width: dateAt.width}; noWrap = true; }
      geometry.set(ph, {x: Math.round(box.x * EMU_PER_PIXEL), y: Math.round((line ?? box).y * EMU_PER_PIXEL), cx: Math.round(box.width * EMU_PER_PIXEL), cy: Math.round((line ?? box).height * EMU_PER_PIXEL),
        algn: ph === 'dt' && !own && dateAt ? dateAt.algn : {left: 'l', center: 'ctr', right: 'r'}[part.alignment] ?? 'l', noWrap, sz: Math.round(part.fit.fontSize * 75)});
    }
    return {geometry, present};
  } catch {
    return undefined;
  }
}

// The slide and deck as given to toPptx (variables not yet resolved), for the furniture manifest's authored header and footer text.
const authoredFurniture =(context, slideIndex) => ({presentation: context.authored, slide: context.authored?.slides?.[slideIndex]});

async function addFurniture(slide,presentation,source,layout,context,options,slideIndex) {
  // RR-72: every slide is listed, a slide without furniture too (it may need a layout that hides the master's).
  const drawn = [];
  context.furnitureParts[slideIndex] = {path: `ppt/slides/slide${slideIndex + 1}.xml`, parts: drawn};
  if(!layout){
    if(['header','footer'].some(kind=>(source.design?.[kind]??presentation.design?.[kind])))throw new OPFPptxError('missing-furniture-layout','Header/footer export requires coordinated core furniture geometry.',{path:`slides.${slideIndex}.design`});
    const manifest = furnitureManifest(presentation, source, {parts: []}, slideIndex, undefined, undefined, authoredFurniture(context, slideIndex));
    if (manifest) context.furnitureManifests.set(`ppt/slides/slide${slideIndex + 1}.xml`, manifest);
    return;
  }
  const staticDates = new Map();
  // RR-11: the first footer text, date and slide number that fit one line are native placeholders (src/native-furniture.js).
  const natives = nativeFurnitureParts(layout, {staticNumbers: context.staticSlideNumbers});
  for(const [index,part]of layout.parts.entries()){
    const entry = {index, kind: part.kind, zone: part.zone, field: part.field, type: part.type, path: part.path, native: natives.has(index), names: []};
    drawn.push(entry);
    if(part.type==='image'){
      const region={x:part.box.x/96,y:part.box.y/96,w:part.box.width/96,h:part.box.height/96};
      // A logo reference draws the organization's asset: a source that cannot be drawn is reported where the asset is written.
      const objectName = await addImagePayload(slide,presentation,part.image,region,part.reference!==undefined?part.sourcePath:part.path,context,options,{group:false});
      if (objectName) {
        entry.names.push(objectName);
        context.furnitureTags.set(objectName, {v:1, role:'image', group:String(slideIndex), part:index});
        // RR-71: a part drawn from a logo reference (var:organization.logo.icon) records its picture, so import can tell it is unchanged.
        if (part.reference !== undefined) context.furnitureImages.set(`ppt/slides/slide${slideIndex + 1}.xml|${part.kind}.${part.zone}`, objectName);
      }
    }else{
      if(!part.fit?.sourceLines)throw new OPFPptxError('missing-furniture-layout','Repeated text requires accepted source lines from core.',{path:part.path});
      // Slide numbers ({{slide.number}}) and current dates become native PowerPoint fields; {{deck.slideCount}},
      // {{slide.section}} and fixed dates stay fixed text. A current date whose pattern no PowerPoint
      // date field shows, in the deck's language or en-US, is written as its laid-out text.
      const fields=[];
      for(const field of furniturePartFields(part)){
        // RR-91: with slideNumberFields 'static' a number with words around it is fixed text; Keynote drops the words next to a live number.
        if(field.type==='slideNumber'&&context.staticSlideNumbers&&!isBareSlideNumber(part))continue;
        const nativeType=nativeFieldType(field,context.deckLang);
        // RR-102: a date field whose words are English (United States), not the deck's language, says so in its own `lang`.
        const date=field.type==='date'?nativeDateField(field.format??DEFAULT_DATE_FORMAT,context.deckLang):undefined;
        if(nativeType)fields.push({...field,nativeType,...(date&&date.lang!==context.deckLang?{lang:date.lang}:{})});
        else options.onDiagnostic?.({code:'furniture-date-fixed',path:part.path,message:`dateFormat '${field.format}' is not a PowerPoint date field format in ${context.deckLang==='en-US'?'en-US':`${context.deckLang} or en-US`}; the current date is exported as fixed text that PowerPoint will not update.`});
      }
      const liveFields=fields.length?lineFields(part.text,fields,part.fit.sourceLines,part.fit.lines):undefined;
      for(const field of fields.filter(field => !lineFields(part.text,[field],part.fit.sourceLines,part.fit.lines).some(line => line.length))) {
        options.onDiagnostic?.({code:'furniture-field-fixed',path:part.path,message:`The ${field.type} field range ${field.start}..${field.end} does not fit one accepted text line. It is exported as static text that PowerPoint will not update; native compatibility remains a separate gate.`});
        if(context.provenanceMode === 'full') {
          const marker = staticDateFallback(part,field);
          if(marker) staticDates.set(index,marker);
        }
      }
      addMeasuredPayloadText(slide,part.text,part.box,context,options,{path:part.path,fit:part.fit,textStyle:part.style,align:part.alignment,diagnosticsHandled:true,color:context.mutedColor,keepEmpty:true,objectName:`OPF furniture ${slideIndex} part ${index}`,furniture:{group:String(slideIndex),part:index},liveFields,links:part.links});
      entry.names.push(...part.fit.lines.map((line, number) => `OPF furniture ${slideIndex} part ${index} line ${number}`));
      if(natives.has(index)){
        const name=`OPF furniture ${slideIndex} part ${index} line 0`;
        context.nativeFurniture.set(name,natives.get(index));
        // RR-102: the first slide part of each type, which the notes pages repeat.
        if(!context.nativeParts.has(natives.get(index)))context.nativeParts.set(natives.get(index),part);
        // RR-71: a part in a row with other parts is as wide as its text; the master's placeholder spans the zone.
        const band=context.zoneBand?.(part.zone);
        if(band&&part.box.width<band.width-.5)context.nativeFurnitureBands.set(name,band);
      }
    }
  }
  const manifest = furnitureManifest(presentation, source, layout, slideIndex, staticDates, natives, authoredFurniture(context, slideIndex));
  if (manifest) context.furnitureManifests.set(`ppt/slides/slide${slideIndex + 1}.xml`, manifest);
}

const bulletImageName = () => 'OPF bullet image';

function addCodePayload(slide, value, layout, region, context, path, options) {
  if (!layout) throw new OPFPptxError('missing-code-layout', 'Code export requires a coordinated core build with shared code geometry.', {path});
  for (const part of layout.parts) {
    // XML 1.0 Char excludes controls and unpaired UTF-16 surrogates. The u flag
    // keeps valid supplementary characters (surrogate pairs) accepted.
    const invalid = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/u.exec(part.text);
    if (invalid) throw new OPFPptxError('invalid-code-text', `Code text contains U+${invalid[0].codePointAt(0).toString(16).toUpperCase().padStart(4,'0')} at UTF-16 offset ${invalid.index}, which XML cannot represent; edit that character before exporting.`, {path:part.path});
  }
  const group = String(context.codeTags.size + 1), panelName = `OPF code ${group} panel`;
  for (const part of layout.parts) if (!part.fit) throw new OPFPptxError('layout-overflow', 'Code content has no usable internal space; increase its cell size before exporting.', {path:part.path,diagnostics:layout.diagnostics});
  // FA-13: code.highlight is one native rectangle per run of marked lines, between the panel and the line text boxes; marked
  // lines keep the syntax colours, the others are dimmed, from the same core helpers the preview calls.
  const highlight = codeHighlight(value, layout, context);
  context.codeTags.set(panelName,codeManifest(value,layout,group,highlight?.bands.length));
  const syntax = codeSyntax(value, layout, context, path, options);
  const palette = codePalette(context);
  slide.addShape('rect', {...region, fill: {color: codePanelColor(context).slice(1)}, line: {color: context.roles.neutrals?.codePanel ? context.colors.border : '334155', width: .75}, objectName:panelName});
  if (highlight) {
    const bodyPart = layout.parts.find(part => part.role === 'body');
    highlight.bands.forEach((band, bandIndex) => {
      const lineHeight = bodyPart.fit.lineHeight;
      const bandName = `OPF code ${group} highlight ${bandIndex + 1}`;
      context.codeTags.set(bandName, {v:1, group, role:'highlight', index:bandIndex});
      slide.addShape('rect', {x: region.x + .01, y: (bodyPart.box.y + band.first * lineHeight) / 96, w: region.w - .02, h: (band.last - band.first + 1) * lineHeight / 96,
        fill: {color: highlight.colors.band.slice(1)}, line: {type: 'none'}, objectName: bandName});
    });
  }
  for (const [partIndex,part] of layout.parts.entries()) {
    if (!part.fit) throw new OPFPptxError('layout-overflow', 'Code content has no usable internal space; increase its cell size before exporting.', {path:part.path,diagnostics:layout.diagnostics});
    for (const [index,line] of part.fit.sourceLines.entries()) {
      const tabStops=line.segments.filter(segment=>segment.kind==='tab').map(segment=>({position:(segment.x+segment.width)/96,alignment:'l'}));
      const objectName = `OPF code ${group} ${part.role} line ${index+1}`;
      context.codeTags.set(objectName,{v:1,group,role:'line',part:partIndex,line:index});
      // RR-07: the same token ranges and palette the preview paints; the text of the runs is the line text, unchanged.
      const runs = syntax && part.role==='body' ? codeLineRuns(syntax.tokens,line.start,line.end,part.text) : undefined;
      const lineColors = highlight && part.role==='body' ? (highlight.marked.has(highlight.numbers[index]) ? highlight.colors.lit : highlight.colors.dim) : undefined;
      const lineText = part.text.slice(line.start,line.end);
      const lineOptions = {
        ...textBoxOptions({x:part.box.x/96,y:(part.box.y+index*part.fit.lineHeight)/96,w:part.box.width/96,h:part.fit.lineHeight/96},context,part.fit.fontSize*.75),
        ...nativeFontOptions(part.style),
        color:part.role==='body'?(lineColors?.plain.slice(1)??palette.plain.slice(1)):palette.keyword.slice(1),align:'left',fit:'none',wrap:false,lineSpacingMultiple:1,
        tabStops:tabStops.length?tabStops:undefined,objectName,
      };
      // A run's own options replace the line's, so every run repeats the font, size, alignment and tab stops and differs only in colour.
      slide.addText(runs?.some(run=>run.kind) ? runs.map(run=>({text:part.text.slice(run.start,run.end),options:{...lineOptions,color:(lineColors??syntax.palette)[run.kind??'plain'].slice(1)}})) : lineText,lineOptions);
    }
  }
}

// FA-13: the marked lines of code.highlight, their bands (runs of displayed lines) and the lit/dimmed colours, from core (the preview
// calls the same functions); undefined when the code marks no line.
function codeHighlight(value, layout, context) {
  if (!value || typeof value !== 'object' || !Array.isArray(value.highlight)) return undefined;
  const body = layout.parts.find(part => part.role === 'body');
  if (!body?.fit) return undefined;
  const lines = codeHighlightLines(value.highlight, body.text).lines;
  if (!lines.length) return undefined;
  return {marked: new Set(lines), numbers: codeLineNumbers(body.fit.sourceLines), bands: codeHighlightBands(body.fit.sourceLines, lines), colors: codeHighlightColors(context.colorScheme, codePalette(context), codePanelColor(context))};
}

// Token ranges and palette for the code body, from core (the preview calls the same functions); undefined for plain code.
function codeSyntax(value, layout, context, path, options) {
  const body = layout.parts.find(part => part.role === 'body');
  const language = typeof value?.language === 'string' ? value.language : layout.parts.find(part => part.role === 'language')?.text;
  if (!body || !language) return undefined;
  const tokens = tokenizeCode(body.text, language);
  return tokens.length ? {tokens, palette: codePalette(context)} : undefined;
}

// RR-96: the code panel, plain text, comment and syntax colors are the slide's own roles through its variant (core codeSyntaxPaletteForRoles, the
// panel `roles.neutrals.codePanel`), written as scheme colors in the finished slide; an older core keeps the fixed palette.
function codePalette(context) {
  return context.roles.neutrals?.codePanel ? codeSyntaxPaletteForRoles(context.roles) : codeSyntaxPaletteForScheme(context.colorScheme);
}
function codePanelColor(context) {
  return context.roles.neutrals?.codePanel?.hex ?? '#111827';
}

function addMetricPayload(slide,value,layout,context,path,options,presentation) {
  if (!layout) throw new OPFPptxError('missing-metric-layout','Metric export requires coordinated core metric geometry.',{path});
  const group=String(context.metricTags.size+1),manifest=metricManifest(value,layout,group);
  // RR-07, LH-53: a trend adds one native arrow shape where core placed it (before the delta; the trend word is not drawn) and colors
  // the delta text. LH-54: a metric in a card is colored against the card fill (context.cardFill), as the preview does. LH-57: on a
  // dark one, a value whose accent falls under 4.5:1 takes the text color.
  const backdrop=context.cardFill??`#${normalizeHex(context.colors.background)}`;
  // LH-137: a delta pill (layout.deltaPill), a native rounded rectangle in core metricPillFill under the delta and its arrow, which are
  // colored against it; tagged into the metric's group as decoration (role 'pill'), as the preview draws it.
  const pillFill=layout.deltaPill?metricPillFill(backdrop,`#${normalizeHex(context.colors.text)}`):undefined;
  if (layout.deltaPill) {
    const pill=layout.deltaPill.box,objectName=`OPF metric ${group} pill`;
    slide.addShape('roundRect',{objectName,x:pill.x/96,y:pill.y/96,w:pill.width/96,h:pill.height/96,rectRadius:layout.deltaPill.radius/96,fill:{color:normalizeHex(pillFill)},line:{type:'none'}});
  }
  const trendMark=metricTrendMark(layout,{background:pillFill??backdrop,...(context.roles.neutrals?.trendNeutral ? {neutral: context.roles.neutrals.trendNeutral.hex} : {})});
  // LH-53: a unit on its value's line is part of the figure and takes the value's color, as the preview does.
  // LH-57: when the value takes the text color, it is written as the slide's own text color (a scheme color where the text is one).
  const textHex=`#${normalizeHex(context.colors.text)}`,valueHex=metricValueColor(`#${normalizeHex(context.colors.accent)}`,backdrop,textHex).toUpperCase();
  const valueColor=valueHex===textHex.toUpperCase()?context.textColor:valueHex.slice(1);
  // LH-135: a label drawn as the metric's eyebrow is written in the eyebrow's color (eyebrowColor), capitals and tracking as the tag's.
  const partColor=part=>trendMark&&(part.role==='trend'||part.role==='delta')?trendMark.color.slice(1):part.role==='value'||part.role==='unit'&&layout.arrangement==='inline-unit'?valueColor:layout.eyebrow&&part.role==='label'?pptxColor(eyebrowColor(context)):context.textColor;
  for (const [partIndex,part] of layout.parts.entries()) {
    const invalid=/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/u.exec(part.text);
    if (invalid) throw new OPFPptxError('invalid-metric-text',`Metric text contains U+${invalid[0].codePointAt(0).toString(16).toUpperCase().padStart(4,'0')} at UTF-16 offset ${invalid.index}, which XML cannot represent; edit that character before exporting.`,{path:part.path});
    if (!part.visible) continue;
    if (!part.fit||part.linePositions?.length!==part.fit.sourceLines.length) throw new OPFPptxError('layout-overflow','Metric content has no accepted internal line positions; increase its cell size or coordinate package versions.',{path:part.path,diagnostics:layout.diagnostics});
    for (const [index,line] of part.fit.sourceLines.entries()) {
      const origin=part.linePositions[index],objectName=`OPF metric ${group} ${part.role} line ${index+1}`;
      context.metricTags.set(objectName,partIndex===0&&index===0?manifest:{v:1,group,role:'line',part:partIndex,line:index});
      const tabStops=line.segments.filter(segment=>segment.kind==='tab').map(segment=>({position:(segment.x+segment.width)/96,alignment:'l'}));
      // Anchor the native paragraph to the same accepted left/center/right point.
      // Left-aligning at a measured glyph origin loses the intended edge when the
      // native shaper has a slightly different advance. No re-fitting is needed.
      const factor=layout.alignment==='right'?1:layout.alignment==='center'?.5:0;
      const anchor=origin.x+line.width*factor;
      slide.addText(part.text.slice(line.start,line.end),{
        ...textBoxOptions({x:(anchor-part.box.width*factor)/96,y:(origin.baseline-part.fit.fontSize)/96,w:part.box.width/96,h:part.fit.lineHeight/96},context,part.fit.fontSize*.75),
        ...nativeFontOptions(part.style),...eyebrowOptions(part.style,part.fit.fontSize),
        color:partColor(part),align:layout.alignment,...(part.fit.directions?.[index]==='rtl'?{rtlMode:true}:{}),fit:'none',wrap:false,lineSpacingMultiple:1,
        tabStops:tabStops.length?tabStops:undefined,objectName,
      });
    }
  }
  // LH-137: the pill's tag follows the text's, so the metric's manifest stays its first tag (the pill shape is drawn first, under the text).
  if (layout.deltaPill) context.metricTags.set(`OPF metric ${group} pill`,{v:1,group,role:'pill'});
  if(trendMark) {
    const objectName=`OPF metric ${group} trend mark`;
    context.metricTags.set(objectName,{v:1,group,role:'mark'});
    context.metricDescriptions.set(objectName,trendMark.ariaLabel);
    slide.addShape(trendMark.shape,{objectName,x:trendMark.box.x/96,y:trendMark.box.y/96,w:trendMark.box.width/96,h:trendMark.box.height/96,fill:{color:trendMark.color.slice(1)},line:{transparency:100},altText:trendMark.ariaLabel});
  }
}

async function addQuotePayload(slide, presentation, value, layout, context, options, path) {
  if (!layout) throw new OPFPptxError('missing-quote-layout', 'Quote export requires a coordinated core build with shared quote geometry.', {path});
  for (const part of layout.parts) if (!part.fit) throw new OPFPptxError('layout-overflow', 'Quote content has no usable internal space; increase its cell size before exporting.', {path:part.path,diagnostics:layout.diagnostics});
  // Every line shape is tagged (OPF_QUOTE_V1) so an unchanged export re-imports as a quote payload (FF-57).
  const group=String(context.quoteTags.size),anchor=quoteManifest(value,layout);
  for (const [index,part] of layout.parts.entries()) {
    // FA-10: a TextRun[] quote body (core's rich lines, quotation marks joined to its first and last run) is exported line by line like rich body text, with the same quote tags.
    if (part.runs && part.fit.richLines) {
      addRichFitLines(slide, part.fit, part.box, context, {
        value: part.text, path: part.path, alignment: part.fit.placement?.alignment ?? context.contentAlignment ?? 'left', fallback: context.textColor,
        objectName: line => `OPF quote ${group} part ${index} line ${line}`,
        tag: (name, line, count, boundary) => context.quoteTags.set(name, {v: 1, role: 'text', group, part: index, line, count, ...boundary, base: richBase(part.fit, part.style, context.colors.text), ...(index === 0 && line === 0 ? {anchor} : {})})
      });
      continue;
    }
    addMeasuredPayloadText(slide,part.text,part.box,context,options,{
      path:part.path,fit:part.fit,textStyle:part.style,diagnosticsHandled:true,
      color:part.role==='footer'?context.mutedColor:context.textColor,
      quote:{group,part:index,anchor},
    });
  }
  if (layout.photo) await addQuotePhoto(slide, presentation, layout.photo, group, context, options);
  // LH-78: a quote card's decorative mark, one native text box in the primary color (against the card, as a metric's value is) where core placed it,
  // tagged into the quote's group as decoration (role 'mark') so an unchanged export imports back with the quote.
  if (layout.mark) {
    const mark = layout.mark, backdrop = context.cardFill ?? `#${normalizeHex(context.colors.background)}`, textHex = `#${normalizeHex(context.colors.text)}`;
    const markHex = metricValueColor(`#${normalizeHex(context.colors.accent)}`, backdrop, textHex).toUpperCase();
    addMeasuredPayloadText(slide, mark.text, mark.box, context, options, {path: mark.path, fit: mark.fit, textStyle: mark.style, diagnosticsHandled: true, color: markHex === textHex.toUpperCase() ? context.textColor : markHex.slice(1), quote: {group, part: layout.parts.length}});
    context.quoteTags.set(`OPF quote ${group} part ${layout.parts.length} line 0`, {v: 1, role: 'mark', group});
  }
  // LH-114: a pull line's accent rule, a native rectangle in the primary color where core placed it (as the preview draws it), tagged
  // into the quote's group so an unchanged export imports back with the quote.
  if (layout.rule) {
    const objectName = `OPF quote rule ${group}`, rule = layout.rule;
    slide.addShape('rect', {objectName, x: rule.x / 96, y: rule.y / 96, w: rule.width / 96, h: rule.height / 96, fill: {color: context.colors.accent}, line: {transparency: 100}});
    context.quoteTags.set(objectName, {v: 1, role: 'rule', group});
  }
}

// FA-12: the attributed person's headshot is a native picture in the core circle frame: cropped to fill it (a:srcRect after the bytes
// are embedded) with the `ellipse` preset geometry, the alt text as its description, tagged into the quote's provenance group.
async function addQuotePhoto(slide, presentation, photo, group, context, options) {
  const box = { x: photo.box.x / 96, y: photo.box.y / 96, w: photo.box.width / 96, h: photo.box.height / 96 };
  const outcome = { box, cover: true };
  const resolved = await resolveImage(photo.value, presentation, options, photo.path, outcome);
  if (!resolved) {
    // opf-pptx#210: the headshot placeholder reports its cause like every other picture, so strict export (--fail-on warning) gates it.
    if (!outcome.reported) options.onDiagnostic?.({code: 'unresolved-asset', path: photo.path, reason: 'unresolved-source', message: 'The quote photo needs an embedded raster, a declared asset or a host imageResolver; the photo exports as the unavailable-image placeholder. Remote images are never fetched.'});
    addImagePlaceholder(slide, presentation, photo.value, box, photo.path, context, options);
    return;
  }
  const objectName = quotePhotoName(group);
  // PowerPoint is not confirmed to apply a non-rectangular mask to an SVG picture, so an SVG photo exports as its PNG raster (as a masked slide image does).
  if (outcome.svg) options.onDiagnostic?.({ code: 'export-lossy', feature: 'svg-rasterized', path: photo.path, message: 'An SVG quote photo exports as its PNG raster so the circular mask applies as in the preview; PowerPoint has not been confirmed to apply it to an SVG picture.' });
  context.quotePhotos.set(objectName, { region: box, mode: 'crop', path: photo.path, shape: photo.shape, ...(photo.focus ? { focus: photo.focus } : {}) });
  context.quoteTags.set(objectName, { v: 1, role: 'photo', group });
  const alt = assetAlt(photo.value, presentation);
  context.pictureText.set(objectName, pictureText(alt, photo.value, presentation));
  slide.addImage({ ...resolved, objectName, ...box, altText: alt });
}

function addTimelinePayload(slide, value, layout, context, options, path) {
  if(!layout)throw new OPFPptxError('missing-timeline-layout','Timeline export requires a coordinated core build with shared timeline geometry.',{path});
  // Validate optional field fits before the provenance manifest dereferences
  // source lines or any drawing/tag mutation is performed.
  for(const part of layout.parts)if(!part.fit)throw new OPFPptxError('layout-overflow','Timeline field has no usable space; change the arrangement or paginate events.',{path:part.path,diagnostics:layout.diagnostics});
  const scale=Math.min(context.dimensions.widthInches,context.dimensions.heightInches)*96/720;
  const group=String(context.timelineTags.size),anchor=timelineManifest(value,layout),connectorName=`OPF timeline ${group} connector`;
  const {x1,y1,x2,y2}=layout.connector;
  slide.addShape('line',{objectName:connectorName,x:x1/96,y:y1/96,w:(x2-x1)/96,h:(y2-y1)/96,line:{color:context.colors.border,width:3*scale*.75}});
  context.timelineTags.set(connectorName,{v:1,group,role:'connector'});
  for(const range of layout.ranges??[]){
    const name=`OPF timeline ${group} range ${range.eventIndex}`,box=range.box;
    slide.addShape('rect',{objectName:name,x:box.x/96,y:box.y/96,w:box.width/96,h:box.height/96,fill:{color:context.colors.accent,transparency:68},line:{color:normalizeHex(context.colors.background),width:scale*1.5}});
    context.timelineTags.set(name,{v:1,group,role:'range',eventIndex:range.eventIndex});
  }
  for(const link of layout.rangeLinks??[]){
    const name=`OPF timeline ${group} range link ${link.eventIndex}`,dx=link.x2-link.x1,dy=link.y2-link.y1;
    slide.addShape('line',{objectName:name,x:Math.min(link.x1,link.x2)/96,y:Math.min(link.y1,link.y2)/96,w:Math.abs(dx)/96,h:Math.abs(dy)/96,flipV:dx*dy<0,line:{color:context.colors.border,width:scale*.75}});
    context.timelineTags.set(name,{v:1,group,role:'range-link',eventIndex:link.eventIndex});
  }
  // LH-121: the connector up to the current event, a second native line in the primary color over the first.
  if(layout.progress){
    const progressName=`OPF timeline ${group} progress`,{x1,y1,x2,y2}=layout.progress;
    slide.addShape('line',{objectName:progressName,x:x1/96,y:y1/96,w:(x2-x1)/96,h:(y2-y1)/96,line:{color:context.colors.accent,width:3*scale*.75}});
    context.timelineTags.set(progressName,{v:1,group,role:'progress'});
  }
  // FA-11: a status draws from the deck's colors through core's shared shapes: native ellipses (solid fill, or the
  // background fill plus a line for a hollow marker or a ring) and a muted text color for a planned event.
  const statusColors={background:`#${normalizeHex(context.colors.background)}`,primary:`#${context.colors.accent}`,text:`#${normalizeHex(context.colors.text)}`,mutedText:`#${context.colors.mutedText}`};
  for(const marker of layout.markers){
    if(!marker.status){
      const objectName=`OPF timeline ${group} marker ${marker.eventIndex}`;
      slide.addShape('ellipse',{objectName,x:(marker.x-marker.radius)/96,y:(marker.y-marker.radius)/96,w:marker.radius*2/96,h:marker.radius*2/96,fill:{color:context.colors.accent},line:{transparency:100}});
      context.timelineTags.set(objectName,{v:1,group,role:'marker',eventIndex:marker.eventIndex});
      continue;
    }
    for(const shape of timelineMarkerShapes(marker,statusColors)){
      const objectName=`OPF timeline ${group} ${shape.role} ${marker.eventIndex}`;
      slide.addShape(shape.shape,{objectName,x:(shape.cx-shape.radius)/96,y:(shape.cy-shape.radius)/96,w:shape.radius*2/96,h:shape.radius*2/96,
        fill:{color:normalizeHex(shape.fill)},line:shape.stroke?{color:normalizeHex(shape.stroke.color),width:shape.stroke.width*.75}:{transparency:100}});
      context.timelineTags.set(objectName,{v:1,group,role:shape.role,eventIndex:marker.eventIndex,...(shape.role==='marker'?{status:marker.status}:{})});
    }
  }
  for(const [index,part]of layout.parts.entries()){
    const statusColor=part.status==='planned'?normalizeHex(timelineTextColor(part,statusColors)):undefined;
    // Native RTL proofing reorders Latin date digits even when the paragraph is LTR.
    // Keep a wholly Latin date as one English run, as the existing bidi writer does
    // for Latin phrases, without parsing dates or changing any text or geometry.
    const latinDate=context.direction==='rtl'&&part.role==='when'&&/\p{Script=Latin}/u.test(part.text)&&/^[\p{Script=Latin}0-9\p{P}\p{S}\p{Z}]*$/u.test(part.text);
    addMeasuredPayloadText(slide,part.text,part.box,context,options,{path:part.path,fit:part.fit,textStyle:part.style,align:part.alignment,diagnosticsHandled:true,timeline:{group,part:index,anchor},...(latinDate?{lang:'en-US'}:{}),...(statusColor?{color:statusColor}:{})});
  }
  // LH-121: the generated status words, tagged into the group as `status` so import consumes them (the status comes from the markers).
  for(const label of layout.statusLabels??[]){
    if(!label.fit)continue;
    const objectName=`OPF timeline ${group} status ${label.eventIndex}`;
    addMeasuredPayloadText(slide,label.text,label.box,context,options,{path:label.path,fit:label.fit,textStyle:label.style,align:label.alignment,diagnosticsHandled:true,objectName,color:normalizeHex(timelineTextColor(label,statusColors))});
    for(let line=0;line<label.fit.lines.length;line++)context.timelineTags.set(`${objectName} line ${line}`,{v:1,group,role:'status',eventIndex:label.eventIndex});
  }
}

// Mirror the renderer's media placeholder: a bordered surface, a centred 72px
// play badge and a centred caption (title, then source). Native video embedding
// is not attempted; the caption keeps the reference editable.
function addMediaPayload(slide, presentation, value, region, path, context, options) {
  const box = pixelBox(region);
  const icon = {x: box.x + (box.width - 72) / 2, y: box.y + (box.height - 72) / 2};
  // The frame links to a web source (after asset dereferencing), so the
  // reference stays usable in PowerPoint; OPF_MEDIA_V1 keeps the OPF value.
  const resolved = dereferenceAsset(value, presentation, path), source = typeof resolved === "string" ? resolved : resolved?.src;
  const hyperlink = typeof source === "string" && /^https?:\/\//i.test(source) ? {url: source} : undefined;
  const names = {frame: `OPF media ${path} frame`, badge: `OPF media ${path} badge`, play: `OPF media ${path} play`};
  if (context.provenanceMode !== false) {
    context.mediaTags.set(names.frame, mediaFrameRecord(value, path, presentation, context.provenanceMode, options.onDiagnostic));
    context.mediaTags.set(names.badge, {v: 1, role: "badge", path});
    context.mediaTags.set(names.play, {v: 1, role: "play", path});
  }
  slide.addShape("rect", {x: region.x, y: region.y, w: region.w, h: region.h, fill: {color: context.colors.surface}, line: {color: context.colors.border, width: 0.75}, hyperlink, objectName: names.frame});
  slide.addShape("ellipse", {x: icon.x / 96, y: icon.y / 96, w: 72 / 96, h: 72 / 96, fill: {color: context.colors.accent}, line: {transparency: 100}, hyperlink: hyperlink && {url: source}, objectName: names.badge});
  slide.addShape("triangle", {x: (icon.x + 28) / 96, y: (icon.y + 22) / 96, w: 28 / 96, h: 28 / 96, rotate: 90, fill: {color: context.roles ? normalizeHex(readableSchemeColor(`#${context.colors.accent}`, context.roles).hex) : "FFFFFF"}, line: {transparency: 100}, hyperlink: hyperlink && {url: source}, objectName: names.play});
  addMeasuredPayloadText(slide, mediaCaption(value), {...box, y: icon.y + 72 + 20, height: 50}, context, options,
    {path, fontSize: 18, fontFamily: context.fonts.body, fontWeight: 600, align: "center", color: context.colors.mutedText, objectName: `OPF media ${path} caption`, media: true, keepEmpty: true, hyperlink});
}

// The asset an image block names, layered as the preview layers it: fields on the
// block win over the registry entry it references, and an unknown reference keeps
// the block's own fields.
function placeholderAsset(asset, presentation) {
  const plain = value => typeof value === "string" ? { src: value } : isPlainObject(value) ? value : { src: "" };
  let current = plain(asset);
  const seen = new Set();
  while (typeof current.src === "string" && current.src.startsWith("asset:")) {
    const id = current.src.slice(6);
    if (seen.has(id) || !Object.hasOwn(presentation.assets ?? {}, id)) break;
    seen.add(id);
    const { src: _source, ...overrides } = current;
    current = { ...plain(presentation.assets[id]), ...overrides };
  }
  return current;
}

// An image that cannot be embedded exports the preview's placeholder, not a second
// design: a dashed panel with a centered "Image unavailable" over the asset's alt
// text (else title, else "Image"), set bold at 20 px (shrinking to the composition
// minimum) in the readable text colour for the panel, or a cross when the label
// cannot fit even at that minimum. The panel carries the accessible name the
// preview gives its group, "Image unavailable: <description>".
// The panel's other shapes are named after it (OPF image placeholder N text line i / icon i) and the panel's name is returned,
// so a logo placeholder can be tagged and consumed on import. opf-pptx#221: unless it is a logo's ({logo: true}) or furniture's
// ({group: false}) placeholder, packaging writes the panel and those shapes as one native group carrying the accessible name.
function addImagePlaceholder(slide, presentation, asset, region, path, context, options, {logo = false, group = !logo} = {}) {
  const layered = placeholderAsset(asset, presentation);
  const description = String(layered.alt ?? layered.title ?? "Image");
  const label = `Image unavailable\n${description}`;
  // The preview rejects characters DrawingML/SVG XML cannot represent when it draws the label.
  // The cross and the accessible name would otherwise carry them into the slide XML, so check
  // up front and fail the same way whichever form the placeholder takes.
  const invalid = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\uD800-\uDFFF￾￿]/u.exec(label);
  if (invalid) throw new OPFPptxError("invalid-text", `Text contains U+${invalid[0].codePointAt(0).toString(16).toUpperCase().padStart(4, "0")} at UTF-16 offset ${invalid.index}, which DrawingML XML cannot represent.`, { path });
  const scale = Math.min(context.dimensions.widthInches, context.dimensions.heightInches) * 96 / 720;
  const box = pixelBox(region);
  const padding = Math.min(24 * scale, box.width * .06, box.height * .1);
  const inner = { x: box.x + padding, y: box.y + padding, width: Math.max(1, box.width - padding * 2), height: Math.max(1, box.height - padding * 2) };
  const surface = normalizeHex(context.colors.surface);
  const textColor = normalizeHex(textColorForFill(`#${surface}`, `#${context.colors.text}`));
  const style = resolveTextStyle({ fontFamily: context.fonts.body, fontWeight: 600, path }, options.textMeasurement);
  const measurer = textWidthMeasurer(style, options.textMeasurement);
  const minimum = (context.composition?.minFontSize ?? 16) * scale;
  const fit = fitText(label, inner, 20 * scale, minimum, measurer);
  const objectName = `OPF image placeholder ${context.imagePlaceholders.size + 1}`;
  context.imagePlaceholders.set(objectName, `Image unavailable: ${description}`);
  if (group) context.imagePlaceholderGroups.add(objectName);
  const named = logo || group;
  slide.addShape("rect", {
    x: region.x, y: region.y, w: region.w, h: region.h,
    fill: { color: surface },
    line: { color: context.colors.border, width: .75, dashType: "dash" },
    objectName
  });
  if (!fit.overflow) {
    // The lines are centered vertically in the padded box. Fit against the shifted
    // box so any per-line placement carries the same offset.
    const offset = Math.max(0, (inner.height - fit.lines.length * fit.lineHeight) / 2);
    const centered = { ...inner, y: inner.y + offset };
    addMeasuredPayloadText(slide, label, centered, context, options, {
      path, fit: fitText(label, centered, 20 * scale, minimum, measurer), textStyle: style,
      diagnosticsHandled: true, align: "center", color: textColor, ...(named ? {objectName: `${objectName} text`} : {})
    });
    return objectName;
  }
  // A status indicator, not shortened authored content: the full description stays
  // in the panel's accessible name.
  const size = Math.max(0, Math.min(inner.width, inner.height, 24 * scale));
  if (!size) return objectName;
  const icon = { x: inner.x + (inner.width - size) / 2, y: inner.y + (inner.height - size) / 2 };
  const line = { color: textColor, width: Math.min(2 * scale, size / 8) * .75 };
  for (const flipV of [false, true]) slide.addShape("line", { x: icon.x / 96, y: icon.y / 96, w: size / 96, h: size / 96, line, flipV, ...(named ? {objectName: `${objectName} icon ${flipV ? 2 : 1}`} : {}) });
  return objectName;
}

// A placeholder names what is missing in plain words. It never dumps the source value, so no data or URL lands in slide text.
function addPlaceholderPayload(slide, label, description, region, context) {
  slide.addShape("rect", {
    x: region.x,
    y: region.y,
    w: region.w,
    h: region.h,
    fill: { color: context.colors.surface, transparency: 10 },
    line: { color: context.colors.border, width: 0.75 },
    objectName: "OPF placeholder panel"
  });
  slide.addText(`${label}\n${description}`, {
    isTextBox: true,
    objectName: "OPF placeholder text",
    x: region.x + 0.12,
    y: region.y + 0.12,
    w: Math.max(0.2, region.w - 0.24),
    h: Math.max(0.2, region.h - 0.24),
    margin: 0,
    fontFace: context.fonts.body,
    fontSize: 11,
    color: context.mutedColor,
    // RR-104: OPF writes explicit sizes and never asks PowerPoint to shrink text on overflow (no a:normAutofit).
    fit: "none",
    valign: "mid",
    align: "center"
  });
}

// FF-31: a measurement provider may preview a chosen family with another face
// (Carlito for Aptos or Calibri, Gelasio for Georgia, a caller alias, a generic
// fallback). That substitute changes measurement and drawing only. The package
// always names the developer's chosen family. Measurement still uses the
// substitute, because the provider resolves the chosen family again on every
// measure/outline call, so layout is unchanged.
function sameTypeface(requested, resolved) {
  if (typeof resolved !== 'string') return false;
  const want = requested.trim().toLowerCase(), got = resolved.trim().toLowerCase();
  // A legacy four-style family such as "Roboto Medium" is the chosen typeface.
  return got === want || got.startsWith(`${want} `) && isFaceStyleSuffix(got.slice(want.length + 1));
}
// Use each slide's core script profile, including a rich run's own language, for every fitting path.
// Latin roles follow that slide's scheme; explicit run families remain under the planner's strict glyph policy.
function slideTextMeasurement(presentation, index, options) {
  const measurement = options.fonts?.textMeasurement;
  if (!measurement || !options.createScriptFonts) return options.textMeasurement;
  const core = coreContext(presentation, index, {...options, textMeasurement: undefined});
  const languages = new Map();
  const planner = language => {
    const key = language ?? '';
    if (!languages.has(key)) {
      const resolved = resolveScriptFonts(presentation, {slideIndex: index, ...(options.catalogs !== undefined ? {catalogs: options.catalogs} : {}), ...(language ? {language} : {})});
      const slots = role => {
        // LH-28: in safe mode the Latin slot is the safe family the text is measured and written in.
        const latin = options.safeTypeface ? options.safeTypeface(core.options.fontFamilies[role]) : core.options.fontFamilies[role];
        const slot = name => ['latin', 'schemeFamily'].includes(resolved.sources?.[name]) ? latin : resolved[role]?.[name] ?? latin;
        return {latin, eastAsian: slot('eastAsian'), complexScript: slot('complexScript')};
      };
      languages.set(key, options.createScriptFonts({...resolved, heading: slots('heading'), body: slots('body'), serif: core.resolved.fontScheme.type === 'serif'}, measurement).textMeasurement);
    }
    return languages.get(key);
  };
  const base = planner(), pick = style => planner(style?.lang) ?? base;
  const adapted = {...base, measure: (text, size, style) => pick(style).measure(text, size, style)};
  // The planner's measurement object spreads its provider; inherited class methods must keep their receiver.
  if (typeof measurement.resolveStyle === 'function') adapted.resolveStyle = style => measurement.resolveStyle(style);
  if (typeof measurement.resolveFont === 'function') adapted.resolveFont = style => measurement.resolveFont(style);
  if (typeof base.outlineBounds === 'function') adapted.outlineBounds = (text, size, style) => pick(style).outlineBounds(text, size, style);
  return options.safeTypeface ? safeMeasurement(chosenFamilyMeasurement(adapted), options.safeTypeface) : chosenFamilyMeasurement(adapted);
}

// DrawingML has only a bold flag: a run written for the chosen family (no provider face such as Roboto SemiBold) draws that
// family's bold face at 600 and above and its regular face below, whatever weight the engine asked for.
const nativeDrawnWeight = weight => weight >= 600 ? 700 : 400;
const FACE_WEIGHTS = [100, 200, 300, 400, 500, 600, 700, 800, 900];
const styleName = (weight, italic) => `weight ${weight} ${italic ? 'italic' : 'upright'}`;

// RR-59 (opf-pptx#214): a provider's font-unavailable for a family whose faces are loaded, only not at the requested weight and
// style, names the family, weight and style that are missing and the ones that are loaded. Any other error is returned unchanged.
function missingFaceError(error, style, measurement, drawn) {
  if (error?.code !== 'font-unavailable' || typeof style?.fontFamily !== 'string') return error;
  const weight = style.fontWeight ?? 400, italic = !!style.italic, loaded = [];
  for (const candidateItalic of [false, true]) for (const candidate of FACE_WEIGHTS) {
    if (candidate === weight && candidateItalic === italic) continue;
    try { const face = measurement.resolveStyle({...style, fontWeight: candidate, italic: candidateItalic}); loaded.push({weight: candidate, italic: candidateItalic, family: face?.fontFace?.family ?? face?.fontFamily}); }
    catch { /* not loaded at this weight and style */ }
  }
  if (!loaded.length) return error;
  const policy = error.details?.substitutionPolicy, replacement = error.details?.replacement;
  const families = [...new Set(loaded.map(face => face.family).filter(Boolean))], wanted = styleName(drawn ?? weight, italic);
  const message = `No local font face for '${style.fontFamily}' at ${styleName(weight, italic)}${policy ? ` under substitutionPolicy '${policy}'` : ''}`
    + `${drawn !== undefined && drawn !== weight ? `, nor at ${wanted}, the face PowerPoint draws the run with` : ''}. '${style.fontFamily}' resolves only at ${loaded.map(face => styleName(face.weight, face.italic)).join(', ')}`
    + `${families.length ? ` (${families.join(', ')})` : ''}. Load ${typeof replacement === 'string' ? `its replacement '${replacement}' or licensed '${style.fontFamily}' files` : `a '${style.fontFamily}' face`} at ${wanted} (loadFonts({faces})).`;
  const Type = typeof error.constructor === 'function' && error.constructor !== Error ? error.constructor : undefined;
  const details = {...error.details, fontFamily: style.fontFamily, fontWeight: weight, italic, loadedStyles: loaded.map(({weight, italic}) => ({weight, italic})), cause: error.message};
  let improved;
  try { improved = Type ? new Type('font-unavailable', message, details) : undefined; } catch { improved = undefined; }
  if (!(improved instanceof Error) || improved.code !== 'font-unavailable') improved = Object.assign(new Error(message), {name: error.name, code: 'font-unavailable', details});
  improved.cause = error;
  return improved;
}

function chosenFamilyMeasurement(measurement) {
  if (!measurement || typeof measurement.resolveStyle !== 'function') return measurement;
  const resolveFont = typeof measurement.resolveFont === 'function' ? style => measurement.resolveFont(style) : undefined;
  const wrapped = {
    measure: (text, size, style) => measurement.measure(text, size, style),
    resolveStyle: input => {
      // RR-59 (opf-pptx#214): engine-chosen weights (the image placeholder label and media caption at 600, core's metric value at
      // 800, metric labels and timeline event text at 500) are not always loaded: a metric replacement holds at 400 and 700 only
      // (Aptos -> Intos). The run is written for the chosen family with a bold flag, so it is measured at the weight PowerPoint
      // draws it in, which the policy does resolve. A family the policy cannot resolve at that weight either still fails, and
      // a style that resolves keeps its own resolution, so no output that exported before changes.
      let style = input, resolved;
      try { resolved = measurement.resolveStyle(style); }
      catch (error) {
        const weight = style?.fontWeight ?? 400, drawn = nativeDrawnWeight(weight);
        if (error?.code !== 'font-unavailable' || drawn === weight) throw missingFaceError(error, style, measurement);
        style = {...style, fontWeight: drawn};
        try { resolved = measurement.resolveStyle(style); }
        catch { throw missingFaceError(error, input, measurement, drawn); }
      }
      const requested = style?.fontFamily;
      // Theme tokens are provider business; the exporter always passes concrete families.
      if (typeof requested !== 'string' || requested.startsWith('+')) return resolved;
      // opf-render reports whether a face came from the chosen family or a substitute;
      // other providers are judged by family name.
      const resolution = resolveFont?.(style);
      const faceFamily = resolved?.fontFace?.family;
      const substituted = typeof resolution?.substitute === 'boolean'
        ? resolution.substitute
        : !sameTypeface(requested, resolved?.fontFamily) || typeof faceFamily === 'string' && !sameTypeface(requested, faceFamily);
      if (!substituted) return resolved;
      const chosen = {...style};
      delete chosen.fontFace;
      return chosen;
    },
  };
  if (typeof measurement.outlineBounds === 'function') wrapped.outlineBounds = (text, size, style) => measurement.outlineBounds(text, size, style);
  if (resolveFont) wrapped.resolveFont = resolveFont;
  return wrapped;
}

// FA-13: TextRun.lang as the run's own proofing language (a:rPr lang), when it differs from the deck language.
function langOptions(context, tag) {
  const lang = runLanguageTag(context.scriptFonts, tag, context.slideIndex ?? 0);
  return lang ? {lang} : {};
}

// LH-32: an eyebrow (core's style.caps and style.tracking: the slide tag, a label core sets as one) is written as PowerPoint draws
// one, the authored text with cap="all" and the tracking as spc (points), so it stays editable as written and import reads its words.
function eyebrowOptions(style, fontSize) {
  return style?.caps || style?.tracking ? {...(style.caps ? {caps: 'all'} : {}), ...(style.tracking ? {charSpacing: Math.round(style.tracking * fontSize * .75 * 100) / 100} : {})} : {};
}

function nativeFontOptions(style) {
  const face=style.fontFace;
  if(face!==undefined) {
    if(!face || typeof face.family!=='string' || !face.family.trim() || typeof face.bold!=='boolean' || typeof face.italic!=='boolean')
      throw new OPFPptxError('invalid-font-selection','The font provider must supply a family and explicit bold/italic style-link flags.',{path:style.path});
    return {fontFace:face.family,bold:face.bold,italic:face.italic};
  }
  return {fontFace:style.fontFamily,bold:style.fontWeight>=600,italic:style.italic};
}

// LH-12: every OPF text shape is a native text box (`txBox="1"`), so a screen reader announces text, not a graphic; a shape
// later bound to a layout placeholder drops the flag (native-furniture.js, template-layouts.js). The zero margin is the
// composition's own geometry: each box already is the composed line or text box, so PowerPoint adds no inset of its own.
function textBoxOptions(region, context, fontSize) {
  return {
    isTextBox: true,
    x: region.x,
    y: region.y,
    w: region.w,
    h: region.h,
    margin: 0,
    paraSpaceAfter: 0,
    lineSpacingMultiple: 1.22,
    fontFace: context.fonts.body,
    fontSize,
    color: context.textColor,
    breakLine: false,
    // RR-104: autofit off (PptxGenJS writes no autofit element, which is off): PowerPoint never refits OPF text.
    fit: "none",
    valign: "top"
  };
}

// The private text helpers annotation-export.js writes captions and footnote lines with (RR-34).
const exportHelpers = {textBoxOptions, nativeFontOptions, exportColor, nativeColor};

function textRuns(value, context, fallbackFontSize, path) {
  const runs = Array.isArray(value) ? value : [value];
  return runs.map((run) => {
    assertXmlText(typeof run === "string" ? run : run?.text, path);
    if (typeof run === "string") {
      return {
        text: run,
        options: {
          color: context.textColor,
          fontFace: context.fonts.body,
          fontSize: fallbackFontSize
        }
      };
    }
    return {
      text: String(run?.text ?? ""),
      options: {
        bold: run?.bold,
        italic: run?.italic,
        underline: run?.underline ? { style: "sng", color: linkColor(run, nativeColor(run?.color, exportColor(run?.color, context, context.colors.text), context, context.textColor), context) } : undefined,
        strike: run?.strikethrough ? "sngStrike" : undefined,
        color: linkColor(run, nativeColor(run?.color, exportColor(run?.color, context, context.colors.text), context, context.textColor), context),
        fontFace: run?.fontFamily ?? context.fonts.body,
        fontSize: run?.fontSize ?? fallbackFontSize,
        superscript: run?.superscript,
        subscript: !run?.superscript && run?.subscript,
        hyperlink: run?.link && /^(https?:|mailto:|tel:)/i.test(run.link) ? { url: run.link } : undefined,
        ...langOptions(context, run?.lang)
      }
    };
  });
}

/**
 * Series for a native chart, or `{reason, message}` when the data cannot be plotted (the caller reports it).
 * A first column that holds categories is the usual shape. Chart types whose data is one column of values
 * (histogram, dot plot) have no category column, so their values are plotted directly: a histogram is binned
 * into equal-width bins and exported as a column chart of the counts, every other type plots the values against
 * their row numbers. `adapted` names that transformation so it is reported, never silent.
 *
 * RR-54: the data is resolved by core (`resolveChartData`, docs/chart-table-data.md): a dataset reference, DataColumn
 * objects and `chart.mapping` become the canonical positional table [category, (x,) ...series], and every value cell
 * goes through core's strict `chartNumber` (a string that is not a plain decimal is a gap, reported once per chart as
 * `chart-value-not-numeric`). `formats` holds the Excel codes of the columns' number formats per exported series.
 */
function toPptxChartData(chart, chartexMode = 'auto', presentation, path = 'chart') {
  const unplottable = (reason, summary, message) => ({reason, summary, message: `${message} No native chart was exported; a placeholder frame stands in for it.`});
  // A dataset reference is inlined from the document first (composition normally hands over the inline copy already).
  const source = isDatasetRef(chart?.data) ? inlineChartData(chart, presentation) : chart;
  const authored = source?.data;
  if (isDatasetRef(authored)) {
    return unplottable("dataset-unknown", "The chart's dataset is missing, so it cannot be drawn here.", `The chart references dataset '${stringifyText(authored.dataset)}', which the document does not hold (or a field it names).`);
  }
  if (!authored || !Array.isArray(authored.columns) || !Array.isArray(authored.rows)) {
    return unplottable("no-columns", "The chart has no inline data, so it cannot be drawn here.", "The chart data is not inline columns and rows. Supply inline columns and rows or a dataset.");
  }
  if (authored.rows.length === 0) return unplottable("no-rows", "The chart has no data rows.", "The chart data has no rows.");
  if (authored.columns.length === 0) return unplottable("no-columns", "The chart has no data columns.", "The chart data has no columns.");
  const resolvedData = resolveChartData(source, presentation);
  if (!resolvedData.ok) return unplottable(resolvedData.reason, "The chart data cannot be drawn here.", resolvedData.message);
  // LH-60: core's draw plan: the construct both engines draw (a map over categories that are not places as columns, a pie of several
  // series as a doughnut of rings, a box per series, a scatter by position) and the data as drawn.
  const slideIndex = /^slides\.(\d+)\./.exec(path)?.[1];
  const plan = chartDrawPlan(source, resolvedData, {language: quoteLanguage(presentation, slideIndex === undefined ? undefined : Number(slideIndex))});
  const data = {columns: plan.columns, rows: plan.rows};
  const columnCodes = (plan.formats ?? []).map(excelCode);
  const diagnostics = resolvedData.diagnostics.filter((entry) => entry.severity === 'warning' && entry.code !== 'chart-value-not-numeric');
  const rejected = resolvedData.diagnostics.filter((entry) => entry.code === 'chart-value-not-numeric');
  const {spec: resolved} = resolveChartType(plan.fallback ? plan.type : chart.type);
  // A chartex type (treemap, histogram, pareto, box & whisker, waterfall, funnel, map) has no classic construct. Natively
  // it is written as its cx:chartSpace part and the clustered column chart of the same data is its mc:Fallback
  // (src/chartex.js). 'auto' (the default) does that for the constructs the native PowerPoint check confirmed and keeps
  // the unconfirmed map on the clustered column chart alone; 'fallback' keeps every chartex id there. The fallback is
  // reported as chartex-fallback, never silent. LH-175: a Pareto chart of several series is core's pareto-as-columns fallback (a
  // clustered column chart of every series, as the preview draws it), so it reaches here as a column chart in every mode.
  const native = chartexMode === 'native' || (chartexMode === 'auto' && resolved.family === 'chartex' && !resolved.unconfirmed);
  const chartex = resolved.family === 'chartex' && native ? resolved : null;
  const spec = resolved.family === 'chartex' ? CHARTEX_FALLBACK : resolved;
  const typeName = stringifyText(chart.type);
  const adaptations = [];
  if (resolved.family === 'chartex' && !native) {
    const reason = chartexMode === 'fallback'
      ? 'that this exporter does not write'
      : 'that PowerPoint has not yet accepted natively from this exporter (pass chartex: \'native\' to write its chartex part)';
    adaptations.push({adaptation: "chartex-fallback", message: `The '${typeName}' chart is a PowerPoint extension (chartex) chart ${reason}; its data is exported as a native clustered column chart instead.`});
  }
  if (plan.fallback) adaptations.push(chartFallbackAdaptation(plan, typeName));
  // FA-14: the resolved table (category, X, series columns), which chart.highlight names its series and categories in.
  const mapped = {resolved: {columns: data.columns, hasX: plan.hasX === true, rows: data.rows}, type: spec.pptx, spec, chartex, barDir: spec.barDir, barGrouping: spec.pptx === 'bar' || spec.pptx === 'area' ? spec.grouping : undefined, diagnostics, heading: data.columns[0], pointCount: data.rows.length,
    // FA-15: core's combo plan (column series, then the primary-axis lines, then the secondary-axis lines), aligned with the series.
    ...(spec.family === 'combo' ? {combo: comboPlanOf(resolvedData, data.columns.length - 1)} : {})};
  // Number formats only when a column has one: a chart without formats carries no `formats` and is written as before.
  // LH-141: `groups` flags the series whose default value labels group their thousands (PowerPoint's own labels take `#,##0`).
  const withFormats = (result, formats) => formats.series.some((code) => code !== undefined) || formats.x !== undefined || formats.groups?.some(Boolean) ? {...result, formats} : result;
  if (data.columns.length === 1) {
    const heading = data.columns[0];
    // The lone column holds the chart's values. Each cell is read with chartNumber and each non-numeric cell is counted
    // as rejected. A cell that holds no number is skipped, never plotted as 0.
    const points = data.rows.map((row, index) => ({row: index + 1, value: chartNumber(row?.[0]), cell: row?.[0]}));
    for (const point of points) if (point.value === null && point.cell !== null && point.cell !== undefined && point.cell !== '') rejected.push({path: `/data/rows/${point.row - 1}/0`, cell: point.cell});
    const plottedPoints = points.filter((point) => point.value !== null);
    const notNumeric = notNumericDiagnostic(rejected);
    if (plottedPoints.length === 0) {
      return unplottable("single-column-not-numeric", "The chart's data column has no numbers.", `The only chart data column '${heading}' holds no numbers, and a chart needs values to plot.`);
    }
    const skipped = data.rows.length - plottedPoints.length;
    const skippedNote = skipped ? ` (${skipped} non-numeric ${skipped === 1 ? "cell was" : "cells were"} skipped)` : "";
    if (!native && String(chart.type ?? "").toLowerCase() === "histogram") {
      const bins = histogramBins(plottedPoints.map((point) => point.value));
      return {
        type: "bar", spec: CHARTEX_FALLBACK, barDir: "col", barGrouping: "clustered", heading: "Bin", diagnostics, notNumeric, pointCount: bins.length,
        series: [{name: "Frequency", labels: bins.map((bin) => bin.label), values: bins.map((bin) => bin.count)}],
        adaptations: [{
          adaptation: "histogram-binned",
          message: `The histogram's single data column '${heading}' (${plottedPoints.length} values${skippedNote}) was binned into ${bins.length} equal-width bins and exported as a column chart of the counts; PowerPoint's own histogram chart is not exported, and the binned counts do not restore the raw values on re-import.`
        }]
      };
    }
    // Rows keep their own row numbers, so a skipped cell leaves a gap in the numbering.
    const labels = plottedPoints.map((point) => String(point.row));
    const numbers = plottedPoints.map((point) => point.value);
    const scatter = mapped.type === "scatter";
    const series = scatter
      ? [{name: "Row", labels, values: plottedPoints.map((point) => point.row)}, {name: heading, labels, values: numbers}]
      : [{name: heading, labels, values: numbers}];
    const formats = {series: [columnCodes[0]]};
    // A native histogram or Pareto chart bins the values themselves (PowerPoint's automatic bins); only its classic fallback plots them against row numbers.
    if (chartex?.binning) return withFormats({...mapped, series, heading: "Row", hasCategories: false, adaptations, notNumeric}, formats);
    adaptations.push({adaptation: "row-numbers", message: `The chart's single data column '${heading}' has no category column, so its ${plottedPoints.length} values${skippedNote} are plotted against their row numbers.`});
    return withFormats({...mapped, series, heading: "Row", hasCategories: true, adaptations, notNumeric}, formats);
  }

  const labels = data.rows.map((row) => stringifyText(row?.[0]));
  let series = data.columns.slice(1).map((name, seriesIndex) => ({
    name,
    labels,
    // A cell that holds no number (null, an empty or non-numeric string, a boolean) is a gap, as in the preview and the single-column
    // path above: it is neither plotted as a zero nor written into the cache as one. Core already passed it through chartNumber.
    values: data.rows.map((row) => row?.[seriesIndex + 1] ?? null)
  }));
  let codes = columnCodes.slice(1);
  // LH-60: a pie plots one series (core draws a pie of several as a doughnut, whose rings plot every series).
  const plotted = spec.pptx === 'pie' ? 1 : chartex ? chartex.series : Infinity;
  if (series.length > plotted) {
    // A pie, doughnut or single-series chartex construct plots one series; name the ones left out instead of dropping them silently.
    const dropped = series.slice(plotted).map((entry) => `'${entry.name}'`);
    adaptations.push({adaptation: "series-dropped", message: `The ${typeName} chart plots one series, so its first series '${series[0].name}' is exported and the other ${dropped.length} (${dropped.join(", ")}) ${dropped.length === 1 ? "is" : "are"} not.`});
    series = series.slice(0, plotted);
    codes = codes.slice(0, plotted);
  }
  // Only the exported cells count. Core reports a cell at its authored column, which is its resolved position (1 for the
  // first series) unless a mapping reorders the columns; a series that a pie or a single-series construct drops is not counted.
  const position = (entry) => {
    const column = Number(/\/(\d+)$/.exec(entry.path ?? '')?.[1]);
    return source.mapping === undefined ? column : data.columns.indexOf(dataColumnName(authored.columns[column]));
  };
  const notNumeric = notNumericDiagnostic(rejected.filter((entry) => !(position(entry) > plotted)));
  if (spec.family === 'xy' && !plan.hasX) {
    // [Point, X, Y...] carries its own X column; a lone value column (or, LH-60, series beside an X column without numbers) is plotted against the row numbers.
    series = [{name: 'X', labels, values: data.rows.map((_, index) => index + 1)}, ...series];
    codes = [undefined, ...codes];
    if (plan.fallback !== 'scatter-by-position') adaptations.push({adaptation: "row-numbers", message: `The scatter chart has no X column (a point label column and one value column), so its ${data.rows.length} values are plotted against their row numbers.`});
  }
  // A scatter chart's first series is its X values (PptxGenJS writes one c:ser per Y series, each with c:xVal).
  const formats = spec.family === 'xy' ? {series: codes.slice(1), x: codes[0]} : {series: codes};
  const plottedSeries = spec.family === 'xy' ? series.slice(1) : series;
  formats.groups = formats.series.map((code, index) => code === undefined && groupsThousands(plottedSeries[index].values.map(chartNumber)));
  return withFormats({...mapped, series, hasCategories: true, adaptations, notNumeric}, formats);
}

/** Core's combo plan; a core without one draws every series as columns except the last, a line on the primary axis (the preview's rule). */
function comboPlanOf(resolved, count) {
  if (Array.isArray(resolved.combo) && resolved.combo.length === count) return resolved.combo;
  return Array.from({length: count}, (_, index) => ({role: count > 1 && index === count - 1 ? 'line' : 'bar', axis: 'primary'}));
}

/** A chart column's name: the string, or a DataColumn's `name`. */
function dataColumnName(column) {
  return typeof column === 'string' ? column : column !== null && typeof column === 'object' && typeof column.name === 'string' ? column.name : undefined;
}

/** One chart-value-not-numeric diagnostic per chart (core reports one per cell), or undefined. */
function notNumericDiagnostic(rejected) {
  if (!rejected.length) return undefined;
  const first = rejected[0];
  const shown = Object.hasOwn(first, 'cell') ? JSON.stringify(first.cell) : /chart value (.*) is not a number/.exec(first.message ?? '')?.[1] ?? 'a value';
  return {count: rejected.length, pointer: first.path, message: `${rejected.length} chart ${rejected.length === 1 ? 'value is' : 'values are'} not ${rejected.length === 1 ? 'a number' : 'numbers'} (first: ${shown} at ${first.path}) and ${rejected.length === 1 ? 'is' : 'are'} exported as ${rejected.length === 1 ? 'a gap' : 'gaps'}. Chart values are numbers, or strings in plain decimal syntax (12, -3.5, 1e6); put units, currency and percent in the column's number format.`};
}


/**
 * Equal-width bins (Sturges' count, at most 50) from the minimum to the maximum; every bin but the last is [low, high).
 * Arithmetic stays finite for any finite input (values of +-1e308 and denormals included): the bin edges are
 * computed by interpolating the edges rather than from a width, and a value is placed by comparing it with the edges.
 * Used by the default (fallback) histogram export only; the native chartex histogram bins in PowerPoint.
 */
function histogramBins(values) {
  const min = values.reduce((a, b) => Math.min(a, b)), max = values.reduce((a, b) => Math.max(a, b));
  const count = min === max ? 1 : Math.min(50, Math.ceil(Math.log2(values.length)) + 1);
  const edge = (index) => index === 0 ? min : index === count ? max : min / count * (count - index) + max / count * index;
  const bins = Array.from({length: count}, (_, index) => ({low: edge(index), high: edge(index + 1), count: 0}));
  // A value belongs to the last bin whose lower edge it reaches, so counts always agree with the labelled edges.
  for (const value of values) {
    let index = 0;
    while (index + 1 < count && value >= bins[index + 1].low) index++;
    bins[index].count++;
  }
  // Labels carry six significant digits, and more when that would make two bins read alike.
  for (let precision = 6; ; precision++) {
    const format = (value) => String(Number(value.toPrecision(precision)));
    const labels = bins.map((bin) => min === max ? format(min) : `${format(bin.low)}–${format(bin.high)}`);
    if (new Set(labels).size === labels.length) return bins.map((bin, index) => ({...bin, label: labels[index]}));
    if (precision === 17) return bins.map((bin, index) => ({...bin, label: `${labels[index]} (bin ${index + 1})`}));
  }
}

// Embedded bytes must be a raster the exporter can measure and PptxGenJS can embed (PNG, JPEG, GIF, WebP), or an SVG,
// which exports as a native SVG picture over a PNG fallback raster (see resolveSvgImage). Bytes that are no readable
// image would otherwise fail deep inside packaging. Like an unresolved asset they are not exported as a picture: the
// caller draws the preview's placeholder (or omits the picture) and one `unresolved-asset` diagnostic names the cause;
// `strictAssets` keeps the `unsupported-image-dimensions` error. `outcome.reported` tells a caller that the diagnostic
// was already emitted. `outcome.box` (inches, in) sizes an SVG's fallback raster; `outcome.svg` (out) carries the SVG to
// attach to the picture the caller adds. Local paths are read by PptxGenJS and checked after embedding.
async function resolveImage(asset, presentation, options, path, outcome = {}) {
  const resolved = await resolveImageSource(asset, presentation, options, path, outcome);
  // A local SVG file is read here (PptxGenJS cannot size it); a raster path is read by PptxGenJS itself.
  if (resolved?.path && /\.svg$/i.test(resolved.path)) {
    let file;
    try { file = await readLocalFile(resolved.path); }
    catch (error) {
      if (options.strictAssets) throw new OPFPptxError("invalid-svg-image", `The SVG file could not be read (${errorMessage(error)}).`, { path, reason: "svg-unreadable" });
      options.onDiagnostic?.({ code: "unresolved-asset", path, reason: "svg-unreadable", message: `The SVG file could not be read (${errorMessage(error)}). The image exports as the unavailable-image placeholder.` });
      outcome.reported = true;
      return null;
    }
    return resolveSvgImage(file, options, path, outcome);
  }
  // opf-pptx#210: a local raster PptxGenJS cannot read used to fail the whole export (pptxgen-failed) on every picture path.
  // It is unresolved like any other source: the placeholder (or the path's own fallback) and one diagnostic.
  if (resolved?.path && !(await localFileReadable(resolved.path))) {
    if (options.strictAssets) throw new OPFPptxError("missing-asset", "The local image file could not be read.", { path, src: resolved.path, reason: "file-unreadable" });
    options.onDiagnostic?.({ code: "unresolved-asset", path, reason: "file-unreadable", message: "The local image file could not be read; the image exports as the unavailable-image placeholder (or the picture's fallback)." });
    outcome.reported = true;
    return null;
  }
  if (!resolved?.data) return resolved;
  const bytes = dataUriBytes(resolved.data);
  const raster = bytes && rasterMetadata(bytes);
  // A raster declared as another type (for example a host that resolves an SVG asset to PNG bytes) is embedded as the
  // raster it is. PptxGenJS treats an image/svg+xml data URI as an SVG picture and adds its own fallback, a broken-image
  // placeholder in Node (pptxgenjs-plus; PptxGenJS 4.0.1 pointed the svgBlip at the raster itself).
  if (raster) return dataUriMediaType(resolved.data) === raster.mediaType ? resolved : {...resolved, data: `data:${raster.mediaType};base64,${bytesToBase64(bytes)}`};
  const svg = svgDataUriBytes(resolved.data);
  if (svg) return resolveSvgImage(svg, options, path, outcome);
  const message = `The image is not a readable PNG, JPEG, GIF or WebP (${dataUriMediaType(resolved.data) ?? "unknown type"}); supply a raster through imageResolver (for example opf-render toPng).`;
  if (options.strictAssets) throw new OPFPptxError("unsupported-image-dimensions", `Image fitting requires readable PNG, JPEG, GIF or WebP dimensions. ${message}`, { path });
  options.onDiagnostic?.({ code: "unresolved-asset", path, reason: "unsupported-format", message });
  outcome.reported = true;
  return null;
}

// An SVG picture is PowerPoint 2016's native form: the SVG itself (sanitized, never executed or fetched) plus a PNG
// fallback raster drawn from it at 192 dpi of the displayed size by options.svgRasterizer (default: opf-render's resvg,
// deterministic, with its bundled fonts). The caller adds the PNG as the picture and attaches `outcome.svg` at packaging.
// A malformed SVG, an SVG without an intrinsic size or without a rasterizer exports like any unreadable image.
async function resolveSvgImage(source, options, path, outcome) {
  const unresolved = (code, reason, message) => {
    if (options.strictAssets) throw new OPFPptxError(code, message, { path, reason });
    options.onDiagnostic?.({ code: "unresolved-asset", path, reason, message: `${message} The image exports as the unavailable-image placeholder.` });
    outcome.reported = true;
    return null;
  };
  if (source.error) return unresolved("invalid-svg-image", "svg-malformed", source.error);
  const prepared = prepareSvg(source);
  if (prepared.error) return unresolved("invalid-svg-image", prepared.error.reason, prepared.error.message);
  if (prepared.removed.length) {
    options.onDiagnostic?.({ code: "svg-sanitized", path, message: `The SVG had ${prepared.removed.join(", ")} removed before it was embedded: an exported SVG never runs code or refers to anything outside the file.` });
  }
  const scale = svgRasterScale(prepared, outcome.box, outcome.cover === true);
  const width = Math.max(1, Math.round(prepared.width * scale)), height = Math.max(1, Math.round(prepared.height * scale));
  const cacheKey = `${scale}|${prepared.text}`;
  let png = options.svgRasters.get(cacheKey);
  if (!png) {
    try {
      const rasterize = options.svgRasterizer ?? ((svg, hint) => svgToPng(svg, hint));
      png = await rasterize(prepared.text, { width, height, scale, text: prepared.hasText });
      if (!(png instanceof Uint8Array) || rasterMetadata(png)?.mediaType !== "image/png") throw Object.assign(new Error("The rasterizer did not return a PNG."), { code: "svg-render-failed" });
    } catch (error) {
      const reason = error?.code === "svg-rasterizer-unavailable" ? "svg-rasterizer-unavailable" : "svg-render-failed";
      return unresolved(reason, reason, reason === "svg-rasterizer-unavailable"
        ? `An SVG image needs a rasterizer for its PNG fallback: install the optional peer @openpresentation/opf-render${typeof error.install === "string" ? ` and its PNG converter (\`${error.install}\`)` : ""}, or pass options.svgRasterizer (or an imageResolver that returns a raster).`
        : `The SVG image could not be rasterized for its PNG fallback (${errorMessage(error)}).`);
    }
    options.svgRasters.set(cacheKey, png);
  }
  outcome.svg = { bytes: prepared.bytes, width: prepared.width, height: prepared.height };
  return { data: `data:image/png;base64,${bytesToBase64(png)}` };
}

function dataUriMediaType(uri) {
  return /^data:([^;,]+)/i.exec(uri)?.[1]?.toLowerCase();
}

// Only base64 data URIs carry bytes the exporter can read; any other encoding is not a readable raster.
function dataUriBytes(uri) {
  const match = /^data:[^,]*;base64,/i.exec(uri);
  if (!match) return null;
  try {
    if (typeof Buffer !== "undefined") return new Uint8Array(Buffer.from(uri.slice(match[0].length), "base64"));
    const binary = atob(uri.slice(match[0].length));
    return Uint8Array.from(binary, char => char.charCodeAt(0));
  } catch {
    return null;
  }
}

async function resolveImageSource(asset, presentation, options, path, outcome = {}) {
  const assetObject = dereferenceAsset(asset, presentation, path);
  const src = typeof assetObject === "string" ? assetObject : assetObject?.src;
  if (!src) {
    if (options.strictAssets) {
      throw new OPFPptxError("missing-asset", "Image asset is missing a source.", { path });
    }
    return null;
  }

  let resolvedByHost = null;
  if (options.imageResolver) {
    try { resolvedByHost = await options.imageResolver(src, { asset: assetObject, presentation, path }); }
    catch (error) {
      // RR-97: a resolver that throws (the CLI's does for an image it cannot read) is an unresolved image, not a failed export: the
      // picture's own fallback and one `unresolved-asset` warning that carries the resolver's message. A cancelled export and an
      // exporter error still propagate, and `strictAssets` turns the failure into a `missing-asset` error.
      if (error instanceof OPFPptxError || error?.name === "AbortError") throw error;
      const cause = errorMessage(error).trim();
      if (options.strictAssets) throw new OPFPptxError("missing-asset", cause || "The imageResolver could not read the image.", { path, src, reason: "resolver-failed" });
      options.onDiagnostic?.({ code: "unresolved-asset", path, reason: "resolver-failed", message: `${cause ? `${/[.!?]$/.test(cause) ? cause : `${cause}.`} ` : "The imageResolver could not read the image. "}The image was left out of the export; the preview's fallback is exported instead (the unavailable-image placeholder, the slide background color, the character bullets, or no watermark).` });
      outcome.reported = true;
      return null;
    }
  }
  if (resolvedByHost) return normalizeResolvedImage(resolvedByHost, assetObject);

  if (src.startsWith("data:")) return { data: src };
  if (/^https?:\/\//i.test(src)) {
    if (options.strictAssets) {
      throw new OPFPptxError("unsupported-asset", "Remote image assets require an imageResolver; network fetch is not used.", {
        path,
        src
      });
    }
    return null;
  }
  if (src.startsWith("asset:")) {
    if (options.strictAssets) {
      throw new OPFPptxError("missing-asset", "Image asset reference could not be resolved.", { path, src });
    }
    return null;
  }

  const pathValue = options.baseDir && !isAbsolutePath(src) ? joinPath(options.baseDir, src) : src;
  return { path: pathValue };
}

function normalizeResolvedImage(value, asset) {
  if (typeof value === "string") {
    if (value.startsWith("data:")) return { data: value };
    return { path: value };
  }
  if (value instanceof Uint8Array) {
    const mediaType = asset?.mediaType ?? "image/png";
    return { data: `data:${mediaType};base64,${bytesToBase64(value)}` };
  }
  if (value && typeof value === "object") {
    if (typeof value.data === "string") return { data: value.data };
    if (value.data instanceof Uint8Array) {
      const mediaType = value.mediaType ?? asset?.mediaType ?? "image/png";
      return { data: `data:${mediaType};base64,${bytesToBase64(value.data)}` };
    }
    if (typeof value.path === "string") return { path: value.path };
  }
  throw new OPFPptxError("invalid-image-resolution", "imageResolver must return a data URI, path, Uint8Array, or { data | path } object.");
}

function dereferenceAsset(asset, presentation, path, seen = new Set()) {
  const source = typeof asset === "string" ? asset : asset?.src;
  if (typeof source === "string" && source.startsWith("asset:")) {
    const id = source.slice("asset:".length);
    if (seen.has(id)) {
      throw new OPFPptxError("invalid-asset-reference", "Circular asset reference detected.", { path, assetId: id });
    }
    seen.add(id);
    const target = presentation.assets?.[id];
    if (!target) return asset;
    return dereferenceAsset(target, presentation, path, seen);
  }
  return asset;
}

// PptxGenJS writes its own stand-in (`preencoded.png`, or the local file path) as the picture's description when it is
// given no alt text. The package writes only what the document authored: the alt text as `descr`, and a distinct asset
// `title` as the native `title` attribute (a picture's tooltip and Alt Text title).
function pictureText(alt, asset, presentation) {
  const resolved = dereferenceAsset(asset, presentation, "asset-title");
  const title = isPlainObject(resolved) && typeof resolved.title === "string" && resolved.title && resolved.title !== alt ? resolved.title : undefined;
  return { alt: typeof alt === "string" && alt ? alt : undefined, title: alt ? title : undefined };
}

function writePictureText(picture, text) {
  const escapes = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;", "\r": "&#13;", "\n": "&#10;", "\t": "&#9;" };
  const escape = value => value.replace(/[&<>"'\r\n\t]/g, char => escapes[char]);
  return picture.replace(/<p:cNvPr\b([^>]*?)(\/?)>/, (tag, attributes, close) => {
    attributes = attributes.replace(/\sdescr="[^"]*"/, "").replace(/\stitle="[^"]*"/, "");
    return `<p:cNvPr${attributes}${text.alt ? ` descr="${escape(text.alt)}"` : ""}${text.title ? ` title="${escape(text.title)}"` : ""}${close}>`;
  });
}

function assetAlt(asset, presentation) {
  const resolved = dereferenceAsset(asset, presentation, "asset-alt");
  if (resolved && typeof resolved === "object" && !Array.isArray(resolved)) {
    return resolved.alt ?? resolved.title ?? resolved.description;
  }
  return undefined;
}

function referenceId(reference) {
  if (typeof reference === "string") return reference;
  if (isPlainObject(reference) && typeof reference.id === "string") return reference.id;
  return null;
}

// A solid color or pattern background color is a ColorRef (hex, `var:` variable, colour-scheme slot or role), resolved
// as for table fills and run colours. Roles resolve through the colour scheme alone: the background cannot depend on itself.
// A background that is one color: a color string, a theme slot, or a solid fill (not a picture, gradient or pattern).
function isSingleColorBackground(value) {
  if (value === undefined || value === null) return true;
  if (typeof value === 'string') return true;
  return isPlainObject(value) && (value.type === 'solid' || value.type === 'theme');
}

function resolveBackgroundColorRef(entry, colorScheme, variables = {}) {
  return resolveColorRefValue(entry, {colorScheme, colors: {}, variables});
}

function resolveBackground(value, colorScheme, variables = {}) {
  const fallback = "FFFFFF";
  const reference = entry => normalizeHex(resolveBackgroundColorRef(entry, colorScheme, variables) ?? entry, fallback);
  if (typeof value === "string") {
    if (value.startsWith("#")) return normalizeHex(value, fallback);
    return normalizeHex(colorScheme[value] ?? defaultSlideBackground(colorScheme), fallback);
  }
  if (isPlainObject(value)) {
    if (value.type === "solid" && value.color) return reference(value.color);
    if (value.type === "theme" && value.slot) {
      return normalizeHex(colorScheme[value.slot] ?? defaultSlideBackground(colorScheme), fallback);
    }
    // Like the SVG preview, text contrast follows a pattern's background color.
    if (value.type === "pattern") return reference(value.pattern?.backgroundColor ?? "#FFFFFF");
    if (value.backgroundColor) return normalizeHex(value.backgroundColor, fallback);
  }
  return normalizeHex(defaultSlideBackground(colorScheme), fallback);
}

function normalizeHex(value, fallback = "000000") {
  if (typeof value !== "string") return fallback.replace(/^#/, "").toUpperCase().slice(0, 6);
  const raw = value.trim().replace(/^#/, "");
  if (/^[0-9a-fA-F]{3}$/.test(raw)) {
    return raw.split("").map((char) => char + char).join("").toUpperCase();
  }
  if (/^[0-9a-fA-F]{6,8}$/.test(raw)) {
    return raw.slice(0, 6).toUpperCase();
  }
  return fallback.replace(/^#/, "").toUpperCase().slice(0, 6);
}

// The master, layout and notes master half of the native header/footer (RR-11): placeholders and p:hf on the finished parts.
// Every deck gets them (flags off when no slide uses a type), so Insert > Header & Footer works on a deck with no footer too.
function writeNativeFurnitureMasters(output, context) {
  const size = /<p:sldSz\b[^>]*\bcx="(\d+)"[^>]*\bcy="(\d+)"/.exec(decodeText(output['ppt/presentation.xml'][0]));
  const defaults = new Map((context.defaultFooterOptions ? defaultFooterParts(context.defaultFooterOptions) ?? [] : []).flatMap(part => {
    const ph = nativePlaceholderForPart(part);
    const geometry = ph && defaultPlaceholderGeometry(part);
    return geometry ? [[ph, geometry]] : [];
  }));
  // RR-102: the master placeholders where core draws each part in the deck's footer; a deck whose footer has a current date gives
  // the master and layout date its field (its pattern and language), so a date turned on in the dialog is OPF's (a deck without
  // one keeps PowerPoint's datetimeFigureOut); the notes pages repeat the slides' footer text and date.
  const options = context.defaultFooterOptions, dateFormat = deckDateFormat(deckFooter(options?.presentation));
  const composed = options ? masterFooterGeometry(options, {staticNumbers: context.staticSlideNumbers, dateFormat}) : undefined;
  // The notes pages repeat what the slides draw: the first slide footer text and date that are PowerPoint placeholders.
  const footerPart = context.nativeParts.get('ftr'), datePart = context.nativeParts.get('dt');
  const liveDate = datePart?.fields?.find(entry => entry.type === 'date');
  const liveField = liveDate ? nativeDateField(liveDate.format ?? DEFAULT_DATE_FORMAT, context.deckLang) : null;
  const dateField = liveField ? {type: liveField.type, ownLang: liveField.lang !== context.deckLang} : undefined;
  const notes = {footer: footerPart?.text, date: datePart && (dateField ? {text: datePart.text, ...dateField} : {text: datePart.text})};
  const info = {used: context.nativePlaceholders.used, first: context.nativePlaceholders.first, names: new Set(context.nativeFurniture.keys()), defaults,
    geometry: composed?.geometry, dateField, notes,
    slideSize: {width: size ? Number(size[1]) : 12192000, height: size ? Number(size[2]) : 6858000}, dateText: nativeDateText(context.hostDate, liveField ? dateFormatOfField(liveField.type, liveField.lang) : undefined)};
  const paths = Object.keys(output);
  try {
    // The placeholders carry the deck's language and direction like every other generated part (partScriptFonts is idempotent).
    const written = (path, bytes) => { output[path] = [context.scriptFonts ? encodeText(partScriptFonts(path, decodeText(bytes), context.scriptFonts, 0)) : bytes, output[path][1]]; };
    writeNativeMasters(paths, path => output[path][0], written, info);
  } catch (error) {
    throw new OPFPptxError('packaging-failed', 'Native header/footer placeholders could not be written.', {cause: errorMessage(error)});
  }
}

async function normalizePptxZip(raw, context) {
  let entries;
  try {
    // RR-17: the pptxgenjs-plus output changes opf-pptx does not take (src/vendor-compat.js).
    entries = legacyVendorOutput(unzipSync(raw));
  } catch (error) {
    throw new OPFPptxError("packaging-failed", "Generated PPTX could not be read back as a ZIP.", {
      cause: errorMessage(error)
    });
  }

  // RR-96: slide colors that are scheme colors become schemeClr first, so every fingerprint of a shape's properties (card frames, picture
  // manifests) records the final XML.
  for (const path of Object.keys(entries)) {
    const match = /^ppt\/slides\/slide(\d+)\.xml$/.exec(path), entry = match && context.slideSchemeColors[Number(match[1]) - 1];
    if (entry) entries[path] = encodeText(writeSchemeColors(decodeText(entries[path]), entry.table, entry.keep));
  }
  attachScrims(entries, context.scrims);
  attachCodeTags(entries, context.codeTags);
  attachMetricTags(entries,context.metricTags,context.metricDescriptions);
  attachCardTags(entries,context.cardTags);
  attachMediaTags(entries,context.mediaTags);
  attachHeadingTags(entries,context.headingTags);
  attachPlainTextTags(entries,context.plainTextTags);
  attachTimelineTags(entries,context.timelineTags);
  attachImageCalloutTags(entries,context.imageCalloutTags);
  attachChartMarkTags(entries,context.chartMarkTags);
  attachStepTags(entries,context.stepTags);
  // SH-09: the trapezoids' adjustments, the arrangement shapes' tags, then each tagged SmartArt placeholder becomes its frame and parts.
  writeArrangementAdjustments(entries,context.arrangementTags);
  attachArrangementTags(entries,context.arrangementTags,context.smartArtTags);
  try{attachSmartArt(entries,context.smartArt);}catch(error){throw new OPFPptxError('packaging-failed',`SmartArt parts could not be attached: ${errorMessage(error)}`);}
  attachIconTags(entries,context.iconTags);
  attachTitleRuleTags(entries,context.titleRuleTags);
  attachQuoteTags(entries,context.quoteTags);
  attachAnnotationTags(entries,context);
  attachFurnitureFields(entries,context.furnitureFields);
  attachFurnitureTags(entries,context.furnitureTags,context.furnitureManifests);
  // RR-11: the recorded footer shapes become PowerPoint's date, footer and slide-number placeholders.
  context.nativePlaceholders = attachNativePlaceholders(entries,context.nativeFurniture,context.nativeFurnitureBands,context.footerText);
  // The "Image unavailable" panel of an unresolved logo: identity only, so import does not read it as content.
  attachTextTags(entries,context.logoPlaceholderTags,LOGO_TAG,'opfLogoPlaceholder','logo placeholder');
  // opf-pptx#221: the image block of an unavailable-image placeholder, on its panel (full provenance).
  attachTextTags(entries,context.imagePlaceholderTags,IMAGE_PLACEHOLDER_TAG,'opfImagePlaceholder','image placeholder');
  for(const [part,bytes]of Object.entries(entries)){
    if(!/^ppt\/slides\/slide\d+\.xml$/.test(part))continue;
    const relationships=parseRelationships(entries,part);
    for(const [frame]of decodeText(bytes).matchAll(/<p:graphicFrame>[\s\S]*?<\/p:graphicFrame>/g)){
      const name=frame.match(/<p:cNvPr\b[^>]*\bname="([^"]+)"/)?.[1];
      if(!context.chartHeadings.has(name))continue;
      const id=frame.match(/<c:chart\b[^>]*\br:id="([^"]+)"/)?.[1],chartPart=relationships.get(id)?.path;
      if(!chartPart)throw new OPFPptxError('packaging-failed','Generated chart relationship is missing.');
      const {heading,labelColor,markLabelColor,spec,textSize,layerLayout}=context.chartHeadings.get(name);
      if(heading!==undefined)writeChartCategoryHeading(entries,chartPart,heading);
      // LH-81: the header caption, legend and plot area at the positions core gave them.
      if(layerLayout)entries[chartPart]=encodeText(applyChartLayerLayout(decodeText(entries[chartPart]),layerLayout));
      entries[chartPart]=encodeText(omitEmptyNumberPoints(applyDoughnutRings(applyChartConstruct(decodeText(entries[chartPart]),spec),context.chartHeadings.get(name).rings)));
      const highlight=context.chartHeadings.get(name).highlight;
      if(highlight){
        try{entries[chartPart]=encodeText(applyChartHighlight(decodeText(entries[chartPart]),highlight));}
        catch(error){throw new OPFPptxError('packaging-failed',`Chart highlight could not be written: ${errorMessage(error)}`);}
      }else{
        // RR-89: series that keep a theme accent (or a chart.colors scheme slot) are written as theme colours.
        const {palette,paletteSchemes,circular}=context.chartHeadings.get(name);
        if(paletteSchemes)entries[chartPart]=encodeText(applyChartSchemeColors(decodeText(entries[chartPart]),palette,paletteSchemes,{circular}));
      }
      // PptxGenJS hardcodes a black fallback in pie/doughnut label properties.
      // Normalize only our generated chart text styles; point/series fills stay intact.
      entries[chartPart]=encodeText(decodeText(entries[chartPart]).replace(/<c:txPr>[\s\S]*?<\/c:txPr>/g,properties=>properties.replace(/<a:solidFill>[\s\S]*?<\/a:solidFill>/g,()=>`<a:solidFill><a:srgbClr val="${labelColor}"/></a:solidFill>`)));
      entries[chartPart]=encodeText(applyChartTextSize(decodeText(entries[chartPart]),textSize));
      // RR-35: data labels last, so their own text colours (contrast inside a mark) are not normalized away.
      const {options:chartOptions,kind:optionKind,pointCount}=context.chartHeadings.get(name);
      // LH-92: a pie drawn as nested rings (LH-60) labels inside its rings, as a doughnut does: no c:dLblPos (a doughnut has none) and the
      // colour that contrasts with each slice, as the preview draws them.
      const ringed=optionKind==='pie'&&/<c:doughnutChart>/.test(decodeText(entries[chartPart]));
      if(chartOptions?.dataLabels)entries[chartPart]=encodeText(applyDataLabels(decodeText(entries[chartPart]),{resolved:ringed?{...chartOptions,dataLabels:{...chartOptions.dataLabels,position:null}}:chartOptions,kind:ringed?'doughnut':optionKind,palette:context.chartPalettes.get(name),labelColor:markLabelColor,font:context.chartFonts.get(name)?.body??'Arial',textSize,pointCount,highlight}));
      // LH-109: the segment values that do not fit their segments are hidden, point by point.
      const {stackValues}=context.chartHeadings.get(name);
      if(stackValues&&chartOptions?.dataLabels)entries[chartPart]=encodeText(applyStackValueDeletes(decodeText(entries[chartPart]),stackValues));
      // LH-125: an edge-to-edge stacked area: its categories stand on the tick marks, the first and last on the plot's edges.
      if(context.chartHeadings.get(name).stackEdge)entries[chartPart]=encodeText(decodeText(entries[chartPart]).replace(/<c:crossBetween val="between"\/>/g,'<c:crossBetween val="midCat"/>'));
      // LH-92: each ring of a nested-ring doughnut names its series on the slice core chose, after the data labels it may join.
      const {ringNames,palette:slicePalette}=context.chartHeadings.get(name);
      if(ringNames)entries[chartPart]=encodeText(applyRingLabels(decodeText(entries[chartPart]),ringNames,{labels:chartOptions?.dataLabels,fills:series=>highlight?.pointFills(series)??Array.from({length:pointCount},(_,row)=>slicePalette[row%slicePalette.length]),labelColor:markLabelColor,size:textSize,font:context.chartFonts.get(name)?.body??'Arial'}));
      // LH-105: the series names at the line ends and the category names on the slices, in place of a legend (src/chart-direct-labels.js).
      const {endLabels,sliceLabels}=context.chartHeadings.get(name);
      if(endLabels)entries[chartPart]=encodeText(applyEndLabels(decodeText(entries[chartPart]),{...endLabels,size:textSize,font:context.chartFonts.get(name)?.body??'Arial'}));
      if(sliceLabels)entries[chartPart]=encodeText(applySliceLabels(decodeText(entries[chartPart]),{labels:sliceLabels.labels,fills:highlight?.pointFills(0)??Array.from({length:pointCount},(_,row)=>slicePalette[row%slicePalette.length]),labelColor:markLabelColor,size:textSize,font:context.chartFonts.get(name)?.body??'Arial'}));
      // RR-54: the columns' number formats, after the labels: caches, label and value-axis formats, then the workbook cells.
      const numberFormats=context.chartHeadings.get(name).numberFormats;
      if(numberFormats){
        entries[chartPart]=encodeText(applyChartNumberFormats(decodeText(entries[chartPart]),numberFormats));
        try{writeChartWorkbookFormats(entries,chartPart,numericRanges(decodeText(entries[chartPart]),numberFormats));}
        catch(error){throw new OPFPptxError('packaging-failed',`Chart workbook number formats could not be written: ${errorMessage(error)}`);}
      }
    }
  }
  // opf-pptx#175: after every chart rewrite, each classic series in its CT_*Ser sequence (src/chart-order.js).
  for(const part of Object.keys(entries)){
    if(!/^ppt\/charts\/chart\d+\.xml$/.test(part))continue;
    const xml=decodeText(entries[part]),ordered=orderChartSeries(xml);
    if(ordered!==xml)entries[part]=encodeText(ordered);
  }
  applyChartFonts(entries,context.chartFonts,parseRelationships);
  // LH-81: PptxGenJS copies a chart title onto its frame's cNvPr as the alt-text title; the header caption is the chart's own text, not
  // the frame's alt text, so the frame keeps only its name and descr (FA-09).
  for (const [part, bytes] of Object.entries(entries)) {
    if (!/^ppt\/slides\/slide\d+\.xml$/.test(part)) continue;
    const xml = decodeText(bytes), next = xml.replace(/(<p:cNvPr\b[^>]*?\bname="([^"]+)"[^>]*?)\s+title="[^"]*"/g, (match, head, name) => context.chartHeadings.get(name)?.layerLayout?.title ? head : match);
    if (next !== xml) entries[part] = encodeText(next);
  }
  if (context.frameAlts.size) for (const [part, bytes] of Object.entries(entries)) if (/^ppt\/slides\/slide\d+\.xml$/.test(part)) { const xml = decodeText(bytes), next = applyFrameAlt(xml, context.frameAlts); if (next !== xml) entries[part] = encodeText(next); }
  // Chartex charts: the native cx:chartSpace part, its style parts and the mc:AlternateContent frame (the classic chart above is the fallback).
  try {
    attachChartexParts(entries, context.chartex, parseRelationships);
  } catch (error) {
    throw new OPFPptxError('packaging-failed', `Chartex chart parts could not be attached: ${errorMessage(error)}`);
  }
  applyPitchFamilies(entries,context.fontPitch);
  // Native PowerPoint sections (p14:sectionLst) from slide `section` labels, written whatever the provenance option.
  if (context.sections.some(section => section !== undefined)) {
    try { entries['ppt/presentation.xml'] = encodeText(writeSectionList(decodeText(entries['ppt/presentation.xml']), context.sections)); }
    catch (error) { throw new OPFPptxError('packaging-failed', 'Section list could not be written.', {cause: errorMessage(error)}); }
  }
  const imageSources = new Map();
  for (const [part, bytes] of Object.entries(entries)) {
    if (!/^ppt\/slides\/slide\d+\.xml$/.test(part)) continue;
    const relationships = parseRelationships(entries, part);
    for (const [picture] of decodeText(bytes).matchAll(/<p:pic>[\s\S]*?<\/p:pic>/g)) {
      const name = picture.match(/<p:cNvPr\b[^>]*\bname="([^"]+)"/)?.[1];
      const placement = context.images.get(name) ?? context.quotePhotos.get(name) ?? (name === watermarkName() ? context.watermarks.get(part) : name === logoName() ? context.logos.get(part) : undefined);
      const id = picture.match(/<a:blip\b[^>]*r:embed="([^"]+)"/)?.[1];
      if (placement) imageSources.set(relationships.get(id)?.path, placement.path);
    }
    const background = context.backgroundFills.get(part)?.image;
    const backgroundId = background && decodeText(bytes).match(/<p:bg>[\s\S]*?<a:blip\b[^>]*r:embed="([^"]+)"/)?.[1];
    if (backgroundId) imageSources.set(relationships.get(backgroundId)?.path, background.path);
  }
  // SVG pictures: the media part, its relationship and the asvg:svgBlip extension beside the PNG fallback blip. Fitting then
  // uses the SVG's own proportions (the fallback raster only approximates them at integer pixels).
  // SH-07: each diagram written as shapes replaces the rectangle that stood in for it (before the diagram tags are attached).
  if (context.diagramGroups.size) for (const [part, bytes] of Object.entries(entries)) {
    if (!/^ppt\/slides\/slide\d+\.xml$/.test(part)) continue;
    const xml = decodeText(bytes), next = writeDiagramGroups(xml, context.diagramGroups);
    if (next !== xml) entries[part] = encodeText(next);
  }
  const svgSizes = attachSvgPictures(entries, context.svgPictures);
  // SH-16: each SmartArt fallback picture takes its frame's name, id and outline, and its OPF_SMARTART_V1 record in full provenance.
  try {
    attachSmartArtFallbacks(entries, context.smartArt, parseRelationships);
  } catch (error) {
    throw new OPFPptxError("packaging-failed", `SmartArt fallback pictures could not be attached: ${errorMessage(error)}`);
  }
  // Diagram pictures and placeholders carry OPF_DIAGRAM_V1 in full provenance (src/diagram-provenance.js): the picture's manifest
  // binds its geometry, blip fill and SVG part, so an edited or replaced picture imports as an ordinary picture.
  try {
    tagDiagrams(entries, context.diagramTags, parseRelationships);
  } catch (error) {
    throw new OPFPptxError("packaging-failed", `Diagram tags could not be attached: ${errorMessage(error)}`);
  }
  const imageMetadata = new Map();
  for (const [part, bytes] of Object.entries(entries)) {
    if (!part.startsWith('ppt/media/')) continue;
    let metadata = rasterMetadata(bytes);
    if (metadata && svgSizes.has(part)) metadata = {...metadata, ...svgSizes.get(part)};
    if (metadata?.mediaType === 'image/webp' && context.imageFormat === 'compatible') {
      // LH-29: the compatible PNG of an animated WebP (VP8X chunk with the animation flag) is its first frame.
      if (bytes.length > 20 && decodeText(bytes.subarray(12, 16)) === 'VP8X' && (bytes[20] & 0x02))
        context.reportDiagnostic?.({code: 'export-lossy', feature: 'image-animation', path: imageSources.get(part) ?? part, message: 'An animated WebP image exports as a still PNG of its first frame (images: compatible); export with images: preserve (--images preserve) to keep the animation for viewers that play WebP.'});
      try {
        if (metadata.width * metadata.height > 40_000_000) throw new Error('Image dimensions exceed the 40 megapixel conversion limit.');
        const png = await webpToPng(bytes);
        metadata = rasterMetadata(png);
        if (metadata?.mediaType !== 'image/png') throw new Error('The local decoder did not return a PNG.');
        entries[part] = png;
      } catch (error) {
        throw new OPFPptxError('image-conversion-failed', 'WebP could not be converted to a compatible PNG.', {path: imageSources.get(part) ?? part, cause: errorMessage(error)});
      }
    }
    imageMetadata.set(part, metadata);
  }
  // SH-02: a shape block's click link (a:hlinkClick in its p:cNvPr, with its slide's external hyperlink relationship).
  linkShapeBlocks(entries, context.shapeBlocks, {decode: decodeText, encode: encodeText});
  // Image pictures need the embedded dimensions (core's fitImage crops and pads them); document provenance (FF-32)
  // later records the placed frames as slide geometry evidence.
  try {
    placeImages(entries, context.images, context.imageOverlays, {
      metadataFor: (part, id) => imageMetadata.get(parseRelationships(entries, part).get(id)?.path), fitImage,
      finish: (part, xml) => { const slide = /^ppt\/slides\/slide(\d+)\.xml$/.exec(part), entry = slide && context.slideSchemeColors[Number(slide[1]) - 1]; return entry ? writeSchemeColors(xml, entry.table, entry.keep) : xml; },
      // The key of the bytes the package finally holds: the picture's orientation is normalized when the parts are written.
      mediaKeyFor: (part, id) => { const target = parseRelationships(entries, part).get(id)?.path, bytes = entries[target]; return bytes ? mediaKey(imageMetadata.get(target) ? normalizeImageOrientation(bytes, imageMetadata.get(target)) : bytes) : undefined; },
      fail: path => { throw new OPFPptxError("unsupported-image-dimensions", "Image fitting requires readable PNG, JPEG, GIF or WebP dimensions. Supply a supported raster image through imageResolver.", { path }); }
    });
  } catch (error) {
    if (error instanceof OPFPptxError) throw error;
    throw new OPFPptxError("packaging-failed", `Image pictures could not be placed: ${errorMessage(error)}`);
  }
  tagTextWatermarks(entries, context.textWatermarks);
  placeWatermarks(entries, context.watermarks, (part, id) => imageMetadata.get(parseRelationships(entries, part).get(id)?.path), path => {
    throw new OPFPptxError("unsupported-image-dimensions", "Image fitting requires readable PNG, JPEG, GIF or WebP dimensions. Supply a supported raster image through imageResolver.", { path });
  });
  placeLogos(entries, context.logos, (part, id) => imageMetadata.get(parseRelationships(entries, part).get(id)?.path), path => {
    throw new OPFPptxError("unsupported-image-dimensions", "Image fitting requires readable PNG, JPEG, GIF or WebP dimensions. Supply a supported raster image through imageResolver.", { path });
  });
  // A picture repeated across slides embeds once (after fitting, which needs each slide's own relationship).
  dedupeMedia(entries, imageMetadata, resolveRelationshipTarget);
  masterPictureBackground(entries, context, imageMetadata);
  // The media keys of the logo-reference pictures, now that the package holds its final media (src/furniture-provenance.js).
  stampFurnitureImageKeys(entries, context.furnitureManifests, context.furnitureImages, parseRelationships);
  // Charts and notes follow the language and fonts of the slide they belong to.
  context.partSlides = new Map();
  context.styleSlides = new Map();
  for (const part of Object.keys(entries)) {
    const slide = /^ppt\/slides\/slide(\d+)\.xml$/.exec(part);
    if (!slide) continue;
    context.partSlides.set(part, Number(slide[1]) - 1);
    for (const relationship of parseRelationships(entries, part).values()) {
      if (/\/(?:chart|chartEx|notesSlide)$/.test(relationship.type)) context.partSlides.set(relationship.path, Number(slide[1]) - 1);
      // The chart style and color style parts of a native chart take the scheme colors of their slide.
      if (/\/(?:chart|chartEx)$/.test(relationship.type) && entries[relationship.path]) {
        for (const related of parseRelationships(entries, relationship.path).values()) if (/\/chartStyle$/.test(related.type)) context.styleSlides.set(related.path, Number(slide[1]) - 1);
      }
    }
  }
  const output = {};
  const renameMaps = buildRenameMaps(Object.keys(entries));
  // The host may transform assets or supply a filename/MIME hint that no
  // longer matches its bytes. Native package metadata must describe the bytes.
  renameMaps.media = new Map();
  for (const [path, metadata] of imageMetadata) {
    if (!metadata) continue;
    const extension = metadata.mediaType.slice('image/'.length);
    const currentExtension = path.split('.').at(-1).toLowerCase();
    if (currentExtension === extension || (extension === 'jpeg' && currentExtension === 'jpg')) continue;
    const target = path.replace(/\.[^/.]+$/, `.${extension}`);
    if (target !== path && Object.hasOwn(entries, target)) throw new OPFPptxError('packaging-failed', 'Normalized image paths collide.', {path, target});
    renameMaps.media.set(path, target);
  }
  for (const path of Object.keys(entries).sort()) {
    const normalizedPath = normalizePartPath(path, renameMaps);
    const bytes = normalizePartBytes(path, entries[path], context, renameMaps, entries, imageMetadata);
    output[normalizedPath] = [bytes, {
      level: context.compressionLevel,
      mtime: context.zipDate
    }];
  }

  writeNativeFurnitureMasters(output, context);
  giveNotesMastersOwnThemes(output);
  // opf-pptx#168: one slide master and theme per script profile, so each slide's own East Asian / complex-script fonts
  // reach PowerPoint through its master's theme (runs name none, FF-05). One profile: no change.
  if (context.scriptFonts && output['ppt/theme/theme1.xml']) {
    const slideThemes = planSlideThemes(context.scriptFonts, decodeText(output['ppt/theme/theme1.xml'][0]));
    try {
      giveSlidesScriptMasters(output, slideThemes);
    } catch (error) {
      throw new OPFPptxError('packaging-failed', 'Slide masters for per-slide script fonts could not be written.', {cause: errorMessage(error)});
    }
    reportPerSlideNotesScriptFonts(context.scriptFonts, slideThemes);
  }
  // RR-81: one native slide layout per 0.19 template the slides use, under each slide's master, and the objects bound to its
  // placeholders (src/template-layouts.js). Before RR-72, which copies a slide's own layout for a furniture variant.
  if (context.templateSlides.some(Boolean) || context.deckTemplates?.length || context.automaticSlides.some(Boolean)) {
    try {
      writeTemplateLayouts(output, context.templateSlides, context.deckTemplates ?? [], context.placeholderBindings,
        (path, xml) => context.scriptFonts ? partScriptFonts(path, xml, context.scriptFonts, 0) : xml, {records: context.provenanceMode === 'full', automaticSlides: context.automaticSlides, masterColorMap: context.clrMap});
    } catch (error) {
      throw new OPFPptxError('packaging-failed', 'Native slide layouts for the layout templates could not be written.', {cause: errorMessage(error)});
    }
  }
  // RR-72: furniture drawn the same on several slides moves to the slide master or a layout (src/master-furniture.js).
  try {
    liftMasterFurniture(output, context.furnitureParts, diagnostic => context.reportDiagnostic?.(diagnostic));
  } catch (error) {
    throw new OPFPptxError('packaging-failed', 'Header and footer furniture could not be written to the slide master and layouts.', {cause: errorMessage(error)});
  }
  // LH-28: safe mode names the Office-safe family wherever a Latin text family is written (runs, bullets, the themes, charts),
  // after every other part rewrite and before the "Fonts Used" list is read from the parts.
  if (context.safeTypeface) {
    const latinFallback = {ea: context.scriptFonts?.deck?.sources?.eastAsian === 'latin', cs: context.scriptFonts?.deck?.sources?.complexScript === 'latin'};
    for (const path of Object.keys(output)) {
      if (!/^ppt\/.*\.xml$/.test(path)) continue;
      const xml = decodeText(output[path][0]), next = writeSafeTypefaces(xml, context.safeTypeface, {latinFallback});
      if (next !== xml) output[path] = [encodeText(next), output[path][1]];
    }
    // Composition already measured and named most families as their safe family; the pass above caught the rest. Each
    // authored family that was replaced is reported once (generic CSS families are engine defaults, not authored).
    for (const [family, safe] of [...context.safeTypeface.replaced].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) context.reportDiagnostic?.({code: 'typeface-replaced', path: '', family, replacement: safe,
      message: sameMetrics(family, safe)
        ? `${family} is written as ${safe}, which has the same character widths, so the text wraps as in the preview.`
        : `${family} is written as ${safe}, an Office-safe family on every Windows and macOS machine; the text was laid out with ${safe}'s widths, so its line breaks can differ from the preview drawn in ${family}.`});
  }
  finalizeFontsUsed(output);
  // Structural proofing records are needed even without full source provenance.
  const languageParts = Object.fromEntries(Object.entries(output).map(([path, [bytes]]) => [path, bytes]));
  attachNativeLanguageTags(languageParts);
  for (const [path, bytes] of Object.entries(languageParts)) output[path] = [bytes, {level: context.compressionLevel, mtime: context.zipDate}];
  // Document references record evidence from the final normalized parts.
  if (context.documentProvenance) {
    const parts = Object.fromEntries(Object.entries(output).map(([path, [bytes]]) => [path, bytes]));
    try {
      attachDocumentProvenance(parts, context.documentProvenance);
    } catch (error) {
      throw new OPFPptxError("packaging-failed", "Document provenance tags could not be attached.", {cause: errorMessage(error)});
    }
    // RR-54: chart and table data records (on the final chart parts, so their cache evidence is what import reads) and the
    // datasets map beside the document tag.
    if (context.provenanceMode === 'full') {
      try {
        attachDataProvenance(parts, {records: context.dataRecords, paths: context.dataRecordPaths, datasets: context.datasets, parseRelationships, report: context.reportDiagnostic});
      } catch (error) {
        throw new OPFPptxError("packaging-failed", "Chart and table data tags could not be attached.", {cause: errorMessage(error)});
      }
    }
    for (const [path, bytes] of Object.entries(parts)) output[path] = [bytes, {level: context.compressionLevel, mtime: context.zipDate}];
  }

  // Sort after chart/worksheet renaming; source counters can cross digit widths.
  const sortedOutput = Object.fromEntries(Object.keys(output).sort().map(path => [path, output[path]]));
  return stampGeneratedZip(zipSync(sortedOutput, {
    level: context.compressionLevel,
    mtime: context.zipDate
  }), context.zipDateStamp);
}

function preserveCarriageReturns(xml, textElements) {
  // Only our generated text content is rewritten. Escaped literal entity text
  // remains escaped, and XML formatting outside these elements is untouched.
  return xml.replace(/(<([\w:]+)\b[^>]*>)([^<]*)(<\/\2>)/g, (element, open, name, text, close) =>
    textElements.has(name) ? open + text.replace(/\r/g, '&#13;') + close : element);
}

const CORE_TEXT_ELEMENTS = new Set(['dc:title', 'dc:subject', 'dc:description', 'dc:creator']);

function preserveGeneratedNotes(xml, notes, path) {
  // PptxGenJS changes LF to CRLF. For authored CR, write the original text into
  // its one generated native notes body; nothing is retained in hidden tags.
  const text = notes.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;').replace(/\r/g, '&#13;');
  let bodies = 0, texts = 0;
  const output = xml.replace(/<p:sp\b[^>]*>[\s\S]*?<\/p:sp>/g, shape => {
    if (!/<p:ph\b[^>]*\btype="body"/.test(shape)) return shape;
    bodies++;
    return shape.replace(/(<a:t\b[^>]*>)[^<]*(<\/a:t>)/g, (_, open, close) => {
      texts++;
      return open + text + close;
    });
  });
  if (bodies !== 1 || texts !== 1) throw new OPFPptxError('packaging-failed', 'Generated notes must have one body text element.', {path});
  return output;
}

function normalizeCoreProperties(xml, timestamp) {
  return preserveCarriageReturns(xml, CORE_TEXT_ELEMENTS)
    .replace(/<dcterms:created xsi:type="dcterms:W3CDTF">[^<]*<\/dcterms:created>/g, `<dcterms:created xsi:type="dcterms:W3CDTF">${timestamp}</dcterms:created>`)
    .replace(/<dcterms:modified xsi:type="dcterms:W3CDTF">[^<]*<\/dcterms:modified>/g, `<dcterms:modified xsi:type="dcterms:W3CDTF">${timestamp}</dcterms:modified>`);
}

function normalizePartBytes(path, bytes, context, renameMaps, entries, imageMetadata) {
  if (imageMetadata.has(path)) return normalizeImageOrientation(bytes, imageMetadata.get(path));
  if (path.endsWith(".xlsx")) {
    return normalizeNestedZip(bytes, context);
  }
  if (path === "docProps/core.xml") {
    return encodeText(normalizePartReferences(normalizeCoreProperties(decodeText(bytes), context.timestamp), renameMaps));
  }
  if (isXmlPart(path)) {
    let xml=decodeText(bytes);
    if (context.notesWithCarriageReturns.has(path)) xml = preserveGeneratedNotes(xml, context.notesWithCarriageReturns.get(path), path);
    if (path === '[Content_Types].xml') {
      // PptxGenJS 4.0.1 emitted one slide-master override per slide even
      // though it created only the actual master parts (pptxgenjs-plus fixed
      // this, #1444). Omit any phantom master declaration without changing
      // any existing part or relationship.
      xml = xml.replace(/<Override PartName="\/(ppt\/slideMasters\/slideMaster\d+\.xml)"[^>]*\/>/g,
        (override, part) => Object.hasOwn(entries, part) ? override : '');
      // Explicit per-part types describe the actual bytes (PptxGenJS 4.0.1's
      // image/jpg default; pptxgenjs-plus writes image/jpeg).
      const overrides = [...imageMetadata].filter(([, metadata]) => metadata).map(([part, metadata]) =>
        `<Override PartName="/${part}" ContentType="${metadata.mediaType}"/>`).join('');
      xml = xml.replace('</Types>', `${overrides}</Types>`);
    }
    if (/^ppt\/slideMasters\/slideMaster\d+\.xml$/.test(path)) {
      // Name the generated master; PowerPoint's layout category also needs the default theme name. Script masters copy this label.
      xml = themeMasterBulletFonts(xml).replace(/<p:cSld\b([^>]*)>/, (_, attributes) =>
        `<p:cSld${attributes.replace(/\s+name="[^"]*"/, '')} name="pptx.gallery">`);
    }
    if (context.clrMap && /^ppt\/slideMasters\/slideMaster\d+\.xml$/.test(path)) xml = writeColorMap(xml, context.clrMap);
    if (context.masterBackground && path === 'ppt/slideMasters/slideMaster1.xml') xml = writeMasterBackground(xml, context.masterBackground);
    if (context.masterBackground && /^ppt\/slideLayouts\/slideLayout\d+\.xml$/.test(path)) xml = inheritLayoutBackground(xml);
    if (path === 'ppt/presentation.xml') xml = presentationInSchemaOrder(xml);
    if (path === 'ppt/theme/theme1.xml') xml = writeThemeColors(xml, {colors: context.themeColors, schemeName: context.schemeName, themeName: context.themeName});
    if (/^ppt\/slides\/slide\d+\.xml$/.test(path)) {
      xml = writeLinkSentinels(xml, context.linkSentinels);
      const override = context.clrMapOverrides.get(path);
      if (override) xml = xml.replace('<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>', `<p:clrMapOvr><a:overrideClrMapping${Object.entries(override).map(([role, slot]) => ` ${role}="${slot}"`).join('')}/></p:clrMapOvr>`);
      const fill = context.backgroundFills.get(path);
      if (typeof fill === 'string') xml = xml.replace(/<p:bg>[\s\S]*?<\/p:bg>/, `<p:bg><p:bgPr>${fill}<a:effectLst/></p:bgPr></p:bg>`);
      else if (fill?.image) {
        // Fit the exact raster PptxGenJS embedded for this slide background.
        const backgroundRelationships = parseRelationships(entries, path);
        xml = xml.replace(/<p:bg>[\s\S]*?<\/p:bg>/, background => {
          const id = background.match(/<a:blip\b[^>]*r:embed="([^"]+)"/)?.[1];
          const metadata = imageMetadata.get(backgroundRelationships.get(id)?.path);
          if (!id || !metadata) throw new OPFPptxError("unsupported-image-dimensions", "Background image fitting requires readable PNG, JPEG, GIF or WebP dimensions. Supply a supported raster image through imageResolver.", { path: fill.image.path });
          if ((metadata.orientation ?? 1) !== 1) fill.image.report?.({code: 'unsupported-background-image-orientation', path: fill.image.path, message: 'A slide background picture fill cannot rotate or mirror its image; the JPEG EXIF orientation is not applied in the native background.'});
          return `<p:bg><p:bgPr>${nativeImageBackgroundFill(id, metadata, {...fill.image, fitImage})}<a:effectLst/></p:bgPr></p:bg>`;
        });
      }
      // PptxGenJS table IDs can collide with other objects on the same slide.
      // Preserve existing IDs and allocate unused IDs only for duplicates. This
      // export path creates no connector attachments or animation ID references.
      const objectIds = [...xml.matchAll(/<p:cNvPr\b[^>]*\bid="(\d+)"/g)].map(match => Number(match[1]));
      let nextObjectId = Math.max(0, ...objectIds) + 1;
      const seenObjectIds = new Set();
      // SH-16: a SmartArt's fallback picture is the same object as its frame (mc:Fallback of the frame's mc:Choice) and keeps its id.
      xml = xml.replace(/(<p:cNvPr\b[^>]*\bid=")(\d+)(")|<mc:Fallback><p:pic>[\s\S]*?<\/mc:Fallback>/g, (node, before, rawId, after) => {
        if (before === undefined) return node;
        const id = Number(rawId);
        if (seenObjectIds.has(id)) return `${before}${nextObjectId++}${after}`;
        seenObjectIds.add(id);
        return node;
      });
      // PptxGenJS 4 has no firstRow option. Set the native flag explicitly so
      // viewers and later imports distinguish column labels from data rows.
      xml = xml.replace(/<p:graphicFrame>([\s\S]*?)<\/p:graphicFrame>/g, frame => {
        const name = frame.match(/name="(OPF table \d+)"/)?.[1];
        if (!context.tableHeaders.has(name)) return frame;
        frame = frame.replace('<a:tblPr/>', `<a:tblPr firstRow="${context.tableHeaders.get(name) ? 1 : 0}"/>`);
        const table = context.tableCells.get(name);
        if (!table) return frame;
        const anchors = table.layout.rows.flatMap(row => row.cells);
        const ownerAt = (row,column) => anchors.find(anchor => row >= anchor.row && row < anchor.row + anchor.rowSpan && column >= anchor.column && column < anchor.column + anchor.colSpan);
        let rowIndex = 0;
        return frame.replace(/<a:tr\b[^>]*>[\s\S]*?<\/a:tr>/g, rowXml => {
          const currentRow = rowIndex++;
          const cells = table.layout.rows[currentRow].cells;
          let column = 0;
          return rowXml.replace(/<a:tc\b[^>]*>[\s\S]*?<\/a:tc>/g, cellXml => {
            const currentColumn = column++;
            const cell = cells.find(cell => cell.column === currentColumn);
            const owner = cell ?? ownerAt(currentRow,currentColumn);
            if (!owner) return cellXml;
            // PowerPoint reads each physical continuation's perimeter border.
            // Anchor-only styling truncates dashes and restores hidden segments.
            const perimeter = {left:currentColumn === owner.column, right:currentColumn === owner.column + owner.colSpan - 1,
              top:currentRow === owner.row, bottom:currentRow === owner.row + owner.rowSpan - 1};
            const style = cell ? {...cell.style} : {borders:Object.fromEntries(Object.keys(perimeter).map(edge => [edge,perimeter[edge] ? owner.style?.borders?.[edge] ?? (edge === 'left' || edge === 'right' ? table.hiddenBorder : table.defaultBorder) : {color:'#000000',width:0}]))};
            style.borders = {...style.borders};
            // Native shared-edge precedence can let an implicit neighbor cover
            // an explicit merge border. Give both physical sides that border.
            for (const [edge,opposite,dr,dc] of [['left','right',0,-1],['right','left',0,1],['top','bottom',-1,0],['bottom','top',1,0]]) {
              if (!perimeter[edge] || style.borders[edge] || owner.rowSpan > 1 || owner.colSpan > 1) continue;
              const neighbor = ownerAt(currentRow+dr,currentColumn+dc);
              if (neighbor?.style?.borders?.[opposite]) style.borders[edge] = neighbor.style.borders[opposite];
            }
            cellXml = cellXml.replace(/<a:tcPr\b([^>]*)\/>/, '<a:tcPr$1></a:tcPr>');
            return cellXml.replace(/<a:tcPr\b([^>]*)>([\s\S]*?)<\/a:tcPr>/, (properties, attributes, contents) => {
              if (style.padding) {
                const padding = {top:8, right:10, bottom:4, left:10, ...style.padding};
                for (const [edge, key] of [['top','marT'],['right','marR'],['bottom','marB'],['left','marL']]) {
                  attributes = attributes.replace(new RegExp(` ${key}="[^"]*"`), '');
                  attributes += ` ${key}="${Math.round(padding[edge] * table.scale * 9525)}"`;
                }
              }
              for (const [edge, native] of [['left','lnL'],['right','lnR'],['top','lnT'],['bottom','lnB']]) {
                const border = style.borders?.[edge];
                if (!border) continue;
                const slideContext = table.context, borderHex = exportColor(border.color, slideContext, slideContext.colors.border);
                const borderOpacity = borderHex.length === 8 ? parseInt(borderHex.slice(6), 16) / 255 : 1;
                const borderScheme = borderOpacity === 1 ? schemeColorValue(border.color, borderHex, slideContext) : undefined;
                const fill = border.width === 0 ? '<a:noFill/>' : borderScheme ? `<a:solidFill><a:schemeClr val="${borderScheme}"/></a:solidFill>` : nativeBackgroundFill({type:'solid',color:'#' + borderHex.slice(0, 6), opacity: borderOpacity},{width:1,height:1}, slideContext.colors.border);
                const dash = {solid:'solid',dash:'dash',dot:'sysDot'}[border.dash ?? 'solid'];
                const line = `<a:${native} w="${Math.round(border.width * table.scale * 9525)}" cap="flat" cmpd="sng" algn="ctr">${fill}<a:prstDash val="${dash}"/></a:${native}>`;
                const existing = new RegExp(`<a:${native}\\b[^>]*>[\\s\\S]*?<\\/a:${native}>`);
                contents = existing.test(contents) ? contents.replace(existing, line) : contents + line;
              }
              return `<a:tcPr${attributes}>${contents}</a:tcPr>`;
            });
          });
        });
      });
      // Image data is already resolved and embedded by PptxGenJS. Read those
      // exact bytes instead of fetching or resolving the source a second time.
      const relationships = parseRelationships(entries, path);
      let bulletRelationship;
      xml = xml.replace(/<p:pic>([\s\S]*?)<\/p:pic>/g, picture => {
        if (picture.match(/<p:cNvPr\b[^>]*\bname="([^"]+)"/)?.[1] === bulletImageName()) {
          // Only its media part and relationship are wanted: every picture-bullet paragraph points at them (a:buBlip).
          bulletRelationship = picture.match(/<a:blip\b[^>]*r:embed="([^"]+)"/)?.[1];
          return '';
        }
        const text = context.pictureText.get(picture.match(/<p:cNvPr\b[^>]*\bname="([^"]+)"/)?.[1]);
        if (text) picture = writePictureText(picture, text);
        // Image pictures were placed with the slide's other pictures (placeImages); quote photos are fitted here.
        const placement = context.quotePhotos.get(picture.match(/name="(OPF quote photo \d+)"/)?.[1]);
        if (!placement) return picture;
        const id = picture.match(/<a:blip\b[^>]*r:embed="([^"]+)"/)?.[1];
        const dimensions = imageMetadata.get(relationships.get(id)?.path);
        if (!dimensions) throw new OPFPptxError("unsupported-image-dimensions", "Image fitting requires readable PNG, JPEG, GIF or WebP dimensions. Supply a supported raster image through imageResolver.", { path: placement.path });
        // LH-132: a portrait beside the quote crops around the focus core gave it (the upper third), as the preview does.
        const fitted = placement.focus ? pictureFrame(dimensions, { box: placement.region, fit: 'cover', focus: placement.focus }, fitImage) : pictureTransform(dimensions, placement.region, placement.mode);
        const emu = value => Math.round(value * EMUS_PER_INCH);
        const transformAttrs = `${fitted.rotation ? ` rot="${fitted.rotation * 60000}"` : ''}${fitted.flipH ? ' flipH="1"' : ''}${fitted.flipV ? ' flipV="1"' : ''}`;
        picture = picture.replace(/<a:xfrm\b[^>]*>[\s\S]*?<\/a:xfrm>/, `<a:xfrm${transformAttrs}><a:off x="${emu(fitted.x)}" y="${emu(fitted.y)}"/><a:ext cx="${emu(fitted.w)}" cy="${emu(fitted.h)}"/></a:xfrm>`);
        if (fitted.crop) {
          const attrs = Object.entries(fitted.crop).map(([key, value]) => `${key}="${value}"`).join(' ');
          picture = picture.replace('<a:stretch>', `<a:srcRect ${attrs}/><a:stretch>`);
        }
        // The circular headshot mask: the core frame's DrawingML preset (ellipse) instead of the rectangle; LH-132's portrait beside the
        // quote is a roundRect with core's corner (its adjust value).
        const adjust = Object.entries(placement.shape?.adjust ?? {}).map(([name, value]) => `<a:gd name="${name}" fmla="val ${value}"/>`).join('');
        if (placement.shape) picture = picture.replace(/<a:prstGeom\b[\s\S]*?<\/a:prstGeom>/, `<a:prstGeom prst="${placement.shape.preset}">${adjust ? `<a:avLst>${adjust}</a:avLst>` : '<a:avLst/>'}</a:prstGeom>`);
        return picture;
      });
      // SH-02: shape blocks take core's geometry, fill, line, style and text body (src/shape-blocks.js).
      xml=writeShapeBlocks(xml,context.shapeBlocks);
      // SH-04: connectors as native p:cxnSp glued to the shapes at their ends (src/connectors.js).
      xml=writeConnectors(xml,context.connectors);
      // Native bullets otherwise inherit the first rich run's size, font and
      // color, which can differ from the measured list marker.
      xml=xml.replace(/<p:sp>([\s\S]*?)<\/p:sp>/g,(shape)=>{
        const marker=context.listMarkers.get(shape.match(/name="(OPF list [^"]* line \d+)"/)?.[1]);
        if(!marker)return shape;
        if(marker.picture&&bulletRelationship)return shape.replace(/<a:buChar\b[^>]*\/>/g,`<a:buBlip><a:blip r:embed="${bulletRelationship}"/></a:buBlip>`);
        const family=marker.fontFamily.replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[char]));
        // RR-33: an auto-number takes the measured size, colour and family like a character bullet, and startAt only when it is not 1.
        const autoNumber=/<a:buSzPct val="100000"\/><a:buFont typeface="\+mj-lt"\/><a:buAutoNum type="([A-Za-z]+)" startAt="(\d+)"\/>/;
        if(autoNumber.test(shape))return shape.replace(autoNumber,(_,type,startAt)=>`<a:buClr>${solidColorXml(marker.color)}</a:buClr><a:buSzPts val="${Math.round(marker.fontSize*100)}"/><a:buFont typeface="${family}"/><a:buAutoNum type="${type}"${startAt==='1'?'':` startAt="${startAt}"`}/>`);
        return shape.replace(/<a:buSzPct val="100000"\/>/g,`<a:buClr>${solidColorXml(marker.color)}</a:buClr><a:buSzPts val="${Math.round(marker.fontSize*100)}"/><a:buFont typeface="${family}"/>`);
      });
      // PptxGenJS gives shapes no alternative text. An unavailable image's panel
      // carries the accessible name the preview gives its group.
      const escapes={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;','\r':'&#13;','\n':'&#10;','\t':'&#9;'};
      const describe=description=>description.replace(/[&<>"'\r\n\t]/g,char=>escapes[char]);
      xml=xml.replace(/<p:cNvPr id="(\d+)" name="(OPF image placeholder \d+)"(\/?)>/g,(node,id,name,close)=>{
        const description=context.imagePlaceholders.get(name);
        if(description===undefined)return node;
        // opf-pptx#221: a grouped placeholder's accessible name is on its group (below), as the preview names its <g>. The empty panel
        // then has no alt text of its own, so it is marked decorative (the adec:decorative extension, "Mark as decorative"), or
        // PowerPoint's Accessibility Checker flags it. The text lines carry text and are not marked. PptxGenJS writes this cNvPr self-closing.
        if(context.imagePlaceholderGroups.has(name))return close?writeFrameAlt(node,''):node;
        return `<p:cNvPr id="${id}" name="${name}" descr="${describe(description)}"${close}>`;
      });
      xml=groupImagePlaceholders(xml,context.imagePlaceholderGroups,name=>describe(context.imagePlaceholders.get(name)));
      // PptxGenJS 4.0.1 emitted pPr before each rich run (pptxgenjs-plus writes
      // one). OOXML allows one pPr, before all runs. Paragraph options belong
      // to the first run.
      xml=xml.replace(/<a:p>([\s\S]*?)<\/a:p>/g,(_,body)=>{
        let properties='';
        const content=body.replace(/<a:pPr\b[^>]*(?:\/>|>[\s\S]*?<\/a:pPr>)/g,node=>{properties ||= node;return '';});
        return `<a:p>${properties}${content}</a:p>`;
      });
      xml = nativeTitleAutofit(nativeBodyDefaults(xml, context.nativeBodies), context.nativeTitles);
    }
    // theme1.xml: FF-24 colors and names above, then FF-07 fonts here; they touch disjoint elements.
    // RR-96: literal colors that are scheme colors become schemeClr (with lumMod/lumOff for the derived neutrals).
    if (/^ppt\/(?:slides\/slide|charts\/chart(?:Ex)?|charts\/style)\d+\.xml$/.test(path)) {
      const index = context.partSlides.get(path) ?? context.styleSlides.get(path), entry = context.slideSchemeColors[index];
      // SH-02: with the derived colors of the slide's shape styles (addShapeItem).
      const shapeColors = context.shapeSchemeColors.get(index);
      if (entry) xml = writeSchemeColors(xml, shapeColors?.size ? new Map([...entry.table, ...[...shapeColors].filter(([hex]) => !entry.table.has(hex))]) : entry.table, entry.keep);
    } else if (/^ppt\/(?:slideMasters\/slideMaster|slideLayouts\/slideLayout)\d+\.xml$/.test(path)) xml = writeSchemeColors(xml, context.deckSchemeColors.table, context.deckSchemeColors.keep);
    if (context.scriptFonts) xml = partScriptFonts(path, xml, context.scriptFonts, context.partSlides.get(path) ?? 0);
    else if (/^ppt\/theme\/theme\d+\.xml$/.test(path)) xml = themeEastAsianFromLatin(xml);
    if (/^ppt\/(?:slides\/slide|notesSlides\/notesSlide)\d+\.xml$/.test(path)) xml = stripRunScriptFonts(xml);
    if (context.scriptFonts && /^ppt\/slides\/slide\d+\.xml$/.test(path)) xml = runLanguageFonts(xml, context.scriptFonts, context.partSlides.get(path) ?? 0);
    return encodeText(normalizePartReferences(xml, renameMaps));
  }
  return bytes;
}

// The vendored PptxGenJS master (4.0.1 and pptxgenjs-plus 4.3.4) hard-codes Arial as the bullet font on
// all nine bodyStyle levels, while each level's text already uses +mn-lt.
// Point those bullets at the same theme minor (body) font so a document's
// fontScheme also governs master bullets. a:buFont is CT_TextFont, like
// a:latin, so the theme reference is schema-valid. Slide list markers keep
// their explicit per-shape buFont; only the master bodyStyle is touched.
const VENDOR_MASTER_BULLET_FONT = '<a:buFont typeface="Arial" pitchFamily="34" charset="0"/>';
const THEME_MINOR_BULLET_FONT = '<a:buFont typeface="+mn-lt"/>';
// opf-pptx#221: each unavailable-image placeholder (panel, then its label lines or cross strokes, written consecutively) becomes
// one p:grpSp (CT_GroupShape: nvGrpSpPr, grpSpPr, members) named "<panel> group" with the accessible name as its descr. Its
// transform is the identity (chOff/chExt equal off/ext, the members' union), so every member keeps its box and stays an
// editable shape; tags and names stay on the members.
function groupImagePlaceholders(xml,panels,description){
  if(!panels.size)return xml;
  let next=Math.max(0,...[...xml.matchAll(/<p:cNvPr\b[^>]*\bid="(\d+)"/g)].map(match=>Number(match[1])))+1;
  const nameOf=shape=>shape.match(/<p:cNvPr\b[^>]*\bname="([^"]*)"/)?.[1]??'';
  const memberOf=(panel,name)=>name.startsWith(`${panel} `)&&/^(?:text line|icon) \d+$/.test(name.slice(panel.length+1));
  return xml.replace(/<p:sp>[\s\S]*?<\/p:sp>(?:<p:sp>[\s\S]*?<\/p:sp>)*/g,run=>{
    const shapes=run.match(/<p:sp>[\s\S]*?<\/p:sp>/g);
    let out='';
    for(let index=0;index<shapes.length;index++){
      const panel=nameOf(shapes[index]);
      if(!panels.has(panel)){out+=shapes[index];continue;}
      const members=[shapes[index]];
      while(index+1<shapes.length&&memberOf(panel,nameOf(shapes[index+1])))members.push(shapes[++index]);
      const boxes=members.map(shape=>shape.match(/<a:off x="(-?\d+)" y="(-?\d+)"\/><a:ext cx="(\d+)" cy="(\d+)"\/>/)).filter(Boolean).map(match=>match.slice(1).map(Number));
      if(!boxes.length){out+=members.join('');continue;}
      const x=Math.min(...boxes.map(box=>box[0])),y=Math.min(...boxes.map(box=>box[1]));
      const cx=Math.max(...boxes.map(box=>box[0]+box[2]))-x,cy=Math.max(...boxes.map(box=>box[1]+box[3]))-y;
      out+=`<p:grpSp><p:nvGrpSpPr><p:cNvPr id="${next++}" name="${imagePlaceholderGroupName(panel)}" descr="${description(panel)}"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>`+
        `<p:grpSpPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/><a:chOff x="${x}" y="${y}"/><a:chExt cx="${cx}" cy="${cy}"/></a:xfrm></p:grpSpPr>${members.join('')}</p:grpSp>`;
    }
    return out;
  });
}

function themeMasterBulletFonts(xml) {
  return xml.replace(/<p:bodyStyle>[\s\S]*?<\/p:bodyStyle>/, bodyStyle =>
    bodyStyle.split(VENDOR_MASTER_BULLET_FONT).join(THEME_MINOR_BULLET_FONT));
}

// FF-05: PptxGenJS (4.0.1 and pptxgenjs-plus 4.3.4) writes p:notesMasterIdLst after p:sldIdLst, but CT_Presentation is a sequence
// (sldMasterIdLst, notesMasterIdLst, handoutMasterIdLst, sldIdLst, sldSz, ...). PowerPoint reads the out-of-order
// list as no notes master and lists a default-theme font (Aptos) in Presentation.Fonts; schema order restores
// the exporter's own notes master. Only the list's position changes.
function presentationInSchemaOrder(xml) {
  const notes = /<p:notesMasterIdLst>[\s\S]*?<\/p:notesMasterIdLst>/.exec(xml)?.[0];
  if (!notes || xml.indexOf(notes) < xml.indexOf('</p:sldMasterIdLst>')) return xml;
  return xml.replace(notes, '').replace('</p:sldMasterIdLst>', `</p:sldMasterIdLst>${notes}`);
}

function isXmlPart(path) {
  return path.endsWith(".xml") || path.endsWith(".rels") || path === "[Content_Types].xml";
}

function buildRenameMaps(paths) {
  return {
    charts: numberedFilenameMap(paths, /^ppt\/charts\/chart(\d+)\.xml$/),
    worksheets: numberedFilenameMap(paths, /^ppt\/embeddings\/Microsoft_Excel_Worksheet(\d+)\.xlsx$/)
  };
}

function numberedFilenameMap(paths, pattern) {
  const ids = [...new Set(paths.flatMap((path) => {
    const match = pattern.exec(path);
    return match ? [Number(match[1])] : [];
  }))].sort((a, b) => a - b);
  return new Map(ids.map((id, index) => [String(id), String(index + 1)]));
}

function normalizePartPath(path, renameMaps) {
  return normalizePartReferences(renameMaps.media?.get(path) ?? path, renameMaps);
}

function normalizePartReferences(value, renameMaps) {
  let output = value;
  for (const [oldId, newId] of renameMaps.charts) {
    output = output.replace(new RegExp(escapeRegExp(`chart${oldId}.xml`), "g"), `chart${newId}.xml`);
  }
  for (const [oldId, newId] of renameMaps.worksheets) {
    output = output.replace(
      new RegExp(escapeRegExp(`Microsoft_Excel_Worksheet${oldId}.xlsx`), "g"),
      `Microsoft_Excel_Worksheet${newId}.xlsx`
    );
  }
  // Rewrite package references only, not user-visible text containing paths.
  output = output.replace(/\b(Target|PartName)="([^"]+)"/g, (attribute, name, value) => {
    const prefix = value.startsWith('../media/') ? '../' : value.startsWith('/ppt/media/') ? '/ppt/' : null;
    if (!prefix) return attribute;
    const part = 'ppt/' + value.slice(prefix.length);
    const target = renameMaps.media?.get(part);
    return target ? `${name}="${prefix}${target.slice('ppt/'.length)}"` : attribute;
  });
  return output;
}

function normalizeNestedZip(bytes, context) {
  // RR-17 (opf-pptx#162): valid table and dimension ranges, or Keynote drops the chart (see chart-workbook.js).
  const entries = repairChartWorkbookRanges(unzipSync(bytes));
  const output = {};
  for (const path of Object.keys(entries).sort()) {
    // A gap in the chart data is a blank workbook cell, not a numeric cell with an empty value. RR-54 (opf-pptx#172): the
    // engine writes a scatter (and bubble) X gap as `<v>${val}</v>`, so a null X value became `<v>null</v>`, a numeric cell
    // that is no number; it is a gap too. Zero values are kept as `<v>0</v>` (pptxgenjs-plus fixed the `values[idx] || ''`
    // of PptxGenJS 4.0.1, upstream issue #1430; test/chart-workbook-values.mjs).
    const entryBytes = path === "docProps/core.xml"
      ? encodeText(normalizeCoreProperties(decodeText(entries[path]), context.timestamp))
      : /^xl\/worksheets\/sheet\d+\.xml$/.test(path)
        ? encodeText(decodeText(entries[path]).replace(/<c ((?:r|s)="[^"]*"(?: (?:r|s)="[^"]*")*)><v>(?:null|undefined)?<\/v><\/c>/g, "<c $1/>"))
        : entries[path];
    output[path] = [entryBytes, {
      level: context.compressionLevel,
      mtime: context.zipDate
    }];
  }
  return stampGeneratedZip(zipSync(output, {
    level: context.compressionLevel,
    mtime: context.zipDate
  }), context.zipDateStamp);
}

// Explicit ZIP dates use UTC calendar fields. fflate clones mtime and reads
// local fields, so passing a Date cannot express this reliably (including DST
// gaps and skipped civil days). Leave the established default path unchanged.
function resolveZipDateStamp(value) {
  if (value === undefined) return null;
  const invalid = () => {
    throw new OPFPptxError('invalid-zip-date', 'zipDate must be a valid Date, finite epoch milliseconds, an ISO date, or an ISO datetime with Z/offset, within UTC years 1980–2099.', {path: 'options.zipDate'});
  };
  let time;
  if (typeof value === 'string') {
    const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?(Z|[+-]\d{2}:\d{2}))?$/.exec(value);
    if (!match) invalid();
    const [, year, month, day, hour = '00', minute = '00', second = '00', fraction = '', zone = 'Z'] = match;
    const parts = [year, month, day, hour, minute, second].map(Number);
    if (parts[1] < 1 || parts[1] > 12 || parts[2] < 1 || parts[3] > 23 || parts[4] > 59 || parts[5] > 59) invalid();
    const date = new Date(0);
    date.setUTCFullYear(parts[0], parts[1] - 1, parts[2]);
    date.setUTCHours(parts[3], parts[4], parts[5], Number(fraction.slice(0, 3).padEnd(3, '0')));
    if (date.getUTCFullYear() !== parts[0] || date.getUTCMonth() !== parts[1] - 1 || date.getUTCDate() !== parts[2]) invalid();
    const offsetHours = zone === 'Z' ? 0 : Number(zone.slice(1, 3));
    const offsetMinutes = zone === 'Z' ? 0 : Number(zone.slice(4, 6));
    if (offsetHours > 23 || offsetMinutes > 59) invalid();
    const offset = (offsetHours * 60 + offsetMinutes) * (zone[0] === '-' ? -1 : 1);
    time = date.getTime() - offset * 60000;
  } else if (typeof value === 'number') {
    time = value;
  } else {
    // The native brand check accepts cross-realm Dates without coercing objects.
    try { time = Date.prototype.getTime.call(value); } catch { invalid(); }
  }
  const date = new Date(time);
  const year = date.getUTCFullYear();
  if (!Number.isFinite(time) || !Number.isFinite(year) || year < 1980 || year > 2099) invalid();
  return (((year - 1980) << 25) | ((date.getUTCMonth() + 1) << 21) | (date.getUTCDate() << 16) |
    (date.getUTCHours() << 11) | (date.getUTCMinutes() << 5) | (date.getUTCSeconds() >> 1)) >>> 0;
}

function stampGeneratedZip(bytes, stamp) {
  if (stamp === null) return bytes;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const fail = () => { throw new OPFPptxError('packaging-failed', 'Generated ZIP headers could not be timestamped safely.'); };
  const end = bytes.length - 22;
  if (end < 0 || view.getUint32(end, true) !== 0x06054b50 || view.getUint16(end + 4, true) !== 0 ||
    view.getUint16(end + 6, true) !== 0 || view.getUint16(end + 20, true) !== 0) fail();
  const count = view.getUint16(end + 10, true);
  const start = view.getUint32(end + 16, true);
  if (count !== view.getUint16(end + 8, true) || start + view.getUint32(end + 12, true) !== end) fail();
  const positions = [];
  let central = start, localEnd = 0;
  for (let i = 0; i < count; i++) {
    if (central + 46 > end || view.getUint32(central, true) !== 0x02014b50) fail();
    const nameSize = view.getUint16(central + 28, true);
    const next = central + 46 + nameSize + view.getUint16(central + 30, true) + view.getUint16(central + 32, true);
    const local = view.getUint32(central + 42, true);
    if (next > end || local !== localEnd || local + 30 > start || view.getUint32(local, true) !== 0x04034b50 ||
      view.getUint16(local + 26, true) !== nameSize || view.getUint16(central + 34, true) !== 0) fail();
    const content = local + 30 + nameSize + view.getUint16(local + 28, true);
    localEnd = content + view.getUint32(central + 20, true);
    if (content > start || localEnd > start || view.getUint32(local + 18, true) !== view.getUint32(central + 20, true) ||
      view.getUint32(local + 14, true) !== view.getUint32(central + 16, true) ||
      view.getUint32(local + 22, true) !== view.getUint32(central + 24, true) ||
      view.getUint16(local + 6, true) !== view.getUint16(central + 8, true) ||
      view.getUint16(local + 8, true) !== view.getUint16(central + 10, true)) fail();
    for (let j = 0; j < nameSize; j++) if (bytes[local + 30 + j] !== bytes[central + 46 + j]) fail();
    positions.push(local + 10, central + 12);
    central = next;
  }
  if (central !== end || localEnd !== start) fail();
  for (const position of positions) view.setUint32(position, stamp, true);
  return bytes;
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function withDeterministicRandom(seed, callback) {
  const originalRandom = Math.random;
  let state = seed >>> 0;
  Math.random = () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 0x100000000;
  };

  try {
    return await callback();
  } finally {
    Math.random = originalRandom;
  }
}

function asUint8Array(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  throw new OPFPptxError("invalid-output", "PPTX generator returned an unsupported output type.");
}

function stringifyText(value) {
  if (value === null || value === undefined) return "";
  if (Array.isArray(value)) return value.map(stringifyText).join("");
  if (isPlainObject(value)) {
    if (value.text !== undefined) return stringifyText(value.text);
    if (value.value !== undefined) return stringifyText(value.value);
    return JSON.stringify(value);
  }
  return String(value);
}

// PptxGenJS writes a gap (null) as `<c:pt idx="n"><c:v></c:v></c:pt>`. A native gap is a numeric cache with no point at that
// index (ptCount keeps the row count); an empty value is not a number, so drop those points, leaving the index unwritten.
function omitEmptyNumberPoints(xml) {
  return xml.replace(/<c:numCache>[\s\S]*?<\/c:numCache>/g, cache => cache.replace(/<c:pt idx="\d+"><c:v><\/c:v><\/c:pt>/g, ""));
}

function normalizeAuthor(author) {
  if (typeof author === "string") return author;
  if (Array.isArray(author)) return joinAuthors(author);
  return null;
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function isAbsolutePath(value) {
  return /^(?:[a-zA-Z]:[\\/]|\/)/.test(value);
}

function joinPath(base, relative) {
  return `${String(base).replace(/[\\/]+$/, "")}/${String(relative).replace(/^[\\/]+/, "")}`;
}

function bytesToBase64(bytes) {
  if (typeof Buffer !== "undefined") return Buffer.from(bytes).toString("base64");
  let binary = "";
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

function decodeText(bytes) {
  return new TextDecoder().decode(bytes);
}

function encodeText(value) {
  return new TextEncoder().encode(value);
}

function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}

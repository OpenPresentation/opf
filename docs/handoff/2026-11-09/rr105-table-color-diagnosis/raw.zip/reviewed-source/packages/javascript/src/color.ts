import { ENGINE_DEFAULT_COLOR_SCHEME } from './engine-vocabularies.js';
import { legible } from './legible-color.js';

const schemeColorSlots = new Set([
  'accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6',
  'dark1', 'dark2', 'light1', 'light2', 'hyperlink', 'followedHyperlink',
]);

const schemeColorRoles = new Set([
  'primary', 'secondary', 'accent', 'background', 'surface', 'surfaceAlt', 'text', 'textSecondary',
]);

const defaultRoleSlots: Record<string, string> = {
  primary: 'accent1',
  secondary: 'accent2',
  accent: 'accent3',
  background: 'light1',
  surface: 'light2',
  text: 'dark1',
  textSecondary: 'dark2',
};

/** Normalize a literal hex color to uppercase #RRGGBB. */
export function normalizeHexColor(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  let hex = value.trim();
  if (/^#[0-9a-f]{3}$/i.test(hex)) hex = `#${[...hex.slice(1)].map((char) => char + char).join('')}`;
  if (/^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(hex)) return hex.length === 9 ? `#${hex.slice(1, 7).toUpperCase()}` : hex.toUpperCase();
  return undefined;
}

export type ResolveColorRefRoles = Partial<Record<
  'primary' | 'secondary' | 'accent' | 'background' | 'surface' | 'surfaceAlt' | 'text' | 'textSecondary',
  string
>>;

export interface ResolveColorRefOptions {
  /** Effective color scheme after design resolution (OOXML slots plus optional role hex overrides). */
  colorScheme: Record<string, unknown>;
  /** Optional resolved chrome colors (e.g. renderer `design.colors` with `textSecondary` mapped to `mutedText`). */
  roles?: ResolveColorRefRoles;
  /** Top-level presentation `variables` map. */
  variables?: Record<string, unknown>;
  /** Theme text color returned when a reference cannot be resolved. */
  fallback: string;
}

function schemeSlot(colorScheme: Record<string, unknown>, slot: string, fallback: string): string {
  return normalizeHexColor(colorScheme[slot]) ?? fallback;
}

function resolveVariable(variables: Record<string, unknown>, id: string, fallback: string): string {
  const entry = variables[id];
  if (typeof entry === 'string') return normalizeHexColor(entry) ?? fallback;
  if (entry && typeof entry === 'object' && (entry as { type?: string }).type === 'color') {
    return normalizeHexColor((entry as { value?: unknown }).value) ?? fallback;
  }
  return fallback;
}

/**
 * SH-02: the lighter or darker form of a ColorRef, `{ color, lighten }` or `{ color, darken }` (opf.schema.json ColorTransform), as the
 * DrawingML luminance transform PowerPoint's theme tints and shades use: `lighten` L is lumMod (1 - L) and lumOff L, `darken` D is
 * lumMod (1 - D), both in thousandths of a percent. Undefined for anything else (a string ColorRef, or an object that is neither).
 */
export function colorTransform(reference: unknown): { color: unknown; lumMod: number; lumOff: number } | undefined {
  if (reference === null || typeof reference !== 'object' || Array.isArray(reference)) return undefined;
  const { color, lighten, darken } = reference as { color?: unknown; lighten?: unknown; darken?: unknown };
  const share = (value: unknown) => typeof value === 'number' && Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : undefined;
  const light = share(lighten), dark = share(darken);
  if (color === undefined || (light === undefined) === (dark === undefined)) return undefined;
  return light !== undefined ? { color, lumMod: Math.round((1 - light) * 100000), lumOff: Math.round(light * 100000) } : { color, lumMod: Math.round((1 - dark!) * 100000), lumOff: 0 };
}

/** SH-02: `hex` (#RGB, #RRGGBB or #RRGGBBAA) with a ColorRef's lighter or darker transform applied; an alpha byte is kept. */
export function applyColorTransform(hex: string, transform: { lumMod: number; lumOff: number }): string {
  const literal = normalizeHexColor(hex);
  if (!literal) return hex;
  const alpha = /^#[0-9a-f]{8}$/i.test(hex.trim()) ? hex.trim().slice(7).toUpperCase() : '';
  return applyLuminance(literal, transform.lumMod, transform.lumOff) + alpha;
}

/** Resolve a ColorRef (or a TextRun.color string) to a literal hex color; the lighter or darker object form resolves its base and applies its transform. */
export function resolveColorRef(reference: unknown, options: ResolveColorRefOptions): string {
  const transform = colorTransform(reference);
  if (transform) return applyColorTransform(resolveColorRef(transform.color, options), transform);
  if (typeof reference !== 'string') return options.fallback;
  const { colorScheme, roles, variables = {}, fallback } = options;
  const literal = normalizeHexColor(reference);
  if (literal) return literal;

  if (reference.startsWith('var:')) {
    const id = reference.slice('var:'.length);
    if (/^[a-z][a-z0-9-]*$/.test(id)) return resolveVariable(variables, id, fallback);
    return fallback;
  }

  if (schemeColorRoles.has(reference)) {
    const roleKey = reference as keyof ResolveColorRefRoles;
    const fromRoles = roles?.[roleKey];
    if (fromRoles) return normalizeHexColor(fromRoles) ?? fallback;
    // surfaceAlt has no slot or scheme override: it is derived from the surface and text roles (see surfaceAltColor).
    if (reference === 'surfaceAlt') {
      const surface = resolveColorRef('surface', { colorScheme, roles, variables, fallback: '#FFFFFF' });
      const text = resolveColorRef('text', { colorScheme, roles, variables, fallback: textColorForFill(surface, '#000000') });
      return surfaceAltColor(surface, text);
    }
    const fromScheme = normalizeHexColor(colorScheme[reference]);
    if (fromScheme) return fromScheme;
    const slot = defaultRoleSlots[reference];
    return slot ? schemeSlot(colorScheme, slot, fallback) : fallback;
  }

  if (schemeColorSlots.has(reference)) return schemeSlot(colorScheme, reference, fallback);

  return fallback;
}

/** WCAG relative luminance below which a slide background counts as dark (the point where white and black text contrast equally). */
export const DARK_BACKGROUND_LUMINANCE = 0.179;

/** True when text on this color should be light: its relative luminance is under {@link DARK_BACKGROUND_LUMINANCE}. An unreadable color is not dark. */
export function isDarkColor(color: unknown): boolean {
  const hex = normalizeHexColor(color);
  const value = hex ? luminance(hex) : undefined;
  return value !== undefined && value < DARK_BACKGROUND_LUMINANCE;
}

/**
 * The slide background a color scheme implies when the design names no single-color background: the scheme's
 * `background` role override, else its light1 slot, else white. Gradient and picture backgrounds use it too.
 */
export function defaultSlideBackground(colorScheme: Record<string, unknown>): string {
  return keepAlpha(colorScheme.background) ?? slotKeepingAlpha(colorScheme, 'light1', '#FFFFFF');
}

/** A hex color as uppercase #RRGGBB, keeping an #RRGGBBAA alpha byte (a translucent scheme surface stays translucent). */
function keepAlpha(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const hex = value.trim();
  if (/^#[0-9a-f]{8}$/i.test(hex)) return hex.toUpperCase();
  return normalizeHexColor(hex);
}

function slotKeepingAlpha(colorScheme: Record<string, unknown>, slot: string, fallback: string): string {
  return keepAlpha(colorScheme[slot]) ?? fallback;
}

/** The OOXML theme hyperlink colors a scheme without hyperlink slots gets (the Office theme values the PPTX export writes). */
const DEFAULT_HYPERLINK = '#0563C1';
const DEFAULT_FOLLOWED_HYPERLINK = '#954F72';

/** The link color a slide draws: the scheme's, unless it is hard to read on this background (the rule the slide tag follows for the primary color). */
const MIN_LINK_CONTRAST = 4.5;
function readableLink(link: string, background: string, text: string): string {
  const linkHex = normalizeHexColor(link), backgroundHex = normalizeHexColor(background);
  const contrast = linkHex && backgroundHex ? colorContrast(linkHex, backgroundHex) : undefined;
  return contrast !== undefined && contrast < MIN_LINK_CONTRAST ? text : link;
}

// --------------------------------------------------------------- variants: PowerPoint's colour map over one scheme (RR-96)

/** The four light and dark slots: the text roles (tx1, tx2) always map to one of them. */
export type ColorBaseSlot = 'light1' | 'light2' | 'dark1' | 'dark2';
export type ColorAccentSlot = 'accent1' | 'accent2' | 'accent3' | 'accent4' | 'accent5' | 'accent6';
/** The slots a variant can use as the slide background: the four light and dark slots, or an accent (LH-01). */
export type ColorVariantBackground = ColorBaseSlot | ColorAccentSlot;
const ACCENT_SLOTS: readonly ColorAccentSlot[] = ['accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6'];
const isAccentSlot = (value: unknown): value is ColorAccentSlot => (ACCENT_SLOTS as readonly unknown[]).includes(value);

/**
 * A variant of the deck's single colour scheme: which slot is the background (and so which are the text and the alternate surface),
 * and optionally the order of the accents. It is a mapping over the scheme's twelve slots, as PowerPoint's `clrMap` is, never a second
 * scheme: nothing in it is a colour.
 */
export interface ColorVariant {
  background: ColorVariantBackground;
  /** A permutation of `accent1` to `accent6`: entry `i` is the scheme slot drawn as accent `i + 1`. Default: the scheme's own order. */
  accents?: readonly ColorAccentSlot[];
}

/** The slots the roles bg1, tx1, bg2 and tx2 and the six accents point at (OOXML `clrMap`, with `lt1` named `light1` and so on). */
export interface ColorMap {
  bg1: ColorVariantBackground;
  tx1: ColorBaseSlot;
  bg2: ColorVariantBackground;
  tx2: ColorBaseSlot;
  accents: readonly ColorAccentSlot[];
}

const MAPS: Record<ColorBaseSlot, Omit<ColorMap, 'accents'>> = {
  light1: { bg1: 'light1', tx1: 'dark1', bg2: 'light2', tx2: 'dark2' },
  light2: { bg1: 'light2', tx1: 'dark1', bg2: 'light2', tx2: 'dark2' },
  dark1: { bg1: 'dark1', tx1: 'light1', bg2: 'dark2', tx2: 'light2' },
  dark2: { bg1: 'dark2', tx1: 'light1', bg2: 'dark2', tx2: 'light2' },
};

/** A variant as authored: the background slot alone (`"dark1"`, the same as `{ "background": "dark1" }`), or the object form, which is needed only for an accent order. */
export type ColorVariantInput = ColorVariantBackground | ColorVariant;

const isVariantBackground = (value: unknown): value is ColorVariantBackground => (typeof value === 'string' && Object.hasOwn(MAPS, value)) || isAccentSlot(value);

/** The variant an authored value stands for, always the normalized object form, or undefined for a value that is not a variant: a background slot string, or an object with a background slot and, when given, a permutation of the six accent slots. */
export function normalizeColorVariant(value: unknown): ColorVariant | undefined {
  if (typeof value === 'string') return isVariantBackground(value) ? { background: value } : undefined;
  if (!value || typeof value !== 'object' || Array.isArray(value)) return undefined;
  const { background, accents } = value as { background?: unknown; accents?: unknown };
  if (!isVariantBackground(background)) return undefined;
  if (accents === undefined) return { background: background as ColorVariantBackground };
  return Array.isArray(accents) && accents.length === 6 && ACCENT_SLOTS.every(slot => accents.includes(slot))
    ? { background: background as ColorVariantBackground, accents: [...accents] as ColorAccentSlot[] }
    : undefined;
}

/** True for a well formed variant in either form (see {@link normalizeColorVariant}). */
export function isColorVariant(value: unknown): value is ColorVariantInput {
  return normalizeColorVariant(value) !== undefined;
}

/**
 * LH-01: the tone-relative values a layout record's `design.variant` can take besides a variant, resolved against the deck's own variant
 * (its background slot and whether it is dark) by {@link layoutColorVariant}:
 *
 * - `surface`: the deck's secondary surface on its own side, light2 on a light deck and dark2 on a dark one (light1 or dark1 where the deck
 *   is already on light2 or dark2), so a statement stands off the deck without flipping its tone;
 * - `brand`: the scheme's brand dark, dark2 (dark1 where the deck is already on dark2), the strong surface a closing slide takes on a light or
 *   a dark deck, with light text.
 */
export type LayoutVariantRole = 'surface' | 'brand';
const LAYOUT_VARIANT_ROLES: readonly LayoutVariantRole[] = ['surface', 'brand'];

/** The deck a layout's tone-relative variant is resolved against: its background slot (bg1 of its map) and whether its text is light. */
export interface LayoutVariantDeck {
  background: ColorVariantBackground;
  dark: boolean;
}

/** The layout record's `design.variant` as authored, when it is well formed: a variant (normalized) or a {@link LayoutVariantRole}. */
function layoutVariantValue(layout: unknown): ColorVariant | LayoutVariantRole | undefined {
  const design = layout && typeof layout === 'object' ? (layout as { design?: unknown }).design : undefined;
  const value = design && typeof design === 'object' ? (design as { variant?: unknown }).variant : undefined;
  return (LAYOUT_VARIANT_ROLES as readonly unknown[]).includes(value) ? (value as LayoutVariantRole) : normalizeColorVariant(value);
}

/**
 * LH-01: the variant a layout record names (`layout.design.variant`), normalized, or undefined: a variant as written, or a
 * {@link LayoutVariantRole} resolved against `deck` (default: a light deck on light1). It ranks above the deck's design and the theme and
 * below the slide's own design (docs/programs/layout-harvest/README.md, Decisions), so a section or a closing draws on its variant in any
 * deck while an author can still set a slide's own.
 */
export function layoutColorVariant(layout: unknown, deck: LayoutVariantDeck = { background: 'light1', dark: false }): ColorVariant | undefined {
  const value = layoutVariantValue(layout);
  if (value === 'surface') return { background: deck.dark ? (deck.background === 'dark2' ? 'dark1' : 'dark2') : deck.background === 'light2' ? 'light1' : 'light2' };
  if (value === 'brand') return { background: deck.background === 'dark2' ? 'dark1' : 'dark2' };
  return value;
}

/** LH-164: what a layout record's `design.variant` is: a tone-relative `surface` (the statement, the quote), a `brand`, a variant as written, or undefined when it names none. */
export function layoutVariantKind(layout: unknown): 'surface' | 'brand' | 'variant' | undefined {
  const value = layoutVariantValue(layout);
  return value === undefined ? undefined : value === 'surface' || value === 'brand' ? value : 'variant';
}

const isSetBackground = (value: unknown): boolean => value !== undefined && value !== null && value !== false;
/** The image sources a background string shorthand can be (composition's IMAGE_SOURCE). */
const IMAGE_SOURCE_SHORTHAND = /^(asset:|https:\/\/|data:|\.\/|\.\.\/)/;

/**
 * LH-103: whether a background definition is fixed, so a gallery layout's variant never replaces it: a hex color (shorthand or a solid's
 * color), a solid whose color is a `var:` variable, a gradient, a pattern or a picture (an image source string or `{ type: "image" }`).
 * Scheme-based, and so open to a layout variant: no background, a theme slot (`"dark1"`, `{ type: "theme" }`) and a solid whose color
 * is a scheme slot or role name (`accent1`, `primary`, `background`), which follow the scheme as the variant does. A `var:` reference
 * counts as fixed whatever it holds, because the author named a color of the deck's own rather than a place in the scheme.
 */
export function isFixedBackground(definition: unknown): boolean {
  if (!isSetBackground(definition)) return false;
  if (typeof definition === 'string') return normalizeHexColor(definition) !== undefined || IMAGE_SOURCE_SHORTHAND.test(definition);
  if (typeof definition !== 'object') return false;
  const background = definition as { type?: unknown; color?: unknown };
  if (background.type === 'solid') return normalizeHexColor(background.color) !== undefined || (typeof background.color === 'string' && background.color.trim().startsWith('var:'));
  return background.type === 'gradient' || background.type === 'pattern' || background.type === 'image';
}

/**
 * LH-103: whether the deck and the theme draw a fixed background ({@link isFixedBackground}), which a layout's variant does not replace:
 * the slide keeps that background and its text follows that background's tone or luminance, as on a slide with no layout variant. The
 * drawn background is the deck's own, else the theme's unless a deck variant hides it (as colorChoice does). A deck `variant` beside its
 * own fixed background only maps the text and the surfaces, so that background still wins over the layout.
 */
export function deckBackgroundIsFixed(deckDesign: unknown, themeBackground: unknown): boolean {
  const deck = deckDesign && typeof deckDesign === 'object' ? (deckDesign as { variant?: unknown; background?: unknown }) : {};
  if (isSetBackground(deck.background)) return isFixedBackground(deck.background);
  return !normalizeColorVariant(deck.variant) && isFixedBackground(themeBackground);
}

/**
 * LH-01: whether a layout's variant decides the slide's background: the layout names one and the slide's own design sets neither a
 * variant nor a background, so the layout hides a scheme-based background of the deck and the theme (the slide is the variant's bg1).
 * LH-103: never over a fixed background of the deck or the theme ({@link deckBackgroundIsFixed}), which the slide keeps.
 * LH-164: `surface` is a variant the slide's content asks for (a message-only slide's accent surface, messageSurface): it decides the
 * background under the same conditions, over a layout that names no variant.
 */
export function layoutVariantApplies(slideDesign: unknown, layout: unknown, deckDesign: unknown = {}, themeBackground: unknown = undefined, surface: unknown = undefined): boolean {
  const own = slideDesign && typeof slideDesign === 'object' ? (slideDesign as { variant?: unknown; background?: unknown }) : {};
  return (layoutVariantValue(layout) !== undefined || (surface !== undefined && !deckBackgroundIsChosen(deckDesign, themeBackground))) && own.variant === undefined && !isSetBackground(own.background) && !deckBackgroundIsFixed(deckDesign, themeBackground);
}

/**
 * LH-164: whether the deck or the theme draws a background the author chose, so a content-asked surface (a message-only slide's accent) leaves
 * it alone: any background but none and the neutral theme slots (`light1`, `dark2`, `{ type: "theme" }`), which are the deck's plain surface.
 * A solid slot or role color (`accent2`, `primary`) is a chosen one, though a layout's variant still replaces it (LH-103).
 */
export function deckBackgroundIsChosen(deckDesign: unknown, themeBackground: unknown): boolean {
  const deck = deckDesign && typeof deckDesign === 'object' ? (deckDesign as { background?: unknown }) : {};
  const chosen = (definition: unknown) => isSetBackground(definition) && !(typeof definition === 'string' && /^(light|dark)[12]$/.test(definition)) && !(definition && typeof definition === 'object' && (definition as { type?: unknown }).type === 'theme');
  return isSetBackground(deck.background) ? chosen(deck.background) : chosen(themeBackground);
}

/** LH-01: the contrast tx2 needs on an accent background to stay the family's secondary text; under it tx2 maps to tx1's slot. */
export const ACCENT_SECONDARY_MIN_CONTRAST = 4.5;

/**
 * The map a variant stands for: `light1` is the default map (bg1 = light1, tx1 = dark1, bg2 = light2, tx2 = dark2); `dark1` swaps
 * light and dark; `light2` and `dark2` make that slot both the background and the alternate surface (bg2, as a slide with that theme
 * background has always had it, which keeps the default theme's dark2 background unchanged), with the text of the family's side. No variant is `light1`.
 *
 * LH-01: an accent background is both bg1 and bg2, as light2 and dark2 are, with the text of the family whose tx1 reads better on that
 * accent in `colorScheme` (light1 and light2 when light1 has the higher contrast, else dark1 and dark2), so the scheme's own slots carry
 * the text and no colour is invented; tx2 maps to tx1's slot where the family's tx2 is under {@link ACCENT_SECONDARY_MIN_CONTRAST} on the
 * accent. Without a scheme the accent counts as dark.
 */
export function colorMapFor(variant?: ColorVariantInput, colorScheme: Record<string, unknown> = {}): ColorMap {
  const normalized = normalizeColorVariant(variant);
  const accents = normalized?.accents ? [...normalized.accents] : ACCENT_SLOTS;
  const background = normalized?.background ?? 'light1';
  if (!isAccentSlot(background)) return { ...MAPS[background], accents };
  const hex = (slot: string, fallback: string) => normalizeHexColor(colorScheme[slot]) ?? fallback;
  const fill = hex(background, '#000000');
  const contrast = (slot: ColorBaseSlot, fallback: string) => colorContrast(hex(slot, fallback), fill) ?? 0;
  const lightText = contrast('light1', '#FFFFFF') >= contrast('dark1', '#000000');
  const tx1: ColorBaseSlot = lightText ? 'light1' : 'dark1', family: ColorBaseSlot = lightText ? 'light2' : 'dark2';
  const tx2 = contrast(family, lightText ? '#F8FAFC' : '#1E293B') >= ACCENT_SECONDARY_MIN_CONTRAST ? family : tx1;
  return { bg1: background, tx1, bg2: background, tx2, accents };
}

const OOXML_SLOT: Record<string, string> = { light1: 'lt1', light2: 'lt2', dark1: 'dk1', dark2: 'dk2', accent1: 'accent1', accent2: 'accent2', accent3: 'accent3', accent4: 'accent4', accent5: 'accent5', accent6: 'accent6' };

/**
 * The attributes of PowerPoint's `<p:clrMap>` for a map (`bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" ...` and the two
 * hyperlink slots unchanged), so the PPTX export writes the master map and a slide's `clrMapOvr` from the same data the preview reads.
 */
export function clrMapAttributes(map: ColorMap): Record<string, string> {
  return {
    bg1: OOXML_SLOT[map.bg1]!, tx1: OOXML_SLOT[map.tx1]!, bg2: OOXML_SLOT[map.bg2]!, tx2: OOXML_SLOT[map.tx2]!,
    accent1: map.accents[0]!, accent2: map.accents[1]!, accent3: map.accents[2]!, accent4: map.accents[3]!, accent5: map.accents[4]!, accent6: map.accents[5]!,
    hlink: 'hlink', folHlink: 'folHlink',
  };
}

// HSL as DrawingML defines it, for the luminance transforms (`lumMod`, `lumOff`) that PowerPoint writes for tints and shades of a scheme colour.
function rgbToHsl([r, g, b]: readonly [number, number, number]): [number, number, number] {
  const red = r / 255, green = g / 255, blue = b / 255, max = Math.max(red, green, blue), min = Math.min(red, green, blue), l = (max + min) / 2;
  if (max === min) return [0, 0, l];
  const d = max - min, s = l > .5 ? d / (2 - max - min) : d / (max + min);
  const h = max === red ? (green - blue) / d + (green < blue ? 6 : 0) : max === green ? (blue - red) / d + 2 : (red - green) / d + 4;
  return [h / 6, s, l];
}
function hslToRgb([h, s, l]: readonly [number, number, number]): [number, number, number] {
  if (s === 0) return [l * 255, l * 255, l * 255];
  const q = l < .5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const channel = (t: number) => { const u = t < 0 ? t + 1 : t > 1 ? t - 1 : t; return 255 * (u < 1 / 6 ? p + (q - p) * 6 * u : u < .5 ? q : u < 2 / 3 ? p + (q - p) * (2 / 3 - u) * 6 : p); };
  return [channel(h + 1 / 3), channel(h), channel(h - 1 / 3)];
}

/**
 * A scheme colour as the PPTX export writes it and the preview draws it: `slot` is the colour role or slot (`tx1`, `bg1`, `bg2`, `tx2`,
 * `accent1` ...), `lumMod` and `lumOff` are DrawingML luminance transforms in thousandths of a percent (`lumMod 15000, lumOff 85000` is
 * 15% of the slot's luminance plus 85%), `alpha` an opacity in the same unit, and `hex` is the colour the transforms give for the
 * resolved scheme, so a preview that draws `hex` and a PPTX that writes `<a:schemeClr val={slot}>` with the transforms show the same colour.
 */
export interface SchemeColor {
  slot: string;
  hex: string;
  lumMod?: number;
  lumOff?: number;
  alpha?: number;
}

/** The colour a `lumMod`/`lumOff` pair (thousandths of a percent) makes of `hex`: its HSL luminance times `lumMod`, plus `lumOff`. */
export function applyLuminance(hex: string, lumMod = 100000, lumOff = 0): string {
  const channels = opaqueChannels(hex);
  if (!channels) return hex;
  const [h, s, l] = rgbToHsl(channels);
  return hexOfChannels(hslToRgb([h, s, Math.min(1, Math.max(0, l * lumMod / 100000 + lumOff / 100000))]));
}

/**
 * A scheme colour between a slot and its background: the slot's colour made as light (or dark) as `share` of the way from the
 * background's luminance to the slot's. `share` 0.15 is PowerPoint's gridline (tx1 at 15%: black on white is luminance 0.85). The
 * transform is chosen on the slot (`lumMod`/`lumOff`), so it keeps the slot's hue, and `hex` is the transform applied, to the thousandth of a percent.
 */
function mixTowardsBackground(slot: string, slotHex: string, backgroundHex: string, share: number): SchemeColor {
  const from = opaqueChannels(slotHex), to = opaqueChannels(backgroundHex);
  if (!from || !to) return { slot, hex: slotHex };
  const own = rgbToHsl(from)[2], target = rgbToHsl(to)[2] + share * (own - rgbToHsl(to)[2]);
  let lumMod = 100000, lumOff = 0;
  if (target >= own) { const k = own >= 1 ? 0 : (target - own) / (1 - own); lumMod = Math.round((1 - k) * 100000); lumOff = Math.round(k * 100000); }
  else lumMod = Math.round(target / own * 100000);
  return { slot, hex: applyLuminance(slotHex, lumMod, lumOff), ...(lumMod !== 100000 ? { lumMod } : {}), ...(lumOff !== 0 ? { lumOff } : {}) };
}

/** Shares of the text colour (tx1) mixed into the background (bg1) for the neutrals, PowerPoint's chart-style values. */
export const NEUTRAL_SHARES = { border: .2, gridline: .15, axisLine: .25, chartText: .65, codeComment: .65 } as const;

/** LH-54: the share of the text colour (light1 on a dark slide) a dark card starts from, mixed into the background. */
export const CARD_SURFACE_MIX = 0.07;
/** LH-54: the contrast a mixed dark card reaches against the background, stepping the mix up from {@link CARD_SURFACE_MIX} (Claude Design's #0B2A5C on #011842 is 1.25:1). */
export const CARD_SURFACE_MIN_CONTRAST = 1.25;
/** Wave 8: the contrast the slide's text keeps on a mixed card (WCAG AA for body text); the mix towards the text stops before it falls under it. */
export const CARD_TEXT_MIN_CONTRAST = 4.5;
/** LH-54: the share of the text colour mixed into a mixed dark card for its 1 px stroke (about 12% white over the card). */
export const CARD_BORDER_MIX = 0.12;
/** LH-79: a light variant's tx1 at or below this relative luminance (about #1A1A1A) is near-black, and the code panel takes tx2 instead. */
export const CODE_PANEL_NEAR_BLACK = 0.01;
/** LH-79: the contrast bg1 text keeps on tx2 for tx2 to be the code panel of a light variant. */
export const CODE_PANEL_MIN_TEXT_CONTRAST = 7;
/** LH-79: a dark variant's code panel is bg1 at this share of its HSL lightness (`lumMod`; Claude Design's #001030 on #011842). */
export const CODE_PANEL_DARK_SHADE = 0.7;
/** LH-79: the contrast the shaded panel needs against the background to count as a step below it. */
export const CODE_PANEL_MIN_STEP = 1.05;
/** LH-79: the share of the way from bg1 to tx1 a near-black dark slide's code panel is lifted when neither shade nor bg2 stands off. */
export const CODE_PANEL_LIFT = 0.06;

/**
 * The colours OPF draws that are neither text nor an accent, all derived from the scheme through the variant's map, so a dark variant
 * gets light lines and a change of variant or background style in PowerPoint recolours them.
 */
export interface SchemeNeutrals {
  /** Quiet structural rules, card borders and table borders: tx1 at {@link NEUTRAL_SHARES}.border over bg1. */
  border: SchemeColor;
  /** Chart gridlines: tx1 at 15%. */
  gridline: SchemeColor;
  /** Chart axis lines: tx1 at 25%. */
  axisLine: SchemeColor;
  /** Chart axis labels and legend text where the chart does not use the slide text colour: tx1 at 65%. */
  chartText: SchemeColor;
  /** Pie and treemap outlines, the video play icon and anything drawn on top of a mark: bg1. */
  outline: SchemeColor;
  /** The neutral metric trend (no good or bad news): tx2. */
  trendNeutral: SchemeColor;
  /**
   * The code panel, a dark card on either variant (LH-79). On a light variant it is tx1, or tx2 when tx1 is near-black ({@link CODE_PANEL_NEAR_BLACK})
   * and tx2 is dark enough to carry bg1 text at {@link CODE_PANEL_MIN_TEXT_CONTRAST}: a navy theme gets a navy panel, not a black one. On a dark
   * variant it is bg1 shaded to {@link CODE_PANEL_DARK_SHADE} of its lightness, a surface just below the slide; where that cannot stand off a
   * near-black background ({@link CODE_PANEL_MIN_STEP}), bg2 when it does, else bg1 lifted {@link CODE_PANEL_LIFT} towards tx1.
   */
  codePanel: SchemeColor;
  /** Plain code text: bg1 or tx1, whichever reads better on the panel. */
  codeText: SchemeColor;
  /** Code comments and line numbers: the code text at 65% over the panel. */
  codeComment: SchemeColor;
  /**
   * The fill of a card (a composed item's `frameBox`), LH-54: the `surface` role wherever it stands off the background, and on a dark slide
   * where it does not (the dark2 variant, whose bg2 is the background itself) the background mixed towards tx1 from {@link CARD_SURFACE_MIX}
   * until it reaches {@link CARD_SURFACE_MIN_CONTRAST}, so a dark card reads as a filled surface rather than a hairline outline. A mixed card is
   * a literal colour (no single luminance transform of a slot reproduces it), as `surfaceAlt` is.
   */
  card: SchemeColor;
  /** The 1 px stroke of a card: `border`, or on a mixed dark card that card mixed {@link CARD_BORDER_MIX} towards tx1 (a literal colour). */
  cardBorder: SchemeColor;
}

export interface ResolvedColorRoles {
  /** Role override, else the first accent of the variant (accent1 by default). */
  primary: string;
  /** Role override, else the second accent of the variant (accent2 by default). */
  secondary: string;
  /** Role override, else the third accent of the variant (accent3 by default). */
  accent: string;
  /** The slide background: the resolved single-color background of the slide, else the variant's bg1 (light1 by default; see {@link defaultSlideBackground}). */
  background: string;
  /** Role override, else bg2 of the variant (light2 on a light slide, dark2 on a dark one). */
  surface: string;
  /** The alternate surface of banded table rows: {@link surfaceAltColor} of `surface` and `text`, always distinguishable from `surface`. */
  surfaceAlt: string;
  /** Default text: tx1 of the variant (light1 on a dark background). On a light background the `text` role override, else dark1. */
  text: string;
  /** Role override, else tx2 of the variant (light2 on a dark background and dark2 on a light one). */
  textSecondary: string;
  /** The color of a link run that sets no color of its own: the scheme's hyperlink slot (OOXML hlink), unless that has under 4.5:1 contrast against the slide background, then the slide `text` color. */
  hyperlink: string;
  /** Followed-hyperlink slot (OOXML folHlink). */
  followedHyperlink: string;
  /** Quiet structural rules/cards: `neutrals.border.hex`, tx1 mixed into bg1. Authored borders still resolve their own ColorRef. */
  border: string;
  /** Whether the slide background is dark; text, surface and textSecondary defaults follow it. */
  dark: boolean;
  /** The variant these roles were resolved with: the one given, else the one the background's luminance (or tone) implies. */
  variant: ColorVariant;
  /** The map behind the roles (bg1, tx1, bg2, tx2 and the accent order), for PPTX `clrMap` and `clrMapOvr` ({@link clrMapAttributes}). */
  map: ColorMap;
  /** The six accent colours in the variant's order (primary, secondary and accent are the first three unless overridden). */
  accents: string[];
  /** Every neutral derived from the scheme, with its slot and luminance transform for `schemeClr` export. */
  neutrals: SchemeNeutrals;
}

export interface ResolveColorRolesOptions {
  /** The slide's resolved single-color background (solid, theme-slot or pattern background color). Omit for a gradient, picture or no background. */
  background?: string | null;
  /** The slide's variant (RR-96), as authored (`"dark1"` or the object form). It sets the map; without it the background's luminance (or `tone`) chooses light1 or dark1. */
  variant?: ColorVariantInput;
  /** `dark` or `light` for a picture or gradient background that names its tone: it chooses dark1 or light1 when there is no `variant`. */
  tone?: 'dark' | 'light';
}

/**
 * Resolve a color scheme's abstract roles for one slide: the single definition the opf-render preview, the
 * PPTX export and the audit share, so the same deck draws the same colors in all three.
 *
 * RR-96: the roles come from the variant's map over the scheme's slots, as PowerPoint's roles do: background is bg1, text tx1,
 * textSecondary tx2, surface bg2, and primary, secondary and accent the first three accents in the variant's order. Without
 * `options.variant` the map is chosen from the slide: `options.tone` for a picture or gradient that names one, else the luminance of
 * `options.background` ({@link isDarkColor}; dark1 when dark, light1 otherwise), which is the earlier behavior. Role overrides on the
 * scheme (`primary`, `secondary`, `accent`, `background`, `surface`, `text`, `textSecondary`) win over the slots they default to; a
 * `text` override applies only on a light background, so a dark slide always gets readable light text. `roles.neutrals` holds every
 * line and quiet color derived from the same map, each with the slot and luminance transform the PPTX export writes.
 * Values are uppercase #RRGGBB, or #RRGGBBAA where the scheme color carries an alpha byte.
 */
export function resolveColorRoles(colorScheme: Record<string, unknown>, options: ResolveColorRolesOptions = {}): ResolvedColorRoles {
  const slot = (name: string, fallback: string) => slotKeepingAlpha(colorScheme, name, fallback);
  const FALLBACK: Record<string, string> = { light1: '#FFFFFF', light2: '#F8FAFC', dark1: '#111827', dark2: '#1E293B' };
  const explicit = normalizeColorVariant(options.variant);
  // The slide background decides light or dark when no variant does: a named tone, else the luminance of the resolved colour.
  const explicitBackground = keepAlpha(options.background);
  const variant: ColorVariant = explicit ?? { background: (options.tone ? options.tone === 'dark' : isDarkColor(explicitBackground ?? defaultSlideBackground(colorScheme))) ? 'dark1' : 'light1' };
  const map = colorMapFor(variant, colorScheme);
  // The slide is dark where its text is the light family: dark1, dark2, and an accent that takes light text (LH-01).
  const dark = map.tx1 === 'light1';
  const slotColor = (name: ColorVariantBackground) => slot(name, FALLBACK[name] ?? '#000000');
  // The default map keeps the scheme's `background` override as its bg1; any other map reads its slot.
  const bg1 = map.bg1 === 'light1' ? defaultSlideBackground(colorScheme) : slotColor(map.bg1);
  const background = explicitBackground ?? bg1;
  const tx1 = slotColor(map.tx1), bg2 = slotColor(map.bg2), tx2 = slotColor(map.tx2);
  const text = dark ? tx1 : (keepAlpha(colorScheme.text) ?? tx1);
  const surface = keepAlpha(colorScheme.surface) ?? bg2;
  const accents = map.accents.map(name => slot(name, '#000000'));
  const neutrals = schemeNeutrals({ bg1: explicitBackground ?? bg1, bg1Slot: bg1, tx1, bg2, tx2, dark, surface, surfaceAuthored: keepAlpha(colorScheme.surface) !== undefined });
  return {
    primary: keepAlpha(colorScheme.primary) ?? accents[0]!,
    secondary: keepAlpha(colorScheme.secondary) ?? accents[1]!,
    accent: keepAlpha(colorScheme.accent) ?? accents[2]!,
    background,
    surface,
    surfaceAlt: surfaceAltColor(surface, text),
    border: neutrals.border.hex,
    text,
    textSecondary: keepAlpha(colorScheme.textSecondary) ?? tx2,
    hyperlink: readableLink(slot('hyperlink', DEFAULT_HYPERLINK), background, text),
    followedHyperlink: slot('followedHyperlink', DEFAULT_FOLLOWED_HYPERLINK),
    dark,
    variant,
    map,
    accents,
    neutrals,
  };
}

/** The neutrals of a resolved map: see {@link SchemeNeutrals}. The four colors are opaque #RRGGBB (or with alpha, as the scheme has them). */
function schemeNeutrals(colors: { bg1: string; bg1Slot: string; tx1: string; bg2: string; tx2: string; dark: boolean; surface: string; surfaceAuthored: boolean }): SchemeNeutrals {
  const { bg1, tx1, bg2, tx2, dark } = colors;
  const opaque = (value: string) => normalizeHexColor(value) ?? value;
  const [back, front, second, secondText] = [opaque(bg1), opaque(tx1), opaque(bg2), opaque(tx2)];
  const share = (amount: number) => mixTowardsBackground('tx1', front, back, amount);
  const border = share(NEUTRAL_SHARES.border);
  // A luminance transform of bg1 is bg1's only while the background is the slot's colour; over a literal background it stays literal.
  const ofBackground = (lumMod: number, lumOff = 0): SchemeColor => {
    const hex = applyLuminance(back, lumMod, lumOff);
    return back === opaque(colors.bg1Slot) ? { slot: 'bg1', hex, ...(lumMod !== 100000 ? { lumMod } : {}), ...(lumOff !== 0 ? { lumOff } : {}) } : { slot: 'bg1', hex };
  };
  // LH-79: the code panel is a dark card. Light: tx1, or tx2 for a near-black tx1 (a navy theme gets a navy panel, not a black one).
  // Dark: bg1 shaded a step below the slide; a near-black slide that cannot go darker takes bg2 when it stands off, else bg1 lifted.
  let panel: SchemeColor;
  if (!dark) {
    const navy = (luminance(front) ?? 1) <= CODE_PANEL_NEAR_BLACK && secondText !== front && (colorContrast(back, secondText) ?? 0) >= CODE_PANEL_MIN_TEXT_CONTRAST;
    panel = navy ? { slot: 'tx2', hex: secondText } : { slot: 'tx1', hex: front };
  } else {
    const shaded = ofBackground(Math.round(CODE_PANEL_DARK_SHADE * 100000));
    const standsOff = (hex: string) => (colorContrast(hex, back) ?? 0) >= CODE_PANEL_MIN_STEP;
    panel = standsOff(shaded.hex) ? shaded : standsOff(second) ? { slot: 'bg2', hex: second }
      : (() => { const lift = mixTowardsBackground('bg1', back, front, 1 - CODE_PANEL_LIFT); return ofBackground(lift.lumMod ?? 100000, lift.lumOff ?? 0); })();
  }
  const textOnPanel: SchemeColor = (colorContrast(back, panel.hex) ?? 0) >= (colorContrast(front, panel.hex) ?? 0) ? { slot: 'bg1', hex: back } : { slot: 'tx1', hex: front };
  const comment = mixTowardsBackground(textOnPanel.slot, textOnPanel.hex, panel.hex, NEUTRAL_SHARES.codeComment);
  // LH-54: a card is the surface where it stands off the slide. On a dark slide where it does not (dark2: bg2 is the background) and no
  // `surface` is authored, the background is mixed towards tx1 until the card reaches 1.25:1, with a stroke 12% further towards tx1.
  const surface = normalizeHexColor(colors.surface);
  let card: SchemeColor = { slot: 'bg2', hex: colors.surface }, cardBorder = border;
  const backChannels = opaqueChannels(back), frontChannels = opaqueChannels(front);
  if (dark && !colors.surfaceAuthored && surface && backChannels && frontChannels && (colorContrast(surface, back) ?? 0) < SURFACE_ALT_MIN_CONTRAST) {
    // Wave 8: the mix stops where the slide's text would read under CARD_TEXT_MIN_CONTRAST on the card (an accent slide, whose white text reads
    // about 5:1, reaches 1.25:1 only at a card where it reads 4:1), so text on a card (LH-165's icon cards, LH-162's tiles) reads 4.5:1 where the
    // slide's own text does; the card's border still sets it off.
    let fill = mixChannels(backChannels, frontChannels, CARD_SURFACE_MIX);
    for (let amount = CARD_SURFACE_MIX; (colorContrast(front, fill) ?? 0) < CARD_TEXT_MIN_CONTRAST && amount > 0; ) {
      amount = Math.max(0, amount - .005);
      fill = mixChannels(backChannels, frontChannels, amount);
    }
    for (let amount = CARD_SURFACE_MIX; (colorContrast(fill, back) ?? Infinity) < CARD_SURFACE_MIN_CONTRAST && amount < .5; ) {
      amount = Math.min(.5, amount + .005);
      const next = mixChannels(backChannels, frontChannels, amount);
      if ((colorContrast(front, next) ?? 0) < CARD_TEXT_MIN_CONTRAST) break;
      fill = next;
    }
    card = { slot: 'bg1', hex: fill };
    cardBorder = { slot: 'tx1', hex: mixChannels(opaqueChannels(fill)!, frontChannels, CARD_BORDER_MIX) };
  }
  return {
    border,
    gridline: share(NEUTRAL_SHARES.gridline),
    axisLine: share(NEUTRAL_SHARES.axisLine),
    chartText: share(NEUTRAL_SHARES.chartText),
    outline: { slot: 'bg1', hex: back },
    trendNeutral: { slot: 'tx2', hex: secondText },
    codePanel: panel,
    codeText: textOnPanel,
    codeComment: comment,
    card,
    cardBorder,
  };
}

/** LH-06: the contrast every text role drawn on the emphasis surface keeps against its fill (WCAG AA for body text). */
export const EMPHASIS_TEXT_MIN_CONTRAST = 4.5;
/** LH-06: the contrast the emphasis surface keeps against the slide background, so it reads as a surface of its own (WCAG non-text contrast). */
export const EMPHASIS_SURFACE_MIN_CONTRAST = 3;

/** LH-06: the one contrasting surface a slide may draw a block, a group, a foot band or a pill on, and the roles of what is drawn on it. */
export interface EmphasisSurface {
  /** The variant the surface is drawn in: its bg1 is the fill, its map gives the text (the slide's accent order is kept). */
  variant: ColorVariant;
  /** The surface fill, uppercase #RRGGBB: `roles.background`. */
  fill: string;
  /**
   * The roles of the content on the surface: {@link resolveColorRoles} for `variant`, with every text role (text, textSecondary, primary,
   * secondary, accent) under {@link EMPHASIS_TEXT_MIN_CONTRAST} on the fill replaced by `text`, so a metric value in the primary color on an
   * accent card does not vanish into it. `dark` is whether the surface takes light text.
   */
  roles: ResolvedColorRoles;
}

/**
 * LH-06: the emphasis surface of a slide whose roles are `slide`, from the slide's own scheme slots through the LH-01 variant machinery
 * (no color is invented). A light slide takes the brand dark (dark2, as the `brand` layout variant), then dark1, then the accents in the
 * slide's order; a dark slide takes its accents in order (Claude Design's accent card on a dark deck, with the text the accent's map
 * gives: dark1 where it reads better), then light1. The first candidate whose text reaches {@link EMPHASIS_TEXT_MIN_CONTRAST} on its fill and
 * whose fill reaches {@link EMPHASIS_SURFACE_MIN_CONTRAST} against the slide background is the surface; with none, the candidate with the most
 * text contrast is (the last candidates are the opposite text family, so a scheme with readable text always has one).
 */
export function emphasisSurface(colorScheme: Record<string, unknown>, slide: Pick<ResolvedColorRoles, 'dark' | 'map' | 'background'>): EmphasisSurface {
  const accents = slide.map.accents;
  const candidates: ColorVariantBackground[] = slide.dark ? [...accents, 'light1'] : ['dark2', 'dark1', ...accents];
  const backdrop = normalizeHexColor(slide.background) ?? '#FFFFFF';
  const hex = (color: string) => normalizeHexColor(color) ?? color;
  let best: { surface: EmphasisSurface; contrast: number } | undefined;
  for (const background of candidates) {
    if (background === slide.map.bg1) continue;
    const variant: ColorVariant = { background, accents: [...accents] };
    const roles = resolveColorRoles(colorScheme, { variant });
    const fill = hex(roles.background);
    const readable = (color: string) => (colorContrast(hex(color), fill) ?? 0) >= EMPHASIS_TEXT_MIN_CONTRAST;
    const text = colorContrast(hex(roles.text), fill) ?? 0;
    const surface: EmphasisSurface = {
      variant,
      fill,
      roles: {
        ...roles,
        background: fill,
        textSecondary: readable(roles.textSecondary) ? roles.textSecondary : roles.text,
        primary: readable(roles.primary) ? roles.primary : roles.text,
        secondary: readable(roles.secondary) ? roles.secondary : roles.text,
        accent: readable(roles.accent) ? roles.accent : roles.text,
      },
    };
    if (text >= EMPHASIS_TEXT_MIN_CONTRAST && (colorContrast(fill, backdrop) ?? 0) >= EMPHASIS_SURFACE_MIN_CONTRAST) return surface;
    if (!best || text > best.contrast) best = { surface, contrast: text };
  }
  return best!.surface;
}

/**
 * The scheme color, bg1 or tx1 of the roles, that reads best on `fill`: for table header text, text on a mark and anything else that
 * sits on a color the scheme does not name. Returned as a {@link SchemeColor} (slot `bg1` or `tx1`) so the export can write a theme color.
 */
export function readableSchemeColor(fill: string, roles: Pick<ResolvedColorRoles, 'neutrals' | 'text' | 'background'>): SchemeColor {
  const light: SchemeColor = { slot: 'bg1', hex: normalizeHexColor(roles.background) ?? roles.background };
  const ink: SchemeColor = { slot: 'tx1', hex: normalizeHexColor(roles.text) ?? roles.text };
  return (colorContrast(light.hex, fill) ?? 0) >= (colorContrast(ink.hex, fill) ?? 0) ? light : ink;
}

/** Relative luminance contrast for opaque #RGB/#RRGGBB/#RRGGBBFF colors.
 * Unknown or translucent colors need a resolved backdrop and remain unmeasured.
 * https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html
 */
function luminance(value: string): number | undefined {
  if (typeof value !== 'string') return undefined;
  let hex = value.trim();
  if (/^#[0-9a-f]{3}$/i.test(hex)) hex = `#${[...hex.slice(1)].map(c => c + c).join('')}`;
  if (/^#[0-9a-f]{6}ff$/i.test(hex)) hex = hex.slice(0, 7);
  if (!/^#[0-9a-f]{6}$/i.test(hex)) return undefined;
  return [.2126, .7152, .0722].reduce((sum, weight, index) => {
    const offset = index * 2 + 1;
    const n = Number.parseInt(hex.slice(offset, offset + 2), 16) / 255;
    return sum + weight * (n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4);
  }, 0);
}

export function colorContrast(foreground: string, background: string): number | undefined {
  const a = luminance(foreground), b = luminance(background);
  return a === undefined || b === undefined ? undefined : (Math.max(a, b) + .05) / (Math.min(a, b) + .05);
}

/** Keep an inherited text color at >=4.5:1; otherwise select black or white.
 * Callers must preserve explicit text-color overrides before using this fallback.
 * An unresolved/translucent fill preserves the preferred color, without a contrast claim.
 */
export function textColorForFill(fill: string, preferred: string): string {
  const background = luminance(fill), contrast = colorContrast(preferred, fill);
  if (background === undefined || contrast === undefined || contrast >= 4.5) return preferred;
  return (background + .05) / .05 >= 1.05 / (background + .05) ? '#000000' : '#FFFFFF';
}

/** Keep an inherited chart mark at >=3:1 against its opaque panel. Otherwise
 * mix toward black or white in bounded 1/255 steps, choosing the first passing
 * step (higher contrast breaks a tie). This retains a recognizable palette;
 * it does not establish distinction between adjacent series or colorblind safety.
 * Explicit mark overrides belong to the caller; unresolved alpha is preserved.
 */
export function chartColorForFill(fill: string, preferred: string): string {
  const contrast = colorContrast(preferred, fill);
  if (contrast === undefined || contrast >= 3) return preferred;
  let hex = preferred.trim();
  if (hex.length === 4) hex = `#${[...hex.slice(1)].map(c => c + c).join('')}`;
  const channels = [1, 3, 5].map(offset => Number.parseInt(hex.slice(offset, offset + 2), 16));
  for (let step = 1; step <= 255; step++) {
    const candidates = [0, 255].map(target => {
      const color = `#${channels.map(channel => Math.round(channel + (target - channel) * step / 255).toString(16).padStart(2, '0')).join('')}`.toUpperCase();
      return {color, contrast: colorContrast(color, fill) ?? 0};
    }).sort((a, b) => b.contrast - a.contrast);
    const best = candidates[0];
    if (best && best.contrast >= 3) return best.color;
  }
  // Black or white always exceeds 3:1 for an opaque sRGB fill.
  return textColorForFill(fill, preferred);
}

// --------------------------------------------------------------- chart palettes

/** Smallest CIE L* step kept between neighbouring series (a printed or greyscale chart tells them apart by lightness alone). */
export const CHART_SERIES_MIN_LIGHTNESS_STEP = 11;
/** Smallest CIE76 colour difference kept between any two series that were at least that far apart before the surface adjustment. */
export const CHART_SERIES_MIN_DIFFERENCE = 12;

type Lab = [number, number, number];
const D65 = [0.95047, 1, 1.08883] as const;

function opaqueChannels(value: string): [number, number, number] | undefined {
  if (luminance(value) === undefined) return undefined;
  let hex = value.trim();
  if (hex.length === 4) hex = `#${[...hex.slice(1)].map(c => c + c).join('')}`;
  return [1, 3, 5].map(offset => Number.parseInt(hex.slice(offset, offset + 2), 16)) as [number, number, number];
}
const toLinear = (channel: number) => { const n = channel / 255; return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4; };
const fromLinear = (value: number) => 255 * (value <= .0031308 ? value * 12.92 : 1.055 * value ** (1 / 2.4) - .055);

function labOf(channels: readonly number[]): Lab {
  const [r, g, b] = channels.map(toLinear) as [number, number, number];
  const f = (t: number) => t > 216 / 24389 ? Math.cbrt(t) : (24389 / 27 * t + 16) / 116;
  const fx = f((.4124564 * r + .3575761 * g + .1804375 * b) / D65[0]), fy = f(.2126729 * r + .7151522 * g + .072175 * b), fz = f((.0193339 * r + .119192 * g + .9503041 * b) / D65[2]);
  return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
}

/** Linear sRGB for a Lab colour, or undefined outside the sRGB gamut. */
function labToLinear([l, a, b]: Lab): [number, number, number] | undefined {
  const fy = (l + 16) / 116, fx = fy + a / 500, fz = fy - b / 200;
  const inverse = (t: number) => t ** 3 > 216 / 24389 ? t ** 3 : (116 * t - 16) / (24389 / 27);
  const x = inverse(fx) * D65[0], y = l > 8 ? fy ** 3 : l / (24389 / 27), z = inverse(fz) * D65[2];
  const rgb: [number, number, number] = [
    3.2404542 * x - 1.5371385 * y - .4985314 * z,
    -.969266 * x + 1.8760108 * y + .041556 * z,
    .0556434 * x - .2040259 * y + 1.0572252 * z,
  ];
  return rgb.every(channel => channel >= -.0005 && channel <= 1.0005) ? rgb : undefined;
}

const hexOfChannels = (channels: readonly number[]) => `#${channels.map(channel => Math.max(0, Math.min(255, Math.round(channel))).toString(16).padStart(2, '0')).join('').toUpperCase()}`;

/** The colour of the given lightness that keeps the hue and as much of the chroma as fits in sRGB. */
function labWithLightness(l: number, a: number, b: number): string {
  const chroma = Math.hypot(a, b), hue = Math.atan2(b, a);
  const at = (scale: number): [number, number, number] | undefined => labToLinear([l, Math.cos(hue) * chroma * scale, Math.sin(hue) * chroma * scale]);
  let linear = at(1);
  if (!linear) {
    let low = 0, high = 1;
    for (let step = 0; step < 24; step++) { const mid = (low + high) / 2; if (at(mid)) low = mid; else high = mid; }
    linear = at(low) ?? [0, 0, 0];
  }
  return hexOfChannels(linear.map(channel => fromLinear(Math.max(0, Math.min(1, channel)))));
}

/** CIE76 difference of two opaque #RRGGBB colours (0 when either is not opaque). */
function labDifference(a: Lab, b: Lab): number { return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]); }

/** Series are placed in tiers of this many: a colour is kept apart from the colours of its own and earlier tiers only (see {@link chartPaletteForFill}). */
export const CHART_SERIES_TIER_SIZE = 6;
const tierOf = (index: number): number => Math.floor(index / CHART_SERIES_TIER_SIZE);

/** Cost, in CIE L* points of movement, of each point a placement falls short of the separation from a neighbouring series. */
const CHART_SERIES_SHORTFALL_WEIGHT = 8;

/** WI-5 (P18, D3) and LH-55: the contrast every series from the scheme reaches on a dark chart surface (see {@link ChartPaletteOptions.legible}). */
export const CHART_DARK_SERIES_MIN_CONTRAST = 4.5;
/** LH-55: the CIE L* step kept between series 1 and 2 on a dark chart surface when both come from the scheme (the default blue pair was 9 apart). */
export const CHART_LEAD_LIGHTNESS_STEP = 20;

export interface ChartPaletteOptions {
  /**
   * The series that come from the deck scheme ({@link chartSchemeSeries}): on a dark `fill` each of them reaches {@link CHART_DARK_SERIES_MIN_CONTRAST}
   * (4.5:1) rather than 3:1 (WI-5, P18, decision D3; LH-55 for every series), and series 2 keeps {@link CHART_LEAD_LIGHTNESS_STEP} from series 1
   * when both are listed. An authored `chart.colors` entry and a host palette (omit the option) keep the 3:1 floor.
   */
  legible?: readonly boolean[];
  /**
   * LH-105: soften the series `legible` lists (the scheme's): each is mixed up to {@link CHART_SERIES_SOFT_MIX} of the way towards `fill`
   * after the contrast placement, as far as it keeps its contrast floor and its lightness step from its neighbours ({@link softenChartPalette}).
   * Ordinary data then reads in soft colours and the full-strength colour is left for emphasis (Few). An authored colour is never softened.
   */
  soften?: boolean;
}

/** Series colours for a chart drawn on `fill`: the palette in order, each colour adjusted for contrast
 * (`chartColorForFill`) without letting the adjustment merge series.
 *
 * Lifting or darkening a colour for a dark or mid-tone surface moves every failing colour towards the same
 * few lightness values, so two blues that differ on white can end up identical on a dark card. Colours that
 * already have >= 3:1 contrast against `fill` are kept exactly. A colour the contrast adjustment would move is
 * placed again on the lightness axis, keeping its hue and as much of its chroma as sRGB allows, subject to
 * >= 3:1 contrast against `fill` and these separations from the other series (each capped at the separation
 * that pair had in `palette`, so a pair the palette itself made close is not asked to be far apart):
 *
 * - a colour difference (CIE76) of at least {@link CHART_SERIES_MIN_DIFFERENCE} from every other series;
 * - a lightness step of at least {@link CHART_SERIES_MIN_LIGHTNESS_STEP} (CIE L*) from the neighbouring
 *   series, which is what keeps neighbours apart on a greyscale print;
 * - the same lightness step from the remaining series, as a weaker aim.
 *
 * Series are placed in order against the kept colours and the colours placed before them. The palette is read in tiers of
 * {@link CHART_SERIES_TIER_SIZE} (series 1 to 6, 7 to 12, ...): a colour is separated from the colours of its own and earlier tiers only,
 * so the later tiers (the tints of `chartSeriesPalette`) are placed around the first six without ever pulling them towards a lightness
 * the tints already hold. A palette of six colours or fewer is one tier. The placement
 * with the lowest cost wins: its distance (in L*) from the contrast-adjusted colour plus a penalty for
 * every point it falls short of those separations, so a colour that is already clear of the others is
 * simply the adjusted colour, a near miss is not worth a large change, and a collision is resolved at the
 * nearest lightness that clears it. The result is deterministic and in series order. An unresolved or
 * translucent fill or colour is passed through, like `chartColorForFill`.
 *
 * On a dark `fill` the series `options.legible` lists (the scheme's, {@link chartSchemeSeries}) take {@link CHART_DARK_SERIES_MIN_CONTRAST}
 * (4.5:1) in place of 3:1 throughout: series 1 is lifted to it first (with {@link legible}, keeping its hue) and kept, the others are adjusted
 * and placed against that floor, and series 2 keeps {@link CHART_LEAD_LIGHTNESS_STEP} (L*) from series 1 even where it already had the
 * contrast (LH-55: the second default blue on navy was 3.0:1 and nine L* from the first).
 *
 * It depends only on the surface and the palette, so every chart on a surface gets the same series colours,
 * and preview and export (which both call this function) draw the same ones.
 */
export function chartPaletteForFill(fill: string, palette: readonly string[], options: ChartPaletteOptions = {}): string[] {
  const opaqueFill = colorContrast(fill, fill) !== undefined;
  // WI-5 and LH-55: on a dark surface a series from the scheme reaches 4.5:1 (the default blues on navy were 3.42:1 and 3.0:1); any other series, and every
  // series on a light surface, 3:1.
  const darkFill = opaqueFill && isDarkColor(fill), surface = normalizeHexColor(fill)!;
  const legibleAt = (index: number) => darkFill && options.legible?.[index] === true && opaqueChannels(palette[index]!) !== undefined;
  const floorOf = (index: number) => legibleAt(index) ? CHART_DARK_SERIES_MIN_CONTRAST : 3;
  // Series 1 is lifted first and kept; the other series are placed around it.
  if (legibleAt(0)) palette = [legible(normalizeHexColor(palette[0])!, surface, CHART_DARK_SERIES_MIN_CONTRAST), ...palette.slice(1)];
  // LH-55: series 2 keeps a lightness step of 20 from series 1 when both are the scheme's, so the first two series never read as one blue.
  const leadPair = legibleAt(0) && legibleAt(1);
  const isLeadPair = (a: number, b: number) => leadPair && Math.min(a, b) === 0 && Math.max(a, b) === 1;
  const preferredLab = palette.map(color => { const channels = opaqueChannels(color); return channels ? labOf(channels) : undefined; });
  const adjusted = palette.map((color, index) => legibleAt(index) ? legible(normalizeHexColor(color)!, surface, CHART_DARK_SERIES_MIN_CONTRAST) : chartColorForFill(fill, color));
  const adjustedLab = adjusted.map(color => { const channels = opaqueChannels(color); return channels ? labOf(channels) : undefined; });
  // Colours the surface keeps stay put; only the ones it moves are placed again (and series 2 when it sits too close to series 1).
  const kept = palette.map((color, index) => opaqueFill && preferredLab[index] !== undefined && adjusted[index] === color
    && !(index === 1 && leadPair && Math.abs(adjustedLab[0]![0] - adjustedLab[1]![0]) < CHART_LEAD_LIGHTNESS_STEP));
  const placed: (string | undefined)[] = palette.map((_, index) => kept[index] || !opaqueFill || !preferredLab[index] ? adjusted[index] : undefined);
  const placedLab: (Lab | undefined)[] = placed.map(color => { const channels = color === undefined ? undefined : opaqueChannels(color); return channels ? labOf(channels) : undefined; });
  palette.forEach((_, index) => {
    const wanted = preferredLab[index], base = adjusted[index]!;
    if (placed[index] !== undefined || !wanted) return;
    const baseLab = labOf(opaqueChannels(base)!);
    // The separation every placed series must keep from this one: what the palette itself had, capped at the floor (series 1 and 2 of a
    // dark scheme chart: the full lead step, whatever the palette had).
    const needs = palette.flatMap((_, other) => {
      const before = preferredLab[other], lab = placedLab[other];
      return other !== index && tierOf(other) <= tierOf(index) && before && lab && placed[other] !== undefined
        ? [{ lab, adjacent: Math.abs(other - index) === 1, wide: Math.min(labDifference(before, wanted), CHART_SERIES_MIN_DIFFERENCE), step: isLeadPair(index, other) ? CHART_LEAD_LIGHTNESS_STEP : Math.min(Math.abs(before[0] - wanted[0]), CHART_SERIES_MIN_LIGHTNESS_STEP) }]
        : [];
    });
    // How far a candidate is from the required separations (>= 0 when it meets them): the colour difference from every
    // series and the lightness step from the neighbours first, then the lightness step from the others.
    const shortfall = (candidate: Lab): { near: number; far: number } => needs.reduce((worst, need) => {
      const lightness = Math.abs(need.lab[0] - candidate[0]) - need.step, difference = labDifference(need.lab, candidate) - need.wide;
      return need.adjacent ? { near: Math.min(worst.near, difference, lightness), far: worst.far } : { near: Math.min(worst.near, difference), far: Math.min(worst.far, lightness) };
    }, { near: Infinity, far: Infinity });
    // Cost of a placement: how far it moves from the adjusted colour, plus a penalty for every point it falls short
    // of the required separations (neighbours and colour difference count most). Cheapest wins; ties keep the nearer one.
    const deficit = (value: number) => Math.max(0, -value - 1e-9);
    const cost = (candidate: { moved: number; near: number; far: number }) => candidate.moved + CHART_SERIES_SHORTFALL_WEIGHT * deficit(candidate.near) + deficit(candidate.far);
    const start = shortfall(baseLab);
    if (deficit(start.near) === 0 && deficit(start.far) === 0) { placed[index] = base; placedLab[index] = baseLab; return; }
    // Re-place the colour on the lightness axis, around where the surface adjustment left it.
    let best: { color: string; lab: Lab; cost: number; moved: number } | undefined = { color: base, lab: baseLab, cost: cost({ moved: 0, ...start }), moved: 0 };
    for (let step = 0; step <= 400; step++) {
      const color = labWithLightness(step / 4, wanted[1], wanted[2]), contrast = colorContrast(color, fill);
      if (contrast === undefined || contrast < floorOf(index)) continue;
      const lab = labOf(opaqueChannels(color)!);
      // LH-55: the lead step is a requirement, not a cost: no other separation buys series 2 a place closer to series 1.
      if (index === 1 && leadPair && Math.abs(lab[0] - placedLab[0]![0]) < CHART_LEAD_LIGHTNESS_STEP) continue;
      const moved = Math.abs(lab[0] - baseLab[0]), total = cost({ moved, ...shortfall(lab) });
      if (total < best.cost - 1e-9 || (Math.abs(total - best.cost) <= 1e-9 && moved < best.moved)) best = { color, lab, cost: total, moved };
    }
    placed[index] = best.color;
    placedLab[index] = best.lab;
  });
  const result = opaqueFill ? separateNeighbors(fill, placed as string[], { legible: options.legible, floor: floorOf }) : placed as string[];
  return options.soften && opaqueFill ? softenChartPalette(fill, result, { legible: options.legible, floor: floorOf, lead: leadPair }) : result;
}

/** LH-94: the margin over {@link CHART_SERIES_MIN_LIGHTNESS_STEP} a neighbor is placed at, so a step still reads 11 L* after hex rounding. */
const NEIGHBOR_STEP_MARGIN = 0.4;

/**
 * LH-94: every series from the scheme (`legible`) stands at least {@link CHART_SERIES_MIN_LIGHTNESS_STEP} CIE L* from the series before it,
 * whatever the scheme's own accents were (steel-blue's fifth and sixth accent differ by 0.2 L*, black-and-white's third and fourth by 8): a
 * series that is closer is moved along the lightness axis (its hue and as much of its chroma as sRGB allows kept) to the nearest lightness
 * that keeps its contrast floor, the step from both neighbors and, as a cost, a color difference of at least
 * {@link CHART_SERIES_MIN_DIFFERENCE} from every other series. In series order, so a move is judged against the neighbor already settled;
 * an authored color (not in `legible`) is never moved, so `opf/chart-color-only` still reports the pair an author chose.
 */
function separateNeighbors(fill: string, palette: readonly string[], options: { legible?: readonly boolean[]; floor: (index: number) => number }): string[] {
  const result = [...palette];
  const labs = result.map(color => { const channels = opaqueChannels(color); return channels ? labOf(channels) : undefined; });
  const need = CHART_SERIES_MIN_LIGHTNESS_STEP + NEIGHBOR_STEP_MARGIN;
  for (let index = 1; index < result.length; index++) {
    const lab = labs[index], before = labs[index - 1];
    if (options.legible?.[index] !== true || !lab || !before || Math.abs(lab[0] - before[0]) >= CHART_SERIES_MIN_LIGHTNESS_STEP) continue;
    const after = labs[index + 1];
    const deficit = (value: number) => Math.max(0, -value - 1e-9);
    let best: { color: string; lab: Lab; cost: number } | undefined;
    for (let step = 0; step <= 400; step++) {
      const color = labWithLightness(step / 4, lab[1], lab[2]), contrast = colorContrast(color, fill);
      if (contrast === undefined || contrast < options.floor(index)) continue;
      const candidate = labOf(opaqueChannels(color)!);
      if (Math.abs(candidate[0] - before[0]) < need) continue;
      // The nearest lightness wins; falling short of the step from the next series (settled after this one) or of the color difference
      // from any other series costs more the further it falls.
      let cost = Math.abs(candidate[0] - lab[0]);
      if (after) cost += CHART_SERIES_SHORTFALL_WEIGHT * deficit(Math.abs(candidate[0] - after[0]) - need);
      labs.forEach((other, at) => { if (other && at !== index && at !== index - 1 && (at < index || options.legible?.[at] !== true)) cost += deficit(labDifference(candidate, other) - CHART_SERIES_MIN_DIFFERENCE); });
      if (!best || cost < best.cost - 1e-9) best = { color, lab: candidate, cost };
    }
    if (best) { result[index] = best.color; labs[index] = best.lab; }
  }
  return result;
}

/** LH-161: the most a pie's last slice moves along the lightness axis to clear the first: further and it stops belonging to the palette. */
export const CHART_SLICE_MAX_SHIFT = 20;
/** LH-161: the width of the surface-colored border that separates a pie's wrap pair when no color within {@link CHART_SLICE_MAX_SHIFT} does, in pixels at the 720-px reference. */
export const CHART_SLICE_SEPARATOR_PX = 2;

/** LH-161: the slices of a pie or doughnut: their colors, and whether the chart separates every slice with a surface-colored border. */
export interface ChartSlicePlan { colors: string[]; bordered: boolean }

/**
 * LH-161: the colors of a pie or doughnut of `count` slices, from `palette` (the colors a chart draws, {@link chartPaletteForFill} with
 * its softening). A circle has one more neighbor pair than a row of series: the last slice sits beside the first. When the last slice
 * (palette color `count - 1`, a color from the scheme: `options.legible`) is closer than {@link CHART_SERIES_MIN_LIGHTNESS_STEP} CIE L*
 * to the first, it alone moves, along the lightness axis (its hue and as much chroma as sRGB allows kept) by at most
 * {@link CHART_SLICE_MAX_SHIFT} L*, to the nearest lightness that keeps its contrast floor against `fill` and the step from both its
 * neighbors (a color difference under {@link CHART_SERIES_MIN_DIFFERENCE} from any other slice costs more the further it falls). Where no
 * such lightness exists the palette color stays and `bordered` is true: the engines draw a {@link CHART_SLICE_SEPARATOR_PX} border in
 * the surface color on every slice of the chart, which separates the pair by shape (`opf/chart-color-only` accepts it). Every other color
 * stays, so a pie of any count draws the palette except possibly its last slice. An authored color is never moved or bordered (the rule
 * reports the pair an author chose), and fewer than three slices, or more than the palette holds (the colors repeat), change nothing.
 */
export function chartSlicePlan(fill: string, palette: readonly string[], count: number, options: { legible?: readonly boolean[] } = {}): ChartSlicePlan {
  const result = [...palette], last = count - 1, none = { colors: result, bordered: false };
  if (!Number.isInteger(count) || count < 3 || count > palette.length || options.legible?.[last] !== true || colorContrast(fill, fill) === undefined) return none;
  const labs = result.map(color => { const channels = opaqueChannels(color); return channels ? labOf(channels) : undefined; });
  const lab = labs[last], first = labs[0], before = labs[last - 1];
  if (!lab || !first || !before || Math.abs(lab[0] - first[0]) >= CHART_SERIES_MIN_LIGHTNESS_STEP) return none;
  const floor = isDarkColor(fill) ? CHART_DARK_SERIES_MIN_CONTRAST : 3, need = CHART_SERIES_MIN_LIGHTNESS_STEP + NEIGHBOR_STEP_MARGIN;
  const deficit = (value: number) => Math.max(0, -value - 1e-9);
  let best: { color: string; cost: number } | undefined;
  for (let step = 0; step <= 400; step++) {
    const color = labWithLightness(step / 4, lab[1], lab[2]), contrast = colorContrast(color, fill);
    if (contrast === undefined || contrast < floor) continue;
    const candidate = labOf(opaqueChannels(color)!);
    if (Math.abs(candidate[0] - lab[0]) > CHART_SLICE_MAX_SHIFT || Math.abs(candidate[0] - first[0]) < need || Math.abs(candidate[0] - before[0]) < need) continue;
    let cost = Math.abs(candidate[0] - lab[0]);
    labs.slice(0, count - 1).forEach(other => { if (other) cost += deficit(labDifference(candidate, other) - CHART_SERIES_MIN_DIFFERENCE); });
    if (!best || cost < best.cost - 1e-9) best = { color, cost };
  }
  if (!best) return { colors: result, bordered: true };
  result[last] = best.color;
  return { colors: result, bordered: false };
}

/** LH-105: the share of the backdrop mixed into an ordinary series colour from the scheme (Few: soft colours for ordinary data, strong for emphasis). */
export const CHART_SERIES_SOFT_MIX = 0.25;

/** LH-105: a softened series colour and the DrawingML HSL transforms (thousandths of a percent) that make it of its full-strength colour. */
export interface ChartSoftColor { hex: string; satMod: number; lumMod?: number; lumOff?: number }

/**
 * LH-105: the colour DrawingML's HSL transforms make of `hex`: its saturation times `satMod`, its lightness times `lumMod` plus `lumOff`
 * (thousandths of a percent, each clamped to 0 to 1), as PowerPoint applies `<a:satMod>`, `<a:lumMod>` and `<a:lumOff>` to a scheme colour.
 */
export function applyHslTransforms(hex: string, transforms: { satMod?: number; lumMod?: number; lumOff?: number }): string {
  const channels = opaqueChannels(hex);
  if (!channels) return hex;
  const [h, s, l] = rgbToHsl(channels);
  const clamp = (value: number) => Math.min(1, Math.max(0, value));
  return hexOfChannels(hslToRgb([h, clamp(s * (transforms.satMod ?? 100000) / 100000), clamp(l * (transforms.lumMod ?? 100000) / 100000 + (transforms.lumOff ?? 0) / 100000)]));
}

function softTransforms(fill: string, palette: readonly string[], options: { legible?: readonly boolean[]; floor?: (index: number) => number; lead?: boolean }): (ChartSoftColor | undefined)[] {
  const backdrop = opaqueChannels(fill);
  if (!backdrop) return palette.map(() => undefined);
  const lightness = (color: string | undefined) => { const channels = color === undefined ? undefined : opaqueChannels(color); return channels ? labOf(channels)[0] : undefined; };
  const placedL = palette.map(lightness);
  const soft: (ChartSoftColor | undefined)[] = palette.map(() => undefined);
  const current = (index: number) => soft[index]?.hex ?? palette[index];
  palette.forEach((color, index) => {
    const from = opaqueChannels(color);
    if (!from || options.legible?.[index] !== true) return;
    const floor = options.floor?.(index) ?? 3;
    const steps = [index - 1, index + 1].filter(other => other >= 0 && other < palette.length && placedL[other] !== undefined).map(other => ({
      other,
      step: Math.min(Math.abs(placedL[index]! - placedL[other]!), options.lead && Math.min(index, other) === 0 && Math.max(index, other) === 1 ? CHART_LEAD_LIGHTNESS_STEP : CHART_SERIES_MIN_LIGHTNESS_STEP),
    }));
    for (let percent = Math.round(CHART_SERIES_SOFT_MIX * 100); percent > 0; percent--) {
      // The colour's HSL lightness moved `percent` of the way to the backdrop's, as a lumMod/lumOff pair: the transform the PPTX export
      // writes on the accent's theme colour (as the neutrals are written, RR-96), so re-theming in PowerPoint keeps the soft series.
      // Its HSL saturation is lowered by the same share (satMod), so the soft colour is quieter, not only lighter.
      const base = normalizeHexColor(color)!.slice(0, 7), move = mixTowardsBackground('', base, normalizeHexColor(fill)!.slice(0, 7), 1 - percent / 100);
      if (move.lumMod === undefined && move.lumOff === undefined) continue;
      const satMod = 100000 - percent * 1000, hex = applyHslTransforms(base, { satMod, lumMod: move.lumMod, lumOff: move.lumOff });
      if ((colorContrast(hex, fill) ?? 0) < floor - 1e-9) continue;
      const l = lightness(hex)!;
      if (steps.some(({ other, step }) => Math.abs(l - lightness(current(other))!) < step - 1e-9)) continue;
      soft[index] = { hex, satMod, ...(move.lumMod !== undefined ? { lumMod: move.lumMod } : {}), ...(move.lumOff !== undefined ? { lumOff: move.lumOff } : {}) };
      return;
    }
  });
  return soft;
}

/**
 * LH-105: the soft series colours of a palette already placed for `fill` ({@link chartPaletteForFill}). Each series `legible` lists (the
 * scheme's; an authored colour stays as written) has its HSL lightness moved {@link CHART_SERIES_SOFT_MIX} of the way towards the
 * backdrop's (a DrawingML lumMod/lumOff pair on the colour, which keeps its hue and saturation), or less (in steps of 1%) when the full
 * move would take it under its contrast floor against `fill` (`floor`: 3:1, or 4.5:1 for a scheme series on a dark fill) or closer in
 * lightness to a neighbouring series than the placed palette had them, capped at {@link CHART_SERIES_MIN_LIGHTNESS_STEP} (series 1 and 2
 * of a dark scheme chart: {@link CHART_LEAD_LIGHTNESS_STEP}, `lead`). The neighbours are the series before (already softened) and after
 * (still placed). A colour no move keeps within those bounds stays at full strength. In series order and deterministic.
 */
export function softenChartPalette(fill: string, palette: readonly string[], options: { legible?: readonly boolean[]; floor?: (index: number) => number; lead?: boolean } = {}): string[] {
  return softTransforms(fill, palette, options).map((soft, index) => soft?.hex ?? palette[index]!);
}

/**
 * LH-105: the transform of each softened series of `chartPaletteForFill(fill, palette, {...options, soften: true})`, or undefined for a series
 * drawn at full strength: the PPTX export writes a softened scheme accent as `<a:schemeClr val="accentN"><a:lumMod/><a:lumOff/></a:schemeClr>`.
 */
export function chartSoftColors(fill: string, palette: readonly string[], options: ChartPaletteOptions = {}): (ChartSoftColor | undefined)[] {
  const placed = chartPaletteForFill(fill, palette, { legible: options.legible });
  const dark = colorContrast(fill, fill) !== undefined && isDarkColor(fill);
  const legibleAt = (index: number) => dark && options.legible?.[index] === true && opaqueChannels(palette[index]!) !== undefined;
  return softTransforms(fill, placed, { legible: options.legible, floor: index => legibleAt(index) ? CHART_DARK_SERIES_MIN_CONTRAST : 3, lead: legibleAt(0) && legibleAt(1) });
}

/**
 * LH-105: the colour of a series' direct label (its name at the end of its line): the series colour at full strength, made legible as
 * text on `backdrop` (4.5:1, WCAG 1.4.3) by moving its lightness only, so the label keeps the hue of its line.
 */
export function chartSeriesLabelColor(backdrop: string, color: string): string {
  const fill = normalizeHexColor(backdrop)?.slice(0, 7), base = normalizeHexColor(color)?.slice(0, 7);
  if (!fill || !base) return base ?? color;
  return legible(base.toUpperCase(), fill.toUpperCase(), 4.5);
}

// --------------------------------------------------------------- chart series palette (RR-89)

/** Share of white mixed into each accent to make the extended tints of {@link chartSeriesPalette} (series 7 to 12). */
export const CHART_SERIES_TINT_MIX = 0.4;

/**
 * The series colours of a chart before the per-surface adjustment: twelve opaque #RRGGBB colours in series order, taken from the deck's
 * resolved colour scheme (`design.colorScheme` after the theme, the record and any inline overrides are applied).
 *
 * - 1 to 6: `accent1` to `accent6`. A slot the scheme leaves out takes the engine default scheme's slot.
 * - 7 to 12: the same six accents mixed {@link CHART_SERIES_TINT_MIX} of the way towards white, in the same order (a tint of `accent1`
 *   is series 7), for charts with more than six series.
 *
 * Pass the result to {@link chartPaletteForFill} with the chart panel colour for the colours a chart draws and writes: contrast against
 * the panel without letting two series merge. Series `i` takes colour `i`; a pie, doughnut, treemap or funnel takes colour `i` for
 * category `i`. The colours depend on the scheme only, so the preview, the PPTX export and the colour-blind rule draw the same ones.
 * The role overrides (`primary`, `secondary`, `accent`) do not change the list: series 1 to 3 are always `accent1` to `accent3`, the
 * theme slots the PPTX export writes as `schemeClr accentN`.
 *
 * RR-89: `colors` is the chart's own `chart.colors` (positional ColorRefs). Entry `i` replaces palette colour `i`; an entry that cannot
 * be resolved ({@link resolveChartColors}) keeps the scheme colour, and entries past the twelfth extend the list. `context` carries the
 * deck's roles and `variables` for entries that name them.
 */
export function chartSeriesPalette(colorScheme: Record<string, unknown> = {}, colors?: unknown, context: ChartColorContext = {}): string[] {
  const order = context.accents && context.accents.length === 6 && ACCENT_SLOTS.every(slot => context.accents!.includes(slot)) ? context.accents : ACCENT_SLOTS;
  const accents = order.map(slot => {
    return normalizeHexColor(colorScheme?.[slot]) ?? normalizeHexColor(ENGINE_DEFAULT_COLOR_SCHEME[slot]) ?? '#000000';
  });
  const palette = [...accents, ...accents.map(accent => mixChannels(opaqueChannels(accent)!, [255, 255, 255], CHART_SERIES_TINT_MIX))];
  resolveChartColors(colors, colorScheme, context).forEach((color, index) => {
    if (color === undefined) return;
    // An entry past the twelve palette colours extends the list; a gap before it keeps the scheme colour of its position.
    while (palette.length < index) palette.push(palette[palette.length % 12]!);
    palette[index] = color;
  });
  return palette;
}

/**
 * Which series of a chart come from the deck scheme rather than from an authored `chart.colors` entry, in series order: entry `i` is true
 * when `colors[i]` is absent or cannot be resolved, so the series keeps the scheme colour of its position. These are the series
 * {@link chartPaletteForFill} lifts to 4.5:1 on a dark surface (`options.legible`). The list covers the palette {@link chartSeriesPalette}
 * returns for the same arguments (twelve entries, more when `colors` is longer).
 */
export function chartSchemeSeries(colors: unknown, colorScheme: Record<string, unknown> = {}, context: ChartColorContext = {}): boolean[] {
  const resolved = resolveChartColors(colors, colorScheme, context);
  return Array.from({ length: Math.max(12, resolved.length) }, (_, index) => resolved[index] === undefined);
}

/** What a `chart.colors` entry resolves against: the deck's role colours and `variables`, as for any ColorRef. */
export interface ChartColorContext {
  /** RR-96: the variant's accent order (`roles.map.accents`): series 1 to 6 take these slots in this order. Default: accent1 to accent6. */
  accents?: readonly ColorAccentSlot[];
  roles?: ResolveColorRefRoles;
  variables?: Record<string, unknown>;
}

/**
 * The opaque #RRGGBB colour of each `chart.colors` entry (a hex colour, a colour-scheme slot or role, or a `var:<id>` variable), in
 * order; undefined for an entry that is not a string or cannot be resolved (an unknown variable, a name that is not a colour). Alpha is
 * dropped. `colors` that is not an array resolves to an empty list.
 */
export function resolveChartColors(colors: unknown, colorScheme: Record<string, unknown> = {}, context: ChartColorContext = {}): (string | undefined)[] {
  if (!Array.isArray(colors)) return [];
  return colors.map(entry => {
    // SH-02: the lighter or darker form of a ColorRef resolves its base and applies its transform.
    const transform = colorTransform(entry);
    if (transform) { const base = resolveChartColors([transform.color], colorScheme, context)[0]; return base === undefined ? undefined : normalizeHexColor(applyColorTransform(base, transform)); }
    if (typeof entry !== 'string') return undefined;
    const resolved = resolveColorRef(entry.trim(), { colorScheme, roles: context.roles, variables: context.variables, fallback: '' });
    return normalizeHexColor(resolved);
  });
}

// --------------------------------------------------------------- chart highlight (FA-14)

/** Share of the text colour mixed into the surface to make the muted colour of a highlighted chart. */
export const CHART_HIGHLIGHT_MUTED_MIX = 0.3;
/** Smallest contrast the muted colour keeps against the surface: recessive, but still a visible mark. */
export const CHART_HIGHLIGHT_MUTED_MIN_CONTRAST = 1.6;

const mixChannels = (from: readonly number[], to: readonly number[], amount: number): string =>
  hexOfChannels(from.map((channel, index) => channel + (to[index]! - channel) * amount));

/** LH-105: the colour difference (CIE76) a context gray keeps from every focused colour. */
export const CHART_CONTEXT_FOCUS_DIFFERENCE = 20;

/** LH-105: the contrast the context colour of a focused chart keeps against its backdrop (a mark is a graphical object, WCAG 1.4.11). */
export const CHART_CONTEXT_MIN_CONTRAST = 3;

/**
 * LH-105: the contrast the context colour keeps when every context mark carries its value or name as text (a small chart's value labels,
 * the names at the line ends, the names on the slices): WCAG 1.4.11 does not ask 3:1 of a graphic whose information the text gives, so the
 * context can be the light neutral Few draws, still clearly visible.
 */
export const CHART_CONTEXT_LABELED_MIN_CONTRAST = 1.6;

/**
 * LH-105: the neutral of the marks a chart does not focus on (the title names other series or categories, chart-focus.ts): the backdrop
 * mixed towards the text colour (tx1), from {@link CHART_HIGHLIGHT_MUTED_MIX} in 2% steps until it reaches
 * {@link CHART_CONTEXT_MIN_CONTRAST} against the backdrop. A grey in the backdrop's own hue, quieter than the text, visible as a mark.
 * The first of {@link chartContextColors}.
 */
export function chartContextColor(surface: string, text: string): string {
  return chartContextColors(surface, text, 1)[0]!;
}

/**
 * LH-105: the neutrals of `count` context series (or slices) of a focused chart, in the order the context series come: grays in the
 * backdrop's hue, the backdrop mixed towards the text colour. The lightest step is the first mix (from {@link CHART_HIGHLIGHT_MUTED_MIX}, or from the backdrop when `labeled`, in
 * 1% steps) that reaches the contrast floor against the backdrop ({@link CHART_CONTEXT_MIN_CONTRAST}, or
 * {@link CHART_CONTEXT_LABELED_MIN_CONTRAST} when `labeled`: every context mark carries its text) and keeps a colour difference of
 * {@link CHART_CONTEXT_FOCUS_DIFFERENCE} (CIE76) from each `avoid` colour (the focused colours: a gray stands apart from a coloured focus by
 * its chroma); each further step is the next mix that stands {@link CHART_SERIES_MIN_LIGHTNESS_STEP} L* from the one before and keeps that
 * difference from the `avoid` colours. The first context series takes the strongest step and the last the lightest,
 * so neighbouring context series (stacked segments, slices) are told apart by lightness, as the focused series are by hue. When the mix
 * runs out of room (a dark text colour close to the backdrop), the remaining series repeat the strongest step.
 */
export function chartContextColors(surface: string, text: string, count: number, options: { labeled?: boolean; avoid?: readonly string[] } = {}): string[] {
  const fill = normalizeHexColor(surface)?.slice(0, 7) ?? '#FFFFFF';
  const ink = normalizeHexColor(text)?.slice(0, 7) ?? textColorForFill(fill, '#000000');
  const from = opaqueChannels(fill)!, to = opaqueChannels(ink)!;
  const floor = options.labeled ? CHART_CONTEXT_LABELED_MIN_CONTRAST : CHART_CONTEXT_MIN_CONTRAST;
  const lightness = (hex: string) => labOf(opaqueChannels(hex)!)[0];
  const avoid = (options.avoid ?? []).flatMap(color => { const hex = normalizeHexColor(color)?.slice(0, 7); return hex && opaqueChannels(hex) ? [labOf(opaqueChannels(hex)!)] : []; });
  const steps: string[] = [];
  // Labeled, the context may be as light as its floor allows: the search starts at the backdrop itself.
  for (let percent = options.labeled ? 1 : Math.round(CHART_HIGHLIGHT_MUTED_MIX * 100); percent <= 100 && steps.length < Math.max(1, count); percent++) {
    const candidate = mixChannels(from, to, percent / 100), l = lightness(candidate);
    if ((colorContrast(candidate, fill) ?? Infinity) < floor) continue;
    // A gray is told from a coloured focus by its chroma as much as by its lightness: it keeps a colour difference (CIE76) of
    // CHART_CONTEXT_FOCUS_DIFFERENCE from every focused colour, which near a gray-ish focus means as many L*.
    if (avoid.some(other => labDifference(other, labOf(opaqueChannels(candidate)!)) < CHART_CONTEXT_FOCUS_DIFFERENCE)) continue;
    if (steps.length && Math.abs(lightness(steps[steps.length - 1]!) - l) < CHART_SERIES_MIN_LIGHTNESS_STEP) continue;
    steps.push(candidate);
  }
  // Out of room: the floor alone (no step met the separations), else the strongest step for the rest.
  if (!steps.length) steps.push(chartContextFloor(from, to, fill, floor));
  while (steps.length < Math.max(1, count)) steps.push(steps[steps.length - 1]!);
  return steps.slice(0, Math.max(1, count)).reverse();
}

/**
 * LH-107: the three colors of a waterfall by role (Claude Design and Few: the totals carry the story, the gains the accent, the losses
 * stand back). `increase` is the series color at full strength (`accent`). `total` is the strong color: the scheme's `dark2` when it keeps
 * 3:1 against the backdrop and a color difference of {@link CHART_CONTEXT_FOCUS_DIFFERENCE} (CIE76) from the accent, else the text
 * color (made legible on the backdrop: the strong neutral on a dark slide). `decrease` is the first context neutral
 * ({@link chartContextColors}), kept apart from the other two; `labeled` (every bar carries its signed value) lets it be the light gray.
 */
export function chartWaterfallColors(surface: string, accent: string, text: string, strong: string | undefined, options: { labeled?: boolean } = {}): { total: string; increase: string; decrease: string } {
  const fill = normalizeHexColor(surface)?.slice(0, 7) ?? '#FFFFFF';
  const increase = normalizeHexColor(accent)?.slice(0, 7) ?? chartColorForFill(fill, '#000000');
  const ink = textColorForFill(fill, normalizeHexColor(text)?.slice(0, 7) ?? '#000000');
  const candidate = normalizeHexColor(strong)?.slice(0, 7);
  const apart = (hex: string) => labDifference(labOf(opaqueChannels(hex)!), labOf(opaqueChannels(increase)!)) >= CHART_CONTEXT_FOCUS_DIFFERENCE;
  const total = candidate && opaqueChannels(candidate) && (colorContrast(candidate, fill) ?? 0) >= CHART_CONTEXT_MIN_CONTRAST && apart(candidate) ? candidate : ink;
  const decrease = chartContextColors(fill, ink, 1, { labeled: options.labeled === true, avoid: [increase, total] })[0]!;
  return { total, increase, decrease };
}

/** LH-110: how far the shaded band of a period the title names is mixed from the backdrop towards the text color. */
export const CHART_BAND_MIX = 0.06;

/** LH-110: the fill of a period band: the backdrop mixed {@link CHART_BAND_MIX} towards the text color, a faint neutral under the marks. */
export function chartBandColor(surface: string, text: string): string {
  const fill = normalizeHexColor(surface)?.slice(0, 7) ?? '#FFFFFF';
  const ink = normalizeHexColor(text)?.slice(0, 7) ?? textColorForFill(fill, '#000000');
  return mixChannels(opaqueChannels(fill)!, opaqueChannels(ink)!, CHART_BAND_MIX);
}

function chartContextFloor(from: readonly number[], to: readonly number[], fill: string, floor: number): string {
  let amount = CHART_HIGHLIGHT_MUTED_MIX, muted = mixChannels(from, to, amount);
  while ((colorContrast(muted, fill) ?? Infinity) < floor && amount < 1) {
    amount = Math.min(1, amount + 0.02);
    muted = mixChannels(from, to, amount);
  }
  return muted;
}

/**
 * The two colours of a chart that highlights marks (`chart.highlight`), derived from the theme only: `accent` for the highlighted
 * marks, `muted` for every other mark.
 *
 * - `accent` is the deck's primary colour, kept at >= 3:1 against the surface by `chartColorForFill` (a primary that already has
 *   that contrast is returned unchanged).
 * - `muted` is the surface mixed {@link CHART_HIGHLIGHT_MUTED_MIX} of the way towards the text colour: a light grey on a light surface
 *   and a dim grey on a dark one, in the surface's own hue. When that falls below {@link CHART_HIGHLIGHT_MUTED_MIN_CONTRAST} against
 *   the surface (a surface and text that are close together) the mix moves towards the text colour until it holds.
 *
 * Pure arithmetic on opaque colours: the preview and the PPTX export both call it with the chart panel, the primary and the label
 * colour, so they draw and write the same two colours. An unresolved colour is replaced by white (surface), the surface's own
 * best contrast partner (text) or black (primary).
 */
export function chartHighlightColors(surface: string, primary: string, text: string): { accent: string; muted: string } {
  const fill = normalizeHexColor(surface) ?? '#FFFFFF';
  const accent = chartColorForFill(fill, normalizeHexColor(primary) ?? '#000000');
  const ink = normalizeHexColor(text) ?? textColorForFill(fill, '#000000');
  const from = opaqueChannels(fill)!, to = opaqueChannels(ink)!;
  let muted = mixChannels(from, to, CHART_HIGHLIGHT_MUTED_MIX);
  for (let amount = CHART_HIGHLIGHT_MUTED_MIX; (colorContrast(muted, fill) ?? Infinity) < CHART_HIGHLIGHT_MUTED_MIN_CONTRAST && amount < 1; ) {
    amount = Math.min(1, amount + 0.02);
    muted = mixChannels(from, to, amount);
  }
  return { accent, muted };
}

/** LH-03: smallest contrast every mark of an emphasised small chart keeps against its backdrop: a bar is a graphical object (WCAG 1.4.11, 3:1). */
export const CHART_EMPHASIS_MIN_CONTRAST = 3;
/** LH-03: smallest CIE L* step between the emphasised mark and the other marks, so the emphasis is visible. */
export const CHART_EMPHASIS_MIN_LIGHTNESS_STEP = 15;

/**
 * LH-03, LH-95: the two colours of a small chart's emphasis, in the shape of a highlight: `accent` for the emphasised point, `muted` for
 * every other point. The other points keep the series colour (`color`, already adjusted for the backdrop by `chartPaletteForFill`), and
 * the emphasised point takes a stronger shade of it: the series colour mixed away from the backdrop (towards black on a light backdrop,
 * towards white on a dark one) just far enough to stand {@link CHART_EMPHASIS_MIN_LIGHTNESS_STEP} L* from it. Moving away from the
 * backdrop only raises the contrast, so the shade keeps the series colour's. A series colour too close to black (or white) for that
 * step is shaded the other way instead, while the shade keeps {@link CHART_EMPHASIS_MIN_CONTRAST} against the backdrop.
 *
 * LH-105: `strong` is the series colour at full strength when `color` is its soft form ({@link softenChartPalette}). The emphasised point
 * then takes the full-strength colour itself when that already stands the step from the soft one, and a shade of it otherwise, so the
 * strong colour is kept for the emphasis.
 *
 * A faded tint of the other points (LH-03's first rule) needed room between the series colour and the backdrop, and emphasised only 36
 * of the 84 gallery theme x scheme x variant charts; a stronger shade has room in all of them. Undefined only for an unresolved colour or
 * when neither direction keeps both floors. The preview and the PPTX export call it with the same pair.
 */
export function chartEmphasisColors(surface: string, color: string, strong?: string): { accent: string; muted: string } | undefined {
  const fill = (normalizeHexColor(surface) ?? '#FFFFFF').slice(0, 7);
  const base = (normalizeHexColor(color) ?? '#000000').slice(0, 7).toUpperCase();
  const full = strong === undefined ? undefined : normalizeHexColor(strong)?.slice(0, 7).toUpperCase();
  const from = opaqueChannels(base), start = full !== undefined && full !== base ? opaqueChannels(full) : from, backdrop = luminance(fill), own = luminance(base);
  if (!from || !start || backdrop === undefined || own === undefined) return undefined;
  const lightness = labOf(from)[0];
  const black: [number, number, number] = [0, 0, 0], white: [number, number, number] = [255, 255, 255];
  for (const target of backdrop >= own ? [black, white] : [white, black]) {
    for (let step = start === from ? 1 : 0; step <= 100; step++) {
      const shade = mixChannels(start, target, step / 100).toUpperCase();
      // Towards the backdrop the contrast only falls: once it is under the floor, no further step holds it.
      if ((colorContrast(shade, fill) ?? 0) < CHART_EMPHASIS_MIN_CONTRAST) break;
      if (Math.abs(labOf(opaqueChannels(shade)!)[0] - lightness) >= CHART_EMPHASIS_MIN_LIGHTNESS_STEP) return { accent: shade, muted: base };
    }
  }
  return undefined;
}

// --------------------------------------------------------------- alternate surface (banded table rows)

/** Share of the text colour mixed into the surface for the `surfaceAlt` role. */
export const SURFACE_ALT_MIX = 0.1;
/** Smallest contrast `surfaceAlt` keeps against `surface`, so a band is visible next to a plain row. */
export const SURFACE_ALT_MIN_CONTRAST = 1.1;

/**
 * The `surfaceAlt` colour role: the fill of the banded rows of a table whose other body rows take `surface`. It is the surface
 * mixed {@link SURFACE_ALT_MIX} of the way towards the text colour (a slightly darker band on a light table, a slightly lighter one
 * on a dark table), moved further until it differs from the surface by {@link SURFACE_ALT_MIN_CONTRAST}, while the text keeps
 * 4.5:1 on it. When mixing towards the text cannot keep both (a surface and text that are close together), the band moves the
 * other way, away from the text, which only raises the text contrast. Pure arithmetic on opaque colours, so the preview and
 * the PPTX export, which both resolve the `surfaceAlt` ColorRef from their own `surface` and `text` roles, draw and write the
 * same colour. An unresolved surface is white; an unresolved text colour is the surface's best contrast partner.
 */
export function surfaceAltColor(surface: string, text: string): string {
  const fill = normalizeHexColor(surface) ?? '#FFFFFF';
  const ink = normalizeHexColor(text) ?? textColorForFill(fill, '#000000');
  const from = opaqueChannels(fill)!, toText = opaqueChannels(ink)!;
  const step = (color: string) => (colorContrast(color, fill) ?? 1) >= SURFACE_ALT_MIN_CONTRAST;
  const readable = (color: string) => (colorContrast(ink, color) ?? 0) >= 4.5 || (colorContrast(ink, color) ?? 0) >= (colorContrast(ink, fill) ?? 0);
  for (let amount = SURFACE_ALT_MIX; amount <= 0.5 + 1e-9; amount += 0.02) {
    const band = mixChannels(from, toText, amount);
    if (!readable(band)) break;
    if (step(band)) return band;
  }
  // Away from the text: towards black under light text, towards white under dark text.
  const away = (luminance(ink) ?? 0) > (luminance(fill) ?? 0) ? [0, 0, 0] : [255, 255, 255];
  for (let amount = SURFACE_ALT_MIX; amount <= 1 + 1e-9; amount += 0.02) {
    const band = mixChannels(from, away, Math.min(1, amount));
    if (step(band)) return band;
  }
  return mixChannels(from, toText, SURFACE_ALT_MIX);
}

// --------------------------------------------------------------- highlighted table rows (LH-113)

/** LH-113: share of the accent mixed into the table surface for a highlighted row. */
export const TABLE_HIGHLIGHT_MIX = 0.15;

/**
 * LH-113: the fill of a highlighted table row (`table.highlight`, or the rows the slide's texts name): the table surface mixed
 * {@link TABLE_HIGHLIGHT_MIX} of the way towards the accent (a pale accent tint on a light table, a dark one on a dark table), mixed less
 * when the cell text would fall under 4.5:1 on it (never less readable than on the surface itself). Pure arithmetic on opaque colors, so
 * the preview and the PPTX export, which both pass their own `surface`, accent and text roles, draw and write the same color. An
 * unresolved surface is white, an unresolved accent black, an unresolved text color the surface's best contrast partner.
 */
export function tableHighlightColor(surface: string, accent: string, text: string): string {
  const fill = (normalizeHexColor(surface) ?? '#FFFFFF').slice(0, 7);
  const ink = (normalizeHexColor(text) ?? textColorForFill(fill, '#000000')).slice(0, 7);
  const from = opaqueChannels(fill)!, to = opaqueChannels((normalizeHexColor(accent) ?? '#000000').slice(0, 7)) ?? [0, 0, 0];
  const plain = colorContrast(ink, fill) ?? 0;
  for (let percent = Math.round(TABLE_HIGHLIGHT_MIX * 100); percent >= 1; percent--) {
    const tint = mixChannels(from, to, percent / 100), contrast = colorContrast(ink, tint) ?? 0;
    if (contrast >= 4.5 || contrast >= plain) return tint;
  }
  return fill.toUpperCase();
}

import fs from 'node:fs';
import path from 'node:path';
import {execFileSync,spawnSync} from 'node:child_process';
const root='C:/opf-work/rr20-nine-promotion',logs='C:/opf-work/rr20-nine-promotion-logs-20261109-01';
const source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const tests=['chartex-fallback-archive-review.mjs','rr54-archive-candidate.mjs','chartex.mjs','rr-54-chart-table-data.mjs'];
const results=[];
for(const file of tests){
 const startedUtc=new Date().toISOString(),run=spawnSync(process.execPath,['test/'+file],{cwd:path.join(root,'packages/pptx'),encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});
 fs.writeFileSync(path.join(logs,'focused-'+file+'.log'),(run.stdout??'')+(run.stderr??''),{flag:'wx'});
 const row={file,source,startedUtc,finishedUtc:new Date().toISOString(),exitCode:run.status,signal:run.signal,error:run.error?String(run.error):null};
 fs.writeFileSync(path.join(logs,'focused-'+file+'.exit.json'),JSON.stringify(row,null,2)+'\n',{flag:'wx'});results.push(row);
 process.stdout.write(JSON.stringify(row)+'\n'+(run.stdout??'').split(/\r?\n/).filter(Boolean).slice(-2).join('\n')+'\n');
}
fs.writeFileSync(path.join(logs,'focused-results.json'),JSON.stringify({source,node:process.version,platform:process.platform,machineSlot:true,results},null,2)+'\n',{flag:'wx'});
if(results.some(row=>row.exitCode!==0))process.exitCode=1;


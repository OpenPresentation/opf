import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const root='C:/opf-work/rr20-nine-promotion',destination=root+'/docs/handoff/2026-11-09/rr20-sh24-nine-archive-promotion';
const {zipSync}=createRequire(root+'/packages/pptx/package.json')('fflate'),hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const files=[],parts={};
function collect(root,prefix,directory=root){for(const entry of fs.readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en'))){const file=path.join(directory,entry.name);if(entry.isDirectory())collect(root,prefix,file);else{if(!entry.isFile())throw Error('No links');const name=prefix+'/'+path.relative(root,file).split(path.sep).join('/'),bytes=fs.readFileSync(file);files.push({name,bytes:bytes.length,sha256:hash(bytes)});parts[name]=[bytes,{level:9,mtime:new Date(1980,0,1)}];}}}
collect('C:/opf-work/rr20-nine-promotion-logs-20261109-01','run');collect(root+'/artifacts/check-changed','mapped');
const zip=Buffer.from(zipSync(parts,{level:9,mtime:new Date(1980,0,1)}));
fs.writeFileSync(destination+'/checks.zip',zip,{flag:'wx'});
const manifest={format:1,source:'d623be2d49da7b448f82c2e0395609487d89a4f5',base:'5b9e4386c00319da1fa4370dcc0b3eb6e93c9578',zip:{name:'checks.zip',bytes:zip.length,sha256:hash(zip)},rawFiles:files.length,rawBytes:files.reduce((sum,row)=>sum+row.bytes,0),files};
fs.writeFileSync(destination+'/checks.json',JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({rawFiles:manifest.rawFiles,rawBytes:manifest.rawBytes,zipBytes:zip.length,zipSha256:manifest.zip.sha256}));

Strict ChartEx fallback snapshots still contain the old inverted-pyramid catalog record hash, so they fail after SH-24 removes its public qualification copy. Copy the exact reviewed generated nine-deck proposal and preserve every earlier source/lock history; each output differs only in one provenance tag. The separate21 archive fixture stays unchanged.

Validation: four focused files pass, including ChartEx31 and chart/table-data42 checks. Required mapped validation passes9 steps and all280 PPTX scripts plus the browser-bundle build; strict gallery freshness17/18 is its sole failure, addressed by the separate current-wave metadata leaf. The original combined86997 remains RED.

Actual nine/21 archive evidence is published at594863c06 and7c7e5df4; source proof and full logs are in the dated handoff. Vetoable decision RR20-NINE-SH24-PROMOTION accepts only the generated94cf proposal. Cross-platform/native/final combined acceptance remain coordinator gates.

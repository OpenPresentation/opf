import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {selectTests,nodeArgs} from '/tmp/opf-native-fragments/scripts/run-tests.mjs';
const root='/tmp/opf-native-fragments',dir=root+'/packages/pptx',suites=JSON.parse(fs.readFileSync(dir+'/test/suites.json')),selection=selectTests(fs.readdirSync(dir+'/test'),suites,'contract');
const names=['native-latin-slots.mjs','rr-105-ltr-latin-native.mjs','rr-105-list-scalar-import.mjs','source-run-styles.mjs','source-run-styles-roundtrip.mjs'],rows=[];
for(const name of names){
 if(!selection.scripts.includes(name)&&!selection.batch.includes(name))throw Error('Requested neighbor is not discovered: '+name);
 const args=nodeArgs(name,suites),start=Date.now(),result=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8',timeout:180000,maxBuffer:32*1024*1024}),output=(result.stdout??'')+(result.stderr??''),log='/tmp/opf-native-fragments-neighbor05-'+name+'.log';fs.writeFileSync(log,output);
 const row={name,args,sourceSha256:createHash('sha256').update(fs.readFileSync(dir+'/test/'+name)).digest('hex'),status:result.status,error:result.error?.message,elapsedMs:Date.now()-start,log,logSha256:createHash('sha256').update(output).digest('hex')};rows.push(row);console.log(JSON.stringify(row));
}
fs.writeFileSync('/tmp/opf-native-fragments-neighbors05.json',JSON.stringify(rows,null,2)+'\n');process.exit(rows.some(row=>row.status!==0)?1:0);

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {inflateRawSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='/tmp/opf-schema-review',out='/tmp/opf-lh110-a3b-causal-02',head='6c980ef1295c69793b46adf98d28ce2d0f11380c',git=args=>execFileSync('git',['-C',root,...args],{encoding:'utf8'}).trim(),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.equal(git(['rev-parse','HEAD']),head);assert.equal(git(['status','--porcelain','--untracked-files=normal']),'');assert.equal(git(['diff','--name-only','a3b914964453823a78bde885df2feb464c801a9c',head,'--','packages','spec','examples']),'','No package/spec/example changes during rebind');
const require=createRequire(root+'/packages/integration/package.json'),corePackage=require.resolve('@openpresentation/opf/package.json'),coreManifest=JSON.parse(fs.readFileSync(corePackage));
// composition is an import-only public entry. Use its exact declared ESM route, not CJS require conditions or a loader alias.
const modulePaths={...Object.fromEntries(['@openpresentation/opf','@openpresentation/opf-render/fonts-node','@openpresentation/opf-pptx'].map(name=>[name,require.resolve(name)])),'@openpresentation/opf/composition':path.resolve(path.dirname(corePackage),coreManifest.exports['./composition'].import)};
const [{convert,resolveSlideContext,validate},{loadFonts},{fromPptx},{composeSlide}]=await Promise.all(Object.values(modulePaths).map(file=>import(pathToFileURL(file))));
const source=fs.readFileSync(root+'/packages/integration/test/lh-110-localized-references.test.mjs','utf8'),helperSource=source.slice(source.indexOf('const attrs ='),source.indexOf('test("LH-110:'));
const {attrs,unzip,nativeChart,chartItem,assertSvgLine}=new Function('assert','path','inflateRawSync','composeSlide','resolveSlideContext',helperSource+';return {attrs,unzip,nativeChart,chartItem,assertSvgLine};')(assert,path,inflateRawSync,composeSlide,resolveSlideContext);
const documentBytes=fs.readFileSync(root+'/examples/technical/localized-chart-references.opf.json'),document=JSON.parse(documentBytes),original=structuredClone(document);
assert.equal(validate(document,{catalogs:[]}).schemaValid,true);fs.mkdirSync(out);fs.copyFileSync('/tmp/opf-lh110-causal.mjs',out+'/probe.mjs');
const fonts=await loadFonts({pack:'office',substitutionPolicy:'visual',scripts:'auto',presentation:document});
try{
  const svg=await convert(document,{format:'svg',fonts,catalogs:[],date:'2026-11-08'}),native=await convert(document,{format:'pptx',fonts,catalogs:[],date:'2026-11-08'});
  assert.equal(svg.files.length,7);assert.equal(native.files.length,1);
  const bytes=native.files[0].bytes,parts=unzip(bytes),imported=await fromPptx(bytes,{signals:true,catalogs:[]}),rows=[];
  fs.writeFileSync(out+'/actual.pptx',bytes,{flag:'wx'});fs.writeFileSync(out+'/imported.json',JSON.stringify(imported,null,2)+'\n',{flag:'wx'});
  for(const [index,slide]of document.slides.entries()){
    const svgText=new TextDecoder().decode(svg.files[index].bytes),line=chartItem(document,index,fonts).chart.layer.references.lines[0],svgLine=assertSvgLine(svgText,line),chart=nativeChart(parts,index),helpers=[...chart.xml.matchAll(/<c:ser>[\s\S]*?<\/c:ser>/g)].map(match=>match[0]).filter(text=>text.includes('<opf:reference '));assert.equal(helpers.length,1);
    const helper=helpers[0],nativeLine=/<c:spPr>\s*<a:ln\b([^>]*)>([\s\S]*?)<\/a:ln>\s*<\/c:spPr>/.exec(helper);assert.ok(nativeLine);
    const lnAttrs=attrs(nativeLine[1]),paint=/<a:solidFill>([\s\S]*?)<\/a:solidFill>/.exec(nativeLine[2]);assert.ok(paint);
    const rgb=/<a:srgbClr\b([^>]*)/.exec(paint[1]),scheme=/<a:schemeClr\b([^>]*)/.exec(paint[1]),row={slide:index+1,language:slide.language,label:slide.chart.referenceLines[0].label,authoredStroke:slide.chart.referenceLines[0].stroke,composedStroke:line.stroke,composedStrokeWidth:line.strokeWidth,svg:{stroke:svgLine.stroke,strokeWidth:Number(svgLine['stroke-width']),rawLine:svgLine},native:{widthEmu:Number(lnAttrs.w),widthPixels:Number(lnAttrs.w)/9525,widthPoints:Number(lnAttrs.w)/12700,dash:/<a:prstDash\b([^>]*)/.exec(nativeLine[2])?.[1],rgb:rgb?attrs(rgb[1]):null,scheme:scheme?attrs(scheme[1]):null,rawPaint:paint[1],rawLine:nativeLine[0]},importedStroke:imported.presentation.slides[index].chart.referenceLines[0].stroke};
    rows.push(row);fs.writeFileSync(out+'/slide-'+(index+1)+'.svg',svgText,{flag:'wx'});fs.writeFileSync(out+'/chart-'+(index+1)+'.xml',chart.xml,{flag:'wx'});fs.writeFileSync(out+'/helper-'+(index+1)+'.xml',helper,{flag:'wx'});
  }
  for(const [name,bytes]of parts)if(/^ppt\/theme\/.+\.xml$/.test(name))fs.writeFileSync(out+'/'+name.replaceAll('/','-'),bytes,{flag:'wx'});
  assert.deepEqual(document,original);
  const report={head,node:process.version,sourceTestSha256:sha(source),documentSha256:sha(documentBytes),modules:Object.fromEntries(Object.entries(modulePaths).map(([name,file])=>[name,{path:file,sha256:sha(fs.readFileSync(file))}])),corePackage:{path:corePackage,sha256:sha(fs.readFileSync(corePackage))},nativeSha256:sha(bytes),rows,nativeAcceptance:false,scope:'Actual Node public seven-slide SVG/PPTX/import causal probe; no Office or authored/default mutation.'};
  fs.writeFileSync(out+'/rows.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});assert.equal(git(['rev-parse','HEAD']),head);assert.equal(git(['status','--porcelain','--untracked-files=normal']),'');
  console.log(JSON.stringify({out,head,nativeSha256:report.nativeSha256,rows:rows.map(({slide,language,authoredStroke,composedStroke,composedStrokeWidth,svg,native,importedStroke})=>({slide,language,authoredStroke,composedStroke,composedStrokeWidth,svg:{stroke:svg.stroke,width:svg.strokeWidth},native:{rgb:native.rgb,scheme:native.scheme,widthEmu:native.widthEmu,widthPixels:native.widthPixels,widthPoints:native.widthPoints},importedStroke}))},null,2));
}finally{fonts.dispose?.();}

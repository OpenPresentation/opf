const {defineConfig}=require('C:/opf-work/g033-org/node_modules/@playwright/test')
const current=require('C:/opf-work/g033-org/playwright.config.ts').default
module.exports=defineConfig({
  ...current,
  projects:[{name:'supplemental',testDir:__dirname,testMatch:'phase.spec.ts'}],
  webServer:undefined,
  outputDir:'C:/opf-work/release-033-artifacts/org202-postreload-01/test-results',
})

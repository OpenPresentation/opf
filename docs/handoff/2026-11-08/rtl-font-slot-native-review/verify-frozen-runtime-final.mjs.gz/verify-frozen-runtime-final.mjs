import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const refs=JSON.parse(await fs.readFile('C:/opf-work/font-native-review-01/runtime-before.json','utf8'));
const roots={q473:'C:/opf-work/rr105-sh26-rtl',corrected:'C:/opf-work/rr105-tag-ownership'};
const rows=[];
for(const [key,root]of Object.entries(roots)){const revision=execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),status=execFileSync('git',['-C',root,'status','--porcelain'],{encoding:'utf8'}).trim();if(revision!==refs[key].revision||status)throw Error('Frozen identity drift');for(const f of refs[key].files){const b=await fs.readFile(root+'/'+f.path);if(b.length!==f.bytes||sha(b)!==f.sha256)throw Error('Frozen final runtime drift '+key+'/'+f.path);}rows.push({producer:key,revision,status,verifiedFiles:refs[key].files.length,runtimeSha256:refs[key].sha256,allFilesExact:true});}
const result={scope:'Final read-only frozen-runtime check after both imports, XML review, failure review and seals; no rebuild/install/write to producers',node:process.version,producerSha256:sha(await fs.readFile(new URL(import.meta.url))),rows,nativeAcceptance:false};
await fs.writeFile('C:/opf-work/font-native-evidence-packet-02/final-runtime-verification.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));

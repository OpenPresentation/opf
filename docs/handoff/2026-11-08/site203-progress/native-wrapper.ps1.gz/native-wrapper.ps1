param([Parameter(Mandatory=$true)][ValidateSet('A','B','C')][string]$Case)
$ErrorActionPreference='Stop'
$env:PSModulePath='C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules;C:\Users\micha\Documents\WindowsPowerShell\Modules'
$suiteRoot='C:/opf-work/rr105-proofing-suite-02'
$sourceRoot='C:/opf-work/rr105-proofing-review'
$workerRoot=$sourceRoot+'/tools/rr105-proofing-readonly/worker-package'
$runnerRoot='C:/opf-work/rr105-readonly-survey'
$nativeRoot='C:/opf-work/qualification034-proofing-'+$Case+'-01'
if(Test-Path -LiteralPath $nativeRoot){throw 'Preserve prior native output; no retry'}
if((Get-FileHash -LiteralPath ($suiteRoot+'/suite.json') -Algorithm SHA256).Hash.ToLowerInvariant() -cne '50dc947be9220127c2a18f6b3e47d47479a275bf3563144b00b27c38fa18e097'){throw 'Exact sealed suite required'}
$head=(& git --no-optional-locks -C $sourceRoot rev-parse HEAD | Out-String).Trim()
if($LASTEXITCODE -ne 0 -or $head -cne 'b8461d48b193e32dee4e6e1bb60896823f2303ff'){throw 'Frozen source head changed'}
$dirty=(& git --no-optional-locks -C $sourceRoot status --porcelain --untracked-files=normal | Out-String).Trim()
if($LASTEXITCODE -ne 0 -or $dirty -ne ''){throw 'Frozen source is not clean'}
$suite=Get-Content -LiteralPath ($suiteRoot+'/suite.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if($suite.cases.Count -ne 3 -or ($suite.cases.id -join '|') -cne 'proofing-inheritance-A|proofing-inheritance-B|proofing-inheritance-C'){throw 'Exactly the sealed A/B/C route is required'}
$item=@($suite.cases | Where-Object {$_.id -ceq ('proofing-inheritance-'+$Case)})[0]
if($item.slideCount -ne 1 -or $item.declaredTopLevelShapes -ne 3 -or $item.expectedPrimaryLanguageId -ne 1025 -or $item.requiredPhaseNamePairs -ne 9){throw 'Case scope changed'}
foreach($bound in @(@{root=$suiteRoot;files=$suite.files},@{root=$workerRoot;files=$suite.provenance.workerRepository.files},@{root=$runnerRoot;files=$suite.provenance.suiteRepository.files})){
 foreach($declared in $bound.files){
  $file=Join-Path $bound.root $declared.path
  if((Get-Item -LiteralPath $file).Length -ne $declared.bytes -or (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -cne $declared.sha256){throw ('Frozen byte identity refused '+$declared.path)}
 }
}
[void](New-Item -ItemType Directory -Path $nativeRoot)
$running=@(Get-Process POWERPNT -ErrorAction SilentlyContinue)
[ordered]@{time=(Get-Date).ToUniversalTime().ToString('o');case=$item.id;processCount=$running.Count;processIds=@($running | ForEach-Object {$_.Id});rootReviewedSourceHead=$head;sourceSuitePreparationClaimsRetained=$true;visualImportAcceptance=$false} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($nativeRoot+'/preflight.json') -Encoding UTF8
if($running.Count -ne 0){throw 'PowerPoint exists; no attach, kill, retry or Office call'}
Write-Output ('START '+$item.id)
& ($runnerRoot+'/scripts/native-acceptance/run-windows.ps1') -SuiteDirectory $suiteRoot -PptxRepository $workerRoot -Case $item.id -OutputDirectory ($nativeRoot+'/case') -CaptureTextFonts -TimeoutSeconds 60
$terminal=Get-Content -LiteralPath ($nativeRoot+'/case/native/supervisor.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if($terminal.timedOut -ne $false -or $terminal.exitCode -ne 0 -or $terminal.cleanupConfirmed -ne $true){throw 'Worker completion/cleanup failed; stop without retry'}
$report=Get-Content -LiteralPath ($nativeRoot+'/case/native/report.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$observations=@($report.proofingLanguage.observations)
if($report.cleanupConfirmed -ne $true -or $null -ne $report.error -or $report.lastStage -cne 'worker.complete' -or $observations.Count -ne 9 -or ($report.proofingLanguage.completedPhases -join '|') -cne 'original|edited|reopened'){throw 'Native state lacks complete proofing observations; no retry'}
foreach($probe in $observations){if($probe.observedLanguageId -ne 1025 -or $probe.status -cne 'uniform-exact'){throw 'Actual primary proofing changed; no retry'}}
$remaining=@(Get-Process POWERPNT -ErrorAction SilentlyContinue)
$waitRecord=[ordered]@{started=(Get-Date).ToUniversalTime().ToString('o');observedProcessIds=@($remaining | ForEach-Object {$_.Id});maximumSeconds=30;officeCalls=0;processOwnershipInferred=$false}
if($remaining.Count -gt 0){try{Wait-Process -Id @($remaining | ForEach-Object {$_.Id}) -Timeout 30 -ErrorAction Stop}catch{$waitRecord.observationError=$_.FullyQualifiedErrorId}}
$still=@(Get-Process POWERPNT -ErrorAction SilentlyContinue)
$waitRecord.finished=(Get-Date).ToUniversalTime().ToString('o');$waitRecord.remainingProcessCount=$still.Count
$waitRecord | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($nativeRoot+'/process-exit.json') -Encoding UTF8
if($still.Count -ne 0){throw 'Process remains after confirmed-cleanup observation; no further Office work'}
[ordered]@{case=$item.id;nativeObservationCompleted=$true;primaryProofingObservations=9;expectedPrimaryLanguageId=1025;cleanupConfirmed=$true;officeProcessCountAfter=0;visualImportAcceptance=$false} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($nativeRoot+'/completed.json') -Encoding UTF8
Write-Output ('DONE '+$item.id+'; visual/import acceptance separate')
throw 'Untrusted helper must never execute'

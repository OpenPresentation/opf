import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const base='https://pr-200-pptx-dev-preview.michael-136.workers.dev/docs/opf/diagrams/';
const local=readFileSync('public/docs/opf/diagrams/manifest.json');
const remote=await fetch(new URL('manifest.json',base)); assert.equal(remote.status,200); const bytes=Buffer.from(await remote.arrayBuffer()); assert.ok(bytes.equals(local),'deployed manifest must be byte-identical to final checked-in manifest');
const manifest=JSON.parse(local); assert.equal(manifest.revision,'26fd4de9cee7e57f9e0620eddcad2dcef04e00e3');
const files=await Promise.all(Object.entries(manifest.files).map(async([name,sha256])=>{ const response=await fetch(new URL(name,base));assert.equal(response.status,200,name);const bytes=Buffer.from(await response.arrayBuffer());const actual=createHash('sha256').update(bytes).digest('hex');assert.equal(actual,sha256,name);return {name,bytes:bytes.length,sha256}; }));
const receipt={head:'7d7359148eb45c073e002738f378314441094d38',url:base,source:manifest.revision,manifestSha256:createHash('sha256').update(local).digest('hex'),files};writeFileSync('C:/opf-work/g033-dev-preview-final-assets.json',JSON.stringify(receipt,null,2)+'\n');console.log(`Final exact-head preview: manifest and all ${files.length} canonical diagram SVG hashes PASS.`);

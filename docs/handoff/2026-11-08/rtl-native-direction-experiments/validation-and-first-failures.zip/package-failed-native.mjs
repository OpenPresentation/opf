import fs from 'node:fs';import path from 'node:path';import{createHash}from'node:crypto';import{createRequire}from'node:module';
const require=createRequire('C:/opf-work/rr105-run-dir/packages/pptx/package.json'),{zipSync,unzipSync}=require('fflate');
const root='C:/opf-work/rr105-native-direction-publication';fs.mkdirSync(root,{recursive:true});
const hash=b=>createHash('sha256').update(b).digest('hex'),scan=/gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk_(?:live|test)_[A-Za-z0-9]{16,}|Authorization\s*:\s*Bearer\s+[A-Za-z0-9._-]{16,}/i;
const walk=(dir,rel='')=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{const relative=rel?rel+'/'+e.name:e.name;if(e.isSymbolicLink())throw Error('Reparse entry forbidden '+relative);return e.isDirectory()?walk(path.join(dir,e.name),relative):[{relative,file:path.join(dir,e.name)}];}).sort((a,b)=>a.relative.localeCompare(b.relative));
const archives=[];
for(const[name,source]of[
 ['native-contrast-11','C:/opf-work/qualification034-rtl-contrast-native-01'],
 ['native-direction-3','C:/opf-work/qualification034-rtl-direction-native-01'],
 ['review-contrast-11','C:/opf-work/qualification034-rtl-contrast-review-01'],
 ['review-direction-3','C:/opf-work/qualification034-rtl-direction-review-01'],
 ['candidate-probes-02','C:/opf-work/rr105-run-dir-probes-02'],
 ['first-producer-attempt-01','C:/opf-work/rr105-run-dir-probes-01'],
]){
 const entries={},records=[];for(const{relative,file}of walk(source)){const bytes=fs.readFileSync(file);if(scan.test(bytes.toString('utf8')))throw Error('Credential signature refused '+relative);if(/\.(?:pptx|xlsx|zip)$/i.test(relative)){try{for(const[p,b]of Object.entries(unzipSync(bytes)))if(/\.(?:xml|json|txt|rels)$/i.test(p)&&scan.test(Buffer.from(b).toString('utf8')))throw Error('Credential signature inside archive '+relative+'/'+p);}catch(e){if(e.message.startsWith('Credential'))throw e;}}entries[relative]=[bytes,{mtime:new Date('2000-01-01T00:00:00Z')}];records.push({path:relative,bytes:bytes.length,sha256:hash(bytes)});}
 const packed=zipSync(entries,{level:9}),archive=name+'.zip';fs.writeFileSync(path.join(root,archive),packed);const manifest=Buffer.from(JSON.stringify({source,authority:'Raw complete files, unchanged and losslessly zipped; these are failed/review observations, not native acceptance.',records},null,2)+'\n');fs.writeFileSync(path.join(root,name+'.files.json'),manifest);
 const unpacked=unzipSync(packed);for(const record of records){const b=unpacked[record.path];if(!b||b.length!==record.bytes||hash(b)!==record.sha256)throw Error('Archive round-trip differs '+record.path);}
 archives.push({path:archive,source,files:records.length,rawBytes:records.reduce((n,r)=>n+r.bytes,0),bytes:packed.length,sha256:hash(packed),fileManifest:name+'.files.json',manifestSha256:hash(manifest),losslessVerified:true,credentialSignatureScan:'passed'});
}
const wrappers=['run-rtl-contrast-native-01.ps1','rtl-contrast-native-01.log','run-rtl-direction-native-01.ps1','rtl-direction-native-01.log','review-rtl-native-contrasts.mjs','rtl-contrast-native-review-01.log','rtl-direction-native-review-01.log'];fs.mkdirSync(path.join(root,'executed'),{recursive:true});const executed=[];for(const file of wrappers){const bytes=fs.readFileSync('C:/opf-work/release-033-artifacts/'+file);if(scan.test(bytes.toString('utf8')))throw Error('Credential signature in executed file');fs.writeFileSync(path.join(root,'executed',file),bytes);executed.push({path:'executed/'+file,bytes:bytes.length,sha256:hash(bytes)});}
fs.writeFileSync(path.join(root,'packet-partial.json'),JSON.stringify({schemaVersion:1,frozenRejectedSource:'897005388dd4617965b6a0e4f719e1c4051f1b46',nativeAcceptance:false,registryAcceptance:false,archiveLockPromotion:false,archives,executed},null,2)+'\n');console.log(JSON.stringify(archives.map(({path,files,rawBytes,bytes,losslessVerified})=>({path,files,rawBytes,bytes,losslessVerified})),null,2));

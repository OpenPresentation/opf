import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {spawnSync,execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root='C:/opf-work/rr105-run-dir',out='C:/opf-work/rr105-run-dir-probes-02',old='C:/opf-work/rtl-native-contrast-export-01';
const node='C:/Users/micha/AppData/Local/npm-cache/_npx/00a8f3ae68dc15e1/node_modules/node/bin/node.exe';
const require=createRequire(path.join(root,'packages/pptx/package.json'));
const {unzipSync,strFromU8}=require('fflate'),{XMLParser}=require('fast-xml-parser');
const {fromPptx}=await import(pathToFileURL(path.join(root,'packages/pptx/dist/index.js')));
const {gallery}=await import(pathToFileURL(path.join(root,'packages/gallery/dist/index.js')));
const sha=b=>createHash('sha256').update(b).digest('hex');
const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n');};
const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
const revision=git(['rev-parse','HEAD']);assert.equal(revision,'897005388dd4617965b6a0e4f719e1c4051f1b46');assert.equal(git(['status','--porcelain']),'');
const snapshot=()=>{
 const files=[];for(const pkg of ['javascript','gallery','render','pptx','cli'])for(const kind of ['src','dist']){
  const visit=dir=>{if(!fs.existsSync(dir))return;for(const item of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,item.name);if(item.isDirectory())visit(file);else{const bytes=fs.readFileSync(file);files.push({path:path.relative(root,file).replaceAll('\\','/'),bytes:bytes.length,sha256:sha(bytes)});}}};visit(path.join(root,'packages',pkg,kind));
 }files.sort((a,b)=>a.path.localeCompare(b.path));return{revision,files,sha256:sha(JSON.stringify(files))};
};
const before=snapshot();write(path.join(out,'runtime-before.json'),before);
const parser=new XMLParser({ignoreAttributes:false,attributeNamePrefix:'@',parseTagValue:false,trimValues:false}),array=x=>x===undefined?[]:Array.isArray(x)?x:[x];
const oldSuite=JSON.parse(fs.readFileSync(path.join(old,'suite/suite.json'),'utf8'));
const suite={schemaVersion:1,provenance:{...oldSuite.provenance,scope:'Three exact immutable one-slide source contrasts; candidate a:rtl0 run direction. Producer/import/XML checks are not native acceptance.',nativeAcceptance:false,registryAcceptance:false,exportProducer:{revision,dirty:false,sourceRuntimeBeforeSha256:before.sha256}},cases:[]};
const results=[];
for(const id of ['rtl-contrast-09-long-explicit-arabic','rtl-contrast-10-non-ascii-digits','rtl-contrast-11-long-explicit-french']){
 const dir=path.join(out,'cases',id);fs.mkdirSync(dir,{recursive:true});
 const sourceBytes=fs.readFileSync(path.join(old,'cases',id,'source.opf.json')),sourceFile=path.join(dir,'source.opf.json');fs.writeFileSync(sourceFile,sourceBytes);
 const document=JSON.parse(sourceBytes);assert.equal(document.slides.length,1);
 const run=(format,target)=>{const args=[path.join(root,'packages/cli/dist/index.js'),'convert',sourceFile,target,'--date','2026-11-08'];const result=spawnSync(node,args,{cwd:root,encoding:'utf8',maxBuffer:16*1024*1024,env:{...process.env,PATH:path.dirname(node)+';'+process.env.PATH}});fs.writeFileSync(path.join(dir,format+'.stdout.json'),result.stdout??'');fs.writeFileSync(path.join(dir,format+'.stderr.txt'),result.stderr??'');write(path.join(dir,format+'.exit.json'),{node,args,status:result.status,signal:result.signal});assert.equal(result.status,0,result.stderr);return JSON.parse(result.stdout);};
 const pptx=path.join(dir,'input.pptx'),preview=path.join(out,'previews',id+'-1.png');fs.mkdirSync(path.dirname(preview),{recursive:true});
 run('pptx',pptx);run('png',preview);
 const bytes=fs.readFileSync(pptx),entries=unzipSync(bytes),oldEntries=unzipSync(fs.readFileSync(path.join(old,'cases',id,'input.pptx'))),xml=strFromU8(entries['ppt/slides/slide1.xml']),oldXml=strFromU8(oldEntries['ppt/slides/slide1.xml']);
 const additions=[...xml.matchAll(/<a:rtl val="0"\/>/g)].length;assert.ok(additions>0);assert.equal(xml.replaceAll('<a:rtl val="0"/>',''),oldXml,'only new run-direction children change visible slide XML');
 const changedParts=Object.keys(entries).filter(p=>!oldEntries[p]||!Buffer.from(entries[p]).equals(Buffer.from(oldEntries[p])));assert.deepEqual(Object.keys(entries).sort(),Object.keys(oldEntries).sort());assert.ok(changedParts.every(p=>p==='ppt/slides/slide1.xml'||/^ppt\/tags\//.test(p)),'no visible non-slide part changes');
 assert.ok(fs.readFileSync(preview).equals(fs.readFileSync(path.join(old,'preview',id,'slide-1.png'))),'preview PNG is byte-exact');
 const findings=[],restored=await fromPptx(bytes,{catalogs:[gallery],onDiagnostic:x=>findings.push(x)}),baseline=await fromPptx(fs.readFileSync(path.join(old,'cases',id,'input.pptx')),{catalogs:[gallery]});
 assert.deepEqual(restored,baseline,'new direction cannot alter current import');assert.equal(restored.language,document.language);assert.equal(restored.slides[0].title,document.slides[0].title);
 if(document.slides[0].items)assert.deepEqual(restored.slides[0].items,document.slides[0].items);
 if(document.slides[0].blocks)for(const [i,block]of document.slides[0].blocks.entries())for(const key of ['type','text','items','numbering'])if(block[key]!==undefined)assert.deepEqual(restored.slides[0].blocks[i][key],block[key]);
 write(path.join(dir,'import.json'),{document:restored,findings});
 const tree=parser.parse(xml)['p:sld']['p:cSld']['p:spTree'],count=['p:sp','p:pic','p:graphicFrame','p:cxnSp','p:grpSp'].reduce((n,k)=>n+array(tree[k]).length,0);assert.ok(count<=30);
 const action='actions/'+id+'.json';write(path.join(out,'suite',action),[]);
 for(const [relative,source]of [['inputs/'+id+'.pptx',pptx],['sources/'+id+'.opf.json',sourceFile],['previews/'+id+'-1.png',preview]]){const target=path.join(out,'suite',relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(source,target);}
suite.cases.push({id,worker:'furniture',automaticControlEligible:true,input:'inputs/'+id+'.pptx',actionPlan:action,slideCount:1,archiveSha256:sha(bytes),preview:'previews/'+id+'-1.png',declaredTopLevelShapes:count,scope:'Exact complete source contrast; read-only original/SaveCopyAs/reopen, empty actions. Candidate not natively accepted.'});
 results.push({id,sourceSha256:sha(sourceBytes),archiveSha256:sha(bytes),previewSha256:sha(fs.readFileSync(preview)),topLevelShapes:count,addedRunDirections:additions,changedParts,sourcePreserved:true,previewByteExact:true,onlyAddedRunDirection:true,importEqualToBaseline:true});
 write(path.join(out,'progress.json'),results);
}
const after=snapshot();assert.equal(before.sha256,after.sha256);assert.equal(git(['status','--porcelain']),'');write(path.join(out,'runtime-after.json'),after);suite.provenance.exportProducer.sourceRuntimeAfterSha256=after.sha256;suite.files=[];for(const folder of ['inputs','sources','previews','actions'])for(const filename of fs.readdirSync(path.join(out,'suite',folder))){const relative=folder+'/'+filename,bytes=fs.readFileSync(path.join(out,'suite',relative));suite.files.push({path:relative,bytes:bytes.length,sha256:sha(bytes)});}write(path.join(out,'suite/suite.json'),suite);
write(path.join(out,'receipt.json'),{revision,base:'67dd9ec10b7019cb95807f59c75186482c800f10',node,nodeVersion:process.version,runtimeSha256:before.sha256,unchangedRuntime:true,sourceSuiteSha256:sha(fs.readFileSync(path.join(old,'suite/suite.json'))),suiteSha256:sha(fs.readFileSync(path.join(out,'suite/suite.json'))),nativeAcceptance:false,results});
console.log(JSON.stringify({revision,runtimeSha256:before.sha256,results},null,2));

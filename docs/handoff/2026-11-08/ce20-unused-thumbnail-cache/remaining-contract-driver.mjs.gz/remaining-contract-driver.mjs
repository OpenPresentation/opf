import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync,spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const repo='C:/opf-work/ce20-cache',code='49da7ea85e6bf70bcba62ee8c3a43ef7aa6646a8';
const root=path.join(repo,'packages/editor');
const git=(...args)=>execFileSync('git',args,{cwd:repo,encoding:'utf8'}).trim();
assert.equal(git('rev-parse','HEAD'),code);
const {selectTests,nodeArgs}=await import(pathToFileURL(path.join(repo,'scripts/run-tests.mjs')));
const suites=JSON.parse(fs.readFileSync(path.join(root,'test/suites.json'),'utf8'));
const files=fs.readdirSync(path.join(root,'test'),{withFileTypes:true}).filter(x=>x.isFile()&&x.name.endsWith('.mjs')).map(x=>x.name);
const plan=selectTests(files,suites,'contract');
const failed='codemirror-guard.mjs',at=plan.scripts.indexOf(failed),remaining=plan.scripts.slice(at+1);
assert.equal(at,18);assert.equal(plan.scripts.length,144);assert.equal(remaining.length,125);
const results=[],started=new Date().toISOString();
for(const name of remaining){
 console.log(JSON.stringify({continuationTest:name,afterRetainedFailure:failed}));
 const result=spawnSync(process.execPath,nodeArgs(name,suites),{cwd:root,stdio:'inherit',env:process.env});
 results.push({name,exitCode:result.status??1,error:result.error?.message??null});
}
assert.equal(git('rev-parse','HEAD'),code);
const passed=results.filter(x=>x.exitCode===0).length;
const receipt={kind:'bounded one-pass continuation of exact maintained contract selection after retained Windows symlink failure',source:code,sourceTree:git('rev-parse',code+'^{tree}'),originalFailure:failed,originalMappedStatus:'RED',originalFailurePreserved:true,selectionUsesMaintainedExports:true,totalScripts:144,earlierPassed:18,remainingSelected:125,remainingPassed:passed,remainingFailed:results.filter(x=>x.exitCode!==0),skipped:0,aggregateMappedGreen:false,sourceOrTestChanges:false,nodeVersion:process.version,started,finished:new Date().toISOString(),results};
fs.writeFileSync('C:/opf-work/release-033-artifacts/ce20-cache-remaining-contract.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({remainingSelected:125,remainingPassed:passed,remainingFailed:125-passed,originalGuardFailureRetained:true,aggregateMappedGreen:false}));
process.exitCode=passed===125?0:1;


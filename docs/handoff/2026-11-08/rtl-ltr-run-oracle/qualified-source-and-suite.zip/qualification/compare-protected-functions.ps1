param([string]$Candidate,[string]$Baseline,[string]$Output)
$ErrorActionPreference='Stop'
function Tree([string]$Path){$t=$null;$e=$null;$a=[System.Management.Automation.Language.Parser]::ParseFile($Path,[ref]$t,[ref]$e);if($e.Count){throw 'Parse failed'};return $a}
function Digest([string]$Value){$a=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($a.ComputeHash([Text.Encoding]::UTF8.GetBytes($Value)))).Replace('-','').ToLowerInvariant()}finally{$a.Dispose()}}
$before=Tree $Baseline;$after=Tree $Candidate;$rows=@()
foreach($name in @('Invoke-FurnitureCom','Stop-FurnitureLifecycle','Assert-PresentationNotOpen','Get-ExactSlide','Get-ExactShape','Assert-FurnitureOfficeIdle','Assert-OwnedFurnitureApplication','Open-OwnedFurniture','Save-OwnedFurnitureCopy','Close-OwnedFurniture','Quit-OwnedFurnitureApplication','Assert-FurnitureSurvey','Get-FurnitureSurveySlideCount','Read-FurnitureTextFont','Read-FurnitureFiniteNumber')){
 $old=$before.Find({param($n)$n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
 $new=$after.Find({param($n)$n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
 if($null -eq $old -or $null -eq $new){throw "Missing protected function $name"}
 $oldSha=Digest $old.Extent.Text;$newSha=Digest $new.Extent.Text
 if($oldSha -cne $newSha){throw "Protected function changed $name"}
 $rows+=@([ordered]@{name=$name;beforeSha256=$oldSha;afterSha256=$newSha;exact=$true})
}
[ordered]@{passed=$true;officeConstructed=$false;baseline=$Baseline;candidate=$Candidate;protectedFunctions=$rows}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $Output -Encoding UTF8
Write-Output ("Protected native functions exact: "+$rows.Count)

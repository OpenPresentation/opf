param([string]$Worker,[string]$Root,[string]$Runner)
$ErrorActionPreference='Stop'
$t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($Worker,[ref]$t,[ref]$e);if($e.Count){throw ($e|Out-String)}
foreach($name in @('Get-FurnitureSha256','Get-FurnitureSurveySlideCount','Assert-FurnitureSurvey','Read-FurnitureState')){$fn=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq $name},$true);if($null -eq $fn){throw ('Missing function '+$name)};Invoke-Expression $fn.Extent.Text}
$cases=New-Object 'System.Collections.Generic.List[object]'
function Check([string]$Name,[bool]$Accept,[scriptblock]$Operation){$errorText=$null;try{& $Operation}catch{$errorText=$_.Exception.Message};if($Accept -and $errorText){throw ($Name+': '+$errorText)};if(-not $Accept -and -not $errorText){throw ($Name+' unexpectedly accepted')};$cases.Add([ordered]@{name=$Name;passed=$true;accepted=$Accept;error=$errorText})}
$runnerAst=[Management.Automation.Language.Parser]::ParseFile($Runner,[ref]$t,[ref]$e);if($e.Count){throw ($e|Out-String)}
$importer=$runnerAst.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Import-NativePlanValidation'},$true);Invoke-Expression $importer.Extent.Text
$fake=Join-Path $Root 'unsupported.ps1';[IO.File]::WriteAllText($fake,'param([switch]$Other)')
Check 'missing-survey-switch-refuse' $false {Import-NativePlanValidation $fake $true}
[IO.File]::WriteAllText($fake,'param([string]$ReadOnlySurvey)')
Check 'wrong-survey-switch-type-refuse' $false {Import-NativePlanValidation $fake $true}
Import-NativePlanValidation $Worker $true
$one=Join-Path $Root 'one.pptx'
Check 'one-slide-empty' $true {Assert-FurnitureSurvey $true @() $one}
Check 'default-does-not-enable-survey' $true {Assert-FurnitureSurvey $false @('editable') (Join-Path $Root 'bad.pptx')}
Check 'refuse-action' $false {Assert-FurnitureSurvey $true @([pscustomobject]@{op='set-text'}) $one}
Check 'refuse-null-action-list' $false {Assert-FurnitureSurvey $true $null $one}
foreach($name in @('two','zero','bad','large','entries')){Check ('refuse-'+$name) $false {Assert-FurnitureSurvey $true @() (Join-Path $Root ($name+'.pptx'))}}
function Invoke-FurnitureCom([string]$Stage,[scriptblock]$Operation){return (& $Operation)}
function Read-NativeTags($Tags,[string]$Prefix){return ,@()}
function Read-FurnitureSeriesNameState($Presentation,$Actions,[string]$Phase){return ,@()}
$CaptureTextFonts=$false;$actions=@();$ReadOnlySurvey=$false
function Presentation([int]$Count,[int]$SlideCount=1){
 $values=@();for($i=1;$i -le $Count;$i++){$values+=@([pscustomobject]@{Id=$i;Name=('shape-'+$i);Type=1;Left=1;Top=2;Width=3;Height=4;Rotation=0;HasTextFrame=0;AlternativeText='';Tags=[pscustomobject]@{}})}
 $shapes=[pscustomobject]@{Count=$Count;Values=$values};$shapes|Add-Member ScriptMethod Item {param($Index)return $this.Values[$Index-1]}
 $slide=[pscustomobject]@{SlideID=1;Name='survey';Tags=[pscustomobject]@{};Shapes=$shapes};$slide|Add-Member ScriptMethod Export {param($Path,$Format,$Width,$Height)[IO.File]::WriteAllBytes($Path,[byte[]]@(0))}
 $slides=[pscustomobject]@{Count=$SlideCount;Values=@($slide)};$slides|Add-Member ScriptMethod Item {param($Index)return $this.Values[0]};return [pscustomobject]@{Slides=$slides}
}
Check 'default-30-accept' $true {$state=Read-FurnitureState (Presentation 30) 'default30';if($state.slides[0].shapeCount -ne 30){throw 'Lost default shapes'}}
Check 'default-31-refuse' $false {$null=Read-FurnitureState (Presentation 31) 'default31'}
$ReadOnlySurvey=$true
foreach($count in @(92,100)){Check ('survey-'+$count+'-accept') $true {$state=Read-FurnitureState (Presentation $count) ('survey'+$count);if($state.slides[0].shapes.Count -ne $count -or $state.slides[0].shapes[-1].name -cne ('shape-'+$count)){throw 'Survey lost a shape'}}}
Check 'survey-101-refuse' $false {$null=Read-FurnitureState (Presentation 101) 'survey101'}
Check 'survey-two-actual-slides-refuse' $false {$null=Read-FurnitureState (Presentation 1 2) 'surveyTwo'}
[ordered]@{passed=$true;officeConstructed=$false;cases=$cases.ToArray()}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $Root 'pure-report.json') -Encoding UTF8
Write-Output ('PASS: '+$cases.Count+' actual pure survey and state-boundary controls; no Office')

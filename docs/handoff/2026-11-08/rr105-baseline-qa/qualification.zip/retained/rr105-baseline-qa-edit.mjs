import fs from 'node:fs';import assert from 'node:assert/strict';
const root='C:/opf-work/rr105-baseline-qa';
const edit=(file,fn)=>{const p=root+'/'+file,before=fs.readFileSync(p,'utf8').replace(/\r\n/g,'\n');fs.writeFileSync(p,fn(before).replace(/\r\n/g,'\n'));};
const replace=(s,from,to)=>{from=from.replace(/\r/g,'');assert.equal(s.split(from).length,2,from);return s.replace(from,to);};
edit('packages/pptx/test/rr-105-native-body-wrap.mjs',s=>{
 s=replace(s,"// 1. layout-sampler slides 41 (step cards), 22 (a text block core measured at 980 px in a 1164.8 px region) and 20 (a body PowerPoint could\n// break either way). Slides keep their positions in a three-slide deck.\n{\n  const picked = [40, 21, 19];\n  const deck = {...sampler, slides: picked.map(index => sampler.slides[index])};".replace(/\n/g,'\r\n'),String.raw`// Select the original authored witnesses by identity: sampler additions must not silently change the regression cases.
const fixtureIds = ['dynamic-six-points', 'layout-chart', 'layout-image-beside'];
const selectFixtures = slides => fixtureIds.map(id => {
  const matches = slides.filter(slide => slide.id === id);
  assert.equal(matches.length, 1, id + ' must appear exactly once in the sampler');
  return matches[0];
});
const fixtures = selectFixtures(sampler.slides);
assert.deepEqual(selectFixtures([...sampler.slides].reverse()), fixtures, 'Sampler order cannot change the native-wrap witnesses');
assert.throws(() => selectFixtures(sampler.slides.filter(slide => slide.id !== fixtureIds[0])), /must appear exactly once/);
assert.throws(() => selectFixtures([...sampler.slides, fixtures[0]]), /must appear exactly once/);
assert.deepEqual(fixtures[0].blocks.map(block => block.text), [
  'Start with a baseline.', 'Keep the scope to one workflow.', 'Review feedback every week.',
  'Name one owner per decision.', 'Share results with both teams.', 'Decide with the evidence, not the calendar.',
], 'All six original card texts remain the tested source');
for (const fixture of fixtures.slice(1)) assert.equal(fixture.blocks[1].text,
  'Test with two teams for six weeks. Measure task completion and time before deciding what to scale.');

// 1. Six step cards, a lead measured narrower than its region, and a body PowerPoint could break either way.
// Their order within this three-slide deck preserves the original assertion paths.
{
  const deck = {...sampler, slides: fixtures};`);
 return s.replace("layout-sampler slide 41's", "the six-card sampler witness's").replace('// Slide 41:', '// Six-card witness:').replace('// Slide 22:', '// Lead witness:').replace('// Slide 20:', '// Tight-wrap witness:').replace('layout-sampler slide 41 among them','the six-card sampler witness among them');
});
edit('packages/pptx/test/sh21-venn-reading-measure.mjs',s=>{
 const marker="for(const[name,text,oldSize]of";
 assert.equal(s.split(marker).length,2);
 s=s.replace(marker,String.raw`const fallbackOverflow = diagnostic => diagnostic.code === 'text-overflow' && diagnostic.path === 'slides.0.items';
const assertFallbackRefusal = diagnostics => {
 assert.ok(Array.isArray(diagnostics), 'composition exposes its public diagnostics');
 const matches = diagnostics.filter(fallbackOverflow);
 assert.equal(matches.length, 1, 'one text-overflow finding identifies the complete source list');
 assert.match(matches[0].message, /complete diagram fallback/i);
 assert.match(matches[0].message, /whole words to 70 characters per line/);
 assert.match(matches[0].message, /retained type size/);
 assert.match(matches[0].message, /Paginate/);
};
const assertCompleteFallback = (doc, geometry) => {
 const before = details(geometry);
 assert.equal(geometry.arrangements?.length ?? 0, 0, 'the whole diagram falls back, with no partial Venn left');
 assert.deepEqual(before.item.value, doc.slides[0].items, 'the complete authored list stays in source order');
 assert.deepEqual(before.texts.flatMap(text => text.listEntries.map(entry => entry.index)), doc.slides[0].items.map((_, index) => index));
 assert.equal(before.item.text.overflow, true, 'the unfit fallback remains explicitly overflowing');
 assertFallbackRefusal(geometry.diagnostics);
};
const assertStrictRefusal = doc => {
 const strict = structuredClone(doc); strict.slides[0].composition = {overflow: 'error'};
 assert.throws(() => compose(strict), error => {
  assert.equal(error.name, 'OPFCompositionError');
  assertFallbackRefusal(error.diagnostics);
  return true;
 });
};
`+marker);
 s=replace(s,"assert.ok(g.diagnostics.some(d=>d.code==='text-overflow'&&/Venn fallback/.test(d.message)));assert.deepEqual(doc,source);","assertCompleteFallback(doc,g);assert.deepEqual(doc,source);");
 s=replace(s," const strict=structuredClone(doc);strict.slides[0].composition={overflow:'error'};assert.throws(()=>compose(strict),error=>error.diagnostics.some(d=>d.code==='text-overflow'&&/Venn fallback/.test(d.message)));"," assertStrictRefusal(doc);");
 s=replace(s,"assert.ok(!genericFit.diagnostics.some(d=>d.code==='text-overflow'&&/Venn fallback/.test(d.message)),'generic lists retain their existing policy');","assert.ok(!genericFit.diagnostics.some(d=>fallbackOverflow(d)&&/complete diagram fallback/i.test(d.message)),'generic lists retain their existing policy');");
 s=replace(s,"g=compose(doc);assert.ok(g.diagnostics.some(d=>d.code==='text-overflow'&&/Venn fallback/.test(d.message)));assert.throws(()=>paginate", "g=compose(doc);assertCompleteFallback(doc,g);assertStrictRefusal(doc);assert.throws(()=>paginate");
 return s;
});
edit('packages/pptx/test/template-layouts.mjs',s=>{
 s=s.replace(/The 29 built-in templates/g,'All authoritative built-in templates').replace(/The 29 built-in layouts/g,'The authoritative built-in layouts').replace(/A registered catalog of the 29, as gallery 2\.0\.0 will be/g,'A registered catalog of those records, with an independent source identity').replace(/The 29 templates/g,'Every authoritative template').replace(/across all 29 layouts/g,'across all authoritative layouts').replace(/The embedded 29 templates/g,'All embedded authoritative templates');
 s=replace(s,"assert.equal(Object.keys(templates).length, 36);",String.raw`const layoutIndex = JSON.parse(await readFile(new URL('../../gallery/catalog/layouts/index.json', import.meta.url), 'utf8'));
const templateIds = layoutIndex.records.map(record => record.id);
assert.equal(new Set(templateIds).size, templateIds.length, 'The authoritative index contains no duplicate identity');
const assertCatalogCoverage = records => {
  assert.deepEqual(Object.keys(records), templateIds, 'Every authoritative layout is present once in catalog order');
  assert.equal(new Set(Object.values(records).map(record => record.name)).size, templateIds.length, 'Every named layout remains distinct');
};
assertCatalogCoverage(templates);
// A same-size replacement must fail too: coverage is by identity, never a relaxed numeric floor.
const substituted = {...templates}; delete substituted.venn; substituted['unlisted-layout'] = templates.venn;
assert.throws(() => assertCatalogCoverage(substituted), /Every authoritative layout/);
const aliased = {...templates, venn: {...templates.venn, name: templates.hierarchy.name}};
assert.throws(() => assertCatalogCoverage(aliased), /Every named layout remains distinct/);
for (const id of ['flow', 'vertical-flow', 'org-chart', 'hierarchy', 'venn', 'pyramid', 'inverted-pyramid']) {
  assert.ok(templates[id], id + ' remains a required named diagram layout');
}
for (const entry of layoutIndex.records) {
  const {$schema, id, ...record} = JSON.parse(await readFile(new URL('../../gallery/catalog/layouts/' + entry.file, import.meta.url), 'utf8'));
  assert.equal($schema, 'https://openpresentation.org/schema/opf-layout/v2');
  assert.equal(id, entry.id, entry.file + ' retains its authoritative identity');
  assert.equal(record.name, entry.name);
  assert.deepEqual(templates[id], record, id + ': the complete compiled record matches the authoritative source');
}`);
 s=replace(s,"assert.equal(layouts.length, 37, 'The master layout and one slide layout per template.');","assert.equal(layouts.length, templateIds.length + 1, 'The master layout and one slide layout per authoritative template.');");
 s=replace(s,"assert.equal(listed.length, 37);","assert.equal(listed.length, templateIds.length + 1);");
 s=replace(s,"assert.equal(layoutParts(registered.entries).length, 38);","assert.equal(layoutParts(registered.entries).length, templateIds.length + 2, 'Every authoritative template plus the master layout and OPF auto');");
 s=replace(s,": 36 templates as native slide layouts",": ${templateIds.length} authoritative templates as native slide layouts");
 return s;
});
console.log('Edited only the three authorized QA test files');

import fs from 'node:fs';import assert from 'node:assert/strict';
const p='C:/opf-work/rr105-baseline-qa/packages/pptx/test/sh21-venn-reading-measure.mjs';let s=fs.readFileSync(p,'utf8');const mark="for(const[name,text,oldSize]of";assert.equal(s.split(mark).length,2);
s=s.replace(mark,String.raw`// A multi-column item's outer box is the union, not the width of its physical text columns.
const boundedPhysicalColumns = (after, before) => {
 const columns = after.item.listColumns ?? [];
 for (const column of columns) {
  const box = column.box, outer = after.item.box;
  assert.ok([box.x, box.y, box.width, box.height].every(Number.isFinite) && box.width > 0 && box.height > 0, 'physical columns have positive finite boxes');
  assert.ok(box.x >= outer.x - 1e-6 && box.y >= outer.y - 1e-6 && box.x + box.width <= outer.x + outer.width + 1e-6 && box.y + box.height <= outer.y + outer.height + 1e-6, 'each physical column stays inside the list frame');
  for (const entry of column.text.listEntries) {
   const text = entry.textBox;
   assert.ok(text.width > 0 && text.x >= box.x - 1e-6 && text.x + text.width <= box.x + box.width + 1e-6, 'each entry text width stays inside its own column');
   for (const line of entry.text.richLines) for (const fragment of line.fragments) assert.ok(text.x + fragment.x + fragment.width <= box.x + box.width + 1e-6, 'measured text does not cross its physical column');
  }
 }
 for (let left = 0; left < columns.length; left++) for (let right = left + 1; right < columns.length; right++) {
  const a = columns[left].box, b = columns[right].box;
  assert.ok(Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x) <= 1e-6 || Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y) <= 1e-6, 'physical columns do not overlap');
 }
 return columns.length > 1 && columns.every(column => column.box.width < before.item.box.width);
};
const assertWholeWords = (after, sourceItems) => {
 for (const text of after.texts) for (const entry of text.listEntries) {
  const source = sourceItems[entry.index], lines = entry.text.richLines.map(line => line.fragments.map(fragment => fragment.text).join(''));
  assert.equal(lines.join(''), source, 'every source character, including spaces, remains in the drawn fragments');
  assert.deepEqual(lines.flatMap(line => line.trim().split(/\s+/u).filter(Boolean)), source.trim().split(/\s+/u), 'line boundaries never split or change a whole word');
 }
};
`+mark);
const old="assert.ok(!page.diagnostics.some(d=>d.code==='text-overflow'));boundedWrap||=!page.arrangements?.length&&after.item.box.width<before.item.box.width;";
assert.equal(s.split(old).length,2);
s=s.replace(old,"assert.ok(!page.diagnostics.some(d=>d.code==='text-overflow'));assertWholeWords(after,paged.slides[index].items);const physicalWrap=boundedPhysicalColumns(after,before);boundedWrap||=!page.arrangements?.length&&(after.item.box.width<before.item.box.width||physicalWrap);");
fs.writeFileSync(p,s);console.log('Applied only the coordinator-reviewed physical-column and exact-word QA correction');

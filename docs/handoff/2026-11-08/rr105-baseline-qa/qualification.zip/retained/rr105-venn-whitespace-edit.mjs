import fs from 'node:fs';import assert from 'node:assert/strict';const root='C:/opf-work/rr105-baseline-qa',p=root+'/packages/pptx/test/sh21-venn-reading-measure.mjs';let s=fs.readFileSync(p,'utf8');
const replace=(from,to)=>{assert.equal(s.split(from).length,2,from);s=s.replace(from,to);};
replace("import{composeSlide}from'@openpresentation/opf/composition';","import{composeSlide,measureTextOutline}from'@openpresentation/opf/composition';");
replace('const boundedPhysicalColumns = (after, before) => {','const boundedPhysicalColumns = (after, before, measurement) => {');
replace("   for (const line of entry.text.richLines) for (const fragment of line.fragments) assert.ok(text.x + fragment.x + fragment.width <= box.x + box.width + 1e-6, 'measured text does not cross its physical column');",String.raw`   for (const line of entry.text.richLines) {
    // RR17: canonical line.width excludes hanging blanks; a raw fragment advance includes them.
    assert.ok(Number.isFinite(line.width) && line.width >= 0 && text.x + line.width <= box.x + box.width + 1e-6, 'canonical measured line width stays inside its own column');
    for (const fragment of line.fragments) if (/\S/u.test(fragment.text)) {
     const ink = measureTextOutline(fragment.text, fragment.fontSize, fragment.style, measurement);
     assert.ok(ink, 'the same resolved font supplies visible outline bounds');
     assert.ok(text.x + fragment.x + ink.x >= box.x - 1e-6 && text.x + fragment.x + ink.x + ink.width <= box.x + box.width + 1e-6, 'visible glyphs stay inside their physical column');
    }
   }`);
replace("  assert.equal(lines.join(''), source, 'every source character, including spaces, remains in the drawn fragments');",String.raw`  assert.equal(entry.value, source, 'the complete source entry, including spaces, stays exact');
  let cursor = 0, previousLine = -1;
  for (const [lineIndex, line] of entry.text.richLines.entries()) for (const fragment of line.fragments) {
   assert.equal(fragment.runIndex, 0, 'the authored fixture is one exact source run');
   assert.equal(fragment.run.text, source, 'the full authored run retains every source codepoint');
   assert.ok(Number.isInteger(fragment.start) && Number.isInteger(fragment.end) && fragment.start >= cursor && fragment.end >= fragment.start && fragment.end <= source.length);
   if (fragment.start > cursor) assert.ok(previousLine >= 0 && lineIndex > previousLine && /^ +$/u.test(source.slice(cursor, fragment.start)), 'only original ASCII-space gaps may occur at real soft line boundaries');
   assert.equal(fragment.text, source.slice(fragment.start, fragment.end), 'every drawn fragment equals its exact source slice');
   cursor = fragment.end; previousLine = lineIndex;
  }
  assert.equal(cursor, source.length, 'the drawn source ranges reach the original run end');`);
replace('const physicalWrap=boundedPhysicalColumns(after,before);',String.raw`const measurement=resolveSlideContext(paged,index,{catalogs:[gallery],fonts}).options.textMeasurement??fonts.textMeasurement;const physicalWrap=boundedPhysicalColumns(after,before,measurement);
  if(name==='medium'&&index===0){
   const missing=structuredClone(after),fragment=missing.texts[0].listEntries[0].text.richLines[1].fragments[0];fragment.start++;fragment.text=fragment.text.slice(1);
   assert.throws(()=>assertWholeWords(missing,paged.slides[index].items),/only original ASCII-space gaps/,'an actual nonspace source gap is refused');
   const lost=structuredClone(after);lost.texts[0].listEntries[0].text.richLines[0].fragments[0].text=lost.texts[0].listEntries[0].text.richLines[0].fragments[0].text.replace('Planning','');
   assert.throws(()=>assertWholeWords(lost,paged.slides[index].items),/exact source slice/,'a lost source token is refused');
  }
  if(name==='long'&&index===0){
   const outside=structuredClone(after);outside.item.listColumns[0].text.listEntries[0].text.richLines[0].fragments[0].text='W'.repeat(90);
   assert.throws(()=>boundedPhysicalColumns(outside,before,measurement),/visible glyphs stay inside/,'visible ink overflow is refused even when stored line width and physical boxes look valid');
  }
  `);
fs.writeFileSync(p,s.replace(/\r\n/g,'\n'));
const handoff=root+'/docs/handoff/2026-11-08/rr105-baseline-qa.md';let h=fs.readFileSync(handoff,'utf8');h=h.replace('every paginated entry also requires exact character concatenation and unchanged whole-word tokens.', 'every paginated entry also requires exact full source run and fragment slices, only original ASCII-space gaps at real soft line boundaries, and unchanged whole-word tokens. Canonical line widths and same-font visible outlines must fit their own physical columns; hanging blank advances are retained in source but do not falsely count as visible ink. Actual nonspace gaps, lost tokens and visible outline overflow are rejected by controls built from the composed output.');h+='\nThe first aligned strengthened rerun also remains RED3/5: raw fragment concatenation incorrectly treated ordinary U+0020 soft-wrap gaps as lost words, and raw fragment advance incorrectly counted a7px hanging blank as visible overflow. Read-only exact evidence proves all medium tokens/punctuation and source slices intact, and the long Source Sans3/35/400 line has535.71px raw advance but528.71px canonical/blank-trimmed width and529.655px outline right, inside531.9px. Root reviewed the corrected source-range/token/outline contract before any change. No source whitespace, words, font or tolerance was altered; both failed official runs remain retained and the next official focused and mapped checks are still pending.\n';fs.writeFileSync(handoff,h.replace(/\r\n/g,'\n'));console.log('Applied only the coordinator-reviewed soft-wrap/hanging-blank QA semantics and discrimination controls');

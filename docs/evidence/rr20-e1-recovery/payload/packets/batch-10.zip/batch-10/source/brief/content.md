# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Demo Moment"
- text: "Keystone Build Partners should focus the next cycle on reset field safety practices before tower crane installation while making the operating tradeoffs clear to construction stakeholders."
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")

## s02

- Title: "Decision Rule"
- code (python):
```
if risk > threshold:
    escalate(owner)
else:
    approve(change)
```
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"

## s03

- Title: "Decision Options"
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."
- text: "First: state the situation."

## s04

- Title: "Decision Rule"
- stacked-area chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19

## s05

- Title: "Decision Options"
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s06

- Title: "Demand Generation Campaign Brief: execution timeline"
- picture (file images/image-2.png; alt: "NORTH, fictional logo")
- picture (file images/image-3.png; alt: "FIELD, fictional logo")
- picture (file images/image-4.png; alt: "STUDIO, fictional logo")
- picture (file images/image-2.png; alt: "NORTH, fictional logo")

## s07

- Title: "Signal Trend"
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29

## s08

- Title: "Retail Launch Readiness Deck: signal trend"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed

## s09

- Title: "Why This Matters"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- key number: $4.8M, label "Primary signal", note "Reset field safety practices before tower crane installation", trend down

## s10

- Title: "Signal Trend"
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."

## s11

- Title: "Demo Moment"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Urban Lens Collective should focus the next cycle on tell a coherent civic story through image-heavy slides while making the operating tradeoffs clear to portfolio stakeholders."

## s12

- Title: "Onboarding Experience Redesign: why this matters"
- bar chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- text: "Kindred Systems should focus the next cycle on reduce new-hire time to productivity with clearer role paths while making the operating tradeoffs clear to human resources stakeholders."
- stacked-line chart: Current, Baseline by Quarter; Q1: 17 / 14, Q2: 21 / 16, Q3: 24 / 18, Q4: 28 / 20
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."
- column chart: Revenue, Costs by Quarter; Q1: 120 / 80, Q2: 180 / 110, Q3: 240 / 150, Q4: 260 / 170
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."

## s13

- Title: "Next Steps"
- list: "Agree on the owner for seed pitch.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "Agree the budget", "Name the owners", "Review in March"
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Queue", "Route", "Resolve"
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")

## s14

- Title: "What This Proves"
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."

## s15

- Title: "Why This Matters"
- list: "Establish a baseline" (description: "Measure the current completion rate and task time.")
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")

## s16

- Title: "Parks Master Plan Workshop"
- text: "Greenway Parks Department should focus the next cycle on gather resident input on park access and maintenance while making the operating tradeoffs clear to parks and recreation stakeholders."
- text: "Signal"
- text: "Start with a baseline."
- text: "Cost: two team leads at 20% for six weeks."

## s17

- Title: "District Literacy Acceleration Plan: district literacy acceleration plan"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Justice administration, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Riverbend Public Schools should focus the next cycle on raise third-grade reading proficiency through targeted intervention while making the operating tradeoffs clear to k-12 education stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Policy briefing, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Professional services, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]

## s18

- Title: "Signal Trend"
- key number: 91%, label "Primary signal", note "Prioritize second-source work for the highest-risk suppliers", trend up
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."

## s19

- Title: "Three parts, one decision"
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"

## s20

- Title: "Field Enablement Certification: field enablement certification"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data storytelling working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Ports and logistics working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Corporate strategy working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Construction working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Emergency management working group

## s21

- Title: "Why This Matters"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Investor relations, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."

## s22

- Title: "Workforce Reskilling Initiative: decision and follow through"
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."

## s23

- Title: "Broadband Public Hearing Deck: operating model"
- key number: 31%, label "Primary signal", note "Explain broadband route choices and resident impact", trend flat
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up
- key number: 42 pts, label "Primary signal", note "Prepare displaced workers for regional growth sectors", trend down
- key number: 2.4x, label "Primary signal", note "Prepare a self-running lobby deck with concise navigation cues", trend up
- key number: 18%, label "Primary signal", note "Qualify suppliers for the new battery enclosure line", trend flat
- key number: $820K, label "Primary signal", note "Reduce container dwell time through scheduling and yard visibility", trend up
- key number: $820K, label "Primary signal", note "Approve controls for customer-facing predictive models", trend down

## s24

- Title: "One team. One outcome."
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- picture (file images/image-5.png; alt: "Illustrative landscape with two green ridges")

## s25

- Title: "Alumni Giving Campaign: the ask"
- text: "Redwood College Foundation should focus the next cycle on increase alumni participation through a class-year challenge while making the operating tradeoffs clear to advancement stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- text: "Lakehaven Water District should focus the next cycle on approve staged replacement of high-risk mains while making the operating tradeoffs clear to public utilities stakeholders."

## s26

- Title: "Evidence Pack"
- pie chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")

## s27

- Title: "The Ask"
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "A title slide", "A simple list slide", "A closing slide"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"

## s28

- Title: "Execution Timeline"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-7.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-8.png; alt: "Warm earth hills at sunset")
- picture (file images/image-9.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-7.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-8.png; alt: "Warm earth hills at sunset")

## s29

- Title: "Execution Timeline"
- text: "North Pier Advisory should focus the next cycle on improve delivery margin without degrading client outcomes while making the operating tradeoffs clear to professional services stakeholders."
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s30

- Title: "Execution Timeline"
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Image backgrounds use a fixed image fill."
- text: "A shared layout contract gives the editor, preview, and PowerPoint export the same content geometry. The narrative stays in JSON and remains easy to revise."

## s31

- Title: "Decision and Follow Through"
- 100pct-stacked-column chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- histogram chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19

## s32

- Title: "School Safety Preparedness Brief"
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused."), "Consistent measures" (description: "Track completion and task time against a baseline."), "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s33

- Title: "Employee Town Hall Run of Show: why this matters"
- picture (file images/image-2.png; alt: "NORTH, fictional logo")
- picture (file images/image-3.png; alt: "FIELD, fictional logo")
- picture (file images/image-4.png; alt: "STUDIO, fictional logo")
- picture (file images/image-2.png; alt: "NORTH, fictional logo")
- picture (file images/image-3.png; alt: "FIELD, fictional logo")

## s34

- Title: "Decision Options"
- bar chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- text: "Granite ID should focus the next cycle on explain what happened and what changes prevent recurrence while making the operating tradeoffs clear to incident review stakeholders."

## s35

- Title: "Robotics Quality Escape Briefing: decision options"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s36

- Title: "Signal Trend"
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- treemap chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Security, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- quotation: "The bottom row remains available for interpretation."

## s37

- Title: "Decision Options"
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."

## s38

- Title: "Decision Rule"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- key number: 11 days, label "Illustrative result", change "-3 days", trend down

## s39

- Title: "Signal Trend"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Air travel, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s40

- Title: "Compliance Readiness Review"
- list: "Center and right span", "No overlap with left"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "Agree the budget", "Name the owners", "Review in March"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s41

- Title: "Distribution And Outliers"
- box-and-whisker chart: Cycle Time by Team; Alpha: 5, Beta: 8, Gamma: 12
- histogram chart: Count by Bucket; 0-5: 8, 6-10: 12, 11-15: 4
- scatter chart: Before, After by Metric; Latency: 420 / 210, Queue: 15 / 7

## s42

- Title: "Signal Trend"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "Center and right span", "No overlap with left"
- list: "What happens next?" (description: "Review completion and task time before expanding.")
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Agree the budget", "Name the owners", "Review in March"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s43

- Title: "Why This Matters"
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."

## s44

- Title: "Library Modernization Roadmap: demo moment"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Academic library, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Visitor orientation, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Higher education, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."

## s45

- Title: "Why This Matters"
- key number: 99.9%, label "Validation pass rate", note "Example value for renderer metric cards.", change "+2.1 pts", trend up
- text: "Waypoint Apps should focus the next cycle on move repetitive questions into self-service without hurting csat while making the operating tradeoffs clear to customer support stakeholders."
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up

## s46

- Title: "Start small enough to learn quickly"
- text: "Learn with two teams before expanding the rollout."

## s47

- Title: "FY27 Budget Tradeoff Deck: why this matters"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Ports and logistics working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Public utilities working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data engineering working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Corporate strategy working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Investor relations working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — City government working group

## s48

- Title: "Execution Timeline"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s49

- Title: "Airline Disruption Recovery Review: airline disruption recovery review"
- text: "AeroVista Airlines should focus the next cycle on shorten recovery time after weather-driven network disruption while making the operating tradeoffs clear to air travel stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."
- text: "RheinWorks Mobility should focus the next cycle on explain automation plans and worker safeguards clearly while making the operating tradeoffs clear to labor relations stakeholders."

## s50

- Title: "Court Backlog Reduction Plan: court backlog reduction plan"
- key number: 42 pts, label "Primary signal", note "Focus leadership debate on the few choices that matter", trend flat
- key number: $4.8M, label "Primary signal", note "Move anchor tenants from interest to signed letters of intent", trend up
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down
- key number: 18%, label "Primary signal", note "Qualify suppliers for the new battery enclosure line", trend flat
- key number: 91%, label "Primary signal", note "Prioritize second-source work for the highest-risk suppliers", trend up
- key number: 18%, label "Primary signal", note "Teach managers a repeatable coaching conversation model", trend flat
- key number: 42 pts, label "Primary signal", note "Prepare displaced workers for regional growth sectors", trend down
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat


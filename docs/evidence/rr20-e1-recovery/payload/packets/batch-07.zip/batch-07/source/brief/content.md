# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Proof Points"
- table with columns "Customer", "Cycle Time", "Change"; rows: [Globex, 11 days, -48%]; [Initech, 9 days, -52%]
- quotation: "The new workflow made exceptions visible before they became escalations." — VP Operations, Globex

## s02

- Title: "Signal Trend"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data engineering working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Operations working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Mining working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Pricing working group

## s03

- Title: "Demo Moment"
- text: "Keystone Build Partners should focus the next cycle on reset field safety practices before tower crane installation while making the operating tradeoffs clear to construction stakeholders."
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15

## s04

- Title: "The Ask"
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."
- text: "First: state the situation."
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- text: "Share results with both teams."

## s05

- Title: "The Ask"
- key number: 31%, label "Primary signal", note "Align growers on irrigation telemetry and drought response", trend flat

## s06

- Title: "Compare three visual directions"
- picture (file images/image-2.png; alt: "Blue and green landscape palette")
- picture (file images/image-3.png; alt: "Warm earth landscape palette")
- picture (file images/image-4.png; alt: "Purple landscape palette")

## s07

- Title: "Operating Model"
- text: "Civic Data Lab should focus the next cycle on show regional patterns with maps, charts, and concise interpretation while making the operating tradeoffs clear to data storytelling stakeholders."
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- text: "Name the next step and the person responsible for it."
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."

## s08

- Title: "Execution Timeline"
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- line chart: Actual, Target by Week; W1: 12 / 10, W2: 18 / 16

## s09

- Title: "Investor Relations Update: why this matters"
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-6.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-8.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s10

- Title: "Execution Timeline"
- picture (file images/image-8.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-6.png; alt: "Purple hills in evening light")

## s11

- Title: "Signal Trend"
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- picture (file images/image-8.png; alt: "Green hills under a pale blue sky")
- text: "Keep the recommendation and its evidence together."

## s12

- Title: "Row Spans"
- area chart: Volume by Month; Jan: 10, Feb: 18, Mar: 24
- quotation: "The bottom row remains available for interpretation."

## s13

- Title: "Grant Equity Review: grant equity review"
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- text: "Pioneer Instruments should focus the next cycle on reduce high-severity escapes through earlier verification while making the operating tradeoffs clear to quality assurance stakeholders."
- text: "Orbital Ridge Systems should focus the next cycle on prepare fleet support teams for the next launch window while making the operating tradeoffs clear to aerospace stakeholders."
- text: "North Pier Health should focus the next cycle on give directors the concise operating picture and needed decisions while making the operating tradeoffs clear to board update stakeholders."
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."

## s14

- Title: "Why This Matters"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat

## s15

- Title: "Execution Timeline"
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "A title slide", "A simple list slide", "A closing slide"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")

## s16

- Title: "Next Steps"
- picture (file images/image-9.png; alt: "NORTH, fictional logo")
- picture (file images/image-10.png; alt: "FIELD, fictional logo")
- picture (file images/image-11.png; alt: "STUDIO, fictional logo")
- picture (file images/image-9.png; alt: "NORTH, fictional logo")
- picture (file images/image-10.png; alt: "FIELD, fictional logo")
- picture (file images/image-11.png; alt: "STUDIO, fictional logo")
- picture (file images/image-9.png; alt: "NORTH, fictional logo")
- picture (file images/image-10.png; alt: "FIELD, fictional logo")

## s17

- Title: "Arabic Digital Services Brief: decision options"
- picture (file images/image-6.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-8.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s18

- Title: "Next Steps"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Q1: Pilot → Q2: Rollout → Q3: Scale
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Now: Observe → Next: Route → Then: Resolve

## s19

- Title: "District Literacy Acceleration Plan"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- text: "Riverbend Public Schools should focus the next cycle on raise third-grade reading proficiency through targeted intervention while making the operating tradeoffs clear to k-12 education stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Pricing working group

## s20

- Title: "Demo Moment"
- text: "Lakehaven Water District should focus the next cycle on approve staged replacement of high-risk mains while making the operating tradeoffs clear to public utilities stakeholders."
- text: "Measure the result."

## s21

- Title: "Signal Trend"
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "The new checklist reached both teams at the start of week four."
- text: "Text payloads accept plain strings or runs: bold, italic, and linked segments."

## s22

- Title: "Signal Trend"
- scatter chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26

## s23

- Title: "Execution Timeline"
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")

## s24

- Title: "The Ask"
- bullet points: "[object Object]", "[object Object]", "[object Object]"

## s25

- Title: "Signal Trend"
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")

## s26

- Title: "Operating Model"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Public engagement, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."

## s27

- Title: "Why This Matters"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Advancement, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Redwood College Foundation should focus the next cycle on increase alumni participation through a class-year challenge while making the operating tradeoffs clear to advancement stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Sales, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- table; rows: [First, Second]; [Third, Fourth]
- text: "Runs support bold, italic, underlined links, and custom color."

## s28

- Title: "Why This Matters"
- key number: 42 pts, label "Illustrative result", change "+6 pts", trend up
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."
- key number: 52, label "Trial participants", note "Across two field teams"
- text: "Option B: broad rollout
All teams, three months. Wider reach with greater coordination needs."
- key number: 6.2 min, label "Median task time", note "Target: under 7 min"
- text: "Text payloads accept plain strings or runs: bold, italic, and linked segments."

## s29

- Title: "Operating Model"
- text: "Inputs"
- text: "Processing"
- list: "Queue", "Route", "Resolve"

## s30

- Title: "Why This Matters"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Portfolio working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Procurement working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Marketing working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Operations working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Mining working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Training working group

## s31

- Title: "Consulting Margin Recovery Plan"
- pareto chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- list: "Standardize intake", "Publish escalation rules", "Review adoption weekly"

## s32

- Title: "Execution Timeline"
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Keep the recommendation and its evidence together."
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Name the next step and the person responsible for it."
- text: "Participants said the checklist made the next step obvious."

## s33

- Title: "School Safety Preparedness Brief"
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- key number: 11 days, label "Primary signal", note "Shorten recovery time after weather-driven network disruption", trend up

## s34

- Title: "Completion rose through the pilot"
- Subtitle: "Share of tasks completed, by week of the pilot"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s35

- Title: "Evidence Pack"
- text: "Northgate Museum should focus the next cycle on prepare a self-running lobby deck with concise navigation cues while making the operating tradeoffs clear to visitor orientation stakeholders."
- text: "First: state the situation."
- text: "Narrative beats describe authoring intent without constraining slide structure."
- text: "Describe the decision."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s36

- Title: "The Ask"
- bar chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- stacked-column chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19

## s37

- Title: "Signal Trend"


## s38

- Title: "The Ask"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-8.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s39

- Title: "Decision Options"
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- picture (file images/image-6.png; alt: "Purple hills in evening light")

## s40

- Title: "Performance"
- line chart: Median latency by Quarter; Q1: 420, Q2: 310, Q3: 260, Q4: 190
- text: "Latency improved 55% over the last four quarters."

## s41

- Title: "Housing Zoning Council Brief: decision and follow through"
- text: "City of Redwood Falls should focus the next cycle on prepare council to vote on mixed-income zoning changes while making the operating tradeoffs clear to city government stakeholders."
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- text: "Riverbend Public Schools should focus the next cycle on raise third-grade reading proficiency through targeted intervention while making the operating tradeoffs clear to k-12 education stakeholders."
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- text: "Urban Lens Collective should focus the next cycle on tell a coherent civic story through image-heavy slides while making the operating tradeoffs clear to portfolio stakeholders."
- text: "North Pier Health should focus the next cycle on give directors the concise operating picture and needed decisions while making the operating tradeoffs clear to board update stakeholders."
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."

## s42

- Title: "Signal Trend"
- key number: 9, label "Escalations"
- pareto chart: Current, Baseline by Quarter; Q1: 19 / 16, Q2: 23 / 18, Q3: 26 / 20, Q4: 30 / 22
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Sales, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Operations working group

## s43

- Title: "Operating Model"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Queue", "Route", "Resolve"
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"

## s44

- Title: "Compliance Readiness Review"
- picture (file images/image-9.png; alt: "NORTH, fictional logo")
- picture (file images/image-10.png; alt: "FIELD, fictional logo")
- picture (file images/image-11.png; alt: "STUDIO, fictional logo")
- picture (file images/image-9.png; alt: "NORTH, fictional logo")
- picture (file images/image-10.png; alt: "FIELD, fictional logo")
- picture (file images/image-11.png; alt: "STUDIO, fictional logo")
- picture (file images/image-9.png; alt: "NORTH, fictional logo")
- picture (file images/image-10.png; alt: "FIELD, fictional logo")
- picture (file images/image-11.png; alt: "STUDIO, fictional logo")

## s45

- Title: "Brazil Climate Adaptation Brief: execution timeline"
- picture (file images/image-6.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-8.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-6.png; alt: "Purple hills in evening light")

## s46

- Title: "Execution Timeline"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed

## s47

- Title: "Demo Moment"
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Academic library working group

## s48

- Title: "Decision Rule"
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."
- text: "First: state the situation."
- text: "The deck-level language can be a catalog id or BCP-47 tag."

## s49

- Title: "Decision Options"
- text: "Waypoint Apps should focus the next cycle on move repetitive questions into self-service without hurting csat while making the operating tradeoffs clear to customer support stakeholders."
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."
- text: "Summit State Athletics should focus the next cycle on balance competitive goals with travel and facility constraints while making the operating tradeoffs clear to college athletics stakeholders."

## s50

- Title: "Why This Matters"
- area chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- text: "Morrow Labs should focus the next cycle on align investment choices to margin and growth guardrails while making the operating tradeoffs clear to finance stakeholders."


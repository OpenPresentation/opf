# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Next Steps"
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Queue", "Route", "Resolve"

## s02

- Title: "Evidence Pack"
- stacked-column chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up

## s03

- Title: "Why This Matters"
- list: "Center and right span", "No overlap with left"
- list: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")

## s04

- Title: "Signal Trend"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")

## s05

- Title: "Signal Trend"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Workforce education, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]

## s06

- Title: "Decision Rule"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat
- text: "Signal"
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- text: "ClearLake Data should focus the next cycle on approve controls for customer-facing predictive models while making the operating tradeoffs clear to analytics stakeholders."
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down

## s07

- Title: "Team Responsibilities"
- text: "Product"
- text: "Engineering"
- text: "Operations"
- bullet points: "Weekly planning review", "Shared risk register", "Single launch checklist"

## s08

- Title: "Execution Timeline"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Marketing working group

## s09

- Title: "Why This Matters"
- pie chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s10

- Title: "Operating Model"
- text: "Metro Transit Authority should focus the next cycle on compare bus rapid transit options for the east corridor while making the operating tradeoffs clear to transportation stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- text: "Task completion climbed from 68% to 84% over the first four weeks of the pilot."
- text: "Document-local catalog records can be referenced by id from the same OPF document."
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")

## s11

- Title: "Why This Matters"
- key number: 18%, label "Primary signal", note "Qualify suppliers for the new battery enclosure line", trend flat
- key number: 31%, label "Primary signal", note "Move analytics workloads with minimal reporting disruption", trend up
- key number: 18%, label "Primary signal", note "Recover weekday occupancy through segmented offers and events", trend down

## s12

- Title: "The largest gain came in week four"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s13

- Title: "Demo Moment"
- text: "Urban Lens Collective should focus the next cycle on tell a coherent civic story through image-heavy slides while making the operating tradeoffs clear to portfolio stakeholders."
- text: "The new checklist reached both teams at the start of week four."
- text: "AtlasWorks should focus the next cycle on grow the strategic account through a measurable multi-threaded plan while making the operating tradeoffs clear to sales stakeholders."
- text: "Participants said the checklist made the next step obvious."
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- text: "Approve $1.2M to expand the rollout to all regions in Q4."

## s14

- Title: "Developer Conference Talk"
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- key number: $820K, label "Primary signal", note "Coordinate launch story, proof, and field actions", trend down
- key number: $820K, label "Illustrative result", change "+$20K", trend up
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")

## s15

- Title: "Onboarding Experience Redesign: why this matters"
- Subtitle: "Kindred Systems should focus the next cycle on reduce new-hire time to productivity with clearer role paths while making the operating tradeoffs clear to human resources stakeholders."


## s16

- Title: "Signal Trend"
- picture (file images/image-4.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")

## s17

- Title: "Branch Modernization Investment Case"
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- text: "The new checklist reached both teams at the start of week four."
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Approve $1.2M to expand the rollout to all regions in Q4."

## s18

- Title: "Next Focus"
- text: "Reduce long-tail retries"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"

## s19

- Title: "Parks Master Plan Workshop: parks master plan workshop"
- text: "Greenway Parks Department should focus the next cycle on gather resident input on park access and maintenance while making the operating tradeoffs clear to parks and recreation stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Harbor City University should focus the next cycle on expand counseling access through stepped-care delivery while making the operating tradeoffs clear to student affairs stakeholders."
- text: "Copper Mesa Mining should focus the next cycle on fund remote monitoring for high-priority containment sites while making the operating tradeoffs clear to mining stakeholders."
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."

## s20

- Title: "Operating Model"
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- 100pct-stacked-column chart: Current, Baseline by Quarter; Q1: 17 / 14, Q2: 21 / 16, Q3: 24 / 18, Q4: 28 / 20
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Pricing, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s21

- Title: "District Literacy Acceleration Plan"
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")

## s22

- Title: "Contract Cycle Time Brief: the ask"
- picture (file images/image-6.png; alt: "NORTH, fictional logo")

## s23

- Title: "German Works Council Update: the ask"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-4.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s24

- Title: "Why This Matters"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed

## s25

- Title: "Execution Timeline"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."

## s26

- Title: "Decision and Follow Through"
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Keep the recommendation and its evidence together."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."

## s27

- Title: "Execution Timeline"
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "SilverOak Group should focus the next cycle on right-size office services around actual hybrid usage while making the operating tradeoffs clear to facilities stakeholders."
- quotation: "The new workflow made exceptions visible before they became escalations." — VP Operations, Acme Corp

## s28

- Title: "Execution Timeline"
- column chart: Current, Baseline by Quarter; Q1: 28 / 25, Q2: 32 / 27, Q3: 35 / 29, Q4: 39 / 31
- text: "Sable Systems should focus the next cycle on explain incident response status and the residual risk plan while making the operating tradeoffs clear to security stakeholders."
- column chart: Revenue by Quarter; Q1: 12, Q2: 18, Q3: 24, Q4: 22

## s29

- Title: "Evidence Pack"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s30

- Title: "Pipeline Chart"
- bar chart: Count by Stage; Lead: 120, Qualified: 64, Proposal: 31, Won: 12

## s31

- Title: "Execution Timeline"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"

## s32

- Title: "Next Steps"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Revenue operations working group
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s33

- Title: "Decision Options"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [College athletics, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Summit State Athletics should focus the next cycle on balance competitive goals with travel and facility constraints while making the operating tradeoffs clear to college athletics stakeholders."

## s34

- Title: "Decision and Follow Through"
- key number: 31 %, label "Illustrative result", change "+6 pts", trend up
- text: "Cobalt Supply should focus the next cycle on resolve demand and supply gaps before the monthly consensus call while making the operating tradeoffs clear to operations stakeholders."
- key number: 42 pts, label "Primary signal", note "Resolve demand and supply gaps before the monthly consensus call", trend down
- text: "Keep the recommendation and its evidence together."
- key number: 84%, label "Task completion", note "Target: at least 80%"
- text: "Share results with both teams."
- key number: 2.4x, label "Primary signal", note "Approve a revised data ethics requirement", trend down
- text: "Describe the decision."

## s35

- Title: "A smaller pilot. A clearer decision."
- Subtitle: "A six-week pilot with two teams"
- picture (file images/image-7.png; alt: "Illustrative landscape with two green ridges")

## s36

- Title: "Why This Matters"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Public utilities working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Tax administration working group

## s37

- Title: "Signal Trend"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up
- key number: 9, label "Escalations"

## s38

- Title: "Signal Trend"
- text: "County Health Alliance should focus the next cycle on increase booster uptake in neighborhoods with low access while making the operating tradeoffs clear to public health stakeholders."

## s39

- Title: "STEM Lab Funding Proposal: signal trend"
- key number: $4.8M, label "Primary signal", note "Reset field safety practices before tower crane installation", trend down
- key number: 91%, label "Primary signal", note "Increase household recycling participation with clearer guidance", trend flat
- key number: $820K, label "Primary signal", note "Approve controls for customer-facing predictive models", trend down
- key number: 11 days, label "Primary signal", note "Show regional patterns with maps, charts, and concise interpretation", trend down

## s40

- Title: "Compare outcomes on consistent measures"
- table with columns "Team", "Participants", "Completion", "Median time (min)"; rows: [A, 28, 89%, 5.8]; [B, 24, 79%, 6.7]
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s41

- Title: "Decision Rule"
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."

## s42

- Title: "Why This Matters"
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s43

- Title: "Signal Trend"
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s44

- Title: "Why This Matters"
- picture (file images/image-4.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-4.png; alt: "Purple hills in evening light")

## s45

- Title: "Why This Matters"
- text: "Pinnacle Mutual should focus the next cycle on speed low-complexity claims while preserving adjuster judgment while making the operating tradeoffs clear to insurance stakeholders."
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- text: "Pattern backgrounds carry a preset plus foreground and background colors."
- picture (file images/image-4.png; alt: "Purple hills in evening light")

## s46

- Title: "Buyer Signal"
- text: "Teams want fewer exports."
- text: "They want review status, owners, and exceptions in one operating view."

## s47

- Title: "Police Training Program Update: why this matters"
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Metro Transit Authority should focus the next cycle on compare bus rapid transit options for the east corridor while making the operating tradeoffs clear to transportation stakeholders."
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."
- text: "Prairie Ridge High School should focus the next cycle on secure funding for hands-on robotics and chemistry labs while making the operating tradeoffs clear to k-12 education stakeholders."
- text: "Cobalt Supply should focus the next cycle on resolve demand and supply gaps before the monthly consensus call while making the operating tradeoffs clear to operations stakeholders."
- text: "Redwood College Foundation should focus the next cycle on increase alumni participation through a class-year challenge while making the operating tradeoffs clear to advancement stakeholders."
- text: "Kindred Systems should focus the next cycle on reduce new-hire time to productivity with clearer role paths while making the operating tradeoffs clear to human resources stakeholders."
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- text: "North Pier Health should focus the next cycle on give directors the concise operating picture and needed decisions while making the operating tradeoffs clear to board update stakeholders."

## s48

- Title: "Evidence Pack"
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s49

- Title: "Demo Moment"
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "Establish a baseline" (description: "Measure the current completion rate and task time.")
- list: "What happens next?" (description: "Review completion and task time before expanding.")
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")

## s50

- Title: "Data Platform Migration Plan: signal trend"
- picture (file images/image-6.png; alt: "NORTH, fictional logo")
- picture (file images/image-8.png; alt: "FIELD, fictional logo")


# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "India Rural Payments Pilot: india rural payments pilot"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")

## s02

- Title: "Execution Timeline"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s03

- Title: "The Ask"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Center for Urban Oceans should focus the next cycle on win support for a cross-disciplinary coastal resilience study while making the operating tradeoffs clear to research stakeholders."

## s04

- Title: "Airline Disruption Recovery Review"
- text: "AeroVista Airlines should focus the next cycle on shorten recovery time after weather-driven network disruption while making the operating tradeoffs clear to air travel stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."
- text: "Measure the result."
- text: "Learn with two teams before expanding the rollout."

## s05

- Title: "Operating Model"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- text: "Civic Data Lab should focus the next cycle on show regional patterns with maps, charts, and concise interpretation while making the operating tradeoffs clear to data storytelling stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data storytelling working group

## s06

- Title: "Investor Relations Update: why this matters"
- stacked-line chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- bar chart: Current, Baseline by Quarter; Q1: 19 / 16, Q2: 23 / 18, Q3: 26 / 20, Q4: 30 / 22
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."

## s07

- Title: "Field Context"
- list: "A title slide", "A simple list slide", "A closing slide"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"

## s08

- Title: "Mixed Evidence Blocks"
- key number: 18%, label "Cycle time reduction", trend up
- column chart: Escalations by Sprint; S1: 14, S2: 10, S3: 6
- quotation: "Blocks let authors provide coherent content without deciding exact placement." — Layout resolver
- table with columns "Block", "Renderer decision"; rows: [Metric, Hero number]; [Chart, Main visual]; [Quote, Supporting proof]

## s09

- Title: "The Ask"
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s10

- Title: "Grant Equity Review"
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- key number: 31%, label "Primary signal", note "Explain broadband route choices and resident impact", trend flat
- quotation: "The new workflow made exceptions visible before they became escalations." — VP Operations, Acme Corp

## s11

- Title: "Execution Timeline"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Higher education, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Lakeside University should focus the next cycle on reduce campus energy use without disrupting instruction while making the operating tradeoffs clear to higher education stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Investor relations, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]

## s12

- Title: "Execution Timeline"
- key number: 31 %, label "Illustrative result", change "+6 pts", trend up
- text: "Lumina Foods should focus the next cycle on prepare supplier data collection for annual climate reporting while making the operating tradeoffs clear to sustainability stakeholders."
- key number: 52, label "Trial participants", note "Target: 50 participants"
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- key number: 31%, label "Primary signal", note "Frame tradeoffs for a pending legislative decision", trend up
- text: "Run a six-week pilot with two teams before expanding. The pilot gives us a baseline, weekly feedback and one clear decision at the end."
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- text: "Document-local catalog records can be referenced by id from the same OPF document."
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down

## s13

- Title: "Test before scaling"
- Subtitle: "Part 2: the evidence"


## s14

- Title: "Evidence Pack"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Engineering working group
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Workforce development working group

## s15

- Title: "Next Steps"
- key number: 18%, label "Primary signal", note "Recover weekday occupancy through segmented offers and events", trend down
- key number: 11 days, label "Primary signal", note "Prepare council to vote on mixed-income zoning changes", trend up
- key number: 31%, label "Primary signal", note "Align growers on irrigation telemetry and drought response", trend flat

## s16

- Title: "Demo Moment"
- text: "Lakehaven Water District should focus the next cycle on approve staged replacement of high-risk mains while making the operating tradeoffs clear to public utilities stakeholders."
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s17

- Title: "Student Mental Health Capacity Review: decision options"
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat
- key number: 11 days, label "Primary signal", note "Balance competitive goals with travel and facility constraints", trend flat
- key number: 18%, label "Primary signal", note "Teach managers a repeatable coaching conversation model", trend flat

## s18

- Title: "Team B needs targeted support"
- table with columns "Team", "Participants", "Completion", "Median time (min)"; rows: [A, 28, 89%, 5.8]; [B, 24, 79%, 6.7]
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s19

- Title: "Decision Options"
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."

## s20

- Title: "Execution Timeline"
- text: "PeopleCraft should focus the next cycle on teach managers a repeatable coaching conversation model while making the operating tradeoffs clear to training stakeholders."
- combo chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18

## s21

- Title: "Operating Model"
- list: "Queue", "Route", "Resolve"
- list: "Content can opt into card rendering.", "Alignment can change per slide."

## s22

- Title: "Signal Trend"
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s23

- Title: "Signal Trend"
- text: "Greenbasket Markets should focus the next cycle on cut shrink across produce and prepared foods without hurting freshness while making the operating tradeoffs clear to retail grocery stakeholders."

## s24

- Title: "Quarter Snapshot"
- table with columns "Metric", "Q3", "Q4"; rows: [Revenue, $12.4M, $18.1M]; [Gross margin, 68%, 72%]; [Pipeline, $31M, $44M]
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s25

- Title: "Signal Trend"
- text: "City Sanitation Bureau should focus the next cycle on increase household recycling participation with clearer guidance while making the operating tradeoffs clear to sanitation stakeholders."

## s26

- Title: "Why This Matters"
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s27

- Title: "Signal Trend"
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s28

- Title: "Defect Escape Reduction Review: why this matters"
- picture (file images/image-6.png; alt: "NORTH, fictional logo")
- picture (file images/image-7.png; alt: "FIELD, fictional logo")
- picture (file images/image-8.png; alt: "STUDIO, fictional logo")

## s29

- Title: "Japan Market Entry Readout: why this matters"
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")

## s30

- Title: "Operating Model"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed

## s31

- Title: "School Safety Preparedness Brief"
- timeline: Now: Observe → Next: Route → Then: Resolve
- key number: 2, label "Teams", note "One workflow each"

## s32

- Title: "Why This Matters"
- text: "Northstar Care Network should focus the next cycle on reduce missed appointments while protecting clinician capacity while making the operating tradeoffs clear to healthcare operations stakeholders."
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- text: "First: state the situation."
- text: "Participants said the checklist made the next step obvious."
- text: "The dashboard pulls review status, owners, and exceptions into one operating view."
- text: "AtlasWorks should focus the next cycle on grow the strategic account through a measurable multi-threaded plan while making the operating tradeoffs clear to sales stakeholders."

## s33

- Title: "Evidence Pack"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Northgate Museum should focus the next cycle on prepare a self-running lobby deck with concise navigation cues while making the operating tradeoffs clear to visitor orientation stakeholders."

## s34

- Title: "Model Governance Review: signal trend"
- stacked-bar chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- text: "ClearLake Data should focus the next cycle on approve controls for customer-facing predictive models while making the operating tradeoffs clear to analytics stakeholders."
- histogram chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- waterfall chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16

## s35

- Title: "Decision Rule"
- list: "Classic theme", "Corporate blue color scheme", "Left-aligned content"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "What happens next?" (description: "Review completion and task time before expanding.")
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "Queue", "Route", "Resolve"

## s36

- Title: "Catalog Overrides"
- text: "Document-local catalog records can be referenced by id from the same OPF document."

## s37

- Title: "Execution Timeline"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Queue", "Route", "Resolve"

## s38

- Title: "Decision and Follow Through"
- stacked-column chart: Current, Baseline by Quarter; Q1: 19 / 16, Q2: 23 / 18, Q3: 26 / 20, Q4: 30 / 22
- key number: 11 days, label "Primary signal", note "Prepare council to vote on mixed-income zoning changes", trend up
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — City government working group

## s39

- Title: "Curriculum Approval Brief: operating model"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Academic governance, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Oakbridge Faculty Senate should focus the next cycle on approve a revised data ethics requirement while making the operating tradeoffs clear to academic governance stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Workforce education, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s40

- Title: "Why This Matters"
- key number: 42 pts, label "Primary signal", note "Focus leadership debate on the few choices that matter", trend flat

## s41

- Title: "From the problem to the next decision"
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"

## s42

- Title: "Enterprise Account Expansion Plan: the ask"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Research report working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Revenue operations working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — College athletics working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Tax administration working group

## s43

- Title: "Execution Timeline"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Energy utilities, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."

## s44

- Title: "Decision Rule"
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- picture (file images/image-3.png; alt: "Purple hills in evening light")

## s45

- Title: "Workforce Pathway Partnership: execution timeline"
- key number: 18%, label "Primary signal", note "Connect employer demand to short-cycle training capacity", trend down
- key number: 11 days, label "Illustrative result", change "-3 days", trend down
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up
- key number: 42 pts, label "Primary signal", note "Resolve demand and supply gaps before the monthly consensus call", trend down
- key number: 91%, label "Primary signal", note "Increase household recycling participation with clearer guidance", trend flat
- key number: 42%, label "Review cycle reduction", note "Median reduction across customer review workflows.", change "+11 pts", trend up

## s46

- Title: "Keep the implementation easy to inspect"
- code (javascript):
```
const total = items.reduce((sum, item) => sum + item.value, 0);
console.log(total);
```
- text: "The reducer adds each item’s value to a running sum. Starting at zero also makes an empty list return zero."

## s47

- Title: "Execution Timeline"
- text: "North Valley State should focus the next cycle on improve first-year retention through proactive advising while making the operating tradeoffs clear to student success stakeholders."
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- text: "Center for Urban Oceans should focus the next cycle on win support for a cross-disciplinary coastal resilience study while making the operating tradeoffs clear to research stakeholders."

## s48

- Title: "Next Steps"
- text: "North Pier Health should focus the next cycle on give directors the concise operating picture and needed decisions while making the operating tradeoffs clear to board update stakeholders."
- 100pct-stacked-area chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28

## s49

- Title: "Evidence Pack"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"
- list: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"

## s50

- Title: "Why This Matters"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")


# Content for a 50-slide deck

Brand colours: background #011842 (alternate surface #0B2A5C), text #FFFFFF, secondary text #C9D3E0, accent #5499C7, light #F0F0F0. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Why This Matters"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat

## s02

- Title: "Next Steps"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Q1: Pilot → Q2: Rollout → Q3: Scale
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Now: Observe → Next: Route → Then: Resolve

## s03

- Title: "Operating Model"
- text: "Inputs"
- text: "Processing"
- list: "Queue", "Route", "Resolve"

## s04

- Title: "School Safety Preparedness Brief"
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- key number: 11 days, label "Primary signal", note "Shorten recovery time after weather-driven network disruption", trend up

## s05

- Title: "Why This Matters"
- area chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- text: "Morrow Labs should focus the next cycle on align investment choices to margin and growth guardrails while making the operating tradeoffs clear to finance stakeholders."

## s06

- Title: "Signal Trend"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s07

- Title: "District Literacy Acceleration Plan"
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")

## s08

- Title: "Next Steps"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Revenue operations working group
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s09

- Title: "Why This Matters"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Public utilities working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Tax administration working group

## s10

- Title: "Evidence Pack"
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s11

- Title: "Execution Timeline"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s12

- Title: "Test before scaling"
- Subtitle: "Part 2: the evidence"


## s13

- Title: "Student Mental Health Capacity Review: decision options"
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat
- key number: 11 days, label "Primary signal", note "Balance competitive goals with travel and facility constraints", trend flat
- key number: 18%, label "Primary signal", note "Teach managers a repeatable coaching conversation model", trend flat

## s14

- Title: "Model Governance Review: signal trend"
- stacked-bar chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- text: "ClearLake Data should focus the next cycle on approve controls for customer-facing predictive models while making the operating tradeoffs clear to analytics stakeholders."
- histogram chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- waterfall chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16

## s15

- Title: "Why This Matters"
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s16

- Title: "Decision Options"
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s17

- Title: "Parks Master Plan Workshop"
- text: "Greenway Parks Department should focus the next cycle on gather resident input on park access and maintenance while making the operating tradeoffs clear to parks and recreation stakeholders."
- text: "Signal"
- text: "Start with a baseline."
- text: "Cost: two team leads at 20% for six weeks."

## s18

- Title: "Field Enablement Certification: field enablement certification"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data storytelling working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Ports and logistics working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Corporate strategy working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Construction working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Emergency management working group

## s19

- Title: "Decision and Follow Through"
- 100pct-stacked-column chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- histogram chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19

## s20

- Title: "Robotics Quality Escape Briefing: decision options"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s21

- Title: "Start small enough to learn quickly"
- text: "Learn with two teams before expanding the rollout."

## s22

- Title: "Court Backlog Reduction Plan: court backlog reduction plan"
- key number: 42 pts, label "Primary signal", note "Focus leadership debate on the few choices that matter", trend flat
- key number: $4.8M, label "Primary signal", note "Move anchor tenants from interest to signed letters of intent", trend up
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down
- key number: 18%, label "Primary signal", note "Qualify suppliers for the new battery enclosure line", trend flat
- key number: 91%, label "Primary signal", note "Prioritize second-source work for the highest-risk suppliers", trend up
- key number: 18%, label "Primary signal", note "Teach managers a repeatable coaching conversation model", trend flat
- key number: 42 pts, label "Primary signal", note "Prepare displaced workers for regional growth sectors", trend down
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat

## s23

- Title: "Operating Model"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Pricing, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Northbeam Software should focus the next cycle on select the packaging move that improves conversion and expansion while making the operating tradeoffs clear to pricing stakeholders."

## s24

- Title: "Execution Timeline"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s25

- Title: "STEM Lab Funding Proposal: signal trend"
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for human resources.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s26

- Title: "Decision Options"
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data engineering working group

## s27

- Title: "Why This Matters"
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- text: "First: state the situation."

## s28

- Title: "Signal Trend"
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."
- scatter chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26

## s29

- Title: "Streaming Churn Winback Strategy: streaming churn winback strategy"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s30

- Title: "Make the next step explicit"
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Agree the budget", "Name the owners", "Review in March"

## s31

- Title: "Decision and Follow Through"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s32

- Title: "Decision Rule"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Revenue operations, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Pricing, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "The new checklist reached both teams at the start of week four."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Public safety, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]

## s33

- Title: "German Works Council Update: decision options"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s34

- Title: "Operating Model"
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s35

- Title: "Vaccination Outreach Briefing"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down

## s36

- Title: "Signal Trend"
- text: "Meridian Cloud should focus the next cycle on help regional partners explain the new integration story while making the operating tradeoffs clear to partnerships stakeholders."
- text: "Inputs"
- text: "Slide-level design can suppress inherited repeated furniture."
- text: "SilverOak Group should focus the next cycle on right-size office services around actual hybrid usage while making the operating tradeoffs clear to facilities stakeholders."
- text: "Decision owners need one place to see what changed."

## s37

- Title: "Operating Model"
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s38

- Title: "Decision Options"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- text: "Oaktrail Animal Health should focus the next cycle on balance appointment access with staff retention while making the operating tradeoffs clear to veterinary care stakeholders."

## s39

- Title: "Scope, evidence and the next decision"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."

## s40

- Title: "Signal Trend"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s41

- Title: "Why This Matters"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Corporate strategy, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."

## s42

- Title: "Customer QBR Renewal Deck: customer qbr renewal deck"
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s43

- Title: "Grant Equity Review"
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- text: "Measure the result."
- text: "Gradient backgrounds carry angle and color stops."
- text: "Support it with evidence and context that the audience can understand."
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s44

- Title: "Decision and Follow Through"
- key number: 42 pts, label "Primary signal", note "Prepare displaced workers for regional growth sectors", trend down
- stacked-line-with-markers chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Workforce development, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Workforce development working group

## s45

- Title: "Decision Options"
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."

## s46

- Title: "Decision Rule"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Sales demo, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."

## s47

- Title: "Brazil Climate Adaptation Brief"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- text: "Instituto Verde Norte should focus the next cycle on align municipal leaders on flood-readiness investments while making the operating tradeoffs clear to climate adaptation stakeholders."
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed

## s48

- Title: "Three steps from evidence to decision"
- list: "Establish a baseline" (description: "Measure the current completion rate and task time.")
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")

## s49

- Title: "Operating Model"
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")

## s50

- Title: "Workplace Occupancy Reset: workplace occupancy reset"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Facilities, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "SilverOak Group should focus the next cycle on right-size office services around actual hybrid usage while making the operating tradeoffs clear to facilities stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Ports and logistics, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Novara Therapeutics should focus the next cycle on restore patient enrollment momentum across priority sites while making the operating tradeoffs clear to pharmaceuticals stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Conference talk, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]


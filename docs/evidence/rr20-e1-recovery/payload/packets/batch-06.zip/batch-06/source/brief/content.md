# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Decision Options"
- text: "Waypoint Apps should focus the next cycle on move repetitive questions into self-service without hurting csat while making the operating tradeoffs clear to customer support stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."

## s02

- Title: "India Rural Payments Pilot"
- list: "Agree on the owner for financial inclusion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")

## s03

- Title: "FY27 Budget Tradeoff Deck: why this matters"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")

## s04

- Title: "Execution Timeline"
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s05

- Title: "Airline Disruption Recovery Review"
- text: "AeroVista Airlines should focus the next cycle on shorten recovery time after weather-driven network disruption while making the operating tradeoffs clear to air travel stakeholders."

## s06

- Title: "Follow-Up"
- list: "Confirm owners for open exceptions.", "Review aging thresholds with operations leads.", "Schedule the next dashboard readout."

## s07

- Title: "Court Backlog Reduction Plan: signal trend"
- text: "County Court Administration should focus the next cycle on reduce case backlog through calendar redesign while making the operating tradeoffs clear to justice administration stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- text: "Bluewater Logistics should focus the next cycle on reduce container dwell time through scheduling and yard visibility while making the operating tradeoffs clear to ports and logistics stakeholders."
- text: "Novara Therapeutics should focus the next cycle on restore patient enrollment momentum across priority sites while making the operating tradeoffs clear to pharmaceuticals stakeholders."

## s08

- Title: "Why This Matters"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."

## s09

- Title: "Signal Trend"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s10

- Title: "Field Context"
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")

## s11

- Title: "Why This Matters"
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-8.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s12

- Title: "Why This Matters"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Step 1: Author → Step 2: Validate → Step 3: Render

## s13

- Title: "Campus Energy Action Brief"
- text: "Lakeside University should focus the next cycle on reduce campus energy use without disrupting instruction while making the operating tradeoffs clear to higher education stakeholders."
- text: "Option B: broad rollout
All teams, three months. Wider reach with greater coordination needs."
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- text: "Review feedback every week."

## s14

- Title: "Transit Corridor Alternatives: operating model"
- text: "Metro Transit Authority should focus the next cycle on compare bus rapid transit options for the east corridor while making the operating tradeoffs clear to transportation stakeholders."
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Greenbasket Markets should focus the next cycle on cut shrink across produce and prepared foods without hurting freshness while making the operating tradeoffs clear to retail grocery stakeholders."
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."
- text: "Lakeside University should focus the next cycle on reduce campus energy use without disrupting instruction while making the operating tradeoffs clear to higher education stakeholders."
- text: "North Pier Health should focus the next cycle on give directors the concise operating picture and needed decisions while making the operating tradeoffs clear to board update stakeholders."

## s15

- Title: "Scope 3 Reporting Readiness"
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 22 / 19, Q2: 26 / 21, Q3: 29 / 23, Q4: 33 / 25
- key number: 52, label "Trial participants", note "Across two field teams"
- quotation: "The payload model stays predictable even as slide content varies." — OPF technical fixture

## s16

- Title: "Evidence Pack"
- funnel chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- waterfall chart: Value by Step; Start: 100, Expansion: 24, Churn: -8, End: 116

## s17

- Title: "Developer Conference Talk: developer conference talk"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s18

- Title: "Decision Rule"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s19

- Title: "Rural Broadband Expansion Proposal: signal trend"
- text: "MesaLink Fiber should focus the next cycle on secure local support for phase two broadband construction while making the operating tradeoffs clear to telecommunications stakeholders."
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- text: "Common Table Network should focus the next cycle on expand distribution throughput before the summer demand spike while making the operating tradeoffs clear to nonprofit food security stakeholders."
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."

## s20

- Title: "The Ask"
- key number: $4.8M, label "Primary signal", note "Move anchor tenants from interest to signed letters of intent", trend up
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat

## s21

- Title: "The Ask"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Design system, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Marketing, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Signal"

## s22

- Title: "Operating Model"
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up
- text: "Northbeam Software should focus the next cycle on select the packaging move that improves conversion and expansion while making the operating tradeoffs clear to pricing stakeholders."
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- text: "Keep the recommendation and its evidence together."

## s23

- Title: "Revenue By Region"
- column chart: Q2, Q3 by Region; Americas: 4.2 / 5.1, EMEA: 3.1 / 3.9, APAC: 1.8 / 2.6

## s24

- Title: "The Ask"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Analytics working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Sanitation working group
- quotation: "The new workflow made exceptions visible before they became escalations." — VP Operations, Globex
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s25

- Title: "Execution Timeline"
- text: "Greenbasket Markets should focus the next cycle on cut shrink across produce and prepared foods without hurting freshness while making the operating tradeoffs clear to retail grocery stakeholders."
- 100pct-stacked-column chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17

## s26

- Title: "Signal Trend"
- text: "City Sanitation Bureau should focus the next cycle on increase household recycling participation with clearer guidance while making the operating tradeoffs clear to sanitation stakeholders."
- text: "Measure the result."
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s27

- Title: "Execution Timeline"
- key number: 84%, label "Task completion", note "Target: at least 80%"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- key number: 2.4x, label "Primary signal", note "Approve a revised data ethics requirement", trend down
- key number: 6.2 min, label "Median time"
- key number: 18%, label "Cycle time reduction", trend up
- key number: 31%, label "Primary signal", note "Frame tradeoffs for a pending legislative decision", trend up

## s28

- Title: "Explain what the audience should notice"
- picture (file images/image-9.png; alt: "Illustrative landscape with two green ridges")
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s29

- Title: "Execution Timeline"
- text: "SilverOak Group should focus the next cycle on right-size office services around actual hybrid usage while making the operating tradeoffs clear to facilities stakeholders."
- text: "Start with a baseline."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s30

- Title: "Why This Matters"
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s31

- Title: "Identity Incident Executive Brief: execution timeline"
- picture (file images/image-8.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")

## s32

- Title: "Operating Model"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s33

- Title: "Why This Matters"
- text: "Northstar Care Network should focus the next cycle on reduce missed appointments while protecting clinician capacity while making the operating tradeoffs clear to healthcare operations stakeholders."
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s34

- Title: "Minimal OPF Deck"


## s35

- Title: "Digital Services Modernization: next steps"
- text: "State Service Office should focus the next cycle on improve permit experience through one-stop online services while making the operating tradeoffs clear to digital government stakeholders."
- text: "Copperline Health should focus the next cycle on align leaders on narrative, timing, and live questions while making the operating tradeoffs clear to corporate communications stakeholders."
- text: "Cobalt Supply should focus the next cycle on resolve demand and supply gaps before the monthly consensus call while making the operating tradeoffs clear to operations stakeholders."
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- text: "RheinWorks Mobility should focus the next cycle on explain automation plans and worker safeguards clearly while making the operating tradeoffs clear to labor relations stakeholders."

## s36

- Title: "Signal Trend"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up

## s37

- Title: "Decision Options"
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"

## s38

- Title: "Decision Rule"
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")
- picture (file images/image-5.png; alt: "NORTH, fictional logo")

## s39

- Title: "Water Stewardship Grower Brief: execution timeline"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-8.png; alt: "Warm earth hills at sunset")

## s40

- Title: "Signal Trend"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed

## s41

- Title: "Operating Model"
- text: "Oakbridge Faculty Senate should focus the next cycle on approve a revised data ethics requirement while making the operating tradeoffs clear to academic governance stakeholders."
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."
- text: "County Health Alliance should focus the next cycle on increase booster uptake in neighborhoods with low access while making the operating tradeoffs clear to public health stakeholders."

## s42

- Title: "Signal Trend"
- text: "County Health Alliance should focus the next cycle on increase booster uptake in neighborhoods with low access while making the operating tradeoffs clear to public health stakeholders."

## s43

- Title: "Why This Matters"
- stacked-area chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- key number: 42 pts, label "Primary signal", note "Focus leadership debate on the few choices that matter", trend flat
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Corporate strategy working group

## s44

- Title: "Why This Matters"
- waterfall chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- text: "AtlasWorks should focus the next cycle on grow the strategic account through a measurable multi-threaded plan while making the operating tradeoffs clear to sales stakeholders."
- scatter chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26
- text: "Product"
- radar chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- text: "Measure the result."

## s45

- Title: "Executive Workshop Facilitation: why this matters"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s46

- Title: "Decision and Follow Through"
- list: "undefined", "Name the sponsor and operating owner." (description: "Keep one person accountable for momentum."), "Publish the progress rhythm." (description: "Use the same metric definitions every week."), "Return with proof." (description: "Bring customer, employee, resident, or learner evidence into the next review.")

## s47

- Title: "Satellite Maintenance Readiness Review: why this matters"
- text: "Orbital Ridge Systems should focus the next cycle on prepare fleet support teams for the next launch window while making the operating tradeoffs clear to aerospace stakeholders."
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Northstar Care Network should focus the next cycle on reduce missed appointments while protecting clinician capacity while making the operating tradeoffs clear to healthcare operations stakeholders."
- text: "Granite Falls District should focus the next cycle on clarify safety protocols before the fall semester while making the operating tradeoffs clear to school operations stakeholders."
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."

## s48

- Title: "Execution Timeline"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Community college, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Metro Technical College should focus the next cycle on connect employer demand to short-cycle training capacity while making the operating tradeoffs clear to community college stakeholders."

## s49

- Title: "Advising Retention Review"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Student success, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "North Valley State should focus the next cycle on improve first-year retention through proactive advising while making the operating tradeoffs clear to student success stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Hospitality, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "First: state the situation."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Compliance, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s50

- Title: "Evidence Pack"
- key number: 42 pts, label "Illustrative result", change "+6 pts", trend up
- text: "LatticeLane should focus the next cycle on decide which roadmap bets move into the second half build window while making the operating tradeoffs clear to product stakeholders."
- key number: 2.4x, label "Primary signal", note "Decide which roadmap bets move into the second half build window", trend up
- text: "Explain the tradeoffs."
- key number: 31%, label "Primary signal", note "Explain broadband route choices and resident impact", trend flat


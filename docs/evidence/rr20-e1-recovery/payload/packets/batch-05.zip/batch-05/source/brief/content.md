# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Execution Timeline"
- text: "Metro Technical College should focus the next cycle on connect employer demand to short-cycle training capacity while making the operating tradeoffs clear to community college stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."

## s02

- Title: "Why This Matters"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- text: "Morrow Labs should focus the next cycle on align investment choices to margin and growth guardrails while making the operating tradeoffs clear to finance stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Workforce development working group

## s03

- Title: "Advising Retention Review: advising retention review"
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s04

- Title: "Next Steps"
- picture (file images/image-2.png; alt: "NORTH, fictional logo")
- picture (file images/image-3.png; alt: "FIELD, fictional logo")
- picture (file images/image-4.png; alt: "STUDIO, fictional logo")
- picture (file images/image-2.png; alt: "NORTH, fictional logo")

## s05

- Title: "Why This Matters"
- picture (file images/image-5.png; alt: "Purple hills in evening light")

## s06

- Title: "Demo Moment"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed

## s07

- Title: "Execution Timeline"
- funnel chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s08

- Title: "Regulatory Risk Brief: the ask"
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."

## s09

- Title: "Decision Rule"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- picture (file images/image-5.png; alt: "Purple hills in evening light")

## s10

- Title: "Execution Timeline"
- world chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- doughnut chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16

## s11

- Title: "Execution Timeline"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- text: "Apex Support Cloud should focus the next cycle on prove realized value and align on next-quarter expansion while making the operating tradeoffs clear to qbr stakeholders."
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed

## s12

- Title: "Operating Model"
- key number: 18%, label "Primary signal", note "Close audit evidence gaps before external assessment", trend up
- text: "Tandem BioSystems should focus the next cycle on close audit evidence gaps before external assessment while making the operating tradeoffs clear to compliance stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Compliance working group
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Compliance, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s13

- Title: "Execution Timeline"
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."

## s14

- Title: "Why This Matters"
- combo chart: Current, Baseline by Quarter; Q1: 22 / 19, Q2: 26 / 21, Q3: 29 / 23, Q4: 33 / 25
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s15

- Title: "Demo Moment"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Portfolio, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Urban Lens Collective should focus the next cycle on tell a coherent civic story through image-heavy slides while making the operating tradeoffs clear to portfolio stakeholders."

## s16

- Title: "Why This Matters"
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up
- text: "Kindred Systems should focus the next cycle on reduce new-hire time to productivity with clearer role paths while making the operating tradeoffs clear to human resources stakeholders."

## s17

- Title: "Arrange each idea and its supporting details"
- a group of: text: "Keep the recommendation and its evidence together."; a group of: text: "Evidence: share the same geometry across previews and exports."; text: "Action: revise one group without rearranging the whole slide."
- text: "A separate column holds the supporting context."

## s18

- Title: "Next Steps"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Operations working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Engineering working group

## s19

- Title: "Branch Modernization Investment Case"
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- key number: 84%, label "Completion"
- key number: 2, label "Teams", note "One workflow each"
- picture (file images/image-5.png; alt: "Purple hills in evening light")

## s20

- Title: "Signal Trend"
- text: "Greenway Parks Department should focus the next cycle on gather resident input on park access and maintenance while making the operating tradeoffs clear to parks and recreation stakeholders."

## s21

- Title: "District Literacy Acceleration Plan"
- key number: 42 pts, label "Illustrative result", change "+6 pts", trend up
- key number: 42 pts, label "Primary signal", note "Approve staged replacement of high-risk mains", trend up
- key number: 52, label "Trial participants", note "Across two field teams"
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up
- key number: 2.1x, label "Quarter-over-quarter adoption", change "+8 regions", trend up
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down

## s22

- Title: "Track performance against a target"
- key number: 52, label "Trial participants", note "Target: 50 participants"
- key number: 84%, label "Task completion", note "Target: at least 80%"
- key number: 6.2 min, label "Median task time", note "Target: under 7 min"

## s23

- Title: "Signal Trend"
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."

## s24

- Title: "Why This Matters"
- key number: 2.4x, label "Primary signal", note "Decide which roadmap bets move into the second half build window", trend up
- line chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Labor relations, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Transportation working group

## s25

- Title: "Signal Trend"
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-7.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-8.png; alt: "Warm earth hills at sunset")

## s26

- Title: "Managed Detection Market Update: why this matters"
- stacked-column chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19
- key number: $820K, label "Primary signal", note "Approve controls for customer-facing predictive models", trend down
- stacked-line chart: Current, Baseline by Quarter; Q1: 17 / 14, Q2: 21 / 16, Q3: 24 / 18, Q4: 28 / 20
- key number: 11 days, label "Primary signal", note "Shorten recovery time after weather-driven network disruption", trend up
- stacked-bar chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up

## s27

- Title: "Workforce Reskilling Initiative: decision and follow through"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-7.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-8.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")

## s28

- Title: "The numbers and the voice agree"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- quotation: "The weekly review keeps the next step clear." — Product lead

## s29

- Title: "Operating Model"
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."
- text: "Redwood College Foundation should focus the next cycle on increase alumni participation through a class-year challenge while making the operating tradeoffs clear to advancement stakeholders."

## s30

- Title: "Identity Incident Executive Brief"
- code (python):
```
for region in regions:
    deck = build_review(region)
    validate(deck)
    publish(deck)
```
- text: "Sable Systems should focus the next cycle on explain incident response status and the residual risk plan while making the operating tradeoffs clear to security stakeholders."

## s31

- Title: "Alumni Giving Campaign: why this matters"
- list: "Two teams must release a lead at 20%", "Weekly reviews need a fixed slot", "Analytics needs read access to both workflows"
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Capacity: two regions are at 85% utilization.", "Churn risk in the legacy tier." (description: "Mitigation: migration incentives ship in November."), "Vendor SLA renegotiation slips to Q1."
- list: "Agree on the owner for human resources.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for seed pitch.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s32

- Title: "Evidence Pack"
- picture (file images/image-2.png; alt: "NORTH, fictional logo")
- picture (file images/image-3.png; alt: "FIELD, fictional logo")
- picture (file images/image-4.png; alt: "STUDIO, fictional logo")
- picture (file images/image-2.png; alt: "NORTH, fictional logo")
- picture (file images/image-3.png; alt: "FIELD, fictional logo")

## s33

- Title: "Trial Enrollment Rescue Plan"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-6.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s34

- Title: "Consulting Margin Recovery Plan"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s35

- Title: "Decision Options"
- line-with-markers chart: Current, Baseline by Quarter; Q1: 28 / 25, Q2: 32 / 27, Q3: 35 / 29, Q4: 39 / 31
- key number: 11 days, label "Primary signal", note "Balance competitive goals with travel and facility constraints", trend flat
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — College athletics working group

## s36

- Title: "Tax Portal Modernization: execution timeline"
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."
- text: "North Pier Advisory should focus the next cycle on improve delivery margin without degrading client outcomes while making the operating tradeoffs clear to professional services stakeholders."
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."

## s37

- Title: "Decision and Follow Through"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Operations working group
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")

## s38

- Title: "Why This Matters"
- line-with-markers chart: Current, Baseline by Quarter; Q1: 18 / 15, Q2: 22 / 17, Q3: 25 / 19, Q4: 29 / 21
- text: "Copperline Health should focus the next cycle on align leaders on narrative, timing, and live questions while making the operating tradeoffs clear to corporate communications stakeholders."
- area chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."

## s39

- Title: "Data Incident Postmortem: the ask"
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- text: "Granite ID should focus the next cycle on explain what happened and what changes prevent recurrence while making the operating tradeoffs clear to incident review stakeholders."
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- text: "North Valley State should focus the next cycle on improve first-year retention through proactive advising while making the operating tradeoffs clear to student success stakeholders."

## s40

- Title: "Evidence Pack"
- area chart: Current, Baseline by Quarter; Q1: 18 / 15, Q2: 22 / 17, Q3: 25 / 19, Q4: 29 / 21
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- key number: 11 days, label "Illustrative result", change "-3 days", trend down

## s41

- Title: "Robotics Quality Escape Briefing: the ask"
- text: "Axis Forge Robotics should focus the next cycle on lower rework on the actuator line before the seasonal volume ramp while making the operating tradeoffs clear to advanced manufacturing stakeholders."
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- text: "Kindred Systems should focus the next cycle on reduce new-hire time to productivity with clearer role paths while making the operating tradeoffs clear to human resources stakeholders."
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."

## s42

- Title: "Signal Trend"
- key number: +8 pts, label "Week four gain", note "From 76% to 84%"
- key number: 6.2 min, label "Median time"
- key number: 31 %, label "Illustrative result", change "+6 pts", trend up

## s43

- Title: "Decision Rule"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Sales demo, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Mining, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]

## s44

- Title: "Signal Trend"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up
- text: "Meridian Cloud should focus the next cycle on help regional partners explain the new integration story while making the operating tradeoffs clear to partnerships stakeholders."
- key number: $820K, label "Illustrative result", change "+$20K", trend up

## s45

- Title: "Adoption Doubled"
- key number: 2.1x, label "Quarter-over-quarter adoption", change "+8 regions", trend up
- line chart: Active Teams by Month; Apr: 96, May: 112, Jun: 131, Jul: 188, Aug: 236, Sep: 288

## s46

- Title: "Compliance Readiness Review"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Compliance working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Pricing working group

## s47

- Title: "Why This Matters"
- text: "Pinnacle Mutual should focus the next cycle on speed low-complexity claims while preserving adjuster judgment while making the operating tradeoffs clear to insurance stakeholders."
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down
- key number: 11 days, label "Primary signal", note "Launch an integrated campaign around the new benchmark report", trend down
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")

## s48

- Title: "Decision Options"
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Signal"

## s49

- Title: "Demo Moment"
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- key number: 84%, label "Completion"
- key number: 2.4x, label "Primary signal", note "Approve a revised data ethics requirement", trend down
- key number: 6.2 min, label "Median task time", note "Target: under 7 min"
- key number: 6.2 min, label "Median time"
- key number: 42, label "Inputs"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"

## s50

- Title: "Give the visual room to speak"
- picture (file images/image-9.png; alt: "Illustrative landscape with two green ridges")


# Content for a 50-slide deck

Brand colours: background #011842 (alternate surface #0B2A5C), text #FFFFFF, secondary text #C9D3E0, accent #5499C7, light #F0F0F0. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Execution Timeline"
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s02

- Title: "Pilot outcomes in four measures"
- key number: 52, label "Trial participants", note "Across two field teams"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- key number: 2, label "Teams", note "One workflow each"

## s03

- Title: "Why This Matters"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s04

- Title: "Signal Trend"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Prairie Ridge High School should focus the next cycle on secure funding for hands-on robotics and chemistry labs while making the operating tradeoffs clear to k-12 education stakeholders."
- code (ts):
```
export const valid = result.errors.length === 0;
```
- text: "Keep the recommendation and its evidence together."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s05

- Title: "Compliance Readiness Review"
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")

## s06

- Title: "Why This Matters"
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- stacked-line chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30

## s07

- Title: "Decision Options"
- text: "Tempo Burger Group should focus the next cycle on increase lunch peak capacity with staffing and menu simplification while making the operating tradeoffs clear to quick service restaurants stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s08

- Title: "Streaming Churn Winback Strategy"
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- text: "Signalhouse Media should focus the next cycle on reverse premium subscriber churn with better lifecycle moments while making the operating tradeoffs clear to media and entertainment stakeholders."
- quotation: "The bottom row remains available for interpretation."

## s09

- Title: "Online Program Launch Plan"
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- text: "Teams want fewer exports."
- text: "Team B trails on both measures. Pair its lead with Team A for weeks five and six."
- text: "Review feedback every week."

## s10

- Title: "Decision and Follow Through"
- text: "City of Redwood Falls should focus the next cycle on prepare council to vote on mixed-income zoning changes while making the operating tradeoffs clear to city government stakeholders."
- key number: 11 days, label "Primary signal", note "Prepare council to vote on mixed-income zoning changes", trend up
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s11

- Title: "Enterprise Account Expansion Plan: decision options"
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for seed pitch.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s12

- Title: "Week four brought the biggest gain"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- a group of: key number: +8 pts, label "Week four gain", note "From 76% to 84%"; text: "The new checklist reached both teams at the start of week four."

## s13

- Title: "Retail Launch Readiness Deck"
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s14

- Title: "Operating Model"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."

## s15

- Title: "Decision Options"
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s16

- Title: "Signal Trend"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up
- key number: +8 pts, label "Week four gain", note "From 76% to 84%"
- key number: 52, label "Trial participants", note "Target: 50 participants"

## s17

- Title: "Grid Resilience Capital Plan"
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."
- text: "Measure the result."
- text: "Name the next step and the person responsible for it."
- text: "Team B trails on both measures. Pair its lead with Team A for weeks five and six."
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."

## s18

- Title: "Decision Options"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Oaktrail Animal Health should focus the next cycle on balance appointment access with staff retention while making the operating tradeoffs clear to veterinary care stakeholders."

## s19

- Title: "Why This Matters"
- text: "Canyon Unified Schools should focus the next cycle on improve evaluation timelines and family communication while making the operating tradeoffs clear to student services stakeholders."
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."
- text: "Evidence: share the same geometry across previews and exports."
- text: "Inputs"
- text: "Pattern backgrounds carry a preset plus foreground and background colors."
- text: "Then: explain the change."

## s20

- Title: "Signal Trend"
- stacked-column chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29

## s21

- Title: "Identity Incident Executive Brief: identity incident executive brief"
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Confirm owners for open exceptions.", "Review aging thresholds with operations leads.", "Schedule the next dashboard readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Capacity: two regions are at 85% utilization.", "Churn risk in the legacy tier." (description: "Mitigation: migration incentives ship in November."), "Vendor SLA renegotiation slips to Q1."
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"

## s22

- Title: "Where Team B falls behind"
- Subtitle: "Results to the end of week four"
- table with columns "Team", "Participants", "Completion", "Median time (min)"; rows: [A, 28, 89%, 5.8]; [B, 24, 79%, 6.7]
- text: "Team B trails on both measures. Pair its lead with Team A for weeks five and six."

## s23

- Title: "Decision Options"
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")

## s24

- Title: "Grant Equity Review: grant equity review"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s25

- Title: "Evidence Pack"
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s26

- Title: "Decision Options"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Customer success, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."

## s27

- Title: "Operating Model"
- text: "Bluewater Logistics should focus the next cycle on reduce container dwell time through scheduling and yard visibility while making the operating tradeoffs clear to ports and logistics stakeholders."
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."

## s28

- Title: "Brazil Climate Adaptation Brief"
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- histogram chart: Current, Baseline by Quarter; Q1: 19 / 16, Q2: 23 / 18, Q3: 26 / 20, Q4: 30 / 22
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Climate adaptation, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Training working group

## s29

- Title: "Execution Timeline"
- text: "Metro Technical College should focus the next cycle on connect employer demand to short-cycle training capacity while making the operating tradeoffs clear to community college stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."

## s30

- Title: "Operating Model"
- key number: 18%, label "Primary signal", note "Close audit evidence gaps before external assessment", trend up
- text: "Tandem BioSystems should focus the next cycle on close audit evidence gaps before external assessment while making the operating tradeoffs clear to compliance stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Compliance working group
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Compliance, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s31

- Title: "Why This Matters"
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up
- text: "Kindred Systems should focus the next cycle on reduce new-hire time to productivity with clearer role paths while making the operating tradeoffs clear to human resources stakeholders."

## s32

- Title: "The numbers and the voice agree"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- quotation: "The weekly review keeps the next step clear." — Product lead

## s33

- Title: "Trial Enrollment Rescue Plan"
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s34

- Title: "Decision Options"
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Signal"

## s35

- Title: "FY27 Budget Tradeoff Deck: why this matters"
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")

## s36

- Title: "Scope 3 Reporting Readiness"
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 22 / 19, Q2: 26 / 21, Q3: 29 / 23, Q4: 33 / 25
- key number: 52, label "Trial participants", note "Across two field teams"
- quotation: "The payload model stays predictable even as slide content varies." — OPF technical fixture

## s37

- Title: "Rural Broadband Expansion Proposal: signal trend"
- text: "MesaLink Fiber should focus the next cycle on secure local support for phase two broadband construction while making the operating tradeoffs clear to telecommunications stakeholders."
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- text: "Common Table Network should focus the next cycle on expand distribution throughput before the summer demand spike while making the operating tradeoffs clear to nonprofit food security stakeholders."
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."

## s38

- Title: "Why This Matters"
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s39

- Title: "Digital Services Modernization: next steps"
- text: "State Service Office should focus the next cycle on improve permit experience through one-stop online services while making the operating tradeoffs clear to digital government stakeholders."
- text: "Copperline Health should focus the next cycle on align leaders on narrative, timing, and live questions while making the operating tradeoffs clear to corporate communications stakeholders."
- text: "Cobalt Supply should focus the next cycle on resolve demand and supply gaps before the monthly consensus call while making the operating tradeoffs clear to operations stakeholders."
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- text: "RheinWorks Mobility should focus the next cycle on explain automation plans and worker safeguards clearly while making the operating tradeoffs clear to labor relations stakeholders."

## s40

- Title: "Decision and Follow Through"
- list: "undefined", "Name the sponsor and operating owner." (description: "Keep one person accountable for momentum."), "Publish the progress rhythm." (description: "Use the same metric definitions every week."), "Return with proof." (description: "Bring customer, employee, resident, or learner evidence into the next review.")

## s41

- Title: "Evidence Pack"
- key number: 42 pts, label "Illustrative result", change "+6 pts", trend up
- text: "LatticeLane should focus the next cycle on decide which roadmap bets move into the second half build window while making the operating tradeoffs clear to product stakeholders."
- key number: 2.4x, label "Primary signal", note "Decide which roadmap bets move into the second half build window", trend up
- text: "Explain the tradeoffs."
- key number: 31%, label "Primary signal", note "Explain broadband route choices and resident impact", trend flat

## s42

- Title: "Row Spans"
- area chart: Volume by Month; Jan: 10, Feb: 18, Mar: 24
- quotation: "The bottom row remains available for interpretation."

## s43

- Title: "Arabic Digital Services Brief: decision options"
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s44

- Title: "Execution Timeline"
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Keep the recommendation and its evidence together."
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Name the next step and the person responsible for it."
- text: "Participants said the checklist made the next step obvious."

## s45

- Title: "Signal Trend"


## s46

- Title: "Decision Options"
- text: "Waypoint Apps should focus the next cycle on move repetitive questions into self-service without hurting csat while making the operating tradeoffs clear to customer support stakeholders."
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."
- text: "Summit State Athletics should focus the next cycle on balance competitive goals with travel and facility constraints while making the operating tradeoffs clear to college athletics stakeholders."

## s47

- Title: "Why This Matters"
- list: "Center and right span", "No overlap with left"
- list: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")

## s48

- Title: "Developer Conference Talk"
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- key number: $820K, label "Primary signal", note "Coordinate launch story, proof, and field actions", trend down
- key number: $820K, label "Illustrative result", change "+$20K", trend up
- picture (file images/image-1.png; alt: "Portrait silhouette on a light background")

## s49

- Title: "Parks Master Plan Workshop: parks master plan workshop"
- text: "Greenway Parks Department should focus the next cycle on gather resident input on park access and maintenance while making the operating tradeoffs clear to parks and recreation stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Harbor City University should focus the next cycle on expand counseling access through stepped-care delivery while making the operating tradeoffs clear to student affairs stakeholders."
- text: "Copper Mesa Mining should focus the next cycle on fund remote monitoring for high-priority containment sites while making the operating tradeoffs clear to mining stakeholders."
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."

## s50

- Title: "Pipeline Chart"
- bar chart: Count by Stage; Lead: 120, Qualified: 64, Proposal: 31, Won: 12


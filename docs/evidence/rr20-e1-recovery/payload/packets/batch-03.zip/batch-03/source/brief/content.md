# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Grid Resilience Capital Plan"
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."
- text: "Measure the result."
- text: "Name the next step and the person responsible for it."
- text: "Team B trails on both measures. Pair its lead with Team A for weeks five and six."
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."

## s02

- Title: "Demo Moment"
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s03

- Title: "Support Deflection Program: the ask"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Customer support, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Waypoint Apps should focus the next cycle on move repetitive questions into self-service without hurting csat while making the operating tradeoffs clear to customer support stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Automotive supply, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."

## s04

- Title: "FY27 Budget Tradeoff Deck: why this matters"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for human resources.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Capacity: two regions are at 85% utilization.", "Churn risk in the legacy tier." (description: "Mitigation: migration incentives ship in November."), "Vendor SLA renegotiation slips to Q1."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")

## s05

- Title: "Timeline Payload"
- timeline: Step 1: Author → Step 2: Validate → Step 3: Render

## s06

- Title: "Monthly Board Update: next steps"
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for insurance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s07

- Title: "Airline Disruption Recovery Review"
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "A title slide", "A simple list slide", "A closing slide"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")

## s08

- Title: "Execution Timeline"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "County Court Administration should focus the next cycle on reduce case backlog through calendar redesign while making the operating tradeoffs clear to justice administration stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s09

- Title: "Execution Timeline"
- key number: 52, label "Trial participants", note "Illustrative six-week pilot"
- key number: 2.4x, label "Primary signal", note "Approve a revised data ethics requirement", trend down
- key number: 2, label "Teams", note "One workflow each"

## s10

- Title: "Three steps from evidence to decision"
- list: "Establish a baseline" (description: "Measure the current completion rate and task time.")
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")

## s11

- Title: "Decision Rule"
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- text: "Bluewater Logistics should focus the next cycle on reduce container dwell time through scheduling and yard visibility while making the operating tradeoffs clear to ports and logistics stakeholders."

## s12

- Title: "Decision Options"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Oaktrail Animal Health should focus the next cycle on balance appointment access with staff retention while making the operating tradeoffs clear to veterinary care stakeholders."

## s13

- Title: "Execution Timeline"
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s14

- Title: "Decision Options"
- pie chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down

## s15

- Title: "Operating Model"
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")

## s16

- Title: "What participants noticed"
- picture (file images/image-6.png; alt: "Illustrative landscape with two green ridges")
- text: "Participants said the checklist made the next step obvious."
- quotation: "We can now see where participants need help." — Pilot lead

## s17

- Title: "Why This Matters"
- text: "Canyon Unified Schools should focus the next cycle on improve evaluation timelines and family communication while making the operating tradeoffs clear to student services stakeholders."
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."
- text: "Evidence: share the same geometry across previews and exports."
- text: "Inputs"
- text: "Pattern backgrounds carry a preset plus foreground and background colors."
- text: "Then: explain the change."

## s18

- Title: "Evidence Pack"
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."
- text: "Image backgrounds use a fixed image fill."
- text: "Participants said the checklist made the next step obvious."
- text: "Narrative beats describe authoring intent without constraining slide structure."

## s19

- Title: "Photo Essay Portfolio: demo moment"
- list: "Two teams must release a lead at 20%", "Weekly reviews need a fixed slot", "Analytics needs read access to both workflows"
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for financial inclusion.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s20

- Title: "Signal Trend"
- picture (file images/image-7.png; alt: "NORTH, fictional logo")

## s21

- Title: "Signal Trend"
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s22

- Title: "Branch Modernization Investment Case"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s23

- Title: "Why This Matters"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Design system, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."

## s24

- Title: "Signal Trend"
- text: "Greenway Parks Department should focus the next cycle on gather resident input on park access and maintenance while making the operating tradeoffs clear to parks and recreation stakeholders."

## s25

- Title: "Operating Model"
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up
- key number: $820K, label "Primary signal", note "Approve controls for customer-facing predictive models", trend down

## s26

- Title: "Contract Cycle Time Brief: why this matters"
- box-and-whisker chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."
- doughnut chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- text: "Sahyog Pay should focus the next cycle on evaluate pilot results before expanding rural merchant coverage while making the operating tradeoffs clear to financial inclusion stakeholders."

## s27

- Title: "Why This Matters"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- text: "RheinWorks Mobility should focus the next cycle on explain automation plans and worker safeguards clearly while making the operating tradeoffs clear to labor relations stakeholders."
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- text: "The deck-level language can be a catalog id or BCP-47 tag."

## s28

- Title: "Signal Trend"
- stacked-column chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29

## s29

- Title: "Why This Matters"
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "Option A: focused pilot
Two teams, six weeks. Low setup cost and a clear baseline."
- text: "LatticeLane should focus the next cycle on decide which roadmap bets move into the second half build window while making the operating tradeoffs clear to product stakeholders."
- text: "Decide with the evidence, not the calendar."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s30

- Title: "Online Program Launch Plan"
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."
- world chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17

## s31

- Title: "Workplace Occupancy Reset: workplace occupancy reset"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Facilities, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "SilverOak Group should focus the next cycle on right-size office services around actual hybrid usage while making the operating tradeoffs clear to facilities stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Ports and logistics, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Novara Therapeutics should focus the next cycle on restore patient enrollment momentum across priority sites while making the operating tradeoffs clear to pharmaceuticals stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Conference talk, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]

## s32

- Title: "Identity Incident Executive Brief: identity incident executive brief"
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Confirm owners for open exceptions.", "Review aging thresholds with operations leads.", "Schedule the next dashboard readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Capacity: two regions are at 85% utilization.", "Churn risk in the legacy tier." (description: "Mitigation: migration incentives ship in November."), "Vendor SLA renegotiation slips to Q1."
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"

## s33

- Title: "Give the main idea more room"
- Subtitle: "Weighted tracks preserve intent as the content changes."
- text: "A shared layout contract gives the editor, preview, and PowerPoint export the same content geometry. The narrative stays in JSON and remains easy to revise."
- text: "Change the words. Keep the structure. Review the result."

## s34

- Title: "Policy Briefing for Advisors: evidence pack"
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for human resources.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s35

- Title: "Why This Matters"
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for insurance.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s36

- Title: "Digital Services Modernization: next steps"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "State Service Office should focus the next cycle on improve permit experience through one-stop online services while making the operating tradeoffs clear to digital government stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."

## s37

- Title: "Decision Options"
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- key number: 11 days, label "Primary signal", note "Balance competitive goals with travel and facility constraints", trend flat
- key number: 18%, label "Cycle time reduction", trend up
- key number: 2.1x, label "Quarter-over-quarter adoption", change "+8 regions", trend up

## s38

- Title: "Six weeks to an informed decision"
- timeline: Week 1: Baseline → Weeks 2–5: Pilot → Week 6: Review and decide
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s39

- Title: "S&OP Exception Review: decision and follow through"
- text: "Cobalt Supply should focus the next cycle on resolve demand and supply gaps before the monthly consensus call while making the operating tradeoffs clear to operations stakeholders."
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Oaktrail Animal Health should focus the next cycle on balance appointment access with staff retention while making the operating tradeoffs clear to veterinary care stakeholders."
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."

## s40

- Title: "Execution Timeline"
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up

## s41

- Title: "Why This Matters"
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")

## s42

- Title: "Execution Timeline"
- stacked-line-with-markers chart: Current, Baseline by Quarter; Q1: 18 / 15, Q2: 22 / 17, Q3: 25 / 19, Q4: 29 / 21
- key number: 42 pts, label "Primary signal", note "Prepare displaced workers for regional growth sectors", trend down
- stacked-column chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29

## s43

- Title: "Execution Timeline"
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")

## s44

- Title: "Where Team B falls behind"
- Subtitle: "Results to the end of week four"
- table with columns "Team", "Participants", "Completion", "Median time (min)"; rows: [A, 28, 89%, 5.8]; [B, 24, 79%, 6.7]
- text: "Team B trails on both measures. Pair its lead with Team A for weeks five and six."

## s45

- Title: "Signal Trend"
- text: "Prairie Ridge High School should focus the next cycle on secure funding for hands-on robotics and chemistry labs while making the operating tradeoffs clear to k-12 education stakeholders."
- text: "The new checklist reached both teams at the start of week four."
- text: "Inputs"
- text: "They want review status, owners, and exceptions in one operating view."
- text: "Measure the result."
- text: "The tone dark picks the dark1 variant, so the text and lines read on the picture."
- text: "Share results with both teams."
- text: "Run a six-week pilot with two teams before expanding. The pilot gives us a baseline, weekly feedback and one clear decision at the end."
- text: "Name the next step and the person responsible for it."

## s46

- Title: "Decision Options"
- text: "AtlasWorks should focus the next cycle on grow the strategic account through a measurable multi-threaded plan while making the operating tradeoffs clear to sales stakeholders."
- text: "Canyon Unified Schools should focus the next cycle on improve evaluation timelines and family communication while making the operating tradeoffs clear to student services stakeholders."
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Northgate Museum should focus the next cycle on prepare a self-running lobby deck with concise navigation cues while making the operating tradeoffs clear to visitor orientation stakeholders."

## s47

- Title: "Video Demo Sales Narrative: decision rule"
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."
- list: "Agree on the owner for seed pitch.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")

## s48

- Title: "Decision Options"
- picture (file images/image-7.png; alt: "NORTH, fictional logo")
- picture (file images/image-8.png; alt: "FIELD, fictional logo")

## s49

- Title: "Decision Options"
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s50

- Title: "Why This Matters"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed


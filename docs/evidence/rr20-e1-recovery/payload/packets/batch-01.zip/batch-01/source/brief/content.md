# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Compliance Readiness Review"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")

## s02

- Title: "Why This Matters"
- histogram chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26
- key number: 2, label "Teams", note "One workflow each"
- bar chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- key number: 42, label "Inputs"

## s03

- Title: "The Ask"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s04

- Title: "Completion rose every week"
- text: "Task completion climbed from 68% to 84% over the first four weeks of the pilot."
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%

## s05

- Title: "Demo Moment"
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "Tandem BioSystems should focus the next cycle on close audit evidence gaps before external assessment while making the operating tradeoffs clear to compliance stakeholders."
- text: "Next step: name the pilot lead and agree the start date."

## s06

- Title: "Signal Trend"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")

## s07

- Title: "The Ask"
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."

## s08

- Title: "India Rural Payments Pilot: india rural payments pilot"
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")

## s09

- Title: "Execution Timeline"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")

## s10

- Title: "Airline Disruption Recovery Review"
- text: "AeroVista Airlines should focus the next cycle on shorten recovery time after weather-driven network disruption while making the operating tradeoffs clear to air travel stakeholders."
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- text: "Oakbridge Faculty Senate should focus the next cycle on approve a revised data ethics requirement while making the operating tradeoffs clear to academic governance stakeholders."

## s11

- Title: "Operating Model"
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s12

- Title: "Execution Timeline"
- text: "County Court Administration should focus the next cycle on reduce case backlog through calendar redesign while making the operating tradeoffs clear to justice administration stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- text: "Apex Support Cloud should focus the next cycle on prove realized value and align on next-quarter expansion while making the operating tradeoffs clear to qbr stakeholders."

## s13

- Title: "Why This Matters"
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- stacked-line chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30

## s14

- Title: "Field Context"
- box-and-whisker chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."

## s15

- Title: "Decision Options"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- text: "Oaktrail Animal Health should focus the next cycle on balance appointment access with staff retention while making the operating tradeoffs clear to veterinary care stakeholders."

## s16

- Title: "Grant Equity Review"
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- key number: 52, label "Trial participants", note "Illustrative six-week pilot"
- key number: 52, label "Trial participants", note "Across two field teams"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")

## s17

- Title: "Decision Options"
- text: "Tempo Burger Group should focus the next cycle on increase lunch peak capacity with staffing and menu simplification while making the operating tradeoffs clear to quick service restaurants stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s18

- Title: "Signal Trend"
- waterfall chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16
- line chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27

## s19

- Title: "Signal Trend"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Sustainability, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]

## s20

- Title: "Engineering Capacity Planning: evidence pack"
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."

## s21

- Title: "Code Payload"
- code (ts):
```
export const valid = result.errors.length === 0;
```

## s22

- Title: "Developer Conference Talk: signal trend"
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."

## s23

- Title: "Demo Moment"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- key number: 42 pts, label "Primary signal", note "Approve staged replacement of high-risk mains", trend up

## s24

- Title: "Why This Matters"
- code (python):
```
if risk > threshold:
    escalate(owner)
else:
    approve(change)
```
- text: "Harbor City University should focus the next cycle on expand counseling access through stepped-care delivery while making the operating tradeoffs clear to student affairs stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s25

- Title: "Visual Brand System Sampler: why this matters"
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- key number: 2.4x, label "Primary signal", note "Fund remote monitoring for high-priority containment sites", trend flat
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- key number: 99.9%, label "Validation pass rate", note "Example value for renderer metric cards.", change "+2.1 pts", trend up
- text: "Oakbridge Faculty Senate should focus the next cycle on approve a revised data ethics requirement while making the operating tradeoffs clear to academic governance stakeholders."
- key number: 31%, label "Primary signal", note "Align growers on irrigation telemetry and drought response", trend flat
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- key number: $4.8M, label "Primary signal", note "Prepare the quarter narrative for public-market investors", trend flat

## s26

- Title: "Scope, evidence and the next decision"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."

## s27

- Title: "Operating Model"
- text: "Northbeam Software should focus the next cycle on select the packaging move that improves conversion and expansion while making the operating tradeoffs clear to pricing stakeholders."
- text: "Signal"
- text: "Action: revise one group without rearranging the whole slide."
- text: "Apex Support Cloud should focus the next cycle on prove realized value and align on next-quarter expansion while making the operating tradeoffs clear to qbr stakeholders."
- text: "Keep the recommendation and its evidence together."
- text: "The deck-level header, footer, organization logo and watermark apply by default; the footer zone draws the logo icon beside the organization name."

## s28

- Title: "Streaming Churn Winback Strategy"
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- text: "Signalhouse Media should focus the next cycle on reverse premium subscriber churn with better lifecycle moments while making the operating tradeoffs clear to media and entertainment stakeholders."
- quotation: "The bottom row remains available for interpretation."

## s29

- Title: "Why This Matters"
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")

## s30

- Title: "Cold Chain Waste Reduction Review"
- 100pct-stacked-column chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- combo chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- key number: 11 days, label "Illustrative result", change "-3 days", trend down
- area chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18

## s31

- Title: "Signal Trend"
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s32

- Title: "What the first four weeks show"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- bullet points: "Completion rose 16 points", "The largest gain came in week four", "Team B needs targeted support"

## s33

- Title: "Online Program Launch Plan"
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- text: "Teams want fewer exports."
- text: "Team B trails on both measures. Pair its lead with Team A for weeks five and six."
- text: "Review feedback every week."

## s34

- Title: "The Ask"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Construction working group
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s35

- Title: "Workplace Occupancy Reset"
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."

## s36

- Title: "Japan Market Entry Readout: why this matters"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")
- picture (file images/image-5.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s37

- Title: "Operating Model"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s38

- Title: "Ambulatory Access Recovery Plan: why this matters"
- text: "Northstar Care Network should focus the next cycle on reduce missed appointments while protecting clinician capacity while making the operating tradeoffs clear to healthcare operations stakeholders."
- text: "Copperline Health should focus the next cycle on align leaders on narrative, timing, and live questions while making the operating tradeoffs clear to corporate communications stakeholders."
- text: "NimbleOps should focus the next cycle on certify sellers on the new value narrative before launch while making the operating tradeoffs clear to training and enablement stakeholders."
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."

## s39

- Title: "Evidence Pack"
- key number: 42 pts, label "Illustrative result", change "+6 pts", trend up
- key number: 2.4x, label "Primary signal", note "Prepare a self-running lobby deck with concise navigation cues", trend up
- key number: 6.2 min, label "Median time"

## s40

- Title: "Next Steps"
- text: "State Service Office should focus the next cycle on improve permit experience through one-stop online services while making the operating tradeoffs clear to digital government stakeholders."
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."
- text: "Operations"
- text: "Decide with the evidence, not the calendar."

## s41

- Title: "Signal Trend"
- histogram chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19
- list: "Establish a baseline" (description: "Measure the current completion rate and task time.")

## s42

- Title: "Decision Rule"
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- text: "Blue Ridge Institute should focus the next cycle on turn survey results into decisions for program design while making the operating tradeoffs clear to research report stakeholders."
- doughnut chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19

## s43

- Title: "Execution Timeline"
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- text: "Sunfield Cooperative should focus the next cycle on align growers on irrigation telemetry and drought response while making the operating tradeoffs clear to agriculture stakeholders."
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed

## s44

- Title: "Decision and Follow Through"
- text: "City of Redwood Falls should focus the next cycle on prepare council to vote on mixed-income zoning changes while making the operating tradeoffs clear to city government stakeholders."
- key number: 11 days, label "Primary signal", note "Prepare council to vote on mixed-income zoning changes", trend up
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- picture (file images/image-4.png; alt: "Warm earth hills at sunset")

## s45

- Title: "Execution Timeline"
- text: "Summit Park Arena should focus the next cycle on improve entry, concessions, and post-event transit flow while making the operating tradeoffs clear to sports venues stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."

## s46

- Title: "Operating Model"
- box-and-whisker chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- pareto chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15

## s47

- Title: "Why This Matters"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Corporate strategy, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."

## s48

- Title: "Enterprise Account Expansion Plan: decision options"
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for seed pitch.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s49

- Title: "Metric Payload"
- key number: 99.9%, label "Validation pass rate", note "Example value for renderer metric cards.", change "+2.1 pts", trend up

## s50

- Title: "Executive Workshop Facilitation: decision options"
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."


# Content for a 50-slide deck

Brand colours: background #011842 (alternate surface #0B2A5C), text #FFFFFF, secondary text #C9D3E0, accent #5499C7, light #F0F0F0. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Decision Options"
- bar chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- text: "Granite ID should focus the next cycle on explain what happened and what changes prevent recurrence while making the operating tradeoffs clear to incident review stakeholders."

## s02

- Title: "Airline Disruption Recovery Review: airline disruption recovery review"
- text: "AeroVista Airlines should focus the next cycle on shorten recovery time after weather-driven network disruption while making the operating tradeoffs clear to air travel stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- picture (file images/image-1.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."
- text: "RheinWorks Mobility should focus the next cycle on explain automation plans and worker safeguards clearly while making the operating tradeoffs clear to labor relations stakeholders."

## s03

- Title: "Decision Rule"
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "Demand moved upmarket", "Procurement cycles shortened", "Governance became a purchase requirement"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"

## s04

- Title: "Decision Options"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- key number: 18%, label "Primary signal", note "Teach managers a repeatable coaching conversation model", trend flat

## s05

- Title: "Decision Options"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Queue", "Route", "Resolve"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Center and right span", "No overlap with left"

## s06

- Title: "Decision Rule"
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down
- key number: 52, label "Trial participants", note "Across two field teams"

## s07

- Title: "Vaccination Outreach Briefing"
- text: "County Health Alliance should focus the next cycle on increase booster uptake in neighborhoods with low access while making the operating tradeoffs clear to public health stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- text: "Finally: make the recommendation."
- text: "A shared layout contract gives the editor, preview, and PowerPoint export the same content geometry. The narrative stays in JSON and remains easy to revise."
- text: "Next step: name the pilot lead and agree the start date."

## s08

- Title: "One scheme, several variants"
- Subtitle: "design.variant maps the same twelve slots"
- bullet points: "The deck variant is light1: dark text on the light background", "A slide can choose dark1, dark2, light1 or light2", "Borders, gridlines and chart text follow the variant"

## s09

- Title: "Data Storytelling Atlas: operating model"
- key number: 11 days, label "Primary signal", note "Show regional patterns with maps, charts, and concise interpretation", trend down
- text: "Civic Data Lab should focus the next cycle on show regional patterns with maps, charts, and concise interpretation while making the operating tradeoffs clear to data storytelling stakeholders."
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- key number: 2.4x, label "Primary signal", note "Prepare a self-running lobby deck with concise navigation cues", trend up

## s10

- Title: "Execution Timeline"
- combo chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- text: "PeopleCraft should focus the next cycle on teach managers a repeatable coaching conversation model while making the operating tradeoffs clear to training stakeholders."
- radar chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- treemap chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18

## s11

- Title: "Decision Options"
- doughnut chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- key number: 11 days, label "Illustrative result", change "-3 days", trend down

## s12

- Title: "Why This Matters"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "A title slide", "A simple list slide", "A closing slide"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"

## s13

- Title: "Apprenticeship Partnership Deck"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"
- list: "Classic theme", "Corporate blue color scheme", "Left-aligned content"
- list: "Content can opt into card rendering.", "Alignment can change per slide."

## s14

- Title: "Customer QBR Renewal Deck"
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s15

- Title: "Decision Options"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Legal operations, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."

## s16

- Title: "Decision and Follow Through"
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."

## s17

- Title: "Operating Choice"
- bullet points: "Standardize the intake path", "Keep escalation rules visible"
- text: "Decision owners need one place to see what changed."

## s18

- Title: "Video Demo Sales Narrative: decision rule"
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."
- key number: 11 days, label "Illustrative result", change "-3 days", trend down
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."
- key number: $4.8M, label "Primary signal", note "Prepare the quarter narrative for public-market investors", trend flat
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."

## s19

- Title: "Field Context"
- box-and-whisker chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."

## s20

- Title: "Cold Chain Waste Reduction Review"
- 100pct-stacked-column chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- combo chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- key number: 11 days, label "Illustrative result", change "-3 days", trend down
- area chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18

## s21

- Title: "Workplace Occupancy Reset"
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."

## s22

- Title: "Operating Model"
- box-and-whisker chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- pareto chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15

## s23

- Title: "Executive Workshop Facilitation: decision options"
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s24

- Title: "Execution Timeline"
- world chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s25

- Title: "Battery Line Supplier Readiness: signal trend"
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Metro Transit Authority should focus the next cycle on compare bus rapid transit options for the east corridor while making the operating tradeoffs clear to transportation stakeholders."
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."

## s26

- Title: "Quote Payload"
- quotation: "The payload model stays predictable even as slide content varies." — OPF technical fixture

## s27

- Title: "Decision Options"
- key number: 18%, label "Cycle time reduction", trend up
- key number: 84%, label "Task completion", note "Target: at least 80%"

## s28

- Title: "Compliance Readiness Review: compliance readiness review"
- stacked-column chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- text: "Tandem BioSystems should focus the next cycle on close audit evidence gaps before external assessment while making the operating tradeoffs clear to compliance stakeholders."
- area chart: Current, Baseline by Quarter; Q1: 18 / 15, Q2: 22 / 17, Q3: 25 / 19, Q4: 29 / 21
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- column chart: Revenue by Quarter; Q1: 12, Q2: 18, Q3: 24, Q4: 22

## s29

- Title: "Decision Options"
- pie chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down

## s30

- Title: "Photo Essay Portfolio: demo moment"
- list: "Two teams must release a lead at 20%", "Weekly reviews need a fixed slot", "Analytics needs read access to both workflows"
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for financial inclusion.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s31

- Title: "Online Program Launch Plan"
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."
- world chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17

## s32

- Title: "Policy Briefing for Advisors: evidence pack"
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for human resources.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s33

- Title: "Decision Options"
- text: "AtlasWorks should focus the next cycle on grow the strategic account through a measurable multi-threaded plan while making the operating tradeoffs clear to sales stakeholders."
- text: "Canyon Unified Schools should focus the next cycle on improve evaluation timelines and family communication while making the operating tradeoffs clear to student services stakeholders."
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Northgate Museum should focus the next cycle on prepare a self-running lobby deck with concise navigation cues while making the operating tradeoffs clear to visitor orientation stakeholders."

## s34

- Title: "Why This Matters"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s35

- Title: "Let a growing set of ideas reflow"
- text: "Describe the decision."
- text: "Support it with evidence and context that the audience can understand."
- text: "Explain the tradeoffs."
- text: "Name the next step and the person responsible for it."
- text: "Measure the result."

## s36

- Title: "Campus Energy Action Brief"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- key number: 84%, label "Task completion", note "Target: at least 80%"
- key number: 2, label "Teams", note "One workflow each"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up

## s37

- Title: "Decision Options"
- pie chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- text: "Pioneer Instruments should focus the next cycle on reduce high-severity escapes through earlier verification while making the operating tradeoffs clear to quality assurance stakeholders."

## s38

- Title: "Grid Resilience Capital Plan: grid resilience capital plan"
- bar chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19
- key number: 42 pts, label "Primary signal", note "Focus leadership debate on the few choices that matter", trend flat
- stacked-area chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17
- key number: 91%, label "Primary signal", note "Balance platform reliability work with customer-facing commitments", trend flat
- waterfall chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26

## s39

- Title: "Advising Retention Review: advising retention review"
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s40

- Title: "Why This Matters"
- combo chart: Current, Baseline by Quarter; Q1: 22 / 19, Q2: 26 / 21, Q3: 29 / 23, Q4: 33 / 25
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s41

- Title: "Next Steps"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Operations working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Engineering working group

## s42

- Title: "Identity Incident Executive Brief"
- code (python):
```
for region in regions:
    deck = build_review(region)
    validate(deck)
    publish(deck)
```
- text: "Sable Systems should focus the next cycle on explain incident response status and the residual risk plan while making the operating tradeoffs clear to security stakeholders."

## s43

- Title: "Consulting Margin Recovery Plan"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s44

- Title: "Adoption Doubled"
- key number: 2.1x, label "Quarter-over-quarter adoption", change "+8 regions", trend up
- line chart: Active Teams by Month; Apr: 96, May: 112, Jun: 131, Jul: 188, Aug: 236, Sep: 288

## s45

- Title: "Demo Moment"
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- key number: 84%, label "Completion"
- key number: 2.4x, label "Primary signal", note "Approve a revised data ethics requirement", trend down
- key number: 6.2 min, label "Median task time", note "Target: under 7 min"
- key number: 6.2 min, label "Median time"
- key number: 42, label "Inputs"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"

## s46

- Title: "Evidence Pack"
- funnel chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- waterfall chart: Value by Step; Start: 100, Expansion: 24, Churn: -8, End: 116

## s47

- Title: "Operating Model"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-1.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s48

- Title: "Decision Options"
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"

## s49

- Title: "Execution Timeline"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Community college, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Metro Technical College should focus the next cycle on connect employer demand to short-cycle training capacity while making the operating tradeoffs clear to community college stakeholders."

## s50

- Title: "Signal Trend"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data engineering working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Operations working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Mining working group
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Pricing working group


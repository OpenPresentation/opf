# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Decision Rule"
- key number: $820K, label "Illustrative result", change "+$20K", trend up
- pareto chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Emergency management, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s02

- Title: "Execution Timeline"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s03

- Title: "Signal Trend"
- key number: $820K, label "Primary signal", note "Coordinate launch story, proof, and field actions", trend down

## s04

- Title: "Three conditions for a useful pilot"
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s05

- Title: "Evidence Pack"
- text: "LatticeLane should focus the next cycle on decide which roadmap bets move into the second half build window while making the operating tradeoffs clear to product stakeholders."

## s06

- Title: "Why This Matters"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- text: "Copper Mesa Mining should focus the next cycle on fund remote monitoring for high-priority containment sites while making the operating tradeoffs clear to mining stakeholders."
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s07

- Title: "Signal Trend"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")

## s08

- Title: "Demo Moment"
- world chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- key number: $4.8M, label "Primary signal", note "Reset field safety practices before tower crane installation", trend down
- pareto chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- key number: $4.8M, label "Illustrative result", change "+$0.3M", trend up

## s09

- Title: "Why This Matters"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s10

- Title: "Week four brought the biggest gain"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- a group of: key number: +8 pts, label "Week four gain", note "From 76% to 84%"; text: "The new checklist reached both teams at the start of week four."

## s11

- Title: "Why This Matters"
- text: "Center for Urban Oceans should focus the next cycle on win support for a cross-disciplinary coastal resilience study while making the operating tradeoffs clear to research stakeholders."
- text: "Signal"
- text: "The new checklist reached both teams at the start of week four."
- text: "Inputs"
- text: "Support it with evidence and context that the audience can understand."
- text: "Left column"

## s12

- Title: "Execution Timeline"
- world chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s13

- Title: "Operating Model"
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s14

- Title: "Customer QBR Renewal Deck: customer qbr renewal deck"
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s15

- Title: "Retail Launch Readiness Deck"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s16

- Title: "Battery Line Supplier Readiness: signal trend"
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Metro Transit Authority should focus the next cycle on compare bus rapid transit options for the east corridor while making the operating tradeoffs clear to transportation stakeholders."
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."

## s17

- Title: "Demo Moment"
- key number: $4.8M, label "Primary signal", note "Tell a coherent civic story through image-heavy slides", trend flat
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat

## s18

- Title: "Grant Equity Review"
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- text: "Measure the result."
- text: "Gradient backgrounds carry angle and color stops."
- text: "Support it with evidence and context that the audience can understand."
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s19

- Title: "Why This Matters"
- bar chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- list: "Agree on the owner for human resources.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s20

- Title: "Seed Pitch for Climate Risk API: next steps"
- world chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- text: "Climara should focus the next cycle on raise a seed round for climate risk intelligence while making the operating tradeoffs clear to seed pitch stakeholders."
- stacked-line chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30
- text: "MesaLink Fiber should focus the next cycle on secure local support for phase two broadband construction while making the operating tradeoffs clear to telecommunications stakeholders."

## s21

- Title: "The Ask"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- text: "Crescent Public Services should focus the next cycle on present a service redesign for arabic-first residents while making the operating tradeoffs clear to public services stakeholders."
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- text: "Image backgrounds use a fixed image fill."

## s22

- Title: "Compliance Readiness Review"
- Subtitle: "Tandem BioSystems Compliance"


## s23

- Title: "Next Steps"
- text: "Common Table Network should focus the next cycle on expand distribution throughput before the summer demand spike while making the operating tradeoffs clear to nonprofit food security stakeholders."
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."
- text: "Explain the tradeoffs."
- text: "Next step: name the pilot lead and agree the start date."

## s24

- Title: "District Literacy Acceleration Plan"
- text: "Riverbend Public Schools should focus the next cycle on raise third-grade reading proficiency through targeted intervention while making the operating tradeoffs clear to k-12 education stakeholders."
- key number: 42 pts, label "Primary signal", note "Approve staged replacement of high-risk mains", trend up
- key number: 2.1x, label "Quarter-over-quarter adoption", change "+8 regions", trend up
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s25

- Title: "Signal Trend"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Procurement, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Customer success, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]

## s26

- Title: "Field Enablement Certification: execution timeline"
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused."), "Consistent measures" (description: "Track completion and task time against a baseline."), "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."
- list: "Agree on the owner for financial inclusion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for insurance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")

## s27

- Title: "Quote Payload"
- quotation: "The payload model stays predictable even as slide content varies." — OPF technical fixture

## s28

- Title: "Manager Training Deck: execution timeline"
- list: "Agree on the owner for seed pitch.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Confirm owners for open exceptions.", "Review aging thresholds with operations leads.", "Schedule the next dashboard readout."
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s29

- Title: "Decision and Follow Through"
- key number: 42 pts, label "Primary signal", note "Prepare displaced workers for regional growth sectors", trend down
- stacked-line-with-markers chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Workforce development, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Workforce development working group

## s30

- Title: "Operating Model"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."

## s31

- Title: "Decision Options"
- key number: 18%, label "Cycle time reduction", trend up
- key number: 84%, label "Task completion", note "Target: at least 80%"

## s32

- Title: "Choose the smallest useful test"
- text: "Option A: focused pilot
Two teams, six weeks. Low setup cost and a clear baseline."
- text: "Option B: broad rollout
All teams, three months. Wider reach with greater coordination needs."
- text: "Recommendation: establish the evidence with Option A before committing to Option B."

## s33

- Title: "Decision Options"
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."

## s34

- Title: "Signal Trend"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Novara Therapeutics should focus the next cycle on restore patient enrollment momentum across priority sites while making the operating tradeoffs clear to pharmaceuticals stakeholders."

## s35

- Title: "Decision Options"
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s36

- Title: "Signal Trend"
- pareto chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29

## s37

- Title: "Execution Timeline"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")

## s38

- Title: "From baseline to decision in six weeks"
- key number: 52, label "Participants"
- key number: 84%, label "Completion"
- key number: 6.2 min, label "Median time"
- timeline: Week 1: Baseline → Weeks 2–5: Pilot → Week 6: Review and decide

## s39

- Title: "School Safety Preparedness Brief"
- text: "Granite Falls District should focus the next cycle on clarify safety protocols before the fall semester while making the operating tradeoffs clear to school operations stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- text: "Participants said the checklist made the next step obvious."
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- text: "Runs support bold, italic, underlined links, and custom color."
- text: "Processing"

## s40

- Title: "Why This Matters"
- line-with-markers chart: Current, Baseline by Quarter; Q1: 18 / 15, Q2: 22 / 17, Q3: 25 / 19, Q4: 29 / 21
- key number: $4.8M, label "Primary signal", note "Move anchor tenants from interest to signed letters of intent", trend up
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Investor relations working group

## s41

- Title: "Kiosk Orientation Deck: evidence pack"
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s42

- Title: "Data Incident Postmortem: why this matters"
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")

## s43

- Title: "Why This Matters"
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- picture (file images/image-2.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-3.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-4.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-5.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s44

- Title: "Boutique Hotel Revenue Recovery: decision options"
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- text: "Civic Futures Lab should focus the next cycle on frame tradeoffs for a pending legislative decision while making the operating tradeoffs clear to policy briefing stakeholders."
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."

## s45

- Title: "Decision Rule"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Sales demo, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."

## s46

- Title: "Decision and Follow Through"
- text: "City of Redwood Falls should focus the next cycle on prepare council to vote on mixed-income zoning changes while making the operating tradeoffs clear to city government stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "The tone dark picks the dark1 variant, so the text and lines read on the picture."
- text: "ClearLake Data should focus the next cycle on approve controls for customer-facing predictive models while making the operating tradeoffs clear to analytics stakeholders."
- text: "Describe the decision."
- text: "Keep the recommendation and its evidence together."

## s47

- Title: "Signal Trend"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up
- key number: +8 pts, label "Week four gain", note "From 76% to 84%"
- key number: 52, label "Trial participants", note "Target: 50 participants"

## s48

- Title: "Compliance Readiness Review: compliance readiness review"
- stacked-column chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- text: "Tandem BioSystems should focus the next cycle on close audit evidence gaps before external assessment while making the operating tradeoffs clear to compliance stakeholders."
- area chart: Current, Baseline by Quarter; Q1: 18 / 15, Q2: 22 / 17, Q3: 25 / 19, Q4: 29 / 21
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- column chart: Revenue by Quarter; Q1: 12, Q2: 18, Q3: 24, Q4: 22

## s49

- Title: "Brazil Climate Adaptation Brief"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- text: "Instituto Verde Norte should focus the next cycle on align municipal leaders on flood-readiness investments while making the operating tradeoffs clear to climate adaptation stakeholders."
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed

## s50

- Title: "Why This Matters"
- text: "Tandem BioSystems should focus the next cycle on close audit evidence gaps before external assessment while making the operating tradeoffs clear to compliance stakeholders."


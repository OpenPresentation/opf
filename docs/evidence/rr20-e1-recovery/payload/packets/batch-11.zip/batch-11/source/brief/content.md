# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Pilot performance at a glance"
- key number: 52, label "Trial participants", note "Illustrative six-week pilot"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- bar chart: Median task time (min) by Team; A: 5.8, B: 6.7

## s02

- Title: "Apprenticeship Partnership Deck: apprenticeship partnership deck"
- text: "Lakeview Tech Institute should focus the next cycle on recruit employers into a paid apprenticeship consortium while making the operating tradeoffs clear to workforce education stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."

## s03

- Title: "Field Context"
- box-and-whisker chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s04

- Title: "Decision Rule"
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "Demand moved upmarket", "Procurement cycles shortened", "Governance became a purchase requirement"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"

## s05

- Title: "The Ask"
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s06

- Title: "Drive Thru Throughput Playbook: the ask"
- text: "Tempo Burger Group should focus the next cycle on increase lunch peak capacity with staffing and menu simplification while making the operating tradeoffs clear to quick service restaurants stakeholders."
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- text: "Greenbasket Markets should focus the next cycle on cut shrink across produce and prepared foods without hurting freshness while making the operating tradeoffs clear to retail grocery stakeholders."
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")

## s07

- Title: "Operating Model"
- text: "Metro Transit Authority should focus the next cycle on compare bus rapid transit options for the east corridor while making the operating tradeoffs clear to transportation stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "Meridian Cloud should focus the next cycle on help regional partners explain the new integration story while making the operating tradeoffs clear to partnerships stakeholders."
- text: "They want review status, owners, and exceptions in one operating view."

## s08

- Title: "Execution Timeline"
- text: "Lumina Foods should focus the next cycle on prepare supplier data collection for annual climate reporting while making the operating tradeoffs clear to sustainability stakeholders."
- key number: $820K, label "Primary signal", note "Coordinate launch story, proof, and field actions", trend down
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- picture (file images/image-4.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s09

- Title: "Special Education Services Plan: why this matters"
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Capacity: two regions are at 85% utilization.", "Churn risk in the legacy tier." (description: "Mitigation: migration incentives ship in November."), "Vendor SLA renegotiation slips to Q1."
- list: "Two teams must release a lead at 20%", "Weekly reviews need a fixed slot", "Analytics needs read access to both workflows"
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")

## s10

- Title: "Engineering Capacity Planning: evidence pack"
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")

## s11

- Title: "Execution Timeline"
- 100pct-stacked-column chart: Current, Baseline by Quarter; Q1: 27 / 24, Q2: 31 / 26, Q3: 34 / 28, Q4: 38 / 30
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- combo chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18

## s12

- Title: "Rural Broadband Expansion Proposal: signal trend"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s13

- Title: "Decision Options"
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up
- filled-radar chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Student affairs, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Investor relations working group

## s14

- Title: "Branch Modernization Investment Case"
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- text: "Keystone Build Partners should focus the next cycle on reset field safety practices before tower crane installation while making the operating tradeoffs clear to construction stakeholders."

## s15

- Title: "Decision Options"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- key number: 18%, label "Primary signal", note "Teach managers a repeatable coaching conversation model", trend flat

## s16

- Title: "Operating Model"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Pricing, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Northbeam Software should focus the next cycle on select the packaging move that improves conversion and expansion while making the operating tradeoffs clear to pricing stakeholders."

## s17

- Title: "Decision Options"
- list: "Queue", "Route", "Resolve"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "Demand moved upmarket", "Procurement cycles shortened", "Governance became a purchase requirement"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")

## s18

- Title: "Composition And Flow"
- waterfall chart: Value by Step; Start: 100, Expansion: 24, Churn: -8, End: 116
- funnel chart: Accounts by Stage; Qualified: 120, Proposal: 72, Commit: 31
- treemap chart: Value by Area; Product: 42, Sales: 31, Support: 18

## s19

- Title: "Decision Options"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Queue", "Route", "Resolve"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Center and right span", "No overlap with left"

## s20

- Title: "Signal Trend"
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- text: "City Sanitation Bureau should focus the next cycle on increase household recycling participation with clearer guidance while making the operating tradeoffs clear to sanitation stakeholders."
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s21

- Title: "Signal Trend"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s22

- Title: "Workplace Occupancy Reset: signal trend"
- key number: 18%, label "Primary signal", note "Connect employer demand to short-cycle training capacity", trend down
- text: "SilverOak Group should focus the next cycle on right-size office services around actual hybrid usage while making the operating tradeoffs clear to facilities stakeholders."
- key number: $820K, label "Primary signal", note "Reduce container dwell time through scheduling and yard visibility", trend up
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."

## s23

- Title: "Agree the pilot team and start date"
- text: "Next step: name the pilot lead and agree the start date."

## s24

- Title: "Signal Trend"
- text: "Sable Systems should focus the next cycle on explain incident response status and the residual risk plan while making the operating tradeoffs clear to security stakeholders."

## s25

- Title: "Operating Model"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Ports and logistics working group
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")

## s26

- Title: "Ambulatory Access Recovery Plan: why this matters"
- text: "Northstar Care Network should focus the next cycle on reduce missed appointments while protecting clinician capacity while making the operating tradeoffs clear to healthcare operations stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")
- text: "County Health Alliance should focus the next cycle on increase booster uptake in neighborhoods with low access while making the operating tradeoffs clear to public health stakeholders."
- text: "Sahyog Pay should focus the next cycle on evaluate pilot results before expanding rural merchant coverage while making the operating tradeoffs clear to financial inclusion stakeholders."
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")

## s27

- Title: "Digital Services Modernization: next steps"
- key number: 42%, label "Review cycle reduction", note "Median reduction across customer review workflows.", change "+11 pts", trend up
- key number: 11 days, label "Primary signal", note "Prepare council to vote on mixed-income zoning changes", trend up
- key number: 91%, label "Primary signal", note "Balance platform reliability work with customer-facing commitments", trend flat
- key number: 11 days, label "Primary signal", note "Launch an integrated campaign around the new benchmark report", trend down
- key number: $820K, label "Primary signal", note "Approve controls for customer-facing predictive models", trend down
- key number: 11 days, label "Primary signal", note "Show regional patterns with maps, charts, and concise interpretation", trend down
- key number: 2.4x, label "Primary signal", note "Compare bus rapid transit options for the east corridor", trend flat
- key number: 18%, label "Primary signal", note "Teach managers a repeatable coaching conversation model", trend flat
- key number: 2.4x, label "Primary signal", note "Prepare a self-running lobby deck with concise navigation cues", trend up

## s28

- Title: "Give each workstream a clear owner"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")

## s29

- Title: "Athletics Budget Review: decision options"
- text: "Summit State Athletics should focus the next cycle on balance competitive goals with travel and facility constraints while making the operating tradeoffs clear to college athletics stakeholders."
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- text: "Relay Cloud should focus the next cycle on balance platform reliability work with customer-facing commitments while making the operating tradeoffs clear to engineering stakeholders."
- text: "Metro Technical College should focus the next cycle on connect employer demand to short-cycle training capacity while making the operating tradeoffs clear to community college stakeholders."
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."
- text: "City Sanitation Bureau should focus the next cycle on increase household recycling participation with clearer guidance while making the operating tradeoffs clear to sanitation stakeholders."

## s30

- Title: "Decision Rule"
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down
- key number: 52, label "Trial participants", note "Across two field teams"

## s31

- Title: "Decision and Follow Through"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Standardize intake", "Publish escalation rules", "Review adoption weekly"
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "Queue", "Route", "Resolve"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")

## s32

- Title: "Execution Timeline"
- picture (file images/image-8.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-4.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s33

- Title: "Fan Experience Operations Brief: fan experience operations brief"
- text: "Summit Park Arena should focus the next cycle on improve entry, concessions, and post-event transit flow while making the operating tradeoffs clear to sports venues stakeholders."
- picture (file images/image-1.png; alt: "Purple hills in evening light")
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- picture (file images/image-8.png; alt: "Portrait silhouette on a light background")
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."

## s34

- Title: "Vaccination Outreach Briefing"
- text: "County Health Alliance should focus the next cycle on increase booster uptake in neighborhoods with low access while making the operating tradeoffs clear to public health stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."
- text: "Finally: make the recommendation."
- text: "A shared layout contract gives the editor, preview, and PowerPoint export the same content geometry. The narrative stays in JSON and remains easy to revise."
- text: "Next step: name the pilot lead and agree the start date."

## s35

- Title: "Why This Matters"
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."
- key number: 42 pts, label "Primary signal", note "Focus leadership debate on the few choices that matter", trend flat
- key number: 31 %, label "Illustrative result", change "+6 pts", trend up
- picture (file images/image-2.png; alt: "Green hills under a pale blue sky")

## s36

- Title: "STEM Lab Funding Proposal: signal trend"
- list: "Agree on the owner for k-12 education.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for human resources.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s37

- Title: "Enterprise Account Expansion Plan: the ask"
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")
- picture (file images/image-5.png; alt: "NORTH, fictional logo")

## s38

- Title: "The Ask"
- area chart: Current, Baseline by Quarter; Q1: 28 / 25, Q2: 32 / 27, Q3: 35 / 29, Q4: 39 / 31
- text: "Mosaic Strategy should focus the next cycle on guide leaders from issue framing to committed next steps while making the operating tradeoffs clear to workshop stakeholders."
- scatter chart: Before, After by Metric; Latency: 420 / 210, Queue: 15 / 7
- text: "Keep the recommendation and its evidence together."

## s39

- Title: "Satellite Maintenance Readiness Review: the ask"
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s40

- Title: "Execution Timeline"
- list: "What happens next?" (description: "Review completion and task time before expanding.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")

## s41

- Title: "Claims Triage Operating Model: why this matters"
- text: "Pinnacle Mutual should focus the next cycle on speed low-complexity claims while preserving adjuster judgment while making the operating tradeoffs clear to insurance stakeholders."
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Civic Data Lab should focus the next cycle on show regional patterns with maps, charts, and concise interpretation while making the operating tradeoffs clear to data storytelling stakeholders."
- text: "Oaktrail Animal Health should focus the next cycle on balance appointment access with staff retention while making the operating tradeoffs clear to veterinary care stakeholders."

## s42

- Title: "Execution Timeline"
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- 100pct-stacked-area chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Student success, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- quotation: "The weekly review keeps the next step clear." — Product lead

## s43

- Title: "Evidence Pack"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Product, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "LatticeLane should focus the next cycle on decide which roadmap bets move into the second half build window while making the operating tradeoffs clear to product stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Student success, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s44

- Title: "Signal Trend"
- list: "Classic theme", "Corporate blue color scheme", "Left-aligned content"
- list: "Agree on the owner for finance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "Standardize intake", "Publish escalation rules", "Review adoption weekly"
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")
- list: "Establish a baseline" (description: "Measure the current completion rate and task time.")

## s45

- Title: "One scheme, several variants"
- Subtitle: "design.variant maps the same twelve slots"
- bullet points: "The deck variant is light1: dark text on the light background", "A slide can choose dark1, dark2, light1 or light2", "Borders, gridlines and chart text follow the variant"

## s46

- Title: "India Rural Payments Pilot"
- list: "Agree on the owner for financial inclusion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "Agree the budget", "Name the owners", "Review in March"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "What happens next?" (description: "Review completion and task time before expanding.")
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "A title slide", "A simple list slide", "A closing slide"

## s47

- Title: "Decision Options"
- picture (file images/image-3.png; alt: "Warm earth hills at sunset")
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Data engineering working group

## s48

- Title: "Decision Options"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Center for Urban Oceans should focus the next cycle on win support for a cross-disciplinary coastal resilience study while making the operating tradeoffs clear to research stakeholders."

## s49

- Title: "Data Storytelling Atlas: operating model"
- key number: 11 days, label "Primary signal", note "Show regional patterns with maps, charts, and concise interpretation", trend down
- text: "Civic Data Lab should focus the next cycle on show regional patterns with maps, charts, and concise interpretation while making the operating tradeoffs clear to data storytelling stakeholders."
- key number: 91 %, label "Illustrative result", change "+6 pts", trend up
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- key number: 2.4x, label "Primary signal", note "Prepare a self-running lobby deck with concise navigation cues", trend up

## s50

- Title: "Learn before scaling"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."


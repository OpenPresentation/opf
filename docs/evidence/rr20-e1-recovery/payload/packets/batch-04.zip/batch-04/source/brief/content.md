# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Signal Trend"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Training working group
- picture (file images/image-1.png; alt: "Warm earth hills at sunset")

## s02

- Title: "Decision Options"
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s03

- Title: "Evidence Pack"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Product, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "LatticeLane should focus the next cycle on decide which roadmap bets move into the second half build window while making the operating tradeoffs clear to product stakeholders."

## s04

- Title: "Signal Trend"
- line chart: Current, Baseline by Quarter; Q1: 17 / 14, Q2: 21 / 16, Q3: 24 / 18, Q4: 28 / 20

## s05

- Title: "India Rural Payments Pilot"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed

## s06

- Title: "Decision Options"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Compliance, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s07

- Title: "Execution Timeline"
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."

## s08

- Title: "Why This Matters"
- text: "Center for Urban Oceans should focus the next cycle on win support for a cross-disciplinary coastal resilience study while making the operating tradeoffs clear to research stakeholders."
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19

## s09

- Title: "Data Storytelling Atlas: operating model"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Data storytelling, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Civic Data Lab should focus the next cycle on show regional patterns with maps, charts, and concise interpretation while making the operating tradeoffs clear to data storytelling stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Higher education, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Training and enablement, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."

## s10

- Title: "Investor Relations Update: why this matters"
- list: "Agree on the owner for insurance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Escalate only when the decision is irreversible", "Keep reversible changes moving", "Write the reason back to the audit log"
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for seed pitch.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for grantmaking.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s11

- Title: "Let a growing set of ideas reflow"
- text: "Describe the decision."
- text: "Support it with evidence and context that the audience can understand."
- text: "Explain the tradeoffs."
- text: "Name the next step and the person responsible for it."
- text: "Measure the result."

## s12

- Title: "Product Launch Narrative: field context"
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."
- list: "Agree on the owner for cybersecurity services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for nonprofit food security.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for insurance.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."

## s13

- Title: "Signal Trend"
- radar chart: Current, Baseline by Quarter; Q1: 28 / 25, Q2: 32 / 27, Q3: 35 / 29, Q4: 39 / 31
- waterfall chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23

## s14

- Title: "Grant Equity Review: grant equity review"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s15

- Title: "Campus Energy Action Brief"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- key number: 84%, label "Task completion", note "Target: at least 80%"
- key number: 2, label "Teams", note "One workflow each"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up

## s16

- Title: "What the pilot involves"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "What happens next?" (description: "Review completion and task time before expanding.")

## s17

- Title: "Scope 3 Reporting Readiness: scope 3 reporting readiness"
- text: "Lumina Foods should focus the next cycle on prepare supplier data collection for annual climate reporting while making the operating tradeoffs clear to sustainability stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- text: "North Pier Advisory should focus the next cycle on improve delivery margin without degrading client outcomes while making the operating tradeoffs clear to professional services stakeholders."
- text: "RheinWorks Mobility should focus the next cycle on explain automation plans and worker safeguards clearly while making the operating tradeoffs clear to labor relations stakeholders."

## s18

- Title: "The Ask"
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat

## s19

- Title: "Evidence Pack"
- picture (file images/image-1.png; alt: "Warm earth hills at sunset")

## s20

- Title: "Food Bank Distribution Capacity Plan: next steps"
- stacked-bar chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 22 / 19, Q2: 26 / 21, Q3: 29 / 23, Q4: 33 / 25
- key number: $4.8M, label "Primary signal", note "Tell a coherent civic story through image-heavy slides", trend flat

## s21

- Title: "Water Utility Capital Plan: demo moment"
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-1.png; alt: "Warm earth hills at sunset")
- picture (file images/image-4.png; alt: "Purple hills in evening light")

## s22

- Title: "Six lessons from the pilot"
- text: "Start with a baseline."
- text: "Keep the scope to one workflow."
- text: "Review feedback every week."
- text: "Name one owner per decision."
- text: "Share results with both teams."
- text: "Decide with the evidence, not the calendar."

## s23

- Title: "The Ask"
- text: "Harbor City University should focus the next cycle on expand counseling access through stepped-care delivery while making the operating tradeoffs clear to student affairs stakeholders."

## s24

- Title: "Execution Timeline"
- picture (file images/image-4.png; alt: "Purple hills in evening light")
- text: "NimbleOps should focus the next cycle on certify sellers on the new value narrative before launch while making the operating tradeoffs clear to training and enablement stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Compliance working group

## s25

- Title: "Visual Brand System Sampler: the ask"
- list: "Agree on the owner for financial inclusion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused."), "Consistent measures" (description: "Track completion and task time against a baseline."), "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."

## s26

- Title: "Execution Timeline"
- picture (file images/image-5.png; alt: "NORTH, fictional logo")
- picture (file images/image-6.png; alt: "FIELD, fictional logo")
- picture (file images/image-7.png; alt: "STUDIO, fictional logo")

## s27

- Title: "Execution Timeline"
- picture (file images/image-8.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-1.png; alt: "Warm earth hills at sunset")
- picture (file images/image-4.png; alt: "Purple hills in evening light")
- picture (file images/image-8.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-1.png; alt: "Warm earth hills at sunset")

## s28

- Title: "Execution Timeline"
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: Step 1: Author → Step 2: Validate → Step 3: Render

## s29

- Title: "Decision Options"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Visitor orientation working group
- picture (file images/image-4.png; alt: "Purple hills in evening light")

## s30

- Title: "Signal Trend"
- text: "City Sanitation Bureau should focus the next cycle on increase household recycling participation with clearer guidance while making the operating tradeoffs clear to sanitation stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."

## s31

- Title: "Decision Options"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Customer success, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."

## s32

- Title: "Decision Options"
- pie chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- text: "Pioneer Instruments should focus the next cycle on reduce high-severity escapes through earlier verification while making the operating tradeoffs clear to quality assurance stakeholders."

## s33

- Title: "Why This Matters"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."

## s34

- Title: "Execution Timeline"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s35

- Title: "Operating Model"
- text: "Bluewater Logistics should focus the next cycle on reduce container dwell time through scheduling and yard visibility while making the operating tradeoffs clear to ports and logistics stakeholders."
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."

## s36

- Title: "School Safety Preparedness Brief"
- column chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s37

- Title: "Evidence Pack"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Visitor orientation, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s38

- Title: "Signal Trend"
- key number: 18 %, label "Illustrative result", change "+6 pts", trend up

## s39

- Title: "Promoted rows have distinct positions"
- text: "First: state the situation."
- text: "Then: explain the change."
- text: "Finally: make the recommendation."

## s40

- Title: "Decision Rule"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor

## s41

- Title: "Decision Options"
- radar-with-markers chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- doughnut chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23

## s42

- Title: "Housing Zoning Council Brief: decision and follow through"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "City of Redwood Falls should focus the next cycle on prepare council to vote on mixed-income zoning changes while making the operating tradeoffs clear to city government stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Summit State Athletics should focus the next cycle on balance competitive goals with travel and facility constraints while making the operating tradeoffs clear to college athletics stakeholders."

## s43

- Title: "Operating Model"
- key number: 42 pts, label "Illustrative result", change "+6 pts", trend up
- key number: 2.4x, label "Primary signal", note "Approve a revised data ethics requirement", trend down
- key number: 18, label "Routes"
- key number: 31%, label "Primary signal", note "Explain broadband route choices and resident impact", trend flat
- key number: +8 pts, label "Week four gain", note "From 76% to 84%"
- key number: 42, label "Inputs"

## s44

- Title: "Pilot outcomes in three measures"
- key number: 52, label "Trial participants", note "Illustrative six-week pilot"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s45

- Title: "Strategy Offsite Pre-Read: why this matters"
- text: "Northstar Studio should focus the next cycle on focus leadership debate on the few choices that matter while making the operating tradeoffs clear to corporate strategy stakeholders."
- text: "North Valley State should focus the next cycle on improve first-year retention through proactive advising while making the operating tradeoffs clear to student success stakeholders."
- text: "Metro Technical College should focus the next cycle on connect employer demand to short-cycle training capacity while making the operating tradeoffs clear to community college stakeholders."
- text: "Pinnacle Mutual should focus the next cycle on speed low-complexity claims while preserving adjuster judgment while making the operating tradeoffs clear to insurance stakeholders."
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- text: "Oaktrail Animal Health should focus the next cycle on balance appointment access with staff retention while making the operating tradeoffs clear to veterinary care stakeholders."

## s46

- Title: "Brazil Climate Adaptation Brief"
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down
- histogram chart: Current, Baseline by Quarter; Q1: 19 / 16, Q2: 23 / 18, Q3: 26 / 20, Q4: 30 / 22
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Climate adaptation, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Training working group

## s47

- Title: "Why This Matters"
- picture (file images/image-4.png; alt: "Purple hills in evening light")
- picture (file images/image-8.png; alt: "Portrait silhouette on a light background")

## s48

- Title: "Grid Resilience Capital Plan: grid resilience capital plan"
- bar chart: Current, Baseline by Quarter; Q1: 16 / 13, Q2: 20 / 15, Q3: 23 / 17, Q4: 27 / 19
- key number: 42 pts, label "Primary signal", note "Focus leadership debate on the few choices that matter", trend flat
- stacked-area chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17
- key number: 91%, label "Primary signal", note "Balance platform reliability work with customer-facing commitments", trend flat
- waterfall chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26

## s49

- Title: "Wildfire Evacuation Preparedness: decision rule"
- picture (file images/image-8.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-2.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-3.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-1.png; alt: "Warm earth hills at sunset")
- picture (file images/image-4.png; alt: "Purple hills in evening light")

## s50

- Title: "How the running total works"
- code (javascript):
```
const total = items.reduce((sum, item) => sum + item.value, 0);
console.log(total);
```
- text: "The reducer adds each item’s value to a running sum. Starting at zero also makes an empty list return zero."


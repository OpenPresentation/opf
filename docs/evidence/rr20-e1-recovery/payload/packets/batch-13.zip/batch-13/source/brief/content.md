# Content for a 33-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Operating Model"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Metro Transit Authority should focus the next cycle on compare bus rapid transit options for the east corridor while making the operating tradeoffs clear to transportation stakeholders."

## s02

- Title: "Why This Matters"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Canyon Unified Schools should focus the next cycle on improve evaluation timelines and family communication while making the operating tradeoffs clear to student services stakeholders."
- code (ts):
```
export const valid = result.errors.length === 0;
```
- text: "Measure the result."

## s03

- Title: "Photo Essay Portfolio: demo moment"
- key number: $4.8M, label "Primary signal", note "Tell a coherent civic story through image-heavy slides", trend flat
- text: "Urban Lens Collective should focus the next cycle on tell a coherent civic story through image-heavy slides while making the operating tradeoffs clear to portfolio stakeholders."
- key number: 2.4 x, label "Illustrative result", change "+0.3x", trend up
- text: "North Valley State should focus the next cycle on improve first-year retention through proactive advising while making the operating tradeoffs clear to student success stakeholders."
- key number: $4.8M, label "Primary signal", note "Shift the library from stacks-first to research-services-first", trend up
- text: "Pinnacle Mutual should focus the next cycle on speed low-complexity claims while preserving adjuster judgment while making the operating tradeoffs clear to insurance stakeholders."
- key number: 91%, label "Primary signal", note "Balance platform reliability work with customer-facing commitments", trend flat

## s04

- Title: "A shared view makes decisions easier"
- quotation: "We can now see where participants need help." — Pilot lead

## s05

- Title: "Why This Matters"
- text: "Kindred Systems should focus the next cycle on reduce new-hire time to productivity with clearer role paths while making the operating tradeoffs clear to human resources stakeholders."
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- text: "Morrow Labs should focus the next cycle on align investment choices to margin and growth guardrails while making the operating tradeoffs clear to finance stakeholders."
- text: "Decide with the evidence, not the calendar."

## s06

- Title: "Signal Trend"
- text: "MesaLink Fiber should focus the next cycle on secure local support for phase two broadband construction while making the operating tradeoffs clear to telecommunications stakeholders."
- text: "The new checklist reached both teams at the start of week four."
- text: "The tone dark picks the dark1 variant, so the text and lines read on the picture."
- text: "A shared layout contract gives the editor, preview, and PowerPoint export the same content geometry. The narrative stays in JSON and remains easy to revise."

## s07

- Title: "Branch Modernization Investment Case"
- 100pct-stacked-bar chart: Current, Baseline by Quarter; Q1: 13 / 10, Q2: 17 / 12, Q3: 20 / 14, Q4: 24 / 16
- key number: $820K, label "Primary signal", note "Reduce filing friction and call center demand", trend up
- line chart: Latency by Month; Jan: 420, Feb: 310, Mar: 220

## s08

- Title: "Execution Timeline"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")

## s09

- Title: "Pilot outcomes in four measures"
- key number: 52, label "Trial participants", note "Across two field teams"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- key number: 2, label "Teams", note "One workflow each"

## s10

- Title: "District Literacy Acceleration Plan"
- text: "Riverbend Public Schools should focus the next cycle on raise third-grade reading proficiency through targeted intervention while making the operating tradeoffs clear to k-12 education stakeholders."
- text: "Image backgrounds use a fixed image fill."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."

## s11

- Title: "Decision Options"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Legal operations, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."

## s12

- Title: "Signal Trend"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Governance became a purchase requirement"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- list: "Classic theme", "Corporate blue color scheme", "Left-aligned content"
- list: "Agree the budget", "Name the owners", "Review in March"
- list: "Queue", "Route", "Resolve"
- list: "Center and right span", "No overlap with left"
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")

## s13

- Title: "German Works Council Update: decision options"
- picture (file images/image-3.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")

## s14

- Title: "Why This Matters"
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s15

- Title: "Decision and Follow Through"
- text: "State Workforce Board should focus the next cycle on prepare displaced workers for regional growth sectors while making the operating tradeoffs clear to workforce development stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."

## s16

- Title: "Signal Trend"
- radar chart: Current, Baseline by Quarter; Q1: 21 / 18, Q2: 25 / 20, Q3: 28 / 22, Q4: 32 / 24
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"

## s17

- Title: "Operating Model"
- text: "Rural Connectivity Office should focus the next cycle on explain broadband route choices and resident impact while making the operating tradeoffs clear to public engagement stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s18

- Title: "Signal Trend"
- text: "Sable Systems should focus the next cycle on explain incident response status and the residual risk plan while making the operating tradeoffs clear to security stakeholders."
- column chart: Current, Baseline by Quarter; Q1: 28 / 25, Q2: 32 / 27, Q3: 35 / 29, Q4: 39 / 31

## s19

- Title: "Evidence Pack"
- column chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17

## s20

- Title: "Signal Trend"
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s21

- Title: "Next Steps"
- radar chart: Current, Baseline by Quarter; Q1: 14 / 11, Q2: 18 / 13, Q3: 21 / 15, Q4: 25 / 17
- 100pct-stacked-area chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18

## s22

- Title: "Signal Trend"
- text: "North Pier Advisory should focus the next cycle on improve delivery margin without degrading client outcomes while making the operating tradeoffs clear to professional services stakeholders."

## s23

- Title: "Decision Options"
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Agree on the owner for financial services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for telecommunications.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s24

- Title: "Decision and Follow Through"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Operations, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Cobalt Supply should focus the next cycle on resolve demand and supply gaps before the monthly consensus call while making the operating tradeoffs clear to operations stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Product launch, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Option B: broad rollout
All teams, three months. Wider reach with greater coordination needs."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Procurement, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "The deck-level header, footer, organization logo and watermark apply by default; the footer zone draws the logo icon beside the organization name."

## s25

- Title: "Why This Matters"
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s26

- Title: "Operating Choice"
- bullet points: "Standardize the intake path", "Keep escalation rules visible"
- text: "Decision owners need one place to see what changed."

## s27

- Title: "Why This Matters"
- list: "Confirm owners for open exceptions.", "Review aging thresholds with operations leads.", "Schedule the next dashboard readout."
- list: "Capacity: two regions are at 85% utilization.", "Churn risk in the legacy tier." (description: "Mitigation: migration incentives ship in November."), "Vendor SLA renegotiation slips to Q1."
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s28

- Title: "Vaccination Outreach Briefing"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- key number: 91%, label "Primary signal", note "Coordinate evacuation roles before fire season", trend down

## s29

- Title: "Signal Trend"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Prairie Ridge High School should focus the next cycle on secure funding for hands-on robotics and chemistry labs while making the operating tradeoffs clear to k-12 education stakeholders."
- code (ts):
```
export const valid = result.errors.length === 0;
```
- text: "Keep the recommendation and its evidence together."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s30

- Title: "Video Demo Sales Narrative: decision rule"
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up
- text: "SignalKit should focus the next cycle on combine video proof and business case in a compact sales deck while making the operating tradeoffs clear to sales demo stakeholders."
- key number: 11 days, label "Illustrative result", change "-3 days", trend down
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."
- key number: $4.8M, label "Primary signal", note "Prepare the quarter narrative for public-market investors", trend flat
- text: "Sentinel Harbor Security should focus the next cycle on reposition managed detection for mid-market buyers while making the operating tradeoffs clear to cybersecurity services stakeholders."
- key number: 31%, label "Primary signal", note "Select the packaging move that improves conversion and expansion", trend down
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."

## s31

- Title: "Opportunity and constraints"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."

## s32

- Title: "Signal Trend"
- text: "Meridian Cloud should focus the next cycle on help regional partners explain the new integration story while making the operating tradeoffs clear to partnerships stakeholders."
- text: "Inputs"
- text: "Slide-level design can suppress inherited repeated furniture."
- text: "SilverOak Group should focus the next cycle on right-size office services around actual hybrid usage while making the operating tradeoffs clear to facilities stakeholders."
- text: "Decision owners need one place to see what changed."

## s33

- Title: "The Ask"
- text: "Orbital Ridge Systems should focus the next cycle on prepare fleet support teams for the next launch window while making the operating tradeoffs clear to aerospace stakeholders."
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- text: "Urban Lens Collective should focus the next cycle on tell a coherent civic story through image-heavy slides while making the operating tradeoffs clear to portfolio stakeholders."


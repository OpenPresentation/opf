// Writes a content-only brief of the sampler deck for an outside designer: no layout names, regions, composition
// or promoted-region keys; neutral slide ids; images exported as PNG files.
import {mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

const repo = process.argv[2];
const out = process.argv[3];
const {toPng} = await import(pathToFileURL(`${repo}/packages/render/dist/index.js`).href);
const deck = JSON.parse(readFileSync(`${repo}/examples/technical/layout-sampler.opf.json`, 'utf8'));
mkdirSync(`${out}/images`, {recursive: true});
const images = new Map();
const imageFile = async ({src, alt}) => {
  const svg = Buffer.from(src.split(',')[1], 'base64').toString();
  const key = createHash('sha256').update(svg).digest('hex').slice(0, 8);
  if (!images.has(key)) {
    const name = `image-${images.size + 1}.png`;
    writeFileSync(`${out}/images/${name}`, await toPng(svg, {scale: 1}));
    images.set(key, name);
  }
  return `picture (file images/${images.get(key)}; alt: "${alt}")`;
};
const fmt = (value, format) => typeof value === 'number' && format?.includes('%') ? `${Math.round(value * 100)}%` : String(value);
const describe = async (block) => {
  if (block.blocks) return `a group of: ${(await Promise.all(block.blocks.map(describe))).join('; ')}`;
  if (block.text !== undefined) return `text: "${Array.isArray(block.text) ? block.text.map(r => r.text ?? r).join('') : block.text}"`;
  if (block.bullets) return `bullet points: ${block.bullets.map(b => `"${b}"`).join(', ')}`;
  if (block.items) {
    const items = block.items.map(i => typeof i === 'string' ? `"${i}"` : `"${i.text}"${i.description ? ` (description: "${i.description.replace(/\n/g, ' — ')}")` : ''}`);
    return `${block.numbering ? `numbered item ${block.items[0].start ?? 1}` : items.length > 1 ? 'list' : 'item'}: ${items.join(', ')}`;
  }
  if (block.metric) {const m = block.metric; return `key number: ${m.value}${m.unit ? ` ${m.unit}` : ''}, label "${m.label}"${m.description ? `, note "${m.description}"` : ''}`;}
  if (block.quote) {const q = typeof block.quote === 'string' ? {text: block.quote} : block.quote; return `quotation: "${q.text}"${q.attribution ? ` — ${q.attribution}` : ''}${q.source ? ` (${q.source})` : ''}`;}
  if (block.chart) {
    const c = block.chart; const cols = c.data.columns.map(x => typeof x === 'string' ? {name: x} : x);
    return `${c.type} chart of ${cols.slice(1).map(x => x.name).join(', ')} by ${cols[0].name}: ${c.data.rows.map(r => `${r[0]} = ${fmt(r[1], cols[1].format)}`).join(', ')}`;
  }
  if (block.table) {
    const cols = block.table.columns.map(x => typeof x === 'string' ? {name: x} : x);
    return `table with columns ${cols.map(x => `"${x.name}"`).join(', ')}; rows: ${block.table.rows.map(r => `[${r.map((v, i) => fmt(v, cols[i].format)).join(', ')}]`).join('; ')}`;
  }
  if (block.timeline) {const t = Array.isArray(block.timeline) ? block.timeline : block.timeline.events; return `timeline: ${t.map(e => `${e.when}: ${e.what}`).join(' → ')}`;}
  if (block.code) {const c = typeof block.code === 'string' ? {source: block.code} : block.code; return `code${c.language ? ` (${c.language})` : ''}:\n\`\`\`\n${c.source}\n\`\`\``;}
  if (block.image) return imageFile(block.image);
  throw new Error(`unknown block ${JSON.stringify(Object.keys(block))}`);
};
const meta = new Set(['id', 'layout', 'title', 'subtitle', 'design', 'composition', 'section']);
let md = `# Content for a ${deck.slides.length}-slide deck\n\nOne slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.\n\n`;
const mapping = {};
for (const [index, slide] of deck.slides.entries()) {
  const id = `s${String(index + 1).padStart(2, '0')}`;
  mapping[id] = slide.id;
  const parts = [];
  for (const block of slide.blocks ?? []) parts.push(await describe(block));
  for (const [key, value] of Object.entries(slide)) if (!meta.has(key) && key !== 'blocks') parts.push(await describe(value));
  md += `## ${id}\n\n- Title: "${slide.title}"\n- Subtitle: "${slide.subtitle}"\n${parts.map(p => `- ${p}`).join('\n')}\n\n`;
}
writeFileSync(`${out}/content.md`, md);
writeFileSync(`${out}/mapping.json`, `${JSON.stringify(mapping, null, 2)}\n`);
console.log(deck.slides.length, 'slides,', images.size, 'images');

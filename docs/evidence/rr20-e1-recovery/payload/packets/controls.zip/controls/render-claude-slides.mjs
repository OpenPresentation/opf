// Renders Slides-type slide files (project/slides/<id>.html) to PNG at 1280×720 with local Edge, approximating the
// Slides runtime's defaults (format.md): divs are flex columns, no margins, h1–h3/p defaults, x-shape/x-icon stand-ins.
// Images are matched to the brief's local files by alt text.
// node render-claude-slides.mjs <deck root> <brief dir> <out dir> [mapping.json]
import {createRequire} from 'node:module';
import {mkdirSync, readFileSync, readdirSync} from 'node:fs';
import path from 'node:path';

const require = createRequire('C:/Users/micha/Source/opf/.claude/worktrees/opf-tables-charts-storage-40ab73/packages/render/package.json');
const {chromium} = require('playwright');
const [root, brief, out, mappingFile] = process.argv.slice(2);
const mapping = mappingFile ? JSON.parse(readFileSync(mappingFile, 'utf8')) : {};
const deck = JSON.parse(readFileSync(path.join(root, 'project/deck.json'), 'utf8'));
const content = readFileSync(path.join(brief, 'content.md'), 'utf8');
const altToFile = new Map([...content.matchAll(/file (images\/image-\d+\.png); (?:alt|description): "([^"]+)"/g)].map(m => [m[2], m[1]]));
const dataUri = file => `data:image/png;base64,${readFileSync(path.join(brief, file)).toString('base64')}`;
const faces = Object.values(deck.faces ?? {}).filter(f => f.href).map(f => `<link rel="stylesheet" href="${f.href}">`).join('');
const css = `
*{margin:0;box-sizing:border-box}
section{position:relative;width:1920px;height:1080px;overflow:hidden;display:flex;flex-direction:column}
div{min-width:0}div:not([style*="display"]){display:flex;flex-direction:column}
h1{font-size:96px;font-weight:600;line-height:1.1}h2{font-size:64px;font-weight:600;line-height:1.15}
h3{font-size:44px;font-weight:600;line-height:1.2}p{font-size:32px;line-height:1.4}
ul,ol{padding-left:1.2em;font-size:32px;line-height:1.4}
aside{display:none}
x-shape{display:block}x-shape[kind=ellipse]{border-radius:50%}x-shape[kind=diamond]{transform:rotate(45deg) scale(.7)}
x-shape[kind=line]{height:0!important;background:none!important}
x-shape[kind^=arrow-right]{clip-path:polygon(0 30%,60% 30%,60% 0,100% 50%,60% 100%,60% 70%,0 70%)}
x-shape[kind^=arrow-left]{clip-path:polygon(100% 30%,40% 30%,40% 0,0 50%,40% 100%,40% 70%,100% 70%)}
x-shape[kind^=arrow-down]{clip-path:polygon(30% 0,70% 0,70% 60%,100% 60%,50% 100%,0 60%,30% 60%)}
x-shape[kind^=arrow-up]{clip-path:polygon(30% 100%,70% 100%,70% 40%,100% 40%,50% 0,0 40%,30% 40%)}
x-icon{display:block;border:4px solid currentColor;border-radius:30%;min-width:24px;min-height:24px}
x-connector{display:none}
table{border-collapse:collapse}td,th{padding:.35em .6em;border-bottom:1px solid #d0d0d0;text-align:left}`;
mkdirSync(out, {recursive: true});
const browser = await chromium.launch({channel: 'msedge'});
const page = await browser.newPage({viewport: {width: 1920, height: 1080}, deviceScaleFactor: 2 / 3});
const ids = deck.order?.length ? deck.order : readdirSync(path.join(root, 'project/slides')).map(f => f.replace(/\.html$/, ''));
for (const id of ids) {
  let html = readFileSync(path.join(root, 'project/slides', `${id}.html`), 'utf8');
  html = html.replace(/<img([^>]*?)alt="([^"]*)"([^>]*)>/g, (all, a, alt, b) => {
    const file = altToFile.get(alt);
    if (!file) return all;
    return `<img${a.replace(/src="[^"]*"/, '')}alt="${alt}"${b.replace(/src="[^"]*"/, '')} src="${dataUri(file)}">`;
  });
  await page.setContent(`<!doctype html><html><head><meta charset="utf-8">${faces}<style>${css}</style></head><body>${html.replace(/<section([^>]*)\shidden/, '<section$1')}</body></html>`, {waitUntil: 'networkidle'});
  await page.evaluate(() => document.fonts.ready);
  const name = mapping[id] ?? id;
  await page.locator('section').first().screenshot({path: path.join(out, `${name}.png`)});
}
await browser.close();
console.log(ids.length, 'slides ->', out);

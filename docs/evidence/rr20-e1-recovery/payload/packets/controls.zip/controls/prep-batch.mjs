// Prepares one LH-27 batch for review: renders Claude Design's slides, then tiles ours beside Claude's, six pairs a sheet.
// node prep-batch.mjs <batch name>
import {execFileSync} from 'node:child_process';
import {copyFileSync, existsSync, mkdirSync, readdirSync, rmSync} from 'node:fs';
import path from 'node:path';

const batch = process.argv[2];
const scratch = 'C:/Users/micha/AppData/Local/Temp/claude/C--Users-micha-Source-opf--claude-worktrees-opf-tables-charts-storage-40ab73/3162499e-b72b-4dce-aa88-88bcbb3743cc/scratchpad/corpus';
const repo = 'C:/Users/micha/Source/opf/.claude/worktrees/opf-tables-charts-storage-40ab73';
const corpus = `C:/opf-work/harvest/corpus/${batch}`;
const claude = `${corpus}/claude`;
execFileSync('node', ['C:/opf-work/harvest/render-claude-slides.mjs', `${scratch}/${batch}/deck`, `${scratch}/${batch}/brief`, claude], {stdio: 'inherit'});
const ids = readdirSync(`${corpus}/ours`).map(file => file.replace(/\.png$/, '')).sort();
const pairs = `${corpus}/pairs`;
rmSync(pairs, {recursive: true, force: true});
mkdirSync(pairs, {recursive: true});
for (let start = 0, sheet = 1; start < ids.length; start += 6, sheet++) {
  const tiles = `${corpus}/tiles-${sheet}`;
  rmSync(tiles, {recursive: true, force: true});
  mkdirSync(tiles);
  const names = [];
  for (const id of ids.slice(start, start + 6)) {
    copyFileSync(`${corpus}/ours/${id}.png`, `${tiles}/${id}-a-opf.png`);
    names.push(`${id}-a-opf`);
    if (existsSync(`${claude}/${id}.png`)) { copyFileSync(`${claude}/${id}.png`, `${tiles}/${id}-b-claude.png`); names.push(`${id}-b-claude`); }
  }
  execFileSync('node', [`${repo}/scripts/layout-sampler-sheet.mjs`, tiles, path.join(pairs, `sheet-${String(sheet).padStart(2, '0')}.png`), '4', ...names], {cwd: repo, stdio: 'inherit'});
  rmSync(tiles, {recursive: true, force: true});
}
console.log(`${batch}: ${readdirSync(pairs).length} sheets in ${pairs}`);

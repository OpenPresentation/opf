// Builds examples/technical/layout-sampler.opf.json: one slide per default layout (the gallery's editorial example
// content) plus dynamic compositions (no layout record) on the same fictional pilot story.
import {readFileSync, writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';

const repo = process.argv[2];
const {readCatalog} = await import(pathToFileURL(`${repo}/packages/gallery/scripts/build.mjs`).href);
const {editorialDeck} = await import(pathToFileURL(`${repo}/packages/gallery/scripts/editorial-previews.mjs`).href);
const {gallery} = await readCatalog();
const index = JSON.parse(readFileSync(`${repo}/packages/gallery/catalog/layouts/index.json`, 'utf8'));
const slides = [];
const noFooter = new Set(['cover', 'section']);
for (const {id} of index.records) {
  const slide = editorialDeck(id, gallery.layouts[id]).slides[0];
  slides.push({id: `layout-${id}`, ...slide, ...(noFooter.has(id) ? {design: {...slide.design, footer: false}} : {})});
}
const code = slides.find(s => s.layout === 'code').blocks.find(b => b.code).code;
const picture = slides.find(s => s.layout === 'image').blocks.find(b => b.image).image;
const subtitles = {'dynamic-table-text': 'Results to the end of week four'};
const metric = (value, label, description, unit) => ({metric: {value, ...(unit ? {unit} : {}), label, ...(description ? {description} : {})}});
const completion = {type: 'column', axisTitles: {category: 'Week', value: 'Task completion'},
  data: {columns: ['Week', {name: 'Task completion', format: '0%'}], rows: [['1', .68], ['2', .72], ['3', .76], ['4', .84]]}};
const dynamic = [
  {id: 'dynamic-row-weighted', title: 'Lead with the recommendation', composition: {mode: 'row', weights: [2, 1]}, blocks: [
    {text: 'Run a six-week pilot with two teams before expanding. The pilot gives us a baseline, weekly feedback and one clear decision at the end.'},
    {text: 'Cost: two team leads at 20% for six weeks.'}]},
  {id: 'dynamic-auto-three', title: 'What makes a pilot worth running', composition: {mode: 'auto', columns: 3}, blocks: [
    {items: [{text: 'Clear scope', description: 'Two teams and one workflow keep the pilot focused.'}]},
    {items: [{text: 'Consistent measures', description: 'Track completion and task time against a baseline.'}]},
    {items: [{text: 'An explicit decision', description: 'Agree the evidence needed before expanding.'}]}]},
  {id: 'dynamic-metric-grid', title: 'Pilot outcomes in four measures', composition: {mode: 'grid', columns: 2}, blocks: [
    metric(52, 'Trial participants', 'Across two field teams'), metric('84%', 'Task completion', 'Up from 68% at baseline'),
    metric('6.2', 'Median task time', 'Down from 9.4 min', 'min'), metric(2, 'Teams', 'One workflow each')]},
  {id: 'dynamic-column', title: 'Completion rose every week', composition: {mode: 'column', weights: [1, 3]}, blocks: [
    {text: 'Task completion climbed from 68% to 84% over the first four weeks of the pilot.'}, {chart: completion}]},
  {id: 'dynamic-chart-list', title: 'What the first four weeks show', blocks: [
    {chart: completion},
    {bullets: ['Completion rose 16 points', 'The largest gain came in week four', 'Team B needs targeted support']}]},
  {id: 'dynamic-nested-group', title: 'Week four brought the biggest gain', blocks: [
    {chart: completion},
    {composition: {mode: 'column'}, blocks: [metric('+8 pts', 'Week four gain', 'From 76% to 84%'),
      {text: 'The new checklist reached both teams at the start of week four.'}]}]},
  {id: 'dynamic-promoted-columns', title: 'What the pilot asks of us', left: {text: 'The pilot shows a clear gain in completion with modest effort.'},
    'center+right': {items: ['Two teams must release a lead at 20%', 'Weekly reviews need a fixed slot', 'Analytics needs read access to both workflows']}},
  {id: 'dynamic-promoted-grid', title: 'From baseline to decision in six weeks',
    'top:left': metric(52, 'Participants'), 'top:center': metric('84%', 'Completion'), 'top:right': metric('6.2', 'Median time', undefined, 'min'),
    'middle+bottom:left+center+right': {timeline: {events: [{when: 'Week 1', what: 'Baseline'}, {when: 'Weeks 2–5', what: 'Pilot'}, {when: 'Week 6', what: 'Review and decide'}]}}},
  {id: 'dynamic-image-text-quote', title: 'What participants noticed', blocks: [
    {image: picture},
    {text: 'Participants said the checklist made the next step obvious.'},
    {quote: {text: 'We can now see where participants need help.', attribution: 'Pilot lead', source: 'Illustrative quotation'}}]},
  {id: 'dynamic-table-text', title: 'Where Team B falls behind', blocks: [
    {table: {columns: ['Team', {name: 'Participants', format: '0'}, {name: 'Completion', format: '0%'}, {name: 'Median time (min)', format: '0.0'}],
      rows: [['A', 28, .89, 5.8], ['B', 24, .79, 6.7]]}},
    {text: 'Team B trails on both measures. Pair its lead with Team A for weeks five and six.'}]},
  {id: 'dynamic-six-points', title: 'Six lessons from the pilot', blocks: [
    {text: 'Start with a baseline.'}, {text: 'Keep the scope to one workflow.'}, {text: 'Review feedback every week.'},
    {text: 'Name one owner per decision.'}, {text: 'Share results with both teams.'}, {text: 'Decide with the evidence, not the calendar.'}]},
  {id: 'dynamic-code-text', title: 'How the running total works', composition: {mode: 'row', weights: [3, 2]}, blocks: [
    {code}, {text: 'The reducer adds each item’s value to a running sum. Starting at zero also makes an empty list return zero.'}]},
  {id: 'dynamic-chart-quote', title: 'The numbers and the voice agree', 'left+center': {chart: completion},
    right: {quote: {text: 'The weekly review keeps the next step clear.', attribution: 'Product lead', source: 'Illustrative quotation'}}},
];
for (const {id, title, ...rest} of dynamic) slides.push({id, title, ...(subtitles[id] ? {subtitle: subtitles[id]} : {}), ...rest});
const deck = {
  $schema: 'https://openpresentation.org/schema/opf/v1',
  name: 'Layout sampler',
  language: 'en',
  description: 'One slide for each of the 30 default layouts, then 13 dynamic compositions (no layout record), all on one fictional six-week pilot story. The layout slides use the editorial example content of the gallery layout previews. Used to compare layouts with other designers and to review layout changes before and after.',
  design: {background: 'light1', footer: {left: {text: 'Illustrative example • fictional data'}, right: {text: '{{slide.number}}'}}},
  slides,
};
// Like every example, the deck embeds the records it uses, so it validates and renders with no catalog registered.
const {embed} = await import(pathToFileURL(`${repo}/packages/javascript/dist/index.js`).href);
const {gallery: built} = await import(pathToFileURL(`${repo}/packages/gallery/dist/index.js`).href);
const {document, unresolved} = embed(deck, {catalogs: [built]});
if (unresolved.length) throw new Error(`unresolved: ${JSON.stringify(unresolved)}`);
writeFileSync(`${repo}/examples/technical/layout-sampler.opf.json`, `${JSON.stringify(document, null, 2)}\n`);
console.log(slides.length, 'slides');

You are a presentation designer working in Claude's **Slides** artifact type (Claude Design). The goal is to see how you would design each slide from its content alone. Below, `<batch>` is the batch name you were given (for example `batch-05`), and `<scratch>` is `C:/Users/micha/AppData/Local/Temp/claude/C--Users-micha-Source-opf--claude-worktrees-opf-tables-charts-storage-40ab73/3162499e-b72b-4dce-aa88-88bcbb3743cc/scratchpad/corpus`.

## Input

Read only these: `<scratch>/<batch>/brief/content.md`, and the `images/` folder beside it. Read no other file on this machine and no repository.

The brief lists the slides (s01, s02, ...), each with a title, an optional subtitle, and content in reading order. Its first lines give the brand colours and the typeface.

## The deck

Make ONE Slides deck titled **"Layout harvest <batch>"**, with one slide per brief entry, in order, and slide ids exactly `s01`, `s02`, and so on.

- **Design.** Design each slide as you judge best for its content: arrangement, hierarchy, sizes, grouping, emphasis, cards, rules. That judgment is the point.
- **Content.** Keep every word and number, and add no facts. You may restyle: split a label from its body, or render a timeline as a diagram. Draw charts as inline SVG, to scale, with correct values. Code goes in Roboto Mono.
- **Too much content.** If a slide has too much content to fit, keep all of it: use smaller type, columns or a denser arrangement. Never split it into two slides. Name the slides that were too full in your report.
- **Pictures and brand.** Use only the given images, uploaded as assets. Icons and shapes are fine. Use no design system: the user declined one, so do not list or install any. Use the brief's brand colours and Roboto.
- **Speaker notes.** In each slide's `<aside>`, give one sentence on the design choice.

## How

The account has reached its daily limit on artifact publishes, so do not publish anything. The comparison renders your slide files locally.

1. Read the Slides type's instructions and references with the Artifact tool. Use `action: "read"` with `url: "https://claude.ai/artifact/8jTsAFQMFDb2oA8MsPJ2eL"`; a read is not a publish. Read `SKILL.md` first. Then read, with `paths`: `artifact-type/reference/format.md`, `fonts.md`, `deck-files.md`, `layout.md`, `styles.md` and `craft.md`.
2. Write the deck exactly as the type specifies, but only on disk, under `<scratch>/<batch>/deck/`:
   - `project/deck.json`, with `title`, the full `order`, and `faces` (Roboto and Roboto Mono, as Google Fonts `href`s);
   - one `project/slides/sNN.html` per slide, in the slide format.
3. For pictures, write `<img src="images/image-N.png" alt="...">` using the brief's file names and its exact alt texts. The comparison matches pictures by alt text.
4. Never call publish. Create, commit and push nothing.

## Report back

- The folder you wrote.
- One line per slide naming the arrangement you chose.
- The slides that were too full.

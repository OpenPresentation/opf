# Content for a 11-slide deck

Brand colours: background #011842 (alternate surface #0B2A5C), text #FFFFFF, secondary text #C9D3E0, accent #5499C7, light #F0F0F0. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Decision and Follow Through"
- key number: 31 %, label "Illustrative result", change "+6 pts", trend up
- text: "Cobalt Supply should focus the next cycle on resolve demand and supply gaps before the monthly consensus call while making the operating tradeoffs clear to operations stakeholders."
- key number: 42 pts, label "Primary signal", note "Resolve demand and supply gaps before the monthly consensus call", trend down
- text: "Keep the recommendation and its evidence together."
- key number: 84%, label "Task completion", note "Target: at least 80%"
- text: "Share results with both teams."
- key number: 2.4x, label "Primary signal", note "Approve a revised data ethics requirement", trend down
- text: "Describe the decision."

## s02

- Title: "Buyer Signal"
- text: "Teams want fewer exports."
- text: "They want review status, owners, and exceptions in one operating view."

## s03

- Title: "India Rural Payments Pilot: india rural payments pilot"
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-1.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-2.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")

## s04

- Title: "Demo Moment"
- text: "Lakehaven Water District should focus the next cycle on approve staged replacement of high-risk mains while making the operating tradeoffs clear to public utilities stakeholders."
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s05

- Title: "Operating Model"
- list: "Queue", "Route", "Resolve"
- list: "Content can opt into card rendering.", "Alignment can change per slide."

## s06

- Title: "Evidence Pack"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Northgate Museum should focus the next cycle on prepare a self-running lobby deck with concise navigation cues while making the operating tradeoffs clear to visitor orientation stakeholders."

## s07

- Title: "Execution Timeline"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"
- list: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Queue", "Route", "Resolve"

## s08

- Title: "Next Steps"
- text: "North Pier Health should focus the next cycle on give directors the concise operating picture and needed decisions while making the operating tradeoffs clear to board update stakeholders."
- 100pct-stacked-area chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28

## s09

- Title: "Decision Options"
- text: "Regional Clean Air Board should focus the next cycle on align inspectors on risk-based compliance priorities while making the operating tradeoffs clear to regulators stakeholders."
- text: "First: state the situation."

## s10

- Title: "What This Proves"
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."

## s11

- Title: "Signal Trend"
- key number: 91%, label "Primary signal", note "Prioritize second-source work for the highest-risk suppliers", trend up
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."


# Content for a 50-slide deck

Brand colours: background #FFFFFF (alternate surface #F0F0F0), text #000000, secondary text #595959, accent #2874A6, dark #011842. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Why This Matters"
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- text: "First: state the situation."

## s02

- Title: "Signal Trend"
- treemap chart: Current, Baseline by Quarter; Q1: 19 / 16, Q2: 23 / 18, Q3: 26 / 20, Q4: 30 / 22
- key number: 31%, label "Primary signal", note "Frame tradeoffs for a pending legislative decision", trend up
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Pricing working group

## s03

- Title: "Signal Trend"
- radar chart: Current, Baseline by Quarter; Q1: 28 / 25, Q2: 32 / 27, Q3: 35 / 29, Q4: 39 / 31

## s04

- Title: "Grant Equity Review"
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s05

- Title: "Recognize the partners"
- picture (file images/image-2.png; alt: "NORTH, fictional geometric mark")
- picture (file images/image-3.png; alt: "FIELD, fictional geometric mark")
- picture (file images/image-4.png; alt: "STUDIO, fictional geometric mark")

## s06

- Title: "Signal Trend"
- text: "Lakeside University should focus the next cycle on reduce campus energy use without disrupting instruction while making the operating tradeoffs clear to higher education stakeholders."

## s07

- Title: "Next Steps"
- key number: 91%, label "Primary signal", note "Increase household recycling participation with clearer guidance", trend flat
- key number: 2.4x, label "Primary signal", note "Decide which roadmap bets move into the second half build window", trend up
- key number: $820K, label "Primary signal", note "Improve forecast quality by focusing on stage hygiene", trend flat

## s08

- Title: "Signal Trend"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "A title slide", "A simple list slide", "A closing slide"
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "Queue", "Route", "Resolve"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Governance became a purchase requirement"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"

## s09

- Title: "Why This Matters"
- picture (file images/image-5.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-6.png; alt: "Warm earth hills at sunset")
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s10

- Title: "Food Bank Distribution Capacity Plan: next steps"
- text: "Common Table Network should focus the next cycle on expand distribution throughput before the summer demand spike while making the operating tradeoffs clear to nonprofit food security stakeholders."
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- picture (file images/image-5.png; alt: "Green hills under a pale blue sky")
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- picture (file images/image-6.png; alt: "Warm earth hills at sunset")

## s11

- Title: "Demo Moment"
- text: "Lakehaven Water District should focus the next cycle on approve staged replacement of high-risk mains while making the operating tradeoffs clear to public utilities stakeholders."
- text: "Signal"
- text: "Pattern backgrounds carry a preset plus foreground and background colors."
- text: "Teams want fewer exports."
- text: "Option B: broad rollout
All teams, three months. Wider reach with greater coordination needs."
- text: "Decision owners need one place to see what changed."

## s12

- Title: "Signal Trend"
- text: "Ironwood Devices should focus the next cycle on prioritize second-source work for the highest-risk suppliers while making the operating tradeoffs clear to procurement stakeholders."
- scatter chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26

## s13

- Title: "Student Mental Health Capacity Review: why this matters"
- list: "Agree on the owner for healthcare operations.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Catalog source search paths are document-level configuration.", "Inline records are available before external catalogs.", "Object-form references can override resolved catalog records."
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for corporate communications.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for insurance.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s14

- Title: "Field Enablement Certification: field enablement certification"
- picture (file images/image-8.png; alt: "NORTH, fictional logo")
- picture (file images/image-9.png; alt: "FIELD, fictional logo")
- picture (file images/image-10.png; alt: "STUDIO, fictional logo")
- picture (file images/image-8.png; alt: "NORTH, fictional logo")
- picture (file images/image-9.png; alt: "FIELD, fictional logo")
- picture (file images/image-10.png; alt: "STUDIO, fictional logo")
- picture (file images/image-8.png; alt: "NORTH, fictional logo")
- picture (file images/image-9.png; alt: "FIELD, fictional logo")

## s15

- Title: "Execution Timeline"
- combo chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- text: "PeopleCraft should focus the next cycle on teach managers a repeatable coaching conversation model while making the operating tradeoffs clear to training stakeholders."
- radar chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- text: "The deck-level language can be a catalog id or BCP-47 tag."
- treemap chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18

## s16

- Title: "Streaming Churn Winback Strategy: streaming churn winback strategy"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed

## s17

- Title: "Operating Model"
- list: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")
- list: "Confirm owners for open exceptions.", "Review aging thresholds with operations leads.", "Schedule the next dashboard readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s18

- Title: "Cold Chain Waste Reduction Review: cold chain waste reduction review"
- text: "Greenbasket Markets should focus the next cycle on cut shrink across produce and prepared foods without hurting freshness while making the operating tradeoffs clear to retail grocery stakeholders."
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Orbital Ridge Systems should focus the next cycle on prepare fleet support teams for the next launch window while making the operating tradeoffs clear to aerospace stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."

## s19

- Title: "The Ask"
- key number: 11 days, label "Primary signal", note "Shorten recovery time after weather-driven network disruption", trend up
- doughnut chart: Current, Baseline by Quarter; Q1: 23 / 20, Q2: 27 / 22, Q3: 30 / 24, Q4: 34 / 26
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Advancement, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Corporate strategy working group

## s20

- Title: "The Ask"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Customer success, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Evergreen CRM should focus the next cycle on recover at-risk renewals with executive sponsorship and value proof while making the operating tradeoffs clear to customer success stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Retail grocery, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "Keep the recommendation and its evidence together."

## s21

- Title: "The Ask"
- list: "Slides can reference one beat or multiple beats.", "Validators accept slides without beat references.", "Renderers can use beats for outlines and speaker notes."

## s22

- Title: "Table on a light slide"
- table with columns "Region", "Revenue", "Growth"; rows: [North, 1240, 12%]; [South, 980, 8%]; [East, 1510, 15%]; [West, 760, 4%]

## s23

- Title: "Why This Matters"
- list: "Agree on the owner for international expansion.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s24

- Title: "Execution Timeline"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."

## s25

- Title: "School Safety Preparedness Brief"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Granite Falls District should focus the next cycle on clarify safety protocols before the fall semester while making the operating tradeoffs clear to school operations stakeholders."
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```

## s26

- Title: "Kiosk Orientation Deck: evidence pack"
- key number: 2.4x, label "Primary signal", note "Prepare a self-running lobby deck with concise navigation cues", trend up
- text: "Northgate Museum should focus the next cycle on prepare a self-running lobby deck with concise navigation cues while making the operating tradeoffs clear to visitor orientation stakeholders."
- key number: 42 pts, label "Illustrative result", change "+6 pts", trend up
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- key number: 11 days, label "Primary signal", note "Show regional patterns with maps, charts, and concise interpretation", trend down
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."

## s27

- Title: "Make the next step explicit"
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Agree the budget", "Name the owners", "Review in March"

## s28

- Title: "Signal Trend"
- text: "ClearLake Data should focus the next cycle on approve controls for customer-facing predictive models while making the operating tradeoffs clear to analytics stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."
- text: "Product"

## s29

- Title: "Decision Options"
- area chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- key number: 11 days, label "Primary signal", note "Launch an integrated campaign around the new benchmark report", trend down
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Commercial real estate working group

## s30

- Title: "Decision Options"
- doughnut chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23
- key number: 11 days, label "Illustrative result", change "-3 days", trend down

## s31

- Title: "Decision and Follow Through"
- picture (file images/image-11.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s32

- Title: "What makes a pilot worth running"
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Consistent measures" (description: "Track completion and task time against a baseline.")
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s33

- Title: "Operating Model"
- text: "Oakbridge Faculty Senate should focus the next cycle on approve a revised data ethics requirement while making the operating tradeoffs clear to academic governance stakeholders."
- text: "First: state the situation."

## s34

- Title: "Compliance Readiness Review"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Compliance, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Tandem BioSystems should focus the next cycle on close audit evidence gaps before external assessment while making the operating tradeoffs clear to compliance stakeholders."

## s35

- Title: "Why This Matters"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "An explicit decision" (description: "Agree the evidence needed before expanding.")
- list: "Content can opt into card rendering.", "Alignment can change per slide."
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "A title slide", "A simple list slide", "A closing slide"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"

## s36

- Title: "Brazil Climate Adaptation Brief: signal trend"
- picture (file images/image-11.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-7.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-5.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-6.png; alt: "Warm earth hills at sunset")

## s37

- Title: "Signal Trend"
- picture (file images/image-1.png; alt: "Purple hills in evening light")

## s38

- Title: "Decision Rule"
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s39

- Title: "Why This Matters"
- text: "Waypoint Apps should focus the next cycle on move repetitive questions into self-service without hurting csat while making the operating tradeoffs clear to customer support stakeholders."
- combo chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15

## s40

- Title: "Execution Timeline"
- text: "Metro Technical College should focus the next cycle on connect employer demand to short-cycle training capacity while making the operating tradeoffs clear to community college stakeholders."

## s41

- Title: "FY27 Budget Tradeoff Deck: why this matters"
- picture (file images/image-8.png; alt: "NORTH, fictional logo")
- picture (file images/image-9.png; alt: "FIELD, fictional logo")
- picture (file images/image-10.png; alt: "STUDIO, fictional logo")
- picture (file images/image-8.png; alt: "NORTH, fictional logo")
- picture (file images/image-9.png; alt: "FIELD, fictional logo")
- picture (file images/image-10.png; alt: "STUDIO, fictional logo")
- picture (file images/image-8.png; alt: "NORTH, fictional logo")
- picture (file images/image-9.png; alt: "FIELD, fictional logo")
- picture (file images/image-10.png; alt: "STUDIO, fictional logo")

## s42

- Title: "Next Steps"
- 100pct-stacked-area chart: Current, Baseline by Quarter; Q1: 25 / 22, Q2: 29 / 24, Q3: 32 / 26, Q4: 36 / 28
- text: "North Pier Health should focus the next cycle on give directors the concise operating picture and needed decisions while making the operating tradeoffs clear to board update stakeholders."
- funnel chart: Accounts by Stage; Qualified: 120, Proposal: 72, Commit: 31
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."
- treemap chart: Current, Baseline by Quarter; Q1: 12 / 9, Q2: 16 / 11, Q3: 19 / 13, Q4: 23 / 15
- text: "Morrow Labs should focus the next cycle on align investment choices to margin and growth guardrails while making the operating tradeoffs clear to finance stakeholders."

## s43

- Title: "Tailings Monitoring Investment Brief: why this matters"
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Sep: Baseline → Oct: Pilot → May: Scale → Jun: Embed
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- timeline: Jun: Baseline → Jul: Pilot → Aug: Scale → Sep: Embed
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed

## s44

- Title: "Court Backlog Reduction Plan"
- stacked-area chart: Current, Baseline by Quarter; Q1: 17 / 14, Q2: 21 / 16, Q3: 24 / 18, Q4: 28 / 20
- line chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27

## s45

- Title: "Construction Safety Stand Down: demo moment"
- text: "Keystone Build Partners should focus the next cycle on reset field safety practices before tower crane installation while making the operating tradeoffs clear to construction stakeholders."
- text: "Bloom & Anchor Beauty should focus the next cycle on coordinate field teams for a national product launch while making the operating tradeoffs clear to beauty retail stakeholders."
- text: "Canyon Unified Schools should focus the next cycle on improve evaluation timelines and family communication while making the operating tradeoffs clear to student services stakeholders."
- text: "State Service Office should focus the next cycle on improve permit experience through one-stop online services while making the operating tradeoffs clear to digital government stakeholders."
- text: "Tempo Burger Group should focus the next cycle on increase lunch peak capacity with staffing and menu simplification while making the operating tradeoffs clear to quick service restaurants stakeholders."
- text: "Granite Falls District should focus the next cycle on clarify safety protocols before the fall semester while making the operating tradeoffs clear to school operations stakeholders."

## s46

- Title: "Apprenticeship Partnership Deck"
- list: "Profile slow tool calls", "Cache stable lookups", "Batch low-risk writes"
- list: "Classic theme", "Corporate blue color scheme", "Left-aligned content"
- list: "Content can opt into card rendering.", "Alignment can change per slide."

## s47

- Title: "Decision Rule"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Revenue operations, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Pricing, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "The new checklist reached both teams at the start of week four."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Public safety, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]

## s48

- Title: "Execution Timeline"
- list: "Agree on the owner for partnerships.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for school operations.", "Confirm the reporting cadence.", "Return with the first progress readout."

## s49

- Title: "Market Shift"
- text: "Signal"
- list: "Demand moved upmarket", "Procurement cycles shortened", "Teams asked for operational controls"

## s50

- Title: "Customer QBR Renewal Deck"
- list: "Agree on the owner for student services.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Agree on the owner for digital government.", "Confirm the reporting cadence.", "Return with the first progress readout."


# Content for a 50-slide deck

Brand colours: background #011842 (alternate surface #0B2A5C), text #FFFFFF, secondary text #C9D3E0, accent #5499C7, light #F0F0F0. Typeface: Roboto (Roboto Mono for code).

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "Decision Options"
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")

## s02

- Title: "Decision Options"
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."

## s03

- Title: "Signal Trend"
- radar chart: Current, Baseline by Quarter; Q1: 28 / 25, Q2: 32 / 27, Q3: 35 / 29, Q4: 39 / 31
- waterfall chart: Current, Baseline by Quarter; Q1: 20 / 17, Q2: 24 / 19, Q3: 27 / 21, Q4: 31 / 23

## s04

- Title: "Scope 3 Reporting Readiness: scope 3 reporting readiness"
- text: "Lumina Foods should focus the next cycle on prepare supplier data collection for annual climate reporting while making the operating tradeoffs clear to sustainability stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- text: "North Pier Advisory should focus the next cycle on improve delivery margin without degrading client outcomes while making the operating tradeoffs clear to professional services stakeholders."
- text: "RheinWorks Mobility should focus the next cycle on explain automation plans and worker safeguards clearly while making the operating tradeoffs clear to labor relations stakeholders."

## s05

- Title: "Decision Options"
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Visitor orientation working group
- picture (file images/image-3.png; alt: "Purple hills in evening light")

## s06

- Title: "Why This Matters"
- timeline: Aug: Baseline → Sep: Pilot → Oct: Scale → May: Embed
- text: "Northstar Robotics Japan should focus the next cycle on localize sales motion and support model for japan while making the operating tradeoffs clear to international expansion stakeholders."

## s07

- Title: "Pilot outcomes in three measures"
- key number: 52, label "Trial participants", note "Illustrative six-week pilot"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s08

- Title: "Wildfire Evacuation Preparedness: decision rule"
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- picture (file images/image-6.png; alt: "Green hills under a pale blue sky")
- picture (file images/image-7.png; alt: "Warm earth hills at sunset")
- picture (file images/image-3.png; alt: "Purple hills in evening light")

## s09

- Title: "Demo Moment"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Portfolio, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Urban Lens Collective should focus the next cycle on tell a coherent civic story through image-heavy slides while making the operating tradeoffs clear to portfolio stakeholders."

## s10

- Title: "Evidence Pack"
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")
- picture (file images/image-8.png; alt: "STUDIO, fictional logo")
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")

## s11

- Title: "Tax Portal Modernization: execution timeline"
- text: "Department of Revenue Services should focus the next cycle on reduce filing friction and call center demand while making the operating tradeoffs clear to tax administration stakeholders."
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."
- text: "Western Coast College should focus the next cycle on launch a flexible certificate program for working adults while making the operating tradeoffs clear to higher education stakeholders."
- text: "North Pier Advisory should focus the next cycle on improve delivery margin without degrading client outcomes while making the operating tradeoffs clear to professional services stakeholders."
- text: "Juniper Legal should focus the next cycle on shorten commercial contract review while managing risk while making the operating tradeoffs clear to legal operations stakeholders."

## s12

- Title: "Why This Matters"
- text: "Pinnacle Mutual should focus the next cycle on speed low-complexity claims while preserving adjuster judgment while making the operating tradeoffs clear to insurance stakeholders."
- key number: $4.8M, label "Primary signal", note "Turn survey results into decisions for program design", trend down
- key number: 11 days, label "Primary signal", note "Launch an integrated campaign around the new benchmark report", trend down
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")

## s13

- Title: "Decision Options"
- text: "Waypoint Apps should focus the next cycle on move repetitive questions into self-service without hurting csat while making the operating tradeoffs clear to customer support stakeholders."
- text: "This fixture keeps identity and attribution metadata separate from slide content."

## s14

- Title: "Campus Energy Action Brief"
- text: "Lakeside University should focus the next cycle on reduce campus energy use without disrupting instruction while making the operating tradeoffs clear to higher education stakeholders."
- text: "Option B: broad rollout
All teams, three months. Wider reach with greater coordination needs."
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- text: "Review feedback every week."

## s15

- Title: "Developer Conference Talk: developer conference talk"
- timeline: Oct: Baseline → May: Pilot → Jun: Scale → Jul: Embed
- text: "VectorTrail should focus the next cycle on teach builders how to design observable agent workflows while making the operating tradeoffs clear to conference talk stakeholders."
- timeline: Jul: Baseline → Aug: Pilot → Sep: Scale → Oct: Embed
- text: "Pine County Emergency Management should focus the next cycle on coordinate evacuation roles before fire season while making the operating tradeoffs clear to emergency management stakeholders."
- timeline: May: Baseline → Jun: Pilot → Jul: Scale → Aug: Embed

## s16

- Title: "Explain what the audience should notice"
- picture (file images/image-9.png; alt: "Illustrative landscape with two green ridges")
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s17

- Title: "Why This Matters"
- text: "Northstar Care Network should focus the next cycle on reduce missed appointments while protecting clinician capacity while making the operating tradeoffs clear to healthcare operations stakeholders."
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s18

- Title: "Advising Retention Review"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Student success, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "North Valley State should focus the next cycle on improve first-year retention through proactive advising while making the operating tradeoffs clear to student success stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Hospitality, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]
- text: "First: state the situation."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Compliance, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]

## s19

- Title: "Next Steps"
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")
- picture (file images/image-8.png; alt: "STUDIO, fictional logo")
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")
- picture (file images/image-8.png; alt: "STUDIO, fictional logo")
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")

## s20

- Title: "Demo Moment"
- text: "Lakehaven Water District should focus the next cycle on approve staged replacement of high-risk mains while making the operating tradeoffs clear to public utilities stakeholders."
- text: "Measure the result."

## s21

- Title: "Consulting Margin Recovery Plan"
- pareto chart: Current, Baseline by Quarter; Q1: 26 / 23, Q2: 30 / 25, Q3: 33 / 27, Q4: 37 / 29
- list: "Standardize intake", "Publish escalation rules", "Review adoption weekly"

## s22

- Title: "Evidence Pack"
- text: "Northgate Museum should focus the next cycle on prepare a self-running lobby deck with concise navigation cues while making the operating tradeoffs clear to visitor orientation stakeholders."
- text: "First: state the situation."
- text: "Narrative beats describe authoring intent without constraining slide structure."
- text: "Describe the decision."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."

## s23

- Title: "Demo Moment"
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Academic library working group

## s24

- Title: "Next Steps"
- list: "Agree on the owner for board update.", "Confirm the reporting cadence.", "Return with the first progress readout."
- list: "Queue", "Route", "Resolve"

## s25

- Title: "The largest gain came in week four"
- column chart: Task completion by Week; 1: 68%, 2: 72%, 3: 76%, 4: 84%
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s26

- Title: "Branch Modernization Investment Case"
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- text: "The new checklist reached both teams at the start of week four."
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")
- text: "Approve $1.2M to expand the rollout to all regions in Q4."

## s27

- Title: "Decision Options"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [College athletics, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Summit State Athletics should focus the next cycle on balance competitive goals with travel and facility constraints while making the operating tradeoffs clear to college athletics stakeholders."

## s28

- Title: "Data Platform Migration Plan: signal trend"
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")

## s29

- Title: "Airline Disruption Recovery Review"
- text: "AeroVista Airlines should focus the next cycle on shorten recovery time after weather-driven network disruption while making the operating tradeoffs clear to air travel stakeholders."
- text: "Growth was broad-based, with margin expansion from infrastructure savings."
- text: "Kiteframe should focus the next cycle on coordinate launch story, proof, and field actions while making the operating tradeoffs clear to product launch stakeholders."
- text: "Measure the result."
- text: "Learn with two teams before expanding the rollout."

## s30

- Title: "Next Steps"
- key number: 18%, label "Primary signal", note "Recover weekday occupancy through segmented offers and events", trend down
- key number: 11 days, label "Primary signal", note "Prepare council to vote on mixed-income zoning changes", trend up
- key number: 31%, label "Primary signal", note "Align growers on irrigation telemetry and drought response", trend flat

## s31

- Title: "Decision Options"
- text: "Framewell Studio should focus the next cycle on demonstrate opf design controls across a reusable brand system while making the operating tradeoffs clear to design system stakeholders."
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."

## s32

- Title: "School Safety Preparedness Brief"
- timeline: Now: Observe → Next: Route → Then: Resolve
- key number: 2, label "Teams", note "One workflow each"

## s33

- Title: "Decision Rule"
- list: "Classic theme", "Corporate blue color scheme", "Left-aligned content"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "What happens next?" (description: "Review completion and task time before expanding.")
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "Queue", "Route", "Resolve"

## s34

- Title: "Keep the implementation easy to inspect"
- code (javascript):
```
const total = items.reduce((sum, item) => sum + item.value, 0);
console.log(total);
```
- text: "The reducer adds each item’s value to a running sum. Starting at zero also makes an empty list return zero."

## s35

- Title: "Demo Moment"
- text: "Keystone Build Partners should focus the next cycle on reset field safety practices before tower crane installation while making the operating tradeoffs clear to construction stakeholders."
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")

## s36

- Title: "District Literacy Acceleration Plan: district literacy acceleration plan"
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Justice administration, Program lead, Watch, Continue]; [Data and reporting, Analytics, At risk, Tighten metric definitions]; [Field adoption, Operations, On track, Add weekly office hours]
- text: "Riverbend Public Schools should focus the next cycle on raise third-grade reading proficiency through targeted intervention while making the operating tradeoffs clear to k-12 education stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Policy briefing, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- text: "Civic Arts Commission should focus the next cycle on make award decisions more transparent and accessible while making the operating tradeoffs clear to grantmaking stakeholders."
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Professional services, Program lead, At risk, Continue]; [Data and reporting, Analytics, On track, Tighten metric definitions]; [Field adoption, Operations, Watch, Add weekly office hours]

## s37

- Title: "Employee Town Hall Run of Show: why this matters"
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")
- picture (file images/image-8.png; alt: "STUDIO, fictional logo")
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")

## s38

- Title: "Decision Options"
- text: "Harbor & Loom Hotels should focus the next cycle on recover weekday occupancy through segmented offers and events while making the operating tradeoffs clear to hospitality stakeholders."
- text: "Voltcrest Components should focus the next cycle on qualify suppliers for the new battery enclosure line while making the operating tradeoffs clear to automotive supply stakeholders."

## s39

- Title: "Execution Timeline"
- quotation: "Teams already know where the friction is; the deck makes the sequence of choices explicit." — Program sponsor
- picture (file images/image-5.png; alt: "Screenshot of a dashboard with a header bar and three panels")

## s40

- Title: "Apprenticeship Partnership Deck: apprenticeship partnership deck"
- text: "Lakeview Tech Institute should focus the next cycle on recruit employers into a paid apprenticeship consortium while making the operating tradeoffs clear to workforce education stakeholders."
- text: "Asteria Robotics should focus the next cycle on prepare the quarter narrative for public-market investors while making the operating tradeoffs clear to investor relations stakeholders."
- text: "Easton University Library should focus the next cycle on shift the library from stacks-first to research-services-first while making the operating tradeoffs clear to academic library stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- text: "HelioGrid Utilities should focus the next cycle on approve the substation hardening program for the next budget cycle while making the operating tradeoffs clear to energy utilities stakeholders."

## s41

- Title: "Decision Options"
- key number: 18%, label "Primary signal", note "Combine video proof and business case in a compact sales deck", trend up
- filled-radar chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27
- table with columns "Workstream", "Owner", "Status", "Decision"; rows: [Student affairs, Program lead, On track, Continue]; [Data and reporting, Analytics, Watch, Tighten metric definitions]; [Field adoption, Operations, At risk, Add weekly office hours]
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Investor relations working group

## s42

- Title: "Decision Options"
- list: "Queue", "Route", "Resolve"
- list: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- list: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- list: "Demand moved upmarket", "Procurement cycles shortened", "Governance became a purchase requirement"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")

## s43

- Title: "Give each workstream a clear owner"
- list: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- list: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- list: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")

## s44

- Title: "Fan Experience Operations Brief: fan experience operations brief"
- text: "Summit Park Arena should focus the next cycle on improve entry, concessions, and post-event transit flow while making the operating tradeoffs clear to sports venues stakeholders."
- picture (file images/image-3.png; alt: "Purple hills in evening light")
- text: "FoundryGrid should focus the next cycle on improve forecast quality by focusing on stage hygiene while making the operating tradeoffs clear to revenue operations stakeholders."
- picture (file images/image-4.png; alt: "Portrait silhouette on a light background")
- text: "Cedarwell Properties should focus the next cycle on move anchor tenants from interest to signed letters of intent while making the operating tradeoffs clear to commercial real estate stakeholders."

## s45

- Title: "Decision Options"
- code (ts):
```
const score = urgency * confidence;
if (score >= threshold) {
  routeToSponsor(workstream);
} else {
  keepInWeeklyReview(workstream);
}
```
- text: "Center for Urban Oceans should focus the next cycle on win support for a cross-disciplinary coastal resilience study while making the operating tradeoffs clear to research stakeholders."

## s46

- Title: "Field Enablement Certification: field enablement certification"
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")
- picture (file images/image-8.png; alt: "STUDIO, fictional logo")
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")
- picture (file images/image-8.png; alt: "STUDIO, fictional logo")
- picture (file images/image-1.png; alt: "NORTH, fictional logo")
- picture (file images/image-2.png; alt: "FIELD, fictional logo")

## s47

- Title: "Cold Chain Waste Reduction Review: cold chain waste reduction review"
- text: "Greenbasket Markets should focus the next cycle on cut shrink across produce and prepared foods without hurting freshness while making the operating tradeoffs clear to retail grocery stakeholders."
- text: "North Metro Police Academy should focus the next cycle on update scenario training around de-escalation and reporting while making the operating tradeoffs clear to public safety stakeholders."
- text: "Orbital Ridge Systems should focus the next cycle on prepare fleet support teams for the next launch window while making the operating tradeoffs clear to aerospace stakeholders."
- text: "Brightpath Analytics should focus the next cycle on launch an integrated campaign around the new benchmark report while making the operating tradeoffs clear to marketing stakeholders."
- text: "Harborline Bank should focus the next cycle on prioritize digital branch upgrades by customer value and risk while making the operating tradeoffs clear to financial services stakeholders."

## s48

- Title: "Decision Options"
- area chart: Current, Baseline by Quarter; Q1: 15 / 12, Q2: 19 / 14, Q3: 22 / 16, Q4: 26 / 18
- key number: 11 days, label "Primary signal", note "Launch an integrated campaign around the new benchmark report", trend down
- quotation: "The path is workable if we keep the metric simple and the decision owner visible." — Commercial real estate working group

## s49

- Title: "Operating Model"
- text: "Oakbridge Faculty Senate should focus the next cycle on approve a revised data ethics requirement while making the operating tradeoffs clear to academic governance stakeholders."
- text: "First: state the situation."

## s50

- Title: "Court Backlog Reduction Plan"
- stacked-area chart: Current, Baseline by Quarter; Q1: 17 / 14, Q2: 21 / 16, Q3: 24 / 18, Q4: 28 / 20
- line chart: Current, Baseline by Quarter; Q1: 24 / 21, Q2: 28 / 23, Q3: 31 / 25, Q4: 35 / 27


# Content for a 43-slide deck

One slide per entry, in this order. Each entry lists the slide's title, subtitle and content in reading order.

## s01

- Title: "A smaller pilot. A clearer decision."
- Subtitle: "Illustrative example • fictional data"
- picture (file images/image-1.png; alt: "Illustrative landscape with two green ridges")

## s02

- Title: "Test before scaling"
- Subtitle: "Illustrative example • fictional data"


## s03

- Title: "From the problem to the next decision"
- Subtitle: "Illustrative example • fictional data"
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"

## s04

- Title: "Three parts, one decision"
- Subtitle: "Illustrative example • fictional data"
- list: "Define the problem", "Review the pilot evidence", "Agree the next decision"

## s05

- Title: "Start small enough to learn quickly"
- Subtitle: "Illustrative example • fictional data"
- text: "Learn with two teams before expanding the rollout."

## s06

- Title: "Agree the pilot team and start date"
- Subtitle: "Illustrative example • fictional data"
- text: "Next step: name the pilot lead and agree the start date."

## s07

- Title: "Learn before scaling"
- Subtitle: "Illustrative example • fictional data"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."

## s08

- Title: "Make the next step explicit"
- Subtitle: "Illustrative example • fictional data"
- list: "Close the audit gaps", "Pilot with two teams", "Report every week"
- list: "Hire two engineers", "Ship the mobile beta", "Retire the old portal"
- list: "Agree the budget", "Name the owners", "Review in March"

## s09

- Title: "A shared view makes decisions easier"
- Subtitle: "Illustrative example • fictional data"
- quotation: "We can now see where participants need help." — Pilot lead (Illustrative quotation)

## s10

- Title: "Opportunity and constraints"
- Subtitle: "Illustrative example • fictional data"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."

## s11

- Title: "Scope, evidence and the next decision"
- Subtitle: "Illustrative example • fictional data"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."

## s12

- Title: "Three conditions for a useful pilot"
- Subtitle: "Illustrative example • fictional data"
- item: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- item: "Consistent measures" (description: "Track completion and task time against a baseline.")
- item: "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s13

- Title: "Choose the smallest useful test"
- Subtitle: "Illustrative example • fictional data"
- text: "Option A: focused pilot
Two teams, six weeks. Low setup cost and a clear baseline."
- text: "Option B: broad rollout
All teams, three months. Wider reach with greater coordination needs."
- text: "Recommendation: establish the evidence with Option A before committing to Option B."

## s14

- Title: "Three steps from evidence to decision"
- Subtitle: "Illustrative example • fictional data"
- numbered item 1: "Establish a baseline" (description: "Measure the current completion rate and task time.")
- numbered item 2: "Run the pilot" (description: "Test with two teams and review feedback each week.")
- numbered item 3: "Decide what to scale" (description: "Compare outcomes with the baseline and agree the next step.")

## s15

- Title: "Six weeks to an informed decision"
- Subtitle: "Illustrative example • fictional data"
- timeline: Week 1: Baseline → Weeks 2–5: Pilot → Week 6: Review and decide
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s16

- Title: "What the pilot involves"
- Subtitle: "Illustrative example • fictional data"
- item: "Who takes part?" (description: "Two field teams, with 52 participants in total.")
- item: "How long does it run?" (description: "Six weeks, including a baseline measurement.")
- item: "What happens next?" (description: "Review completion and task time before expanding.")

## s17

- Title: "Pilot outcomes in three measures"
- Subtitle: "Illustrative example • fictional data"
- key number: 52, label "Trial participants", note "Illustrative six-week pilot"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s18

- Title: "Track performance against a target"
- Subtitle: "Illustrative example • fictional data"
- key number: 52, label "Trial participants", note "Target: 50 participants"
- key number: 84%, label "Task completion", note "Target: at least 80%"
- key number: 6.2 min, label "Median task time", note "Target: under 7 min"

## s19

- Title: "Give the visual room to speak"
- Subtitle: "Illustrative example • fictional data"
- picture (file images/image-1.png; alt: "Illustrative landscape with two green ridges")

## s20

- Title: "Explain what the audience should notice"
- Subtitle: "Illustrative example • fictional data"
- picture (file images/image-1.png; alt: "Illustrative landscape with two green ridges")
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s21

- Title: "Compare three visual directions"
- Subtitle: "Illustrative example • fictional data"
- picture (file images/image-1.png; alt: "Blue and green landscape palette")
- picture (file images/image-2.png; alt: "Warm earth landscape palette")
- picture (file images/image-3.png; alt: "Purple landscape palette")

## s22

- Title: "Completion rose through the pilot"
- Subtitle: "Illustrative example • fictional data"
- column chart of Task completion by Week: 1 = 68%, 2 = 72%, 3 = 76%, 4 = 84%
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s23

- Title: "The largest gain came in week four"
- Subtitle: "Illustrative example • fictional data"
- column chart of Task completion by Week: 1 = 68%, 2 = 72%, 3 = 76%, 4 = 84%
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s24

- Title: "Compare outcomes on consistent measures"
- Subtitle: "Illustrative example • fictional data"
- table with columns "Team", "Participants", "Completion", "Median time (min)"; rows: [A, 28, 89%, 5.8]; [B, 24, 79%, 6.7]
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s25

- Title: "Team B needs targeted support"
- Subtitle: "Illustrative example • fictional data"
- table with columns "Team", "Participants", "Completion", "Median time (min)"; rows: [A, 28, 89%, 5.8]; [B, 24, 79%, 6.7]
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s26

- Title: "Keep the implementation easy to inspect"
- Subtitle: "Illustrative example • fictional data"
- code (javascript):
```
const total = items.reduce((sum, item) => sum + item.value, 0);
console.log(total);
```
- text: "The reducer adds each item’s value to a running sum. Starting at zero also makes an empty list return zero."

## s27

- Title: "One team. One outcome."
- Subtitle: "Illustrative example • fictional data"
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."
- picture (file images/image-1.png; alt: "Illustrative landscape with two green ridges")
- text: "Keep the scope narrow, collect feedback weekly and give each decision a named owner."
- text: "Compare the results with the baseline. Expand only when the evidence supports the next step."
- text: "Test with two teams for six weeks. Measure task completion and time before deciding what to scale."

## s28

- Title: "Pilot performance at a glance"
- Subtitle: "Illustrative example • fictional data"
- key number: 52, label "Trial participants", note "Illustrative six-week pilot"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- column chart of Task completion by Week: 1 = 68%, 2 = 72%, 3 = 76%, 4 = 84%
- bar chart of Median task time (min) by Team: A = 5.8, B = 6.7

## s29

- Title: "Give each workstream a clear owner"
- Subtitle: "Illustrative example • fictional data"
- item: "Ana Ruiz" (description: "Pilot lead — Coordinates the two teams and weekly reviews.")
- item: "Sam Lee" (description: "Product lead — Turns participant feedback into product changes.")
- item: "Kai Moreau" (description: "Analytics lead — Measures completion and task time consistently.")

## s30

- Title: "Recognize the partners"
- Subtitle: "Illustrative example • fictional data"
- picture (file images/image-4.png; alt: "NORTH, fictional geometric mark")
- picture (file images/image-5.png; alt: "FIELD, fictional geometric mark")
- picture (file images/image-6.png; alt: "STUDIO, fictional geometric mark")

## s31

- Title: "Lead with the recommendation"
- Subtitle: "Dynamic composition • fictional data"
- text: "Run a six-week pilot with two teams before expanding. The pilot gives us a baseline, weekly feedback and one clear decision at the end."
- text: "Cost: two team leads at 20% for six weeks."

## s32

- Title: "What makes a pilot worth running"
- Subtitle: "Dynamic composition • fictional data"
- item: "Clear scope" (description: "Two teams and one workflow keep the pilot focused.")
- item: "Consistent measures" (description: "Track completion and task time against a baseline.")
- item: "An explicit decision" (description: "Agree the evidence needed before expanding.")

## s33

- Title: "Pilot outcomes in four measures"
- Subtitle: "Dynamic composition • fictional data"
- key number: 52, label "Trial participants", note "Across two field teams"
- key number: 84%, label "Task completion", note "Up from 68% at baseline"
- key number: 6.2 min, label "Median task time", note "Down from 9.4 min"
- key number: 2, label "Teams", note "One workflow each"

## s34

- Title: "Completion rose every week"
- Subtitle: "Dynamic composition • fictional data"
- text: "Task completion climbed from 68% to 84% over the first four weeks of the pilot."
- column chart of Task completion by Week: 1 = 68%, 2 = 72%, 3 = 76%, 4 = 84%

## s35

- Title: "What the first four weeks show"
- Subtitle: "Dynamic composition • fictional data"
- column chart of Task completion by Week: 1 = 68%, 2 = 72%, 3 = 76%, 4 = 84%
- bullet points: "Completion rose 16 points", "The largest gain came in week four", "Team B needs targeted support"

## s36

- Title: "Week four brought the biggest gain"
- Subtitle: "Dynamic composition • fictional data"
- column chart of Task completion by Week: 1 = 68%, 2 = 72%, 3 = 76%, 4 = 84%
- a group of: key number: +8 pts, label "Week four gain", note "From 76% to 84%"; text: "The new checklist reached both teams at the start of week four."

## s37

- Title: "What the pilot asks of us"
- Subtitle: "Dynamic composition • fictional data"
- text: "The pilot shows a clear gain in completion with modest effort."
- list: "Two teams must release a lead at 20%", "Weekly reviews need a fixed slot", "Analytics needs read access to both workflows"

## s38

- Title: "From baseline to decision in six weeks"
- Subtitle: "Dynamic composition • fictional data"
- key number: 52, label "Participants"
- key number: 84%, label "Completion"
- key number: 6.2 min, label "Median time"
- timeline: Week 1: Baseline → Weeks 2–5: Pilot → Week 6: Review and decide

## s39

- Title: "What participants noticed"
- Subtitle: "Dynamic composition • fictional data"
- picture (file images/image-1.png; alt: "Illustrative landscape with two green ridges")
- text: "Participants said the checklist made the next step obvious."
- quotation: "We can now see where participants need help." — Pilot lead (Illustrative quotation)

## s40

- Title: "Where Team B falls behind"
- Subtitle: "Dynamic composition • fictional data"
- table with columns "Team", "Participants", "Completion", "Median time (min)"; rows: [A, 28, 89%, 5.8]; [B, 24, 79%, 6.7]
- text: "Team B trails on both measures. Pair its lead with Team A for weeks five and six."

## s41

- Title: "Six lessons from the pilot"
- Subtitle: "Dynamic composition • fictional data"
- text: "Start with a baseline."
- text: "Keep the scope to one workflow."
- text: "Review feedback every week."
- text: "Name one owner per decision."
- text: "Share results with both teams."
- text: "Decide with the evidence, not the calendar."

## s42

- Title: "How the running total works"
- Subtitle: "Dynamic composition • fictional data"
- code (javascript):
```
const total = items.reduce((sum, item) => sum + item.value, 0);
console.log(total);
```
- text: "The reducer adds each item’s value to a running sum. Starting at zero also makes an empty list return zero."

## s43

- Title: "The numbers and the voice agree"
- Subtitle: "Dynamic composition • fictional data"
- column chart of Task completion by Week: 1 = 68%, 2 = 72%, 3 = 76%, 4 = 84%
- quotation: "The weekly review keeps the next step clear." — Product lead (Illustrative quotation)


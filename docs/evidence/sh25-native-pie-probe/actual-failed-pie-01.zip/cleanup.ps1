$ErrorActionPreference='Stop'
. C:/opf-work/release-033-final/packages/editor/test/native-playground-lib.ps1
$ownedPath='C:\opf-work\sh25-final-native-pie-01\native\inputs\input.pptx'
$expectedHash='30b55067a65b746906817e99ada7e190936df1596a03f5d360d99959b820e2b0'
$all=@(Get-Process -Name POWERPNT -ErrorAction SilentlyContinue)
$expectedStart=[DateTimeOffset]::Parse('2026-11-08T02:08:17.4601861-08:00').UtcDateTime
if($all.Count -ne 1 -or $all[0].Id -ne 17560 -or $all[0].StartTime.ToUniversalTime() -ne $expectedStart){throw 'Exact owned process identity changed; cleanup refused'}
if($all[0].MainWindowTitle -cne 'input.pptx  -  Read-Only - PowerPoint'){throw 'Owned window title changed; cleanup refused'}
if((Get-OpfFileSha256 $ownedPath) -cne $expectedHash){throw 'Owned input bytes changed; cleanup refused'}
$app=[Runtime.InteropServices.Marshal]::GetActiveObject('PowerPoint.Application')
if($app.Presentations.Count -ne 1){throw 'Unexpected open presentations; cleanup refused'}
$presentation=$app.Presentations.Item(1)
if([IO.Path]::GetFullPath([string]$presentation.FullName) -cne $ownedPath -or $presentation.ReadOnly -ne -1){throw 'Exact read-only owned copy identity changed; cleanup refused'}
[void](Close-OpfOwnedPresentation $presentation $ownedPath)
$empty=$app.Presentations.Count -eq 0
if($empty){$app.Quit()}
@{scope='Separate cleanup only of exact owned process17560/start2026-11-08T10:08:17.4601861Z and its one read-only input after failed pie observation. No chart calls or Office termination.';closed=$true;quitEmpty=$empty;inputSha256=$expectedHash;inputSha256After=(Get-OpfFileSha256 $ownedPath)}|ConvertTo-Json|Set-Content -LiteralPath C:/opf-work/sh25-final-native-pie-01/cleanup.json -Encoding UTF8
Write-Output 'Owned read-only input closed; empty owned PowerPoint quit.'

import {fontFixtures,instanceCases} from '../../../test/font-variations-fixtures.mjs';
import {create} from 'fontkit';
import * as hb from 'harfbuzzjs';
import {writeFile} from 'node:fs/promises';
const result={harfbuzz:hb.versionString(),glyphInstances:0,differences:[],maximumDifference:0};
for(const record of (await fontFixtures()).filter(r=>r.outline==='CFF2')){
 const base=create(record.data),blob=new hb.Blob(record.data.buffer.slice(record.data.byteOffset,record.data.byteOffset+record.data.byteLength)),face=new hb.Face(blob),font=new hb.Font(face);font.setScale(face.upem,face.upem);
 for(const item of instanceCases(record)){
  const varied=base.getVariation(item.coordinates),p=varied._variationProcessor;
  font.setVariations(Object.entries(item.coordinates).map(([k,v])=>new hb.Variation(k,v)));
  for(let gid=0;gid<base.numGlyphs;gid++){
   const advance=base.hmtx.metrics.get(Math.min(gid,base.hmtx.metrics.length-1)).advance;
   const delta=p.getAdvanceAdjustment(gid,base.HVAR),calculated=Math.max(0,advance+Math.sign(delta)*Math.round(Math.abs(delta))),actual=font.glyphHAdvance(gid);
   result.glyphInstances++;result.maximumDifference=Math.max(result.maximumDifference,Math.abs(calculated-actual));
   if(calculated!==actual)result.differences.push({file:record.file,id:item.id,gid,base:advance,delta,calculated,actual});
  }
 }
}
await writeFile('artifacts/font-shaping/variation-metrics/cff2-advance-probe.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));

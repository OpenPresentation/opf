# Geometry and pagination

The shared reference coordinates use 96 pixels per inch. Default widescreen dimensions are resolved by the engine; use the resolved dimensions rather than assuming every deck is 1280×720. Composition gap and padding are fractions of the container's shorter edge. Body font minima use reference pixels at a 720-pixel canvas short edge.

Default heading geometry is a reference-engine policy, not extra JSON. Title and subtitle share the padded width of the free area. Cover slides (no body payload on a v2 template or with no layout; a flowed image counts as body, a placed image does not; empty payloads such as `blocks: []` or `text: ""` do not; whitespace-only text is body) center the tag/title/subtitle group vertically inside the free area beside any placed image, between header and footer furniture; wrapping recenters the group and a group that fills the area is not moved. Content slides keep headings at the top. Reuse `item.box` (and accepted internal part boxes, line and outline origins) for preview, selection and export. Do not silently truncate; report overflow.

Current bounds: columns 1–12; gap 0–0.1; padding 0–0.2; positive weights up to 100; minFontSize 8–32; maxFontSize 8–200 (a cap on body text that `paginate` writes on continuation pages). Check the installed schema before relying on these bounds. Nesting is bounded at 32 content-group levels. V2 layout records declare an ordered `regions` tree. `direction` selects `row` or `column`; a split nests its own `direction` and `regions`. Each list has 1–12 entries. A region or split's `size` is a positive sibling weight up to 100, or `auto` within a column. Splits nest at most three levels including the record's list, and the compiled grid has at most 12 rows and 12 columns. `geometry.regions` reports each named region's box, accepted kinds, bound content, overflow and collapse. Groups inherit only readability constraints (`minFontSize`, `maxFontSize`, `overflow`), and a strict ancestor cannot be weakened by a child. Child padding defaults to zero.

A two-level arrangement:

```json
{
  "slides": [{
    "id": "evidence",
    "title": "Keep supporting evidence together",
    "composition": {"mode": "row", "weights": [2, 1]},
    "blocks": [
      {"composition": {"mode": "column"}, "blocks": [
        {"text": "First source-backed observation."},
        {"text": "Second source-backed observation."}
      ]},
      {"text": "The implication for the decision."}
    ]
  }]
}
```

For raw geometry, `composeSlide(slide, options)` expects validated input. `resolveSlideContext(document, index, { fonts })` builds its options from the document: canvas size, layout, theme, the font families of the slide's effective font scheme, alignment and the fonts handle's `textMeasurement`.

```js
import { resolveSlideContext } from '@openpresentation/opf';
import { gallery } from '@openpresentation/gallery';
import { composeSlide } from '@openpresentation/opf/composition';
const { slide, options, diagnostics } = resolveSlideContext(document, slideIndex, { fonts: { textMeasurement }, catalogs: [gallery] });
// slide: document.slides[slideIndex] with {{slide.number}}, {{slide.section}} and {{deck.slideCount}} substituted.
const geometry = composeSlide(slide, options);
// geometry.items: leaf paths and boxes; geometry.groups: nested group bounds.
// diagnostics holds one unresolved-reference per layout, theme, colour or font scheme reference that resolves nowhere;
// each falls back (automatic composition, or the engine default) and none throws unless strictReferences is set.
console.log(geometry.diagnostics);
```

Below that level, `composeSlide(slide, { width, height, layout, fontFamilies, textMeasurement, ... })` takes every input explicitly; `fontFamilies` is the `{ heading, body, code, accent? }` family names.

Core 0.8.0 adds opt-in `explain: true` to these options. `geometry.explanation` reports versioned automatic candidate scores, selected columns, reasons for preserving explicit modes/regions, and paths whose complete internal fit is unmeasured. `textMeasurement: "provided"` means a width provider was supplied, not that shaping or native fidelity was verified. Core 0.7.0 does not include this option. Costs add cell-aspect deviation, font reduction, 1,000 per overflowing text/table/quote leaf, 100 per small cell, and 2 per unused final-row position. Lower is preferred; costs are not quality percentages. Parent scores use geometric seeds for automatic descendants; final child optimization can differ. Explanations do not apply repairs or change content.

`textMeasurement` above is a host input, not an automatic global. In the editor, `editor.composeSlide(index, {fonts})` performs its design resolution. In the renderer, use `resolvePresentation(presentation, {fonts}).slides[index].geometry`.

For explicit page splitting:

```js
import { paginate } from '@openpresentation/opf/pagination';
const result = paginate(document, {fonts: {textMeasurement}});
const paginatedDocument = result.presentation;
// result.pages contains source/output mappings; preserve it if revisions need provenance.
```

Pagination preserves characters and payload order; it does not summarize. Text offsets in mappings are half-open UTF-16 ranges. Tables repeat columns, headings repeat, and notes stay on the first page. Atomic content that cannot fit rejects the operation. Validate and inspect output; chart and timeline density models are not complete. The editor's `paginateSlide(index, options)` records one undoable change and returns both the change and pagination result.

Core 0.8.0's coordinated quote integration uses `grid-score-v2` and `quote-flow-v1`: quote items carry accepted `quoteLayout.parts`, including body/source boxes, fits, styles and UTF-16 source mappings. The body's compatibility `item.text` includes generated quotation marks. The allocator adjusts footer space before reducing fonts; consumers must reject reported failures and must not re-fit accepted parts. Glyph outlines can differ from these advance-based boxes. Core 0.7.0 does not contain this integration; shared preview/export requires renderer/PPTX 0.6.0. Check the installed versions against the published set (`node scripts/registry-plan.mjs`).

In that coordinated release, pagination persists the evaluated minimum in returned slides even when no extra page is needed. Apply the returned document; a one-page policy change is undoable in the coordinated editor, while a second unchanged invocation is a no-op. Quote bodies may split, but each fragment retains its complete attribution, role, photo and source. A quote with a `photo` carries `quoteLayout.photo` (circle frame at the start edge of the footer, mirrored in a right-to-left deck, three footer font sizes across); `layoutQuote` reports `photo-fit` when it cannot fit at the readability floor. Irreducible footers reject all output.

Core 0.9.0 adds `layoutCode(value, box, options)` and accepted `item.codeLayout.parts` for code filename, language and body. `grid-score-v3` includes every code part's requested-to-fitted font reduction and one overflow penalty per failing code leaf. Reuse the accepted boxes, styles and source/text-tab segments; do not trim source, replace tabs with spaces or fit the parts again. Each source line has half-open UTF-16 `start`, `end`, `nextStart` and a hard/soft/end boundary. Joining `part.text.slice(line.start, line.nextStart)` preserves original spaces and CR/LF/CRLF. Generated labels are not source fields.

Code pagination preserves exact body fragments and repeats filename/language, retaining the evaluated floor. Irreducible metadata rejects the whole operation even with an empty body. Coordinated renderer/PPTX 0.7.0 and editor 0.6.0 reuse these measurements; inspect the installed versions and rollout plan before relying on them. SVG/PPTX reject XML-forbidden code characters with `invalid-code-text`, source path and UTF-16 offset; schema-valid JSON and font coverage are separate checks. Complete native code tags can recover source/metadata after edits, but native formatting, positions, font theme and readability policy are not reconstructed. Inspect native output and preserve the original PPTX; this is not pixel or arbitrary Office round-trip equivalence.


## Vertical budget

How much one slide holds is measured, not guessed. The numbers below come from `composeSlide` on a default 16:9 slide (1280×720 reference pixels, the default theme and layout, a one-line title, no `fontSize` set), with the portable text estimate: they are estimates, and a real font changes them a little. Sizes are reference pixels (points are 0.75 of that). "Full" is the size the engine starts at; when it does not fit, the engine first tries an arrangement that keeps it larger (a long list in two or three columns, a layout's content as the automatic grid, kept only when that sets it at least one step of the type scale larger), then sets the whole block smaller together, down to the readability floor, and reports `overflow` below it.

| Content in one block | Starts at | Still full size | Shrunk to a readable size | At the floor or over |
| --- | --- | --- | --- | --- |
| List entries, one line each (about 40 characters) | 32 | up to 10 | 12 entries at 29, 14 at 24, 16 at 21 | not reached at 16 |
| List entries, two lines each (about 115 characters) | 32 | up to 6 | 7 entries at 27, 8 at 23, 10 at 19 | 19 from 10 entries on |
| `items` with a one-line `description` | 26 | up to 6 | 7 entries at 23, 8 at 20 | 10 at 16 (the floor); 12 overflow |
| Table data rows (plus the header row) | 25 | up to 10 | 12 rows at 22, 14 at 18 | 16 at 14, 20 at 10 |
| Paragraphs of about 230 characters | 28 | up to 4 | 5 at 22, 6 at 19 | |

Reading it as an author:

- A talk to a room wants the **full** column, which is a ceiling and not a target: about 6 list entries, 4 `items` with descriptions, 8 table rows and 3 paragraphs. Past the full column the slide still fits, but its text is smaller than the slide beside it and the audience reads less of it.
- A list or table that sits in the shrunk column is a signal to split the slide (two ideas make two slides), move the detail to a handout or the speaker notes, or turn it into a structure that shows it (a table into a chart, entries into `pillars`).
- A two-line title costs body space: 10 one-line entries stay at 32, but 12 fall from 29 to 25 and 14 from 24 to 21. Keep the title to one line (about 40 characters) before you count.
- Nothing is dropped or cropped and no text is set smaller while an arrangement holds it larger: the floor is `composition.minFontSize` (16 by default), and under it the engine reports `opf/text-overflow` (`opf validate` shows it as a warning) instead of cutting text. Lowering `minFontSize` to make a slide pass is not a repair.

To measure your own content, compose it and read the fitted size, or let the engine split what does not fit:

```js
import { resolveSlideContext } from '@openpresentation/opf';
import { gallery } from '@openpresentation/gallery';
import { composeSlide, layoutTable } from '@openpresentation/opf/composition';

const { slide, options } = resolveSlideContext(document, slideIndex, { catalogs: [gallery] });
const geometry = composeSlide(slide, options);
for (const item of geometry.items) {
  if (item.type === 'list' || item.type === 'text') console.log(item.path, item.text.fontSize, item.text.overflow);
  if (item.type === 'table') {
    const table = layoutTable(item.value, item.box, { fontFamily: options.fontFamilies?.body, textMeasurement: options.textMeasurement, path: item.path });
    console.log(item.path, table.rows[0].cells[0].fit.fontSize, table.overflow);
  }
}
```

A fitted size well under the "Starts at" column is the budget talking. When it is exceeded, split the slide yourself where the story breaks, or run `opf paginate deck.opf.json --check` to list the slides the engine would split and `opf paginate deck.opf.json -i` to split them into continuation slides. Pagination cuts at the point where the content stops fitting, not where the story breaks, so prefer your own split and use pagination as the backstop.

## Resizing tracks

For a v2 region, `anchor: "middle"` or `"bottom"` positions a compact measured content envelope inside the region;
it does not move the named region or change a pin's meaning. The measured-content implementation includes plain
and list text and uncaptioned quote/metric leaves. Quote attribution/photo stays next to the quotation, and metric
value/metadata stays together. A grid row shares an origin based on its tallest measured content; retain the
original nominal metric font size when placing the compact result. Dense text and analytical regions normally
stay top-aligned. Groups, captioned quotes/metrics and explicit slide composition overrides retain their existing
allocation rules. Check the installed engine: the first 0.19 release anchored text/list stacks only.

Published core 0.10.0 introduced [shared vector-outline placement](https://github.com/OpenPresentation/opf/blob/main/docs/plans/text-placement.md). Current core 0.13.0 reports `grid-score-v9` and shared `furniture-flow-v2`. Optional `textMeasurement.outlineBounds` and `textRasterPadding` determine accepted heading/scalar/rich line origins; pass identical options to pagination, preview, editing and export. Explanations report outline availability and effective padding. This does not measure every payload's ink or establish native raster equivalence.

Each composed item carries a resolved `alignment`: `titleAlignment` for the title, the tag and a subtitle in the title area (no `subtitle` region of its own), and `contentAlignment` for every other item (slide design, then the host option, then the deck's design, then the theme's `design`, then the layout record's `design`). When no level sets alignment, metrics default to `center` and other items to `left`. A metric's value and inline unit center together; its label, description, delta and trend follow the same alignment. The direct `layoutMetric` API also defaults to `center`; an explicit `align` preserves its logical alignment semantics, including in right-to-left decks. Consumers anchor text to it instead of re-resolving design; the title never inherits `contentAlignment`. The tag and the title-area subtitle follow `titleAlignment` too, unless the slide's own `design.contentAlignment` says otherwise.

Shared content cards are published in core 0.10.0 and later. The effective `design.contentBox` is resolved by composition (slide design, then deck design, then theme design, then the layout record's `design`; `SlideComposition.design` reports it), so a slide's explicit `false` overrides a deck's `true`; a host `contentBox` option ranks with the deck's value. Each body leaf's optional `frameBox` preserves its outer allocation, while `box` and accepted payload internals use a rounded interior padded by 12 reference pixels at a 720-pixel short edge (capped at one quarter of either frame dimension). Candidate scoring, overflow and pagination use that same interior. Headings and group/track geometry do not acquire another card inset. Consumers must draw the card at `frameBox` and reuse `box`; adding renderer-only padding would measure a different layout. Use the coordinated published set (core 0.11.0, renderer 0.9.0, PPTX 0.9.1, editor 0.8.0); core 0.9.0 predates this behavior.

`geometry.flows` exposes exact track offsets/sizes and container paths. The editor's `prepareTrackResize(document, flow, boundary, fraction)` from `@openpresentation/opf-editor/layout` returns a validated candidate and guarded JSON Patch. The fraction is the first track's share of an adjacent pair, clamped to 5–95%. Row/grid flows resize columns; column flows resize rows. An automatic layout becomes an explicit grid with its currently chosen columns. Preview before applying, especially under strict overflow. Promoted regions do not move; nested flows within them can be resized. A v2 template's tracks come from its `columns` and `rows`; edit the template when the region grid itself must change. Flows with more than twelve tracks should be grouped first. Canvas users can choose Arrange or call `setLayoutEditing(true)`.

## Footnote areas and caption bands

Core 0.15 (FA-22) gives a top-level image block with `placement: {edge, size, inset}` a band along that slide edge (`size` of the slide width or height, default 0.5, edge to edge or inside the padding); the headings and the body compose in the rest. Every image item carries `item.image` (frame `box`, `fit`, `focus`, `shape`, `stroke`, `opacity`, `recolor`, `overlay`, `placement`), and a picture background is `geometry.backgroundImage`, which moves nothing.

Core after 0.11.4 (RR-34) reserves two regions only for decks that use the fields. A slide whose runs carry `cite` or `footnote` markers gets `geometry.footnotes` (`footnote-area-v1`): a rule and `<n> <text>` lines directly above the footer band with the content area's left edge and width, at the furniture size; the content area shrinks by exactly that height plus half the slide gap and nothing above it moves. The area takes at most 35% of the heading-to-footer span; a note that does not fit reports `text-overflow` at `references.N` or the run's path. Markers are fragments with `kind: "marker"` after the marked run's last fragment (0.7 of the run size, raised 0.3 of its own size, zero source length). A captioned `image`, `chart`, `table` or `video` leaf carries `item.caption` (the band, at most 35% of the region, below or above) and `item.box` is the remaining media box; grid selection scores the leaf on that media box. Pass the same `presentation` and `slideIndex` to every consumer so the numbering agrees.

Lists whose text has no authored font size start at 32 reference pixels (24 points), while ordinary body text
starts at 28 reference pixels (21 points; the subtitle too, a table keeps 25, a quote body asks for 40 and fits down, a code body for 22). The shared fit can reduce a dense list to its explicit readability floor or use
list columns; it keeps numbering, nesting and every source entry. Rich-run `fontSize` is expressed in points:
an explicit 24-point run starts at 24 points, independently of the unspecified-list starting size.
When it fits, that size is preserved; dense content can still shrink under the shared fitting and floor rules, after the arrangements that keep text larger (columns, the automatic grid).

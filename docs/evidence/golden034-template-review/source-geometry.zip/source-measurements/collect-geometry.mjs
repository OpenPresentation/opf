import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {templateDeck} from 'file:///C:/opf-work/integration-034/packages/render/test/layout-template-fixture.mjs';
import {resolvePresentation} from 'file:///C:/opf-work/integration-034/packages/render/dist/index.js';
import {paginate} from 'file:///C:/opf-work/integration-034/packages/javascript/dist/pagination.js';
const artifact='C:/opf-work/golden034-artifact-01/templates',keys=JSON.parse(fs.readFileSync(artifact+'/diff.json')).changedSlides;
const sha=value=>createHash('sha256').update(typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(value)).digest('hex');
const cache=new Map(),pagination=new Map();
const get=id=>{if(!cache.has(id)){const fixture=templateDeck(id);cache.set(id,{...fixture,resolved:resolvePresentation(fixture.deck)});}return cache.get(id);};
const rows=[];
for(const[index,key]of keys.entries()){
  const paginated=/^paginated (.+) page (\d+)$/u.exec(key),sourceKey=paginated?paginated[1]:key,[id]=sourceKey.split(' '),source=get(id),sourceIndex=source.keys.indexOf(sourceKey);let slide=source.deck.slides[sourceIndex],geometry=source.resolved.slides[sourceIndex].geometry,mapping;
  if(paginated){if(!pagination.has(sourceKey)){const result=paginate({...source.deck,slides:[slide]});pagination.set(sourceKey,{result,resolved:resolvePresentation(result.presentation)});}const p=pagination.get(sourceKey),page=Number(paginated[2])-1;slide=p.result.presentation.slides[page];geometry=p.resolved.slides[page].geometry;mapping=p.result.pages;}
  const items=geometry.items.map(item=>({path:item.path,type:item.type,region:item.region,box:item.box,frameBox:item.frameBox,fontSize:item.text?.fontSize,fontFamily:item.textStyle?.fontFamily,overflow:item.text?.overflow,lines:item.text?.lines?.map(line=>typeof line==='string'?line:String(line)),entryCount:item.text?.listEntries?.length,listColumns:item.listColumns?.length}));
  const body=items.filter(item=>item.path.includes('.blocks.')),fonts=body.map(item=>item.fontSize).filter(Number.isFinite),lines=body.flatMap(item=>item.lines??[]);
  rows.push({index,file:String(index).padStart(4,'0')+'.png',key,sourceKey,sourceSlide:source.deck.slides[sourceIndex],sourceSlideSha256:sha(source.deck.slides[sourceIndex]),drawnSlide:slide,drawnSlideSha256:sha(slide),sourceDiagnostics:source.resolved.slides[sourceIndex].geometry.diagnostics,diagnostics:geometry.diagnostics,bodyFonts:[...new Set(fonts)],maxTrimmedLineCharacters:Math.max(0,...lines.map(line=>line.trimEnd().length)),sourceBlockCount:source.deck.slides[sourceIndex].blocks?.length,drawnBlockCount:slide.blocks?.length,items,mapping});
}
const git=(...args)=>execFileSync('git',['-C','C:/opf-work/integration-034',...args],{encoding:'utf8'}).trim();const paths=['packages/javascript/src','packages/gallery/catalog','packages/render/src','packages/render/test/layout-template-fixture.mjs'];assertEmpty(git('diff','348fd323b31302b5a3cdd7af2db8bb8bf6fffa2a','HEAD','--',...paths));
function assertEmpty(value){if(value)throw Error('Production source changed from golden commit');}
fs.writeFileSync('artifacts/template-geometry.json',JSON.stringify({goldenCommit:'348fd323b31302b5a3cdd7af2db8bb8bf6fffa2a',measuredHead:git('rev-parse','HEAD'),productionDiffEmpty:true,route:'resolvePresentation and paginate only; no SVG/PNG rendering or golden writes; exact fixture estimated measurement',rows},null,2)+'\n');
console.log(JSON.stringify(rows.map(row=>({index:row.index,key:row.key,fonts:row.bodyFonts,maxLine:row.maxTrimmedLineCharacters,diagnostics:row.diagnostics.map(d=>d.code)}))));

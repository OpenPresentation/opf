// Exact, local-only hydration of missing bounded tracked text prerequisites.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn, execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root = process.cwd(), out = path.join(root, 'artifacts/rr105-exact-hydration-01');
await fs.mkdir(out);
const env = {...process.env, GIT_NO_LAZY_FETCH: '1', GIT_OPTIONAL_LOCKS: '0'};
const head = execFileSync('git', ['rev-parse', 'HEAD'], {encoding: 'utf8', env}).trim();
const tree = execFileSync('git', ['ls-tree', '-rlz', 'HEAD'], {maxBuffer: 16 * 1024 * 1024, env}).toString('utf8');
const selected = [], deferred = [];
const special = 'docs/evidence/rich-input-and-platform-ci-20260915/painting-Linux.json.gz';
for (const entry of tree.split('\0').filter(Boolean)) {
  const match = /^(100644|100755) blob ([a-f0-9]{40}) +(\d+)\t([\s\S]+)$/.exec(entry);
  if (!match) continue;
  const [, mode, oid, length, relative] = match;
  if (!/\.(?:json|jsonc|md|txt|log|csv|tsv|xml|svg|html|css|mjs|js|cjs|ts|tsx|yaml|yml)$/i.test(relative) && relative !== special) continue;
  const target = path.resolve(root, relative);
  assert(target.toLowerCase().startsWith(root.toLowerCase() + path.sep), 'Hydration escaped own checkout');
  try {await fs.lstat(target); continue;} catch (error) {if (error.code !== 'ENOENT') throw error;}
  const record = {path: relative, oid, bytes: Number(length), mode, target};
  if (record.bytes > 16 * 1024 * 1024) deferred.push(record); else selected.push(record);
}
assert(selected.length <= 10000 && selected.reduce((sum, item) => sum + item.bytes, 0) <= 512 * 1024 * 1024, 'Hydration exceeds explicit bounded scope');
const child = spawn('git', ['cat-file', '--batch'], {env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true});
let errorText = ''; child.stderr.on('data', chunk => {errorText += chunk;});
const completion = new Promise((resolve, reject) => {child.on('error', reject); child.on('close', code => code === 0 ? resolve() : reject(Error('Local Git blob read failed: ' + errorText)));});
child.stdin.end(selected.map(row => row.oid).join('\n') + (selected.length ? '\n' : ''));
let buffer = Buffer.alloc(0), current = null, index = 0;
const restored = [];
for await (const chunk of child.stdout) {
  buffer = Buffer.concat([buffer, chunk]);
  while (true) {
    if (!current) {
      const lineEnd = buffer.indexOf(10); if (lineEnd < 0) break;
      const header = buffer.subarray(0, lineEnd).toString('ascii'); buffer = buffer.subarray(lineEnd + 1);
      const expected = selected[index]; assert(expected, 'Unexpected batch result');
      assert.equal(header, expected.oid + ' blob ' + expected.bytes, 'Missing or unexpected exact local blob'); current = expected;
    }
    if (buffer.length < current.bytes + 1) break;
    const bytes = buffer.subarray(0, current.bytes); assert.equal(buffer[current.bytes], 10);
    assert.equal(crypto.createHash('sha1').update(Buffer.from('blob ' + bytes.length + '\0')).update(bytes).digest('hex'), current.oid, 'Raw Git blob identity');
    await fs.mkdir(path.dirname(current.target), {recursive: true}); await fs.writeFile(current.target, bytes, {flag: 'wx'});
    restored.push({path: current.path, oid: current.oid, bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex')});
    buffer = buffer.subarray(current.bytes + 1); current = null; index++;
    if (index % 500 === 0) console.log('Exact local tracked inputs restored: ' + index);
  }
}
await completion; assert.equal(index, selected.length); assert.equal(buffer.length, 0); assert.equal(current, null);
const result = {scope: 'Missing exact tracked bounded text inputs plus the named compressed-text fixture; raw HEAD Git blobs only, no lazy fetch, generated substitutes, overwrite or index changes', head, count: restored.length, bytes: restored.reduce((sum, file) => sum + file.bytes, 0), files: restored, deferred: deferred.map(({target, ...file}) => file)};
await fs.writeFile(path.join(out, 'receipt.json'), JSON.stringify(result, null, 2) + '\n');
await fs.copyFile(new URL(import.meta.url), path.join(out, 'executed-producer.mjs'));
console.log(JSON.stringify({head, restored: result.count, bytes: result.bytes, deferred: result.deferred.length, localOnly: true}));

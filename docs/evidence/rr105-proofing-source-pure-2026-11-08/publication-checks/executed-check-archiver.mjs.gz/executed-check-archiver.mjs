// Retain only this evidence lane's completed local checks. No native output reads.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
const root = process.cwd(), output = path.join(root, 'docs/evidence/rr105-proofing-source-pure-2026-11-08/publication-checks');
const {zipSync} = createRequire(path.join(root, 'packages/pptx/package.json'))('fflate');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
await fs.mkdir(output);
const files = [];
const inputs = {
  'check-changed-01.log.gz': 'artifacts/rr105-evidence-mapped-01/check-changed.log',
  'execution-01.json.gz': 'artifacts/rr105-evidence-mapped-01/execution.json',
  'publication-verifier-node24.json.gz': 'artifacts/publication-verification-node24.json',
  'initial-publication-verifier-node26.json.gz': 'artifacts/publication-verification-01.json',
  'offline-install.log.gz': 'artifacts/evidence-offline-install.log',
  'prerequisite-hydration-receipt.json.gz': 'artifacts/rr105-exact-hydration-01/receipt.json',
  'prerequisite-hydration-producer.mjs.gz': 'artifacts/rr105-exact-hydration-01/executed-producer.mjs',
};
async function retain(name, raw, encoding = 'gzip') {
  const bytes = encoding === 'gzip' ? gzipSync(raw) : raw;
  await fs.writeFile(path.join(output, name), bytes, {flag: 'wx'});
  files.push({path: name, bytes: bytes.length, sha256: sha(bytes), encoding, originalBytes: raw.length, originalSha256: sha(raw)});
}
for (const [name, source] of Object.entries(inputs)) await retain(name, await fs.readFile(path.join(root, source)));
const steps = {};
for (const name of (await fs.readdir(path.join(root, 'artifacts/check-changed'))).sort()) {
  assert.match(name, /^[a-z0-9_.-]+$/i);
  steps[name] = await fs.readFile(path.join(root, 'artifacts/check-changed', name));
}
const stepSeals = Object.entries(steps).map(([name, raw]) => ({path: name, bytes: raw.length, sha256: sha(raw)}));
steps['entry-seals.json'] = Buffer.from(JSON.stringify(stepSeals, null, 2));
await retain('step-logs.zip.gz', gzipSync(zipSync(Object.fromEntries(Object.entries(steps).map(([name, raw]) => [name, [raw, {mtime: new Date('2000-01-01T00:00:00Z')}]])), {level: 9})), 'identity');
await retain('executed-check-archiver.mjs.gz', await fs.readFile(new URL(import.meta.url)));
await fs.writeFile(path.join(output, 'seals.json'), JSON.stringify({scope: 'Completed source/pure evidence publication checks only', sourceHead: 'b8461d48b193e32dee4e6e1bb60896823f2303ff', nativeRun: false, files}, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({files: files.length, stepLogs: stepSeals.length, nativeRun: false}));

// Independent read-only verification of source/pure evidence transport; no Office.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const root = 'C:/opf-work/rr105-proofing-review';
const directory = process.argv[2], expectedHead = process.argv[3];
assert(directory && /^[a-f0-9]{40}$/.test(expectedHead));
const {unzipSync} = createRequire(path.join(root, 'packages/pptx/package.json'))('fflate');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const parse = b => JSON.parse(Buffer.from(b).toString('utf8').replace(/^\uFEFF/, ''));
const receipt = parse(await fs.readFile(path.join(directory, 'receipt.json')));
const transport = await fs.readFile(path.join(directory, 'packet.zip.gz'));
assert.equal(sha(transport), receipt.packetSha256); assert.equal(transport.length, receipt.bytes);
const entries = unzipSync(gunzipSync(transport)), seals = parse(entries['entry-seals.json']);
assert.equal(Object.keys(entries).length, seals.length + 1); assert.equal(new Set(seals.map(x => x.path)).size, seals.length);
for (const file of seals) { assert.equal(entries[file.path].length, file.bytes); assert.equal(sha(entries[file.path]), file.sha256); }
const review = parse(entries['review.json']); assert.equal(review.sourceHead, expectedHead); assert.equal(receipt.sourceHead, expectedHead);
assert.equal(review.nativeRun, false); assert.equal(review.nativeAuthorized, false); assert.equal(review.actualNativeLanguageObservations, 0);
const prefix = 'source/tools/rr105-proofing-readonly/';
assert.equal(sha(entries[prefix + 'worker-package/test/native-furniture-control.ps1']), '26ea8b008cdacebc937decbfe52356ace0a146af0d5ade54e20de6397596415c');
assert.equal(sha(gunzipSync(entries[prefix + 'reference-worker.ps1.gz'])), 'de0905bd8024f3eebbd0518c338e67449c45f5e2de998714069d7a14210e1943');
assert.equal(sha(entries[prefix + 'offline-inputs.zip.gz']), 'a4ee35c59e817f45268b0a35879d26abfbe09992f34862ded82f7a9c36cbf91e');
assert.equal(sha(entries[prefix + 'worker-package/test/fixtures/sh25-native-circle-observations.json']), 'e8e452a52977f6a76925cfb31c92f8d1340448dd59566193468e616a98322af0');
const suite = parse(entries['suite/suite.json']); assert.equal(suite.provenance.workerRepository.revision, expectedHead); assert.equal(sha(entries['suite/suite.json']), receipt.suiteManifestSha256);
for (const id of ['A', 'B', 'C']) { assert.equal(parse(entries['runner-validate-only/' + id + '/runner.json']).status, 'pure-checks-completed; native-not-run'); const c = suite.cases.find(x => x.id === 'proofing-inheritance-' + id); assert.equal(c.expectedPrimaryLanguageId, 1025); assert.equal(c.requiredPhaseNamePairs, 9); assert.equal(c.nativeAcceptance, false); assert.equal(c.knownPriorVisualFailure, id === 'A'); }
assert.equal(parse(entries['history/first-A-validate-only-failure/runner.json']).status, 'failed; no-retry');
const mocks = Object.entries(entries).filter(([name]) => name.endsWith('/source-and-mocks.json')).map(([, b]) => parse(b)).filter(r => r.source.workerSha256 === review.workerSha256);
assert(mocks.length > 0);
for (const result of mocks) { assert.equal(result.passed, true); assert.equal(result.officeConstructed, false); assert.equal(result.actualOfficeAcceptance, false); assert.equal(result.protectedFunctions.length, 39); const positive = result.cases.find(x => x.name === 'all-nine-phase-name-primary-language-getters-exact'); assert.equal(positive.evidence.getters, 9); assert.equal(positive.evidence.observations.length, 9); assert(positive.evidence.observations.every(x => x.observedLanguageId === 1025)); }
for (const file of review.sourceFiles) assert.deepEqual(Buffer.from(entries['source/' + file]), execFileSync('git', ['--no-optional-locks', '-C', root, 'show', expectedHead + ':' + file], {maxBuffer: 16 * 1024 * 1024, windowsHide: true}), 'Frozen source blob ' + file);
console.log(JSON.stringify({passed: true, sourceHead: expectedHead, sealedFiles: seals.length, sourceBlobs: review.sourceFiles.length, currentSourceMockRuns: mocks.length, pureRunnerCases: 3, expectedPrimaryLanguageId: 1025, actualNativeLanguageObservations: 0, nativeRun: false, nativeAuthorized: false}, null, 2));

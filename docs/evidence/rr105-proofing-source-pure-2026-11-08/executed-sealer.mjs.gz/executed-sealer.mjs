// Source/pure evidence transport only. Never invoke PowerShell or Office.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {gzipSync, gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const root = 'C:/opf-work/rr105-proofing-review';
const out = 'C:/opf-work/rr105-proofing-source-review-01';
const suite = 'C:/opf-work/rr105-proofing-suite-02';
const base = '5b604bc00e9e514de99f5157b814090f339effe9';
const {zipSync, unzipSync} = createRequire(path.join(root, 'packages/pptx/package.json'))('fflate');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const git = (...args) => execFileSync('git', ['--no-optional-locks', '-C', root, ...args], {maxBuffer: 16 * 1024 * 1024, windowsHide: true});
const parse = bytes => JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, ''));
assert.equal(git('status', '--porcelain', '--untracked-files=normal').toString().trim(), '', 'Freeze a clean source head');
const head = git('rev-parse', 'HEAD').toString().trim();
const sourceNames = git('diff', '--name-only', base, head).toString().trim().split(/\r?\n/);
const entries = {};
async function retain(name, file) { assert(!entries[name], 'Unique packet path'); entries[name] = await fs.readFile(file); }
async function tree(prefix, directory) {
  for (const item of (await fs.readdir(directory, {withFileTypes: true})).sort((a, b) => a.name.localeCompare(b.name))) {
    const full = path.join(directory, item.name), name = prefix + '/' + item.name;
    assert(!item.isSymbolicLink(), 'No linked evidence');
    if (item.isDirectory()) await tree(name, full); else { assert(item.isFile()); await retain(name, full); }
  }
}
for (const file of sourceNames) {
  const bytes = await fs.readFile(path.join(root, file));
  assert.deepEqual(bytes, git('show', head + ':' + file), 'Source bytes equal frozen Git blob: ' + file);
  entries['source/' + file] = bytes;
}
const worker = entries['source/tools/rr105-proofing-readonly/worker-package/test/native-furniture-control.ps1'];
assert.equal(sha(worker), '26ea8b008cdacebc937decbfe52356ace0a146af0d5ade54e20de6397596415c');
for (const directory of ['rr105-mapped-01', 'rr105-mapped-02', 'rr105-mapped-03', 'rr105-contract-01', 'rr105-exact-hydration-01', 'rr105-worker-review-01', 'rr105-data-closure-01']) await tree('qualification/' + directory, path.join(root, 'artifacts', directory));
const mockDirectories = (await fs.readdir(path.join(root, 'artifacts'))).filter(name => name.startsWith('native-proofing-inheritance-')).sort();
for (const directory of mockDirectories) await tree('qualification/' + directory, path.join(root, 'artifacts', directory));
await retain('qualification/executed-hydration-producer.mjs', path.join(root, 'artifacts/rr105-hydrate-head.mjs'));
await tree('suite', suite);
await tree('history/first-suite', 'C:/opf-work/rr105-proofing-suite-01');
await tree('history/first-A-validate-only-failure', 'C:/opf-work/rr105-proofing-validate-A-01');
for (const id of ['A', 'B', 'C']) await tree('runner-validate-only/' + id, 'C:/opf-work/rr105-proofing-validate-' + id + '-02');
const manifest = parse(entries['suite/suite.json']);
assert.equal(manifest.provenance.workerRepository.revision, head);
for (const name of ['rr105-mapped-01', 'rr105-mapped-02', 'rr105-mapped-03', 'rr105-contract-01']) assert.equal(parse(entries['qualification/' + name + '/execution.json']).exitCode, 0);
assert.match(entries['qualification/rr105-contract-01/contract.log'].toString(), /280 scripts passed \(contract suite\)/);
for (const id of ['A', 'B', 'C']) assert.equal(parse(entries['runner-validate-only/' + id + '/runner.json']).status, 'pure-checks-completed; native-not-run');
assert.equal(parse(entries['history/first-A-validate-only-failure/runner.json']).status, 'failed; no-retry');
const sourceDiff = git('diff', '--binary', base, head); entries['source-vs-integration.diff'] = sourceDiff;
entries['executed-sealer.mjs.gz'] = gzipSync(await fs.readFile(new URL(import.meta.url)));
entries['verifier.mjs.gz'] = gzipSync(await fs.readFile(path.join(root, 'artifacts/rr105-verify-source-review.mjs')));
entries['review.json'] = Buffer.from(JSON.stringify({sourceHead: head, sourceBase: base, sourceFiles: sourceNames, workerSha256: sha(worker), suiteManifestSha256: sha(entries['suite/suite.json']), nativeAuthorized: false, nativeRun: false, neverMerge: true, contractScripts: 280, expectedPrimaryLanguageId: 1025, actualNativeLanguageObservations: 0, note: 'Mocks/pure checks only. A retains its actual prior visual failure; B/C glyph behavior unknown. SaveCopy precedes edited capture.'}, null, 2));
const seals = Object.entries(entries).map(([name, bytes]) => ({path: name, bytes: bytes.length, sha256: sha(bytes)}));
entries['entry-seals.json'] = Buffer.from(JSON.stringify(seals, null, 2));
const transport = gzipSync(zipSync(Object.fromEntries(Object.entries(entries).map(([name, bytes]) => [name, [bytes, {mtime: new Date('2000-01-01T00:00:00Z')}]])), {level: 9}));
const decoded = unzipSync(gunzipSync(transport));
assert.equal(Object.keys(decoded).length, seals.length + 1);
for (const file of seals) { assert.equal(decoded[file.path].length, file.bytes); assert.equal(sha(decoded[file.path]), file.sha256); assert.deepEqual(Buffer.from(decoded[file.path]), entries[file.path]); }
assert.deepEqual(Buffer.from(decoded['entry-seals.json']), entries['entry-seals.json']);
await fs.mkdir(out);
await fs.writeFile(path.join(out, 'packet.zip.gz'), transport, {flag: 'wx'});
await fs.writeFile(path.join(out, 'executed-sealer.mjs.gz'), entries['executed-sealer.mjs.gz'], {flag: 'wx'});
const receipt = {sourceHead: head, sourceBase: base, workerSha256: sha(worker), suiteManifestSha256: sha(entries['suite/suite.json']), packetSha256: sha(transport), bytes: transport.length, sealedFiles: seals.length, roundtripAssertions: 3 * seals.length + 2, nativeRun: false, nativeAuthorized: false};
await fs.writeFile(path.join(out, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify(receipt, null, 2));

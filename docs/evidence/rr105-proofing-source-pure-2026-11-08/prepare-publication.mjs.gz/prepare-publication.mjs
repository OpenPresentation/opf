// Copy only the root-approved immutable source/pure packet. No native output discovery.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const root = process.cwd(), input = 'C:/opf-work/rr105-proofing-source-review-01';
const output = path.join(root, 'docs/evidence/rr105-proofing-source-pure-2026-11-08');
assert.equal(root.toLowerCase().replaceAll('\\', '/'), 'c:/opf-work/rr105-proofing-evidence');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const expected = {
  'packet.zip.gz': 'fcf022d2cd7047b19cb016a338765fc9af252d297723a4ec83c47fdb9e4d5ba2',
  'executed-sealer.mjs.gz': '790c44221ffb1093bcacdbd829825ed0449b3c95d8f618bd53d6dada4d57b67e',
  'verifier.mjs.gz': 'e6d5a272a99d0208aea2aa8acbba43aa4b42a39865bd0e19ea4ef6b20b7fbe16',
  'receipt.json': '9686d5329fb101cbb0147ef9fd696bdff100f3e602b2c31a8ab68fef4088521d',
  'verification.json': 'd13ae486879b97b53df968cbd5adeacdab441f75656893d15572f0bc9486dbe0',
  'final-state.json': '8a281a52ad143d36120cd89789c996152713b751f3beb86ba8362778a9c28bda',
};
await fs.mkdir(output);
const files = [];
for (const [name, hash] of Object.entries(expected)) {
  const raw = await fs.readFile(path.join(input, name)); assert.equal(sha(raw), hash);
  const compressed = name.endsWith('.json');
  const bytes = compressed ? gzipSync(raw) : raw, published = name + (compressed ? '.gz' : '');
  await fs.writeFile(path.join(output, published), bytes, {flag: 'wx'});
  files.push({path: published, bytes: bytes.length, sha256: sha(bytes), encoding: compressed ? 'gzip' : 'identity', originalName: name, originalBytes: raw.length, originalSha256: hash});
}
const producer = await fs.readFile(new URL(import.meta.url)), compressedProducer = gzipSync(producer);
await fs.writeFile(path.join(output, 'prepare-publication.mjs.gz'), compressedProducer, {flag: 'wx'});
files.push({path: 'prepare-publication.mjs.gz', bytes: compressedProducer.length, sha256: sha(compressedProducer), encoding: 'gzip', originalName: 'executed-publication-producer.mjs', originalBytes: producer.length, originalSha256: sha(producer)});
const manifest = {date: '2026-11-08', sourceHead: 'b8461d48b193e32dee4e6e1bb60896823f2303ff', packetSha256: expected['packet.zip.gz'], sealedPacketFiles: 839, sourceBlobs: 16, nativeRun: false, actualNewNativeObservations: 0, files};
await fs.writeFile(path.join(output, 'transport-seals.json'), JSON.stringify(manifest, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({output, copiedOriginalFiles: Object.keys(expected).length, sourceHead: manifest.sourceHead, packetSha256: manifest.packetSha256, nativeRun: false}, null, 2));

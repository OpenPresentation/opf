import fs from'node:fs';
const file='packages/javascript/src/composition.ts';let s=fs.readFileSync(file,'utf8');
s=s.replace('export function composeSlide(input: unknown, options: ComposeSlideOptions = {}): SlideComposition {\n  const result = readableProse(input, options, composeSlideBody(input, options));',`/** LH-41: measure a settled horizontal timeline row in the orientation it actually draws, retaining all role sizes. */
const TIMELINE_NOTE_REFLOW = Symbol('opf.timelineNoteReflow');
function readableTimelineNotes(input: unknown, options: ComposeSlideOptions, result: SlideComposition): SlideComposition {
  if (!overflowCount(result) || result.regions || (options as Record<symbol, unknown>)[TIMELINE_NOTE_REFLOW] !== undefined) return result;
  const slide = record(input), own = record(slide.composition), blocks = slide.blocks;
  if (!Array.isArray(blocks) || ['mode', 'columns', 'weights'].some(key => own[key] !== undefined) || blocks.some(block => ['placement', 'region', 'composition', 'blocks'].some(key => record(block)[key] !== undefined))) return result;
  const body = result.items.filter(item => !headings.has(item.field) && !item.eyebrow && !item.emphasis), timelines = body.filter(item => item.timelineLayout), notes = body.filter(item => item.field === 'text');
  if (timelines.length < 2 || !notes.length || timelines.length + notes.length !== body.length || notes.some(item => !item.text || item.caption || ownRunSizes(item.value))) return result;
  const first = timelines[0]!;
  if (timelines.some(item => item.caption || item.timelineLayout!.overflow || item.timelineLayout!.arrangement === 'vertical' || Math.abs(item.box.y - first.box.y) > .5 || Math.abs(item.box.height - first.box.height) > .5)) return result;
  const scale = Math.min(result.width, result.height) / 720;
  const roles = new Map(timelines.map(item => [item.path, Math.min(...item.timelineLayout!.parts.map(part => (part.fit!.fontSize - part.requestedFontSize) / scale))]));
  const retained: RetainedProse = new Map(result.items.filter(item => item.text).map(item => [item.path, {size: item.text!.fontSize, ...(notes.includes(item) ? {limit: PROSE_MEASURE_CHARS} : {})}]));
  const before = trackQuality(result, options), floor = snapFontSizeUp((result.composition.minFontSize ?? 16) * scale);
  for (const compact of [false, true]) {
    const next = composeVariant(input, {...options, [RECOMPOSE]: true, [TIMELINE_NOTE_REFLOW]: roles, [PROSE_REFLOW]: retained, [PROSE_COMPACT]: compact, [PROSE_NO_TITLE_RULE]: result.titleRule === undefined} as ComposeSlideOptions, before, floor);
    if (!next || overflowCount(next) > 0 || next.items.some(overReadingMeasure) || shrinks(next, result, options)) continue;
    const kept = result.items.every(item => {
      const after = next.items.find(entry => entry.path === item.path);
      if (!after || JSON.stringify(item.value) !== JSON.stringify(after.value) || JSON.stringify(item.textStyle) !== JSON.stringify(after.textStyle)) return false;
      if (item.text && (!after.text || after.text.fontSize < item.text.fontSize - FONT_GRID_EPSILON)) return false;
      return !item.timelineLayout || !!after.timelineLayout && [...item.timelineLayout.parts, ...(item.timelineLayout.statusLabels ?? [])].every(part => {
        const fit = [...after.timelineLayout!.parts, ...(after.timelineLayout!.statusLabels ?? [])].find(entry => entry.path === part.path);
        return !!fit && fit.text === part.text && fit.fit!.fontSize >= part.fit!.fontSize - FONT_GRID_EPSILON && JSON.stringify(fit.style) === JSON.stringify(part.style);
      });
    });
    if (kept && next.diagnostics.every(issue => result.diagnostics.some(was => was.code === issue.code && was.path === issue.path))) return next;
  }
  return result;
}
export function composeSlide(input: unknown, options: ComposeSlideOptions = {}): SlideComposition {
  const result = readableProse(input, options, readableTimelineNotes(input, options, composeSlideBody(input, options)));`);
s=s.replace('    const hint = timelineHints.get(node);\n    // LH-121:',`    const retained = ((options as Record<symbol, unknown>)[TIMELINE_NOTE_REFLOW] as ReadonlyMap<string, number> | undefined)?.get(node.path);
    const hint = retained === undefined ? timelineHints.get(node) : {horizontal: true, sizeOffset: retained};
    // LH-121:`);
s=s.replace("sizeOffset: sizeOffset ?? (sizes === 'floor' ? -TIMELINE_FLOOR_OFFSET : sizes === 'placed' ? hint?.sizeOffset ?? 0 : 0),","sizeOffset: sizeOffset ?? (retained !== undefined ? retained : sizes === 'floor' ? -TIMELINE_FLOOR_OFFSET : sizes === 'placed' ? hint?.sizeOffset ?? 0 : 0),");
s=s.replace("return { nodes: [band(split.majority.map(index => nodes[index]!), {}), band(others, others.length <= 3 ? { mode: 'row' } : {})], settings: { ...rootSettings, mode: 'column' } };",`const majority = split.majority.map(index => nodes[index]!);
    // The retained trial observed these timelines side by side. Intrinsic measurement and placement must use that same row,
    // rather than measuring a 2+1 vertical grid and then drawing three horizontal timelines in its oversized allocation.
    const retained = (options as Record<symbol, unknown>)[TIMELINE_NOTE_REFLOW] as ReadonlyMap<string, number> | undefined;
    const timelineRow = retained !== undefined && majority.every(node => !node.children && node.field === 'timeline' && retained.has(node.path));
    return { nodes: [band(majority, timelineRow ? {mode: 'row'} : {}), band(others, others.length <= 3 ? { mode: 'row' } : {})], settings: { ...rootSettings, mode: 'column' } };`);
fs.writeFileSync(file,s);

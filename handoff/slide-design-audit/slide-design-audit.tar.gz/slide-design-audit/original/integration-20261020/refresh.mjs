// Re-render historical gallery content using the rebased source builds and current catalog.
// Run from core: node --import ./scripts/register-local-opf.mjs artifacts/design-audit/integration-20261020/refresh.mjs
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const root = process.cwd();
const out = path.join(root, 'artifacts/design-audit/integration-20261020');
const original = path.dirname(out);
const moduleAt = relative => import(pathToFileURL(path.resolve(root, relative)).href);
const { gallery } = await import('@openpresentation/gallery');
const { validate } = await moduleAt('packages/javascript/dist/index.js');
const { loadFonts } = await moduleAt('../opf-render/dist/fonts-node.js');
const { toSvg, toPng, resolvePresentation } = await moduleAt('../opf-render/dist/index.js');
const fonts = await loadFonts({ pack: 'office' });
const options = { fonts, catalogs: [gallery], text: 'paths', trace: true };
const hash = value => createHash('sha256').update(value).digest('hex');
const json = async file => JSON.parse(await readFile(file, 'utf8'));
const save = (file, data) => writeFile(file, JSON.stringify(data, null, 2) + '\n');
const revision = dir => execFileSync('git', ['rev-parse', 'HEAD'], {cwd:dir, encoding:'utf8'}).trim();
const escape = text => String(text).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
await mkdir(path.join(out,'gallery'), {recursive:true});
const entries = [];
for (const name of (await readdir(path.join(original,'gallery/baseline'))).filter(name=>name.endsWith('.opf.json')).sort()) {
 const id = name.replace('.opf.json','');
 const before = await json(path.join(original,'gallery/baseline',name));
 const deck = structuredClone(before);
 delete deck.catalogs;
 assert.deepEqual(deck.slides,before.slides,'Preserve every authored slide field');
 const validation = validate(deck, { fonts, catalogs:[gallery] });
 const resolved = resolvePresentation(deck,options).slides[0];
 const diagnostics = [];
 const svg = toSvg(deck,1,{...options,onDiagnostic:d=>diagnostics.push(d)});
 const png = await toPng(svg,{fonts});
 await save(path.join(out,'gallery',name),deck);
 await writeFile(path.join(out,'gallery',id+'.svg'),svg);
 await writeFile(path.join(out,'gallery',id+'.png'),png);
 await save(path.join(out,'gallery',id+'.geometry.json'),resolved.geometry);
 await save(path.join(out,'gallery',id+'.findings.json'),{validation,diagnostics});
 entries.push({id, before:'../gallery/baseline/'+id+'.png',after:'gallery/'+id+'.png',input:'gallery/'+name,inputSlideSha256:hash(JSON.stringify(deck.slides)),unchangedContent:true,changedPng:hash(await readFile(path.join(original,'gallery/baseline',id+'.png')))!==hash(png),validation:validation.counts,geometryDiagnostics:resolved.geometry.diagnostics});
}
assert.equal(entries.length,28);
const oldAuto=await json(path.join(original,'auto/index.json'));
const freshAuto=await json(path.join(out,'auto/index.json'));
const auto=oldAuto.cases.map((item,i)=>{const fresh=freshAuto.cases[i];assert.equal(item.sha256.input,fresh.sha256.input);return {id:item.id,before:'../auto/'+item.files.png,after:'auto/'+fresh.files.png,unchangedContent:true,changedPng:item.sha256.png!==fresh.sha256.png,validation:fresh.validationCounts,geometryDiagnostics:fresh.diagnostics};});
const oldColumns=await json(path.join(original,'columns/manifest.json'));
const newColumns=await json(path.join(out,'columns/manifest.json'));
const columns=[];
for(const item of [...newColumns.entries,...newColumns.controls]) {
 const old=[...oldColumns.entries,...oldColumns.controls].find(e=>e.id===item.id);
 const previous=await json(path.join(original,'columns',old.files.input));
 const current=await json(path.join(out,'columns',item.files.input));
 assert.deepEqual(previous.slides,current.slides,'Column content must remain unchanged');
 const beforePng=await readFile(path.join(original,'columns',old.files.png));
 const afterPng=await readFile(path.join(out,'columns',item.files.png));
 columns.push({id:item.id,before:'../columns/'+old.files.png,after:'columns/'+item.files.png,unchangedContent:true,changedPng:hash(beforePng)!==hash(afterPng),validation:item.validationCounts,geometryDiagnostics:item.geometryDiagnostics});
}
const sources=[];
for(const [name,dir,branch] of [['opf',root,'main'],['opf-render','../opf-render','main'],['opf-pptx','../opf-pptx','main'],['opf-editor','../opf-editor','main'],['openpresentation-site','../openpresentation-site','main'],['pptx-gallery','../pptx-gallery','main'],['pptx-dev','../pptx-dev','master'],['gallery','artifacts/design-audit/gallery-source','main']]) {
 const directory=path.resolve(root,dir);
 sources.push({name,head:revision(directory),upstream:execFileSync('git',['rev-parse','origin/'+branch],{cwd:directory,encoding:'utf8'}).trim(),branch:execFileSync('git',['branch','--show-current'],{cwd:directory,encoding:'utf8'}).trim()});
}
const manifest={scope:'Fresh local source render after upstream integration, preserving all original slide content. This does not approve pending proposals.',node:process.version,coreVersion:(await json(path.join(root,'packages/javascript/package.json'))).version,rendererVersion:(await json(path.join(root,'../opf-render/package.json'))).version,galleryVersion:(await json(path.join(root,'node_modules/@openpresentation/gallery/package.json'))).version,sources,counts:{gallery:entries.length,auto:auto.length,columns:columns.length},changedPngs:{gallery:entries.filter(x=>x.changedPng).length,auto:auto.filter(x=>x.changedPng).length,columns:columns.filter(x=>x.changedPng).length},gallery:entries,auto,columns,limitations:['Gallery refresh uses the current registered default record instead of the historical embedded catalog; authored slide fields and content are exact.','Columns retain the unapproved inline structural candidates for comparability; they are not claims about published gallery defaults.','Validation font-context warnings are retained. Passing geometry is not a visual-quality or native-PowerPoint claim.','Historical proposals require reassessment against current upstream; unchanged stable IDs do not imply every original critique still applies.']};
await save(path.join(out,'manifest.json'),manifest);
const sections=[['gallery',entries],['columns',columns],['auto',auto]];
let html='<!doctype html><meta charset="utf-8"><title>Upstream integration review</title><style>body{font:16px system-ui;max-width:1500px;margin:32px auto;background:#f4f6f8;color:#18212b}article{background:white;padding:20px;margin:18px 0;border-radius:10px}figure{margin:0}img{width:100%;height:auto}div.pair{display:grid;grid-template-columns:1fr 1fr;gap:16px}nav{position:sticky;top:0;background:white;padding:12px}h2{scroll-margin-top:65px}small{color:#536171}</style><h1>Latest upstream integration</h1><p>Original content preserved. Left: historical audit. Right: current source builds (core '+manifest.coreVersion+', renderer '+manifest.rendererVersion+', catalog '+manifest.galleryVersion+'). Proposal approvals remain pending.</p><nav><a href="#gallery-01">Gallery</a> · <a href="#columns-01">Columns</a> · <a href="#auto-01">Auto — final section</a> · <a href="manifest.json">Manifest</a></nav>';
for(const [section,items]of sections)for(let start=0;start<items.length;start+=3){html+='<h2 id="'+section+'-'+String(Math.floor(start/3)+1).padStart(2,'0')+'">'+section+' · batch '+(Math.floor(start/3)+1)+'</h2>';for(const item of items.slice(start,start+3))html+='<article><h3>'+escape(item.id)+'</h3><small>'+(item.changedPng?'Output changed with upstream':'Output is byte-identical')+' · Content preserved · Geometry findings: '+item.geometryDiagnostics.length+'</small><div class="pair"><figure><figcaption>Historical audit</figcaption><a href="'+item.before+'"><img loading="lazy" src="'+item.before+'"></a></figure><figure><figcaption>Current source</figcaption><a href="'+item.after+'"><img loading="lazy" src="'+item.after+'"></a></figure></div></article>';}
await writeFile(path.join(out,'report.html'),html);
console.log(JSON.stringify({counts:manifest.counts,changedPngs:manifest.changedPngs}));

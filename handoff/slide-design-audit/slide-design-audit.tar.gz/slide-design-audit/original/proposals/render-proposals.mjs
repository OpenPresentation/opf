// Illustrations of possible shared-policy changes. Never edits engine, schema, theme, or layout sources.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gallery } from '@openpresentation/gallery';
import { validate } from '../../../packages/javascript/dist/index.js';
import { loadFonts } from '../../../../opf-render/dist/fonts-node.js';
import { resolvePresentation, toPng, toSvg } from '../../../../opf-render/dist/index.js';

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(directory, '../../..');
const baseline = path.join(root, 'artifacts/design-audit/gallery/baseline');
const hash = value => createHash('sha256').update(value).digest('hex');
const load = async file => JSON.parse(await readFile(file, 'utf8'));
const save = (name, value) => writeFile(path.join(directory, name), JSON.stringify(value, null, 2) + '\n');
await mkdir(directory, { recursive: true });
const fonts = await loadFonts({ pack: 'office' });
const options = { fonts, catalogs: [gallery], text: 'paths', trace: true };
const records = [];
const render = async (id, state, deck, note) => {
  const validation = validate(deck, { fonts, catalogs: [gallery] });
  assert.equal(validation.valid, true, JSON.stringify(validation.findings.filter(item => item.severity === 'error')));
  const bound = resolvePresentation(deck, options).slides[0];
  const svg = toSvg(deck, 1, options), png = await toPng(svg, { fonts });
  const stem = `${id}-${state}`;
  await save(`${stem}.opf.json`, deck);
  await save(`${stem}.geometry.json`, { geometry: bound.geometry, design: bound.design, validation });
  await writeFile(path.join(directory, `${stem}.svg`), svg);
  await writeFile(path.join(directory, `${stem}.png`), png);
  const record = { id, state, note, input: `${stem}.opf.json`, svg: `${stem}.svg`, png: `${stem}.png`, geometry: `${stem}.geometry.json`, sha256: hash(png) };
  records.push(record);
  return { record, bound, deck };
};

const cover = await load(path.join(baseline, 'cover.opf.json'));
const originalTitle = cover.slides[0].title;
const originalCover = await render('cover-balance', 'before', cover, 'Unmodified baseline with automatic wrapping.');
const balancedCover = structuredClone(cover);
balancedCover.slides[0].title = 'A smaller pilot.\nA clearer decision.';
assert.equal(balancedCover.slides[0].title.replace(/\s+/g, ' '), originalTitle);
const candidateCover = await render('cover-balance', 'illustration', balancedCover, 'ILLUSTRATION ONLY: one authored newline demonstrates desired balanced automatic wrapping. No balancing algorithm is implemented. Same words, font, layout, and scale.');

for (const id of ['metrics', 'quote', 'chart']) {
  const deck = await load(path.join(baseline, `${id}.opf.json`));
  await render(`${id}-background`, 'dark', deck, 'Unmodified baseline. Default navy background.');
  const light = structuredClone(deck);
  light.design = { ...light.design, background: 'light1' };
  await render(`${id}-background`, 'light', light, 'PROPOSAL ILLUSTRATION: a copied deck background override only. The authoritative theme and fallback defaults are unchanged.');
}

const quote = await load(path.join(baseline, 'quote.opf.json'));
await render('quote-prominence', 'before', quote, 'Unmodified baseline quote, nominal body 28px with footer 17px.');
const prominentQuote = structuredClone(quote);
const quoteBlock = prominentQuote.slides[0].blocks.find(block => block.quote);
assert.equal(typeof quoteBlock.quote.text, 'string');
const originalQuoteText = quoteBlock.quote.text;
quoteBlock.quote.text = [{ text: originalQuoteText, fontSize: 32 }];
const larger = await render('quote-prominence', 'illustration', prominentQuote, 'ILLUSTRATION ONLY: existing schema TextRun.fontSize 32pt (42.67px) on the copied quote body; attribution unchanged. This author override illustrates a shared nominal-scale proposal, not a new default.');
const largerBody = larger.bound.geometry.items.find(item => item.quoteLayout)?.quoteLayout.parts.find(part => part.role === 'body');
const bodyFragments = largerBody.fit.richLines.flatMap(line => line.fragments);
assert.ok(bodyFragments.some(fragment => fragment.fontSize > 42 && fragment.fontSize < 43));
assert.equal(quoteBlock.quote.text.map(run => run.text).join(''), originalQuoteText);

const srgb = channel => channel <= .04045 ? channel / 12.92 : ((channel + .055) / 1.055) ** 2.4;
const luminance = hex => hex.replace('#', '').match(/../g).map(channel => srgb(parseInt(channel, 16) / 255)).reduce((sum, channel, index) => sum + channel * [.2126, .7152, .0722][index], 0);
const ratio = (first, second) => (Math.max(luminance(first), luminance(second)) + .05) / (Math.min(luminance(first), luminance(second)) + .05);
const palette = { accent1: '#2874A6', accent2: '#1B4F72', accent3: '#5499C7', accent4: '#7BDBB2', accent5: '#3AC67A', accent6: '#24A89E' };
const contrast = Object.entries(palette).map(([role, color]) => ({ role, color, onNavy: ratio(color, '#011842'), onWhite: ratio(color, '#FFFFFF') }));

const esc = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('"', '&quot;');
const sheet = async (filename, rows) => {
  const width = 1920, margin = 16, gap = 16, panel = (width - margin * 2 - gap) / 2, rowHeight = 590;
  const parts = [];
  for (const [row, cells] of rows.entries()) for (const [column, [stem, label]] of cells.entries()) {
    const x = margin + column * (panel + gap), y = row * rowHeight;
    const svg = await readFile(path.join(directory, stem + '.svg'));
    parts.push(`<text x="${x}" y="${y + 29}" font-family="Intos" font-size="22" font-weight="700" fill="#1f2937">${esc(label)}</text>`);
    parts.push(`<image x="${x}" y="${y + 48}" width="${panel}" height="${panel * 9 / 16}" href="data:image/svg+xml;base64,${svg.toString('base64')}"/>`);
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${rows.length * rowHeight}"><rect width="100%" height="100%" fill="white"/>${parts.join('')}</svg>`;
  await writeFile(path.join(directory, filename + '.svg'), svg);
  await writeFile(path.join(directory, filename + '.png'), await toPng(svg, { fonts }));
};
await sheet('cover-balance-before-after', [[['cover-balance-before', 'Before: automatic wrap'], ['cover-balance-illustration', 'Illustration: balanced wrap using one authored newline']]]);
await sheet('background-before-after', ['metrics', 'quote', 'chart'].map(id => [[`${id}-background-dark`, `${id}: existing default navy`], [`${id}-background-light`, `${id}: proposed light1 background (copied deck only)`]]));
await sheet('quote-prominence-before-after', [[['quote-prominence-before', 'Before: nominal 28px quote'], ['quote-prominence-illustration', 'Illustration: 32pt rich run (42.67px), same quote and attribution']]]);

const coverLines = bound => bound.geometry.items.find(item => item.field === 'title').text.lines;
await save('manifest.json', {
  scope: 'Reviewable illustrations only; no engine, schema, theme, or layout source edited. Shared-policy changes require user approval.',
  command: 'node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/render-proposals.mjs',
  source: { fonts: 'Pinned office pack; Aptos→Intos metric replacement; same handle for measurement and raster; system fonts disabled; SVG uses glyph paths.' },
  cover: { before: coverLines(originalCover.bound), illustration: coverLines(candidateCover.bound), unchangedWords: true, implementationTarget: 'Core heading wrapping/fitPlacedText; needs a real, content-preserving balancing implementation and broad regression evidence.' },
  background: { from: '#011842', to: '#FFFFFF', contrast, observations: [
    'Primary blue on navy is 3.41894:1. The existing 76px metric figures clear the 3:1 large-text threshold; smaller primary-colored text would miss 4.5:1.',
    'Primary blue on white is 5.07367:1. This gives the headline numbers stronger contrast and meets 4.5:1.',
    'A light background is not a blanket palette repair: accent3 is 3.10735:1 on white, while accent4/5/6 fall below 3:1 and need role-specific contrast handling.',
    'These three fixtures keep ordinary labels in the resolved text or muted-text colors. Their metric labels and quote attribution remain readable; chart labels must still be visually checked.',
    'Changing the gallery minimal theme alone does not alter omitted-design fallback behavior: shared ENGINE_DEFAULT_THEME and spec/reference/engine-defaults.json must be considered together if approved.',
  ], implementationTargets: ['gallery-source/catalog/themes/minimal.json (authoritative gallery theme)', 'packages/javascript/src/engine-vocabularies.ts ENGINE_DEFAULT_THEME (omitted-design fallback)', 'spec/reference/engine-defaults.json (documented fallback)'] },
  quote: { supportedIllustration: 'Quote.text accepts TextRun[] and TextRun.fontSize in points. Copied fixture uses 32pt; no schema change.', actualIllustrationFragmentSizes: [...new Set(bodyFragments.map(fragment => fragment.fontSize))], implementationTarget: 'packages/javascript/src/composition.ts layoutQuote body add(...,28,...). Raise the shared requested body size only after approval, retaining footer sizing, fit logic, and attribution proximity.' },
  records,
});
console.log(JSON.stringify({ output: directory, images: records.length, contrast }, null, 2));

// Authored arrangements illustrating proposed automatic behavior. No shared engine or catalog source changes.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gallery } from '@openpresentation/gallery';
import { validate, resolveSlideContext } from '../../../packages/javascript/dist/index.js';
import { composeSlide } from '../../../packages/javascript/dist/composition.js';
import { loadFonts } from '../../../../opf-render/dist/fonts-node.js';
import { resolvePresentation, toPng, toSvg } from '../../../../opf-render/dist/index.js';

const directory = path.dirname(fileURLToPath(import.meta.url));
const auto = path.resolve(directory, '../auto');
const fonts = await loadFonts({ pack: 'office' });
const options = { fonts, catalogs: [gallery], text: 'paths', trace: true };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const load = async file => JSON.parse(await readFile(file, 'utf8'));
const save = (name, value) => writeFile(path.join(directory, name), JSON.stringify(value, null, 2) + '\n');
const probes = [
  { id: '04-uneven-comparison', title: 'Unequal content needs unequal space', mutate: slide => { slide.composition = { mode: 'row', weights: [1, 2] }; }, intent: 'Give the longer explanation two thirds of the available track width while preserving the first block and source reading order.' },
  { id: '06-five-priorities', title: 'Center the incomplete final row', mutate: slide => { slide.layout = 'pillars'; }, intent: 'Use the existing pillars template grid to illustrate centered final-row placement. This is a layout selection, not implemented automatic behavior.' },
  { id: '10-chart-and-takeaway', title: 'Give primary evidence more width', mutate: slide => { slide.composition = { mode: 'row', weights: [2, 1] }; }, intent: 'Give the chart two thirds of the available track width and keep the interpretation in a readable supporting column.' },
  { id: '17-two-nested-groups', title: 'Keep each owner close to their responsibilities', mutate: slide => {
    slide.composition = { mode: 'row' };
    for (const group of slide.blocks) group.composition = { mode: 'column', weights: [1, 7] };
  }, intent: 'Place the two peer groups in columns; stack each owner above their own list. The authored 1:7 child tracks leave enough space for the short owner label without creating the large gap of equal-height rows, and keep every cell above the existing60px comfort threshold.' },
];

const results = [];
for (const probe of probes) {
  const original = await load(path.join(auto, probe.id + '.opf.json'));
  const candidate = structuredClone(original);
  probe.mutate(candidate.slides[0]);
  const stripped = structuredClone(candidate);
  const removeArrangement = host => {
    delete host.composition;
    delete host.layout;
    for (const block of host.blocks ?? []) removeArrangement(block);
  };
  removeArrangement(stripped.slides[0]);
  assert.deepEqual(stripped, original, 'Only arrangement fields may change');
  const states = [];
  for (const [state, deck] of [['before', original], ['illustration', candidate]]) {
    const validation = validate(deck, { fonts, catalogs: [gallery] });
    assert.equal(validation.valid, true, JSON.stringify(validation.findings.filter(finding => finding.severity === 'error')));
    const bound = resolvePresentation(deck, options).slides[0];
    const context = resolveSlideContext(deck, 0, { fonts, catalogs: [gallery] });
    const geometry = composeSlide(context.slide, { ...context.options, fontFamilies: bound.design.fonts, textMeasurement: bound.textMeasurement, explain: true });
    const { explanation, ...unexplained } = geometry;
    assert.deepEqual(unexplained, bound.geometry);
    const renderDiagnostics = [];
    const svg = toSvg(deck, 1, { ...options, onDiagnostic: issue => renderDiagnostics.push(issue) });
    const png = await toPng(svg, { fonts });
    if (state === 'before') assert.ok(Buffer.from(png).equals(await readFile(path.join(auto, probe.id + '.png'))), `${probe.id}: baseline PNG must match exactly`);
    const stem = `auto-${probe.id}-${state}`;
    await save(stem + '.opf.json', deck);
    await save(stem + '.geometry.json', { geometry, design: bound.design, validation, renderDiagnostics, contextDiagnostics: context.diagnostics });
    await writeFile(path.join(directory, stem + '.svg'), svg);
    await writeFile(path.join(directory, stem + '.png'), png);
    states.push({ state, input: stem + '.opf.json', svg: stem + '.svg', png: stem + '.png', geometry: stem + '.geometry.json', sha256: hash(png), items: geometry.items.map(item => ({ path: item.path, field: item.field, box: item.box, fontSize: item.text?.fontSize, lines: item.text?.lines.length })), diagnostics: geometry.diagnostics, selected: explanation.decisions });
  }
  results.push({ id: probe.id, title: probe.title, intent: probe.intent, contentAndOrderPreserved: true, fontsAndBackgroundPreserved: true, states });
}

const escape = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('"', '&quot;');
const sheet = async (name, rows) => {
  const width = 1920, margin = 16, gap = 16, panel = (width - 2 * margin - gap) / 2, rowHeight = 590;
  const pieces = [];
  for (const [row, result] of rows.entries()) {
    for (const [column, state] of result.states.entries()) {
      const x = margin + column * (panel + gap), y = row * rowHeight;
      const source = await readFile(path.join(directory, state.svg));
      const label = state.state === 'before' ? `${result.id}: existing automatic output` : `${result.id}: authored arrangement illustrates proposed automatic behavior`;
      pieces.push(`<text x="${x}" y="${y + 28}" font-family="Intos" font-size="20" font-weight="700" fill="#1f2937">${escape(label)}</text>`);
      pieces.push(`<image x="${x}" y="${y + 48}" width="${panel}" height="${panel * 9 / 16}" href="data:image/svg+xml;base64,${source.toString('base64')}"/>`);
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${rowHeight * rows.length}"><rect width="100%" height="100%" fill="white"/>${pieces.join('')}</svg>`;
  await writeFile(path.join(directory, name + '.svg'), svg);
  await writeFile(path.join(directory, name + '.png'), await toPng(svg, { fonts }));
};
for (const result of results) await sheet(`auto-${result.id}-before-after`, [result]);
await sheet('auto-arrangement-three-comparisons', results.slice(0, 3));
await sheet('auto-arrangement-proximity-three-comparisons', [results[0], results[1], results[3]]);
await save('auto-arrangement-manifest.json', {
  scope: 'Authored arrangement illustrates proposed automatic behavior. No engine, schema, catalog, or default changes implemented.',
  command: 'node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/render-auto-arrangement-proposals.mjs',
  source: { baseline: '../auto/index.json', coreVersion: '0.20.3', rendererVersion: '0.20.2', galleryVersion: '3.0.0', fonts: 'Same pinned office fonts, metric Intos replacement, SVG paths, system fonts off.', pillarsRecord: gallery.layouts.pillars },
  notes: ['All words, numbers, payload order, fonts, backgrounds, and nominal type sizes are preserved. Plain text remains25px; lists retain their existing32px nominal size.', 'Case06 is an existing pillars layout selection. Only the two final-row horizontal positions change; their widths, heights, vertical positions, and type remain identical.', 'Case17 uses authored nested 1:7 tracks to demonstrate a short owner label close to its own list; equal child rows would leave a large vertical gap.', 'A weighted arrangement shows a possible desired automatic result, not an inferred universal content rule.'],
  results,
});
console.log(JSON.stringify(results.map(result => ({ id: result.id, states: result.states.map(state => ({ state: state.state, png: state.png, diagnostics: state.diagnostics, items: state.items.filter(item => item.field !== 'title') })) })), null, 2));

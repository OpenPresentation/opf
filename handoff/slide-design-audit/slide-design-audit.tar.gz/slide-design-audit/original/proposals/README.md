# Shared behavior proposals: illustrations only

No engine, schema, theme, or layout source is changed here. Exact copied OPF inputs and geometry accompany every PNG and SVG. Shared default changes require the user's approval.

- [Balanced cover heading](cover-balance-before-after.png): same words and size, with one authored newline in the illustration. It demonstrates the desired result of automatic balancing; no balancing algorithm is implemented.
- [Dark and light background comparison](background-before-after.png): three examples (metrics, quote, chart), each unchanged except a copied deck's `design.background: "light1"`. The authoritative theme and omitted-design engine fallback remain navy.
- [Quote prominence](quote-prominence-before-after.png): the existing schema permits `Quote.text` as rich runs. A copied quote uses a 32pt run (42.67px) to illustrate a more prominent shared body scale; the wording, attribution, and layout remain the same. No new default is implemented.

The primary blue `#2874A6` has contrast **3.41894:1** on navy `#011842` and **5.07367:1** on white. The existing large metric numbers meet the 3:1 large-text threshold on navy; smaller primary-colored text would miss 4.5:1. White improves this primary accent but weakens several lighter palette accents. Accent3 is only 3.10735:1 on white, and accent4/5/6 fall below 3:1. Background selection must be accompanied by role-appropriate contrast behavior.

The shown light-background examples use ordinary labels in resolved black or dark navy. Those labels remain readable. Changing only the gallery `minimal` record would not change omitted-design fallback behavior: the shared `ENGINE_DEFAULT_THEME` and its documented reference must be evaluated together if the change is approved.

The [manifest](manifest.json) records all comparison inputs, hashes, actual line breaks, actual quote fragment sizes, contrast calculations, and implementation targets. Fonts are pinned through the office pack, with Aptos measured through its Intos metric replacement; measurement and rasterization share the same handle, SVG text is outlined, and system fonts are disabled.

## Desired automatic arrangements

These comparisons use authored arrangements to illustrate proposed automatic behavior. They do not implement automatic inference or change shared defaults. All words, values, payload order, fonts, backgrounds, and type sizes are preserved; every baseline PNG exactly matches the retained auto corpus.

- [Unequal explanation lengths](auto-04-uneven-comparison-before-after.png): a copied fixture uses row weights of 1:2. The short note wraps from two lines to three; the long explanation improves from nine lines to seven.
- [Five priorities](auto-06-five-priorities-before-after.png): the copied fixture selects the existing `pillars` layout. Only the two last-row horizontal positions change, centering that row while retaining every item width, height, vertical position, and text size.
- [Chart and takeaway](auto-10-chart-and-takeaway-before-after.png): row weights of 2:1 give primary evidence 760.5px rather than 570.4px. The supporting paragraph retains 25px text in a 380.3px column.
- [Owner and responsibilities](auto-17-two-nested-groups-before-after.png): root row mode and child column mode preserve two peer groups, with each owner above their own list. Child weights of 1:7 keep short labels close to their lists while retaining the existing minimum comfortable cell height.

The [three comparison sheet](auto-arrangement-proximity-three-comparisons.png) shows explanation proportions, final-row balance, and nested grouping. The [alternate sheet](auto-arrangement-three-comparisons.png) substitutes chart proportions for nested grouping. Exact sources, explained geometry, findings, and before hashes are in the [arrangement manifest](auto-arrangement-manifest.json). All eight rendered inputs validate and have no geometry diagnostics.

Reproduce from the OPF root:

```sh
node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/render-proposals.mjs
node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/render-auto-arrangement-proposals.mjs
```

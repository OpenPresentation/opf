// Supported authored controls only. These partial illustrations do not implement new defaults or automatic algorithms.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gallery } from '@openpresentation/gallery';
import { validate, resolveSlideContext } from '../../../../packages/javascript/dist/index.js';
import { composeSlide, layoutTable } from '../../../../packages/javascript/dist/composition.js';
import { loadFonts } from '../../../../../opf-render/dist/fonts-node.js';
import { resolvePresentation, toPng, toSvg } from '../../../../../opf-render/dist/index.js';

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(directory, '../../../..');
const baseline = path.join(root, 'artifacts/design-audit/gallery/baseline');
const load = async file => JSON.parse(await readFile(file, 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const save = (name, value) => writeFile(path.join(directory, name), JSON.stringify(value, null, 2) + '\n');
await mkdir(directory, { recursive: true });
const fonts = await loadFonts({ pack: 'office' });
const options = { fonts, catalogs: [gallery], text: 'paths', trace: true };
const schema = await load(path.join(root, 'spec/schemas/opf.schema.json'));
const plainCell = cell => {
  if (cell === null || typeof cell !== 'object' || Array.isArray(cell)) return { value: cell };
  return { value: cell.value ?? cell.name, ...(cell.format !== undefined ? { format: cell.format } : {}), ...(cell.colSpan !== undefined ? { colSpan: cell.colSpan } : {}), ...(cell.rowSpan !== undefined ? { rowSpan: cell.rowSpan } : {}) };
};
const logicalTable = table => ({ columns: table.columns?.map(plainCell), rows: table.rows.map(row => row.map(plainCell)) });
const contentSignature = deck => {
  const content = host => ({ ...Object.fromEntries(['title', 'subtitle', 'tag', 'text', 'items', 'bullets', 'image', 'video', 'chart', 'code', 'metric', 'quote', 'timeline'].filter(field => host[field] !== undefined).map(field => [field, host[field]])), ...(host.table ? { table: logicalTable(host.table) } : {}), ...(host.blocks ? { blocks: host.blocks.map(content) } : {}) });
  return deck.slides.map(content);
};
const xmlText = value => value.replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&#39;', "'");
const svgTexts = svg => [...svg.matchAll(/<text\b([^>]*)>([\s\S]*?)<\/text>/g)].map(([, attrs, body]) => ({ text: xmlText(body.replace(/<[^>]*>/g, '')), fontSize: Number(/font-size="([\d.]+)"/.exec(attrs)?.[1]), attrs }));
const chartTicks = svg => svgTexts(svg).filter(item => /^-?\d+(?:\.\d+)?%$/.test(item.text));
const domain = ticks => { const values = ticks.map(item => Number(item.text.slice(0, -1))); return { minimumPercent: Math.min(...values), maximumPercent: Math.max(...values) }; };

const render = async (id, state, deck) => {
  const signature = hash(JSON.stringify(contentSignature(deck)));
  const validation = validate(deck, { fonts, catalogs: [gallery] });
  assert.equal(validation.valid, true, JSON.stringify(validation.findings.filter(finding => finding.severity === 'error')));
  const bound = resolvePresentation(deck, options).slides[0];
  const context = resolveSlideContext(deck, 0, { fonts, catalogs: [gallery] });
  const geometry = composeSlide(context.slide, { ...context.options, fontFamilies: bound.design.fonts, textMeasurement: bound.textMeasurement, explain: true });
  const { explanation: _explanation, ...unexplained } = geometry;
  assert.deepEqual(unexplained, bound.geometry);
  const renderDiagnostics = [];
  const svg = toSvg(deck, 1, { ...options, onDiagnostic: issue => renderDiagnostics.push(issue) });
  const png = await toPng(svg, { fonts });
  assert.equal(signature, hash(JSON.stringify(contentSignature(deck))), 'No rendering mutation');
  const tables = geometry.items.filter(item => item.field === 'table').map(item => ({ path: item.path, layout: layoutTable(item.value, item.box, { minFontSize: geometry.composition.minFontSize, fontFamily: bound.design.fonts.body, textMeasurement: bound.textMeasurement, path: item.path, presentation: deck }) }));
  const stem = `${id}-${state}`;
  await save(stem + '.opf.json', deck);
  await save(stem + '.geometry.json', { geometry, tables, resolvedDesign: bound.design, validation, renderDiagnostics, actualSvgText: svgTexts(svg).map(({ text, fontSize }) => ({ text, fontSize })) });
  await writeFile(path.join(directory, stem + '.svg'), svg);
  await writeFile(path.join(directory, stem + '.png'), png);
  return { deck, bound, geometry, tables, svg, record: { input: stem + '.opf.json', svg: stem + '.svg', png: stem + '.png', geometry: stem + '.geometry.json', contentSha256: signature, pngSha256: hash(png), geometryDiagnostics: geometry.diagnostics, renderDiagnostics, validationCounts: validation.counts, fontFamilies: bound.design.fonts } };
};

const results = [];

// Chart: use only the supported readability floor. Select a floor that preserves the actually rendered axis domain.
const chartBefore = await load(path.join(baseline, 'chart.opf.json'));
const initialChartSvg = toSvg(chartBefore, 1, options), initialTicks = chartTicks(initialChartSvg);
assert.ok(initialTicks.length > 1);
const chartTrials = [];
let chartAfter;
for (const minimum of [24, 22, 20, 19, 18]) {
  const candidate = structuredClone(chartBefore);
  candidate.slides[0].composition = { minFontSize: minimum };
  const svg = toSvg(candidate, 1, options), ticks = chartTicks(svg);
  const preserved = JSON.stringify(domain(ticks)) === JSON.stringify(domain(initialTicks));
  chartTrials.push({ minFontSize: minimum, tickCount: ticks.length, tickLabels: ticks.map(item => item.text), tickFontSizes: [...new Set(ticks.map(item => item.fontSize))], axisDomain: domain(ticks), accepted: preserved });
  if (preserved && !chartAfter) chartAfter = candidate;
}
assert.ok(chartAfter, 'A same-domain supported label illustration must exist');
assert.deepEqual(chartAfter.slides[0].blocks, chartBefore.slides[0].blocks, 'Chart payload and companion text must remain byte-for-byte equivalent');
const cb = await render('P19-chart', 'before', chartBefore), ca = await render('P19-chart', 'illustration', chartAfter);
assert.deepEqual(domain(chartTicks(ca.svg)), domain(initialTicks));
results.push({
  id: 'P19', kind: 'chart', status: 'Partial supported authored illustration; full proposal is not expressible.',
  before: cb.record, after: ca.record,
  supportedControls: ['Slide composition.minFontSize raises chart text through the existing renderer.'],
  actualChanges: { control: chartAfter.slides[0].composition, beforeTickSizes: [...new Set(initialTicks.map(item => item.fontSize))], afterTickSizes: [...new Set(chartTicks(ca.svg).map(item => item.fontSize))], beforeTickCount: initialTicks.length, afterTickCount: chartTicks(ca.svg).length, axisDomainPreserved: domain(initialTicks), trials: chartTrials },
  notExpressible: ['No chart-specific requested axis/legend font size.', 'No authored tick-count/interval or axis-bound control; the larger floor probes changed the automatic domain and were rejected.', 'No gridline or outer-frame visibility/weight controls.'],
  implementationTargets: ['opf-render/src/charts.js chartContext, maxIntervalsFor, niceScale, gridline, axisLine', 'opf-render/src/svg.js renderChart outer panel and border', 'Shared accepted chart label/plot geometry for coordinated preview and export'],
  limitation: 'This after image demonstrates only modest supported label growth with the same axis domain. It does not show the proposed fewer ticks or lighter frame, and no algorithm/default changed.',
  visualAssessment: 'Axis text is a little clearer at19px, but remains small for a live slide. Tick count and frame competition are unchanged. The full P19 design is still pending.',
});

// Table: preserve scalar types and formats. Raise the supported floor to24px and use legal cell borders; leave widths unchanged.
const tableBefore = await load(path.join(baseline, 'table.opf.json'));
const tableAfter = structuredClone(tableBefore);
tableAfter.slides[0].composition = { minFontSize: 24 };
const table = tableAfter.slides[0].blocks.find(block => block.table).table;
const styledCell = (cell, header) => {
  const existing = cell !== null && typeof cell === 'object' && !Array.isArray(cell) ? cell : undefined;
  const borders = Object.fromEntries(['top', 'right', 'bottom', 'left'].map(edge => [edge, { color: 'text', width: header && edge === 'bottom' ? .75 : 0 }]));
  return { value: existing?.value ?? existing?.name ?? cell, ...(existing?.format !== undefined ? { format: existing.format } : {}), style: { ...(existing?.style ?? {}), borders } };
};
table.columns = table.columns.map(cell => styledCell(cell, true));
table.rows = table.rows.map(row => row.map(cell => styledCell(cell, false)));
assert.deepEqual(logicalTable(table), logicalTable(tableBefore.slides[0].blocks.find(block => block.table).table));
const tb = await render('P20-table', 'before', tableBefore), ta = await render('P20-table', 'illustration', tableAfter);
results.push({
  id: 'P20', kind: 'table', status: 'Partial supported authored illustration; automatic unequal widths remain unsupported.',
  before: tb.record, after: ta.record,
  supportedControls: ['Slide composition.minFontSize:24 raises table cell type from16px to24px.', 'StyledTableCell.style.borders removes the full grid and retains a .75px header separator.'],
  actualChanges: { beforeFontSizes: [...new Set(tb.tables.flatMap(table => table.layout.rows.flatMap(row => row.cells.map(cell => cell.fit.fontSize))))], afterFontSizes: [...new Set(ta.tables.flatMap(table => table.layout.rows.flatMap(row => row.cells.map(cell => cell.fit.fontSize))))], logicalValuesAndScalarTypesAndFormatsPreserved: true, physicalRowAndColumnCountsPreserved: true, equalColumnWidthsRetained: true },
  notExpressible: ['No table default requested font size independent of the readability floor.', 'No numeric or content-aware per-column width control in Table or DataColumn.', 'Using artificial subcolumns/colSpan as a width hack would change the physical/semantic grid, so it was not used.'],
  implementationTargets: ['opf/packages/javascript/src/composition.ts layoutTable requested size, cellWidth, and measured row heights', 'opf-render/src/svg.js renderTable uses the slide-level composition floor; a child-only table floor is not a complete painting contract', 'Coordinated table width geometry in preview and native PPTX'],
  limitation: 'The same data is more readable and less heavily ruled. Columns remain equal; this is not a content-aware-width implementation or a new default.',
  visualAssessment: 'The numbers and headers are substantially easier to inspect, with calmer ruling. The wide empty area below is unchanged, and the equal column allocations are still only a baseline.',
});

// Code: supported floor and a copied template row allocation. Do not claim natural-height panel inference.
const codeBefore = await load(path.join(baseline, 'code.opf.json'));
const codeAfter = structuredClone(codeBefore);
codeAfter.slides[0].composition = { minFontSize: 24 };
const codeLayout = codeAfter.catalogs.default.layouts.code;
codeLayout.areas.push(['.', '.']);
codeLayout.rows = ['auto', 1, 1];
assert.deepEqual(codeAfter.slides[0].blocks, codeBefore.slides[0].blocks);
const kb = await render('P21-code', 'before', codeBefore), ka = await render('P21-code', 'illustration', codeAfter);
const codeParts = result => result.geometry.items.find(item => item.codeLayout).codeLayout.parts.map(part => ({ role: part.role, fontSize: part.fit?.fontSize, lines: part.fit?.lines.length, box: part.box, overflow: part.fit?.overflow }));
results.push({
  id: 'P21', kind: 'code', status: 'Supported authored illustration; compact panel height is explicitly allocated, not automatically inferred.',
  before: kb.record, after: ka.record,
  supportedControls: ['Slide composition.minFontSize:24 raises accepted code body and language metadata to24px.', 'A copied v2 layout adds a blank grid row, allocating half of the free body height to code and notes.'],
  actualChanges: { beforeParts: codeParts(kb), afterParts: codeParts(ka), exactSourceAndLanguagePreserved: true, authoredPanelAllocation: true },
  notExpressible: ['No code-specific requested body or metadata size fields.', 'No content-sized code panel request. Template auto-row naturalHeight uses a fixed18px source-line estimate and does not fully measure wrapped source plus a raised readability floor.'],
  implementationTargets: ['opf/packages/javascript/src/composition.ts layoutCode accepted parts', 'opf/packages/javascript/src/composition.ts naturalHeight code estimate for template auto rows', 'opf-render/src/svg.js renderCode accepted panel and part boxes'],
  limitation: 'The after panel is a hand-authored layout allocation. The floor raises metadata along with source, so independent metadata/body hierarchy still needs shared design work.',
  visualAssessment: 'The source is easier to inspect and the panel has less unnecessary visual weight. Metadata is now as large as the source, exposing the coarse floor control; exact source wrapping remains visible.',
});

for (const [index, result] of results.entries()) {
  const before = [cb, tb, kb][index], after = [ca, ta, ka][index];
  assert.deepEqual(contentSignature(before.deck), contentSignature(after.deck), result.id + ': same source content');
  assert.deepEqual(before.bound.design.fonts, after.bound.design.fonts, result.id + ': same font families');
  assert.ok(Buffer.from(await readFile(path.join(directory, result.before.png))).equals(await readFile(path.join(baseline, ['chart', 'table', 'code'][index] + '.png'))), result.id + ': exact baseline pixels');
  assert.equal(after.geometry.diagnostics.length, 0, result.id + ': no core geometry errors');
  result.proof = { contentIdentical: true, sameFontHandle: true, sameFontFamilies: true, sameBackgroundAndPalette: true, baselinePngExactMatch: true, coreAndRendererGeometryEqual: true };
}

const escapeXml = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('"', '&quot;');
const sheet = async (name, rows) => {
  const width = 1920, margin = 16, gap = 16, panel = (width - margin * 2 - gap) / 2, rowHeight = 590;
  const pieces = [];
  for (const [row, result] of rows.entries()) for (const [column, state] of ['before', 'after'].entries()) {
    const x = margin + column * (panel + gap), y = row * rowHeight;
    // Use the verified individual PNG pixels so the comparison sheets retain the exact reviewed source images.
    const source = await readFile(path.join(directory, result[state].png));
    const label = `${result.id} ${result.kind}: ${state === 'before' ? 'existing output' : 'authored illustration of supported controls only'}`;
    pieces.push(`<text x="${x}" y="${y + 28}" font-family="Intos" font-size="20" font-weight="700" fill="#1f2937">${escapeXml(label)}</text>`);
    pieces.push(`<image x="${x}" y="${y + 48}" width="${panel}" height="${panel * 9 / 16}" href="data:image/png;base64,${source.toString('base64')}"/>`);
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${rows.length * rowHeight}"><rect width="100%" height="100%" fill="white"/>${pieces.join('')}</svg>`;
  await writeFile(path.join(directory, name + '.svg'), svg);
  await writeFile(path.join(directory, name + '.png'), await toPng(svg, { fonts }));
};
for (const result of results) await sheet(result.id + '-before-after', [result]);
await sheet('three-readability-comparisons', results);
await save('report.json', {
  scope: 'Only copied audit fixtures and artifacts changed. No engine, schema, catalog source, proposal queue, or viewer was edited. All outputs are explicitly partial authored illustrations; no approval is inferred.',
  command: 'node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/readability/render-probes.mjs',
  controlsInspected: { chart: Object.keys(schema.$defs.Chart.properties), table: Object.keys(schema.$defs.Table.properties), cellStyle: Object.keys(schema.$defs.TableCellStyle.properties), dataColumn: Object.keys(schema.$defs.DataColumn.properties), code: Object.keys(schema.$defs.Code.properties), composition: schema.$defs.Composition.properties },
  fonts: { pack: 'office', substitutionPolicy: 'metric', systemFonts: false, text: 'paths', sameHandleForAll: true, files: await Promise.all(fonts.fontFiles.map(async file => ({ file: path.relative(root, file), sha256: hash(await readFile(file)) }))), substitutions: fonts.substitutions },
  results,
});
console.log(JSON.stringify(results.map(result => ({ id: result.id, status: result.status, actualChanges: result.actualChanges, after: result.after.png })), null, 2));

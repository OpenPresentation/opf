import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {validate,resolveSlideContext} from '@openpresentation/opf';
import {composeSlide} from '@openpresentation/opf/composition';
import {toSvg,toPng,resolvePresentation} from '../../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../../opf-render/dist/fonts-node.js';
const here=path.dirname(fileURLToPath(import.meta.url));
const audit=path.resolve(here,'../..');
const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const fonts=await loadFonts({pack:'office'});
const sha=value=>createHash('sha256').update(value).digest('hex');
const extract=block=>block.text??(block.items?block.items.map(item=>item.text+'\n'+item.description).join('\n'):block.blocks.map(extract).join('\n'));
const reports=[];
for(const id of ['pillars','process','team']){
  const original=await read(path.join(audit,'gallery/baseline',id+'.opf.json'));
  const after=structuredClone(original);
  after.slides[0].blocks=original.slides[0].blocks.map(block=>{
    const [label,...details]=block.text.split('\n');
    const list={items:[{text:label,description:details.join('\n')}]};
    return id==='team'?{region:block.region,blocks:[list]}:{region:block.region,...list};
  });
  assert.deepEqual(after.catalogs,original.catalogs,'existing layout records unchanged');
  assert.deepEqual(after.design,original.design,'existing design unchanged');
  assert.deepEqual(after.slides[0].blocks.map(extract),original.slides[0].blocks.map(extract),'every original character and order preserved');
  const report={id,exactSourceCharactersAndOrder:true,unchangedLayoutsAndDesign:true,inlineStyleOverrides:false,
    representation:id==='team'?'Each original person becomes an accepted group containing one structured list item: name as text, existing role and responsibility as description.':'Each original label and explanation becomes a one-item structured list using text and description.',
    limitations:['Structured lists generate bullet markers by default; source words are unchanged but the visible marker is additional.'],versions:[]};
  if(id==='team')report.limitations.push('ListItem has no role field. The original role stays on its own first description line, with the same description type treatment as the responsibility. No new semantic field is invented.');
  for(const [phase,deck]of [['before',original],['after',after]]){
    const validation=validate(deck,{fonts});assert.equal(validation.valid,true,JSON.stringify(validation));
    const options={fonts,text:'paths',trace:true,strictReferences:true};
    const resolved=resolvePresentation(deck,options).slides[0];
    const context=resolveSlideContext(deck,0,{fonts,strictReferences:true});
    const geometry=composeSlide(context.slide,{...context.options,fontFamilies:resolved.design.fonts,textMeasurement:resolved.textMeasurement,explain:true});
    assert.deepEqual(geometry.diagnostics,[]);
    const svg=toSvg(deck,1,options);const bytes=await toPng(svg,{fonts});
    if(phase==='before')assert.equal(sha(bytes),sha(await fs.readFile(path.join(audit,'gallery/baseline',id+'.png'))),'before reproduces retained baseline');
    const base=path.join(here,id+'-'+phase);
    const evidence={id,phase,exactSourceCharactersAndOrder:true,sourceText:deck.slides[0].blocks.map(extract),validation,geometry,resolvedFonts:resolved.design.fonts};
    await fs.writeFile(base+'.opf.json',JSON.stringify(deck,null,2)+'\n');
    await fs.writeFile(base+'.geometry.json',JSON.stringify(evidence,null,2)+'\n');
    await fs.writeFile(base+'.svg',svg+'\n');await fs.writeFile(base+'.png',bytes);
    report.versions.push({phase,png:base+'.png',input:base+'.opf.json',geometry:base+'.geometry.json',pngSha256:sha(bytes),diagnostics:0,
      leaves:geometry.items.filter(item=>item.path.includes('.blocks.')).map(item=>({path:item.path,type:item.type,fontSize:item.text?.fontSize,lines:item.text?.lines,descriptionSizes:item.text?.listEntries?.flatMap(entry=>entry.description?.richLines?.flatMap(line=>line.fragments.map(fragment=>fragment.fontSize))??[])}))});
  }
  reports.push(report);
}
await fs.writeFile(path.join(here,'report.json'),JSON.stringify({scope:'Copied fixtures only. Same exact source characters and order, existing layouts/fonts/design. No source or engine changes.',reports},null,2)+'\n');
console.log(JSON.stringify(reports.map(({id,exactSourceCharactersAndOrder,limitations})=>({id,exactSourceCharactersAndOrder,limitations})),null,2));

# Gallery layout review diff

The changes are in the authoritative `gallery-source` audit checkout. They do not change OPF schemas, composition code, renderer code, package versions or dependency metadata.

## Resulting behavior

| File | Change and evidence |
| --- | --- |
| `catalog/layouts/closing.json` | Keep the title, subtitle and next step together in a centered content-sized group. The default support gap falls from 244.96 to 24 pixels with the same text size. A zero-height separator preserves exact title-only centering. Contact images use contain. See `closing/default-{before,after}.png` and empty/long/image stress cases. |
| `catalog/layouts/agenda-split.json` | Add an agenda beside its title for concise entries. Preserve the full-width agenda because it retains larger type for nine long entries. See `agenda/default-{before,after}.png` and short/long item-count comparisons. |
| `catalog/layouts/two-column.json` | Accept timelines in both columns and preserve whole pictures by default. The paired timeline negative control reports two unplaced warnings; the fixed record binds one timeline to each region without warnings. Reviewed image fit comparisons preserve exact content and assets. |
| `catalog/layouts/three-column.json` | Add three independent equal columns accepting all ten leaf kinds plus groups, with the same whole-picture default. This is the tested matrix candidate promoted into an actual catalog intent. |
| `catalog/layouts/index.json`, `catalog/manifest.json` | Add the two new intents in picker order and regenerate only the layout count/content hashes. Other catalog kinds are unchanged. |
| `scripts/editorial-previews.mjs`, `README.md` | Give both new intents representative titles and usage entries; agenda-split uses the same concise agenda fixture. |
| `test/records.test.mjs`, `test/column-content.test.mjs` | Maintain the ordered catalog list; exercise separate two/three-column binding of every content kind and preserve explicit cover/stretch overrides. |
| `changes/slide-layout-proximity.md` | Retain release notes and the major-version requirement without changing a package version during the audit. |

## Verification

63 current-source compatibility tests pass, including record/schema/index/hash validation, all 30 authored example validations, narrative references, all-kind column binding and resolved image-fit behavior. Catalog verification, license, static build and whitespace checks pass. The source test output is `gallery-source-tests.log`.

The four image comparisons assert exact slide and asset equality, unchanged allocation boxes and deeply equal non-image composed items. Actual authoritative definitions render pixel-identically to the reviewed candidates: `image-fit/authoritative-report.json`. Explicit block fit and higher-level theme/deck/slide design override the layout default. Title pixels are identical before and after, verified by fresh-process renderer and direct Resvg conversions: `image-fit/title-pixel-report.json`.

## Release boundary

The existing immutable gallery bootstrap cannot complete because its pinned core/renderer peer metadata conflicts with the current optional PPTX peer resolved by npm. No gate was bypassed. The catalog has 30 layouts while the qualified committed preview set has 28; regenerate the new previews and changed closing preview after the documented bootstrap issue is resolved. Full pinned-engine tests, preview equality, pixel stability and release qualification remain pending. See `gallery-gates.md` for exact dependency details. No PR or package publication is prepared while those official gates are blocked.

The intentionally cropped gallery image-grid layout is unchanged. Text, statement, FAQ and compact comparison remain prototypes or findings; they have not been silently substituted into the catalog. Larger default body typography and shared engine sizing/wrapping require the user's OPF approval and separate evidence.

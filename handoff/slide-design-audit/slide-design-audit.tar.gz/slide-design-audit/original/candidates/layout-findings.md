# Layout definition candidates

All comparisons use identical source content, pinned office font files, the source core 0.20.3 and renderer 0.20.2, no deck or slide design overrides, and the same 1280 × 720 canvas. `render-layout-candidates.mjs` saves the exact input, SVG, PNG, geometry and diagnostics for every case. It changes catalog layout definitions only.

## Implemented: closing

The original closing placed the next step at y631.90 while the subtitle ended at y386.94: 244.96 pixels separated related content. The candidate keeps the same heading position and moves the next step to y410.94, a 24-pixel gap. Type sizes and all source text are preserved.

The layout has flexible top and bottom spacer rows, content-sized title and details rows, and one zero-height empty row between title and details. That empty row prevents a missing details region from merging into the title: title-only geometry remains exactly y305.81 for the title and y383.69 for the subtitle, matching the original.

Checks include the original next step, no details, a two-line next step, a two-line title, and a contact image beside contact text. There are no validation or composition findings in these cases. The `contain` image-fit default preserves a contact code or logo in full; the former `cover` default cropped the square contact image to a wide frame. Authors retain their explicit image-fit overrides.

Evidence: `closing/default-before.png`, `closing/default-after.png`, `closing/empty-support-{before,after}.png`, `closing/long-support-{before,after}.png`, `closing/long-title-{before,after}.png`, and `closing/image-contact-{before,after}.png`.

## Implemented as an addition: agenda-split

A concise agenda gains balance when the title and introduction sit beside a vertically centered list. The existing full-width agenda stays unchanged because it is stronger for detailed entries.

Three, six and nine short agenda items preserve the 32-pixel starting size in the split candidate. Three and six longer items also preserve 32 pixels. Nine long items require 24 pixels in the split arrangement while the original full-width agenda retains 32 pixels. This is evidence for a separate `agenda-split` layout, with a description that points detailed agendas to `agenda`.

Evidence: `agenda/default-{before,after}.png`, `agenda/short-{3,6,9}-{before,after}.png`, and `agenda/long-{3,6,9}-{before,after}.png`. All source items are retained and no findings are reported. The engine's automatic list-column policy is retained; the half-width region cannot open two columns above its quarter-slide minimum width, so a long list eventually fits down in one column.

## Candidate only: statement

The same compact rows improve the original statement's title-to-support proximity and preserve exact title-only centering after the zero-height separator correction. Plain support text fits at 24 pixels rather than 25 because of the content-sized cell's tight fitting boundary. The quote case retains 28 pixels.

The supported metric case regresses: its value's nominal size falls from 76 to 46.27 pixels when the enclosing region becomes content-sized. The measured natural region demand is 165.28 pixels, but final metric sizing derives a fresh nominal value size from that shorter region. This should be investigated as shared nominal-size handling before replacing the existing statement definition. No engine or statement catalog changes have been made.

Evidence: `statement/default-{before,after}.png`, `statement/empty-support-{before,after}.png`, `statement/long-support-{before,after}.png`, `statement/long-title-{before,after}.png`, `statement/quote-support-{before,after}.png`, and `statement/metric-support-{before,after}.png`.

## Candidate only: comparison

Content-sized options followed by the verdict bring the default verdict from y631.90 to y305.48 and preserve both option columns at 25 pixels. Eight-line options also retain 25 pixels. A chart and a table remain readable, with a 302.4-pixel chart frame instead of the original 417.92-pixel frame.

However, dense options fit at 20–21 pixels in the original and 17 pixels in the candidate. The auto-row height cap is half the content box. The candidate trades useful room for proximity in a supported dense case, so it is not applied to the existing comparison definition. A robust shared content-envelope or track-sizing improvement needs explicit OPF approval before implementation.

Evidence: `comparison/default-{before,after}.png`, `comparison/long-options-{before,after}.png`, `comparison/chart-table-options-{before,after}.png`, and `comparison/dense-options-{before,after}.png`.

## Same-content text prototypes

The original text example has a top-heavy composition and body text at 25 reference pixels. This is an observation about the supplied content's rendering; adding content is not a design repair.

Three exact-content comparisons are available:

- Original: `text/default-before.png`.
- A, layout only: `text/default-after.png`. The compact heading-and-body group is centered vertically, preserving the original 25-pixel body text, wrapping, 372.27-pixel column widths, 24-pixel gutters and left alignment. Its top moves from y57.60 to y232.81.
- B, layout and typography prototype: `text/body-24pt-after.png`. The same compact layout uses supported rich runs requesting 24-point text, rendered at 32 reference pixels. Only the copied audit fixture carries this typography override. The layout keeps the same column widths, gutters and left edges; the longest paragraph uses five lines.

The harness asserts exact equality of the title, subtitle and each paragraph's extracted text. Each geometry record stores `sameSourceText: true` and the five unchanged strings. All three versions validate without diagnostics or overflow. No authoritative text definition or OPF typography default has been changed.

## Candidate only: FAQ

The existing FAQ's three short question-and-answer pairs occupy equal-height vertical slots with large visible gaps. A one-key `questions.flow: auto` candidate places those three independent pairs in aligned columns at the same 25-pixel size. Six short pairs retain 25 pixels instead of the original 24. Three longer pairs automatically retain the original vertical flow and 25 pixels; six long pairs retain the original overflow failure rather than hiding it. Nine pairs are explicitly beyond the unchanged region maximum of six, so they are a diagnostic stress case, not a passing use case.

Evidence: `faq/default-{before,after}.png`, `faq/short-{3,6,9}-{before,after}.png`, and `faq/long-{3,6,9}-{before,after}.png`. This candidate has not been applied to the authoritative definition.

## Release boundary

The `two-column` record also now accepts `timeline` in each body region. The previous definition omitted that kind despite promising two independent columns of any content. A paired-timeline negative control is retained at `../columns/two-column-timeline-negative.opf.json`; it places both timelines below the named columns and reports two `layout-unplaced` diagnostics. The regression test now exercises all ten leaf kinds plus a group, requiring two separate column bindings with no warning or implicit-row content. No OPF change is needed for this correction.

The authoritative edits are confined to the gallery checkout. Its closing drawing change requires a major gallery version under the current stability policy; the new agenda layout alone requires a minor version. Package versions are unchanged during the audit. The release notes are retained as `gallery-source/changes/slide-layout-proximity.md`; incorporate them during release preparation. Nothing has been published, and no OPF schema, engine or renderer code has been changed.

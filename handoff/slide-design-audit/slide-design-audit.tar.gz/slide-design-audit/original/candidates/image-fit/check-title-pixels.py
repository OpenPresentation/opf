import json, pathlib, struct, zlib, hashlib

root=pathlib.Path(__file__).parent

def png_pixels(file):
    raw=file.read_bytes()
    assert raw[:8]==b'\x89PNG\r\n\x1a\n'
    pos=8; data=b''
    while pos<len(raw):
        size=struct.unpack('>I',raw[pos:pos+4])[0]; kind=raw[pos+4:pos+8]; chunk=raw[pos+8:pos+8+size];pos+=size+12
        if kind==b'IHDR': width,height,depth,color,_,_,interlace=struct.unpack('>IIBBBBB',chunk)
        if kind==b'IDAT': data+=chunk
    assert (depth,color,interlace)==(8,6,0),(depth,color,interlace)
    decoded=zlib.decompress(data); stride=width*4; rows=[]; prev=bytes(stride); p=0
    for _ in range(height):
        mode=decoded[p];p+=1; row=bytearray(decoded[p:p+stride]);p+=stride
        for x in range(stride):
            a=row[x-4] if x>=4 else 0; b=prev[x]; c=prev[x-4] if x>=4 else 0
            if mode==1: value=a
            elif mode==2: value=b
            elif mode==3: value=(a+b)//2
            elif mode==4:
                v=a+b-c; ds=[abs(v-a),abs(v-b),abs(v-c)]; value=[a,b,c][ds.index(min(ds))]
            else: assert mode==0;value=0
            row[x]=(row[x]+value)%256
        rows.append(bytes(row));prev=row
    return width,height,rows

reports=[]
for ident in ['homogeneous-image-2col','homogeneous-image-3col','mixed-image-text','mixed-video-image-text']:
    title=json.loads((root/f'{ident}-after.geometry.json').read_text())['geometry']['items'][0]['box']
    y0=max(0,int(title['y'])-3);y1=int(title['y']+title['height'])+4
    samples={}
    for phase in ['before','after','after.fresh','after.direct']:
        file=root/f'{ident}-{phase}.png'
        width,height,rows=png_pixels(file)
        roi=b''.join(rows[y0:y1]); white=sum(roi[x]>220 and roi[x+1]>220 and roi[x+2]>220 and roi[x+3]>220 for x in range(0,len(roi),4))
        samples[phase]={'pngSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'titlePixelsSha256':hashlib.sha256(roi).hexdigest(),'whiteTitlePixels':white}
        assert white>1000,(ident,phase,white)
    assert len({v['titlePixelsSha256']for v in samples.values()})==1,(ident,samples)
    reports.append({'id':ident,'titleRows':[y0,y1],'allTitlePixelsExactlyEqual':True,'samples':samples})
(root/'title-pixel-report.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))

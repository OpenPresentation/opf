# Whole-picture defaults in generic columns

This candidate changes only each copied layout's `design.imageFit` from omitted (`cover`) to `contain`. The content, asset registry, column dimensions, gutters, headings and text remain identical. The harness asserts exact equality of slides and assets and of every allocation box; all non-image composed items, including text and the video placeholder, are deeply equal before and after.

The four controlled comparisons are:

- `homogeneous-image-2col-{before,after}.png` — two landscape images.
- `homogeneous-image-3col-{before,after}.png` — three landscape images.
- `mixed-image-text-{before,after}.png` — a landscape beside its explanation.
- `mixed-video-image-text-{before,after}.png` — a video placeholder, landscape and explanation.

All eight renders validate without geometry diagnostics. Fonts are the pinned office pack; output uses source core 0.20.3 and renderer 0.20.2. Each comparison retains the exact OPF JSON, SVG, PNG and measured geometry.

The full landscape is visible with `contain`. With `cover`, the same image is cropped into the column's tall frame, especially in three columns. Keeping the full picture is a safer generic default for diagrams, screenshots and evidence where content at the edges can matter. It trades filling the entire column for preserving the source. The picture remains vertically centered inside the unchanged allocation; the candidate does not repair large empty areas or change the tall video placeholder.

Actual precedence was checked in the composed image geometry for seven cases. A layout `contain` default applies when nothing higher sets fit. A block's explicit `cover` or `stretch` wins. Theme, deck and slide `design.imageFit` overrides also win over the layout default; an explicit block `cover` wins over slide `stretch`. The override belongs beside `image` on the content block, for example `{ "image": "asset:landscape", "fit": "cover" }`. It is not asset metadata.

After primary visual review and the raster verification below, the contain default has been applied to the authoritative two-column record and the new three-column catalog record. `candidate-records.json` retains the reviewed copied definitions. The separate timeline-acceptance correction in the authoritative two-column record is retained. `authoritative-report.json` verifies that the actual catalog definitions render the same pixels as these reviewed candidates while preserving all content and assets.

## Title raster verification

A report that the three-column candidate's title appeared missing prompted independent pixel checks. The current four after PNGs all show their titles on direct visual inspection. In every comparison the entire title-row pixel region is byte-for-byte identical before and after. The three-column title region, rows 54–126, contains 8,155 near-white pixels in both files.

Each after SVG was also rasterized in a fresh Node process using the renderer's `toPng`, and independently using direct `Resvg`. Both new PNG files are byte-for-byte identical to the corresponding existing after PNG. These independent outputs use `.fresh.png` and `.direct.png` suffixes. `title-pixel-report.json` records PNG hashes, title-region hashes and visible-title pixel counts. This does not reproduce a renderer or raster failure in the retained bytes; retain any differing missing-title file for investigation before attributing the observation to an engine bug.

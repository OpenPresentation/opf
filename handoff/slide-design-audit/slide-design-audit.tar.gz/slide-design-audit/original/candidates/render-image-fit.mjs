import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {validate,resolveSlideContext} from '@openpresentation/opf';
import {composeSlide} from '@openpresentation/opf/composition';
import {toSvg,toPng,resolvePresentation} from '../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../opf-render/dist/fonts-node.js';

const here=path.dirname(fileURLToPath(import.meta.url));
const source=path.join(here,'../columns');
const output=path.join(here,'image-fit');
await fs.mkdir(output,{recursive:true});
const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const fonts=await loadFonts({pack:'office'});
const ids=['homogeneous-image-2col','homogeneous-image-3col','mixed-image-text','mixed-video-image-text'];
const records={};
const reports=[];
const geometryById=new Map();
const recordOf=deck=>deck.catalogs.default?.layouts['two-column']??deck.catalogs.custom.layouts['three-column-candidate'];
const resolve=deck=>{
  const options={fonts,text:'paths',strictReferences:true,trace:true};
  const validation=validate(deck,{fonts});
  assert.equal(validation.valid,true,JSON.stringify(validation));
  const resolved=resolvePresentation(deck,options).slides[0];
  const context=resolveSlideContext(deck,0,{fonts,strictReferences:true});
  const geometry=composeSlide(context.slide,{...context.options,fontFamilies:resolved.design.fonts,textMeasurement:resolved.textMeasurement,explain:true});
  return {options,validation,geometry};
};
for(const id of ids){
  const original=await read(path.join(source,`${id}.opf.json`));
  const after=structuredClone(original);
  const record=recordOf(after);
  record.design={...record.design,imageFit:'contain'};
  assert.deepEqual(after.slides,original.slides,'layout-only comparison preserves exact slides');
  assert.deepEqual(after.assets,original.assets,'layout-only comparison preserves exact assets');
  records[original.slides[0].layout]=record;
  for(const [phase,deck]of [['before',original],['after',after]]){
    const {options,validation,geometry}=resolve(deck);
    if(phase==='before')geometryById.set(id,geometry);
    else {
      const before=geometryById.get(id);
      assert.deepEqual(geometry.items.map(item=>({path:item.path,box:item.box})),before.items.map(item=>({path:item.path,box:item.box})),'allocation geometry is unchanged');
      assert.deepEqual(geometry.items.filter(item=>item.type!=='image'),before.items.filter(item=>item.type!=='image'),'non-image content and geometry are unchanged');
    }
    const svg=toSvg(deck,1,options);
    const png=await toPng(svg,{fonts});
    const base=path.join(output,`${id}-${phase}`);
    const images=geometry.items.filter(item=>item.type==='image').map(item=>({path:item.path,box:item.box,image:item.image}));
    assert.ok(images.every(item=>item.image.fit===(phase==='after'?'contain':'cover')));
    const report={id,phase,exactSlidesEqual:true,exactAssetsEqual:true,images,diagnostics:geometry.diagnostics};
    await fs.writeFile(`${base}.opf.json`,JSON.stringify(deck,null,2)+'\n');
    await fs.writeFile(`${base}.geometry.json`,JSON.stringify({report,geometry,validation},null,2)+'\n');
    await fs.writeFile(`${base}.svg`,svg+'\n');
    await fs.writeFile(`${base}.png`,png);
    reports.push(report);
  }
}
// Verify precedence with the real composition result; styling cases keep the image source unchanged.
const controlled=await read(path.join(output,'homogeneous-image-2col-after.opf.json'));
const precedence=[];
for(const [name,edit,expected]of [
  ['layout default',()=>{},'contain'],
  ['block cover',deck=>{deck.slides[0].blocks[0].fit='cover';},'cover'],
  ['block stretch',deck=>{deck.slides[0].blocks[0].fit='stretch';},'stretch'],
  ['theme cover',deck=>{deck.design={theme:'test-theme'};deck.catalogs.default.themes={'test-theme':{name:'Test theme',design:{imageFit:'cover'}}};},'cover'],
  ['deck cover',deck=>{deck.design={imageFit:'cover'};},'cover'],
  ['slide cover',deck=>{deck.slides[0].design={imageFit:'cover'};},'cover'],
  ['block above slide',deck=>{deck.slides[0].design={imageFit:'stretch'};deck.slides[0].blocks[0].fit='cover';},'cover'],
]){
  const deck=structuredClone(controlled);edit(deck);
  const {geometry}=resolve(deck);
  const image=geometry.items.find(item=>item.type==='image');
  assert.equal(image.image.fit,expected,name);
  precedence.push({name,expected,actual:image.image.fit});
}
await fs.writeFile(path.join(output,'report.json'),JSON.stringify({scope:'Layout-only imageFit contain candidate; exact slides and assets preserved',reports,precedence},null,2)+'\n');
await fs.writeFile(path.join(output,'candidate-records.json'),JSON.stringify(records,null,2)+'\n');
console.log(JSON.stringify({output,cases:reports.length,precedence},null,2));

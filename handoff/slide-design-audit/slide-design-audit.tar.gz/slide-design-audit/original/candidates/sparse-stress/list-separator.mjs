// A candidate-only refinement: preserve empty-body centering. No source catalog edits.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {validate} from '@openpresentation/opf';
import {resolvePresentation,toSvg,toPng} from '../../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../../opf-render/dist/fonts-node.js';
const root=path.dirname(fileURLToPath(import.meta.url)),fonts=await loadFonts({pack:'office'}),cases=[];
for(const name of ['original','title-only','twelve-detailed-items']){
 const doc=JSON.parse(await fs.readFile(path.join(root,`list-${name}-after.opf.json`),'utf8'));
 const record=doc.catalogs.custom.layouts.list;
 record.areas=[['.'],['title'],['.'],['body'],['.']];record.rows=[1,'auto','auto','auto',1];
 fonts.registry.clearSubstitutions();const validation=validate(doc,{fonts});assert.equal(validation.valid,true);
 const diagnostics=[],options={fonts,text:'paths',strictReferences:true,trace:true,onDiagnostic:x=>diagnostics.push(x)};
 const resolved=resolvePresentation(doc,options).slides[0],svg=toSvg(doc,1,options),png=Buffer.from(await toPng(svg,{fonts}));
 const stem=`list-separator-${name}-after`;
 await fs.writeFile(path.join(root,stem+'.opf.json'),JSON.stringify(doc,null,2)+'\n');await fs.writeFile(path.join(root,stem+'.svg'),svg+'\n');await fs.writeFile(path.join(root,stem+'.png'),png);
 await fs.writeFile(path.join(root,stem+'.geometry.json'),JSON.stringify({geometry:resolved.geometry,validation,diagnostics},null,2)+'\n');
 const before=JSON.parse(await fs.readFile(path.join(root,`list-${name}-before.opf.json`),'utf8'));
 assert.deepEqual(doc.slides,before.slides);
 const expected=await fs.readFile(path.join(root,`list-${name}-${name==='title-only'?'before':'after'}.png`));
 const reproduces=png.equals(expected);assert.equal(reproduces,true,'The separator should correct only the empty-body case');
 cases.push({name,after:stem+'.png',sameSource:true,reproducesPixels:reproduces,equivalentTo:`list-${name}-${name==='title-only'?'before':'after'}.png`,items:resolved.geometry.items.map(i=>({field:i.field,box:i.box,fontSize:i.text?.fontSize})),diagnostics});
}
await fs.writeFile(path.join(root,'list-separator-report.json'),JSON.stringify({scope:'Candidate only; a zero-height separator preserves original title-only centering and exact four-track-prototype pixels when content exists. Dense type regression remains unresolved.',cases},null,2)+'\n');
console.log(JSON.stringify(cases.map(({name,reproducesPixels,items})=>({name,reproducesPixels,items})),null,2));

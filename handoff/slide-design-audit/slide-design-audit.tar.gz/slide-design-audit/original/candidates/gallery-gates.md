# Gallery gate status

Layout edits: closing definition; agenda-split and three-column additions; timeline support and whole-picture contain default in two-column regions; layout index/manifest rehash; editorial fixtures, README entries and record-order test maintenance. Package versions and dependency metadata are unchanged.

Passed:

- Catalog rehash and offline manifest verification.
- License check.
- Gallery static build.
- 63 record, authored-preview validation, narrative-reference and column binding/fit tests with the current source core 0.20.3 loader. The binding tests exercise both two and three blocks of all ten leaf kinds and a content group, requiring separate regions with no overflow or diagnostic. Composed image tests exercise the contain default and explicit cover/stretch overrides. Output: `gallery-source-tests.log`. This is source compatibility evidence, not the official pinned-engine gate.
- Every default/stress comparison documented in `layout-findings.md`, with exact input, measured office fonts, SVG, PNG and geometry retained.

Official pinned-engine bootstrap did not complete. The first GitHub HTTP/2 clone failed; retrying with HTTP/1.1 successfully fetched both actual default branches, verified both immutable pins are merged ancestors, checked out those pins and built the pinned core. The next dependency-install step failed with `ERESOLVE`:

Pinned core `0.19.0` declares optional renderer peer `^0.19.1` and PPTX peer `^0.20.0`. npm resolves current PPTX `0.20.3`, which in turn requires renderer `^0.20.2`, conflicting with the pinned renderer `0.19.1`. No legacy-peer-deps, force flags, ancestry bypass or dependency metadata changes were used.

Consequences:

- Official package preview regeneration, full package tests, bootstrap verification and pixel-stability release qualification remain pending the existing bootstrap dependency issue.
- The ordinary registry dev pins still use the old string-row layout schema. The sync suite therefore rejects array-row records at `/areas/0 must be string`; this is the expected unbootstrapped schema mismatch, not a failure specific to the edited layouts.
- The catalog now has 30 layouts; the committed package preview set still has 28 previews. Generate the new agenda-split/three-column previews and updated closing preview with the qualified pinned engines before creating a release-ready PR. Do not publish this audit checkout as it stands.

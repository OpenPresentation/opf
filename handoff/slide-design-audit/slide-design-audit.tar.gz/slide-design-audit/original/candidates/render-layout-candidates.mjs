import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {validate, resolveSlideContext} from '@openpresentation/opf';
import {composeSlide} from '@openpresentation/opf/composition';
import {toSvg, toPng, resolvePresentation} from '../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../opf-render/dist/fonts-node.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const here = path.dirname(fileURLToPath(import.meta.url));
const read = async file => JSON.parse(await fs.readFile(file, 'utf8'));
const fonts = await loadFonts({pack:'office'});
const fixtureSource = await read(path.join(root, '../pptx-gallery/data/layout-examples.json'));
const ids = process.argv.slice(2);
const reports = [];

const agendaItems = [
  'Define the problem', 'Review the pilot evidence', 'Agree the next decision',
  'Assess the delivery risks', 'Confirm the operating model', 'Set the funding priorities',
  'Assign accountable owners', 'Agree the rollout milestones', 'Decide how to measure progress',
];
const longAgendaItems = [
  'Define the customer problem and the evidence that makes it worth solving',
  'Review the pilot results across adoption, service quality and operating cost',
  'Agree the next decision and the conditions required to move forward',
  'Assess delivery risks and the actions that reduce our exposure',
  'Confirm the operating model and its implications for the existing teams',
  'Set funding priorities against the benefits and dependencies of each option',
  'Assign accountable owners for the decisions and the work that follows',
  'Agree rollout milestones and the checkpoints that determine readiness',
  'Decide how to measure progress and when to revisit the plan',
];

for (const id of ids) {
  const original = structuredClone(fixtureSource.examples.find(value=>value.id===id).document);
  delete original.design;
  original.slides.forEach(slide=>delete slide.design);
  const baselineRecord = structuredClone(original.catalogs.default.layouts[id]);
  const candidateFile = await read(path.join(here, 'records', `${id}.json`));
  const {$schema, id:recordId, ...candidateRecord} = candidateFile;
  const cases = [{name:'default', edit:()=>{}}];
  if (id === 'text') {
    cases.push({name:'body-24pt',edit:slide=>{slide.blocks=slide.blocks.map(block=>({...block,text:[{text:block.text,fontSize:24}]}));}});
  } else if (id === 'agenda') {
    for (const count of [3,6,9]) {
      cases.push({name:`short-${count}`,edit:slide=>{slide.blocks=[{region:'items',items:agendaItems.slice(0,count)}];}});
      cases.push({name:`long-${count}`,edit:slide=>{slide.blocks=[{region:'items',items:longAgendaItems.slice(0,count)}];}});
    }
  } else if (id === 'faq') {
    for (const count of [3,6,9]) {
      cases.push({name:`short-${count}`,edit:slide=>{slide.blocks=Array.from({length:count},(_,index)=>({region:'questions',text:[
        'Who takes part?\nTwo field teams, with 52 participants in total.',
        'How long does it run?\nSix weeks, including a baseline measurement.',
        'What happens next?\nReview completion and task time before expanding.',
      ][index%3]}));}});
      cases.push({name:`long-${count}`,edit:slide=>{slide.blocks=Array.from({length:count},(_,index)=>({region:'questions',text:[
        'Who takes part in the pilot and how will they be supported?\nTwo field teams will test the new workflow in their normal operating environment. Their managers will receive a short guide, and the support team will review questions every week so that issues are resolved before they affect the next cohort.',
        'How long does the pilot run and what happens at each checkpoint?\nThe six-week pilot begins with a baseline measurement, continues with four weeks of live use and weekly feedback, and finishes with a review of completion, task time and support demand. The steering group will decide whether each readiness condition has been met.',
        'What will determine the next investment decision?\nWe will compare the outcomes with the baseline, check the confidence and completeness of the evidence, and confirm that the support and training model can scale. Any unresolved dependency will have an accountable owner and an explicit review date before more teams are added.',
      ][index%3]}));}});
    }
  } else if (id === 'comparison') {
    cases.push({name:'long-options',edit:slide=>{slide.blocks=[
      {region:'first',text:'Option A: launch broadly\nReach all regions in the first quarter. This delivers value sooner but requires every regional team to complete training at once, resolve local dependencies before launch, and share the same support capacity during the busiest period. The total investment is higher and the results will be harder to attribute to individual interventions.'},
      {region:'second',text:'Option B: stage the rollout\nBegin with two regions and expand when each readiness checkpoint passes. This creates time to improve training and support using actual feedback. The benefits arrive later, but each stage can be funded and evaluated separately. Teams retain capacity to resolve issues before the next cohort starts.'},
      {region:'verdict',text:'Recommendation: stage the rollout and use each checkpoint to decide the next investment.'},
    ];}});
    cases.push({name:'chart-table-options',edit:slide=>{
      const chart = structuredClone(fixtureSource.examples.find(value=>value.id==='chart').document.slides[0].blocks.find(block=>block.chart));
      const table = structuredClone(fixtureSource.examples.find(value=>value.id==='table').document.slides[0].blocks.find(block=>block.table));
      slide.blocks=[{...chart,region:'first'},{...table,region:'second'},{region:'verdict',text:'Compare the trend with the operating assumptions before choosing the next investment.'}];
    }});
    cases.push({name:'dense-options',edit:slide=>{
      slide.blocks=slide.blocks.map(block=>block.region==='verdict'?block:{...block,text: `${block.text}\n\n`+('Each team must complete training, collect baseline evidence, assign an accountable owner and confirm support capacity before this option can proceed. ').repeat(5)});
    }});
  } else {
    cases.push({name:'empty-support',edit:slide=>{delete slide.blocks;}});
    cases.push({name:'long-support',edit:slide=>{slide.blocks=[{text:'Start with one pilot team, measure the impact for six weeks, and use the evidence to decide which workflows to extend. We will agree an accountable owner and a review date before the meeting ends.'}];}});
    cases.push({name:'long-title',edit:slide=>{slide.title='Start with a focused pilot so that each team can learn quickly and turn the evidence into a better decision';}});
    if (id === 'statement') {
      cases.push({name:'metric-support',edit:slide=>{slide.blocks=[{region:'message',metric:{value:'84%',label:'Task completion',description:'Up from 68% at baseline'}}];}});
      cases.push({name:'quote-support',edit:slide=>{slide.blocks=[{region:'message',quote:{text:'We can now see where participants need help.',attribution:'Pilot lead',source:'Illustrative quotation'}}];}});
    }
    if (id === 'closing') {
      const qr = '<svg xmlns="http://www.w3.org/2000/svg" width="144" height="144" viewBox="0 0 144 144"><rect width="144" height="144" fill="white"/><path d="M12 12h42v42H12zM90 12h42v42H90zM12 90h42v42H12zM66 12h12v12H66zM66 36h12v42H66zM90 66h42v12H90zM90 90h12v42H90zM114 90h18v18h-18zM114 120h18v12h-18zM66 90h12v18H66zM66 120h12v12H66z" fill="#001a40"/></svg>';
      cases.push({name:'image-contact',edit:slide=>{slide.blocks=[{region:'details',image:{src:'data:image/svg+xml;base64,'+Buffer.from(qr).toString('base64'),alt:'Illustrative contact code'}},{region:'details',text:'Continue the conversation\nhello@example.org\nexample.org/pilot'}];}});
    }
  }
  const output = path.join(here, id);
  await fs.mkdir(output,{recursive:true});
  for (const scenario of cases) {
    for (const [version,record] of [['before',baselineRecord],['after',candidateRecord]]) {
      const document = structuredClone(original);
      document.catalogs.default.layouts[id] = record;
      scenario.edit(document.slides[0]);
      const validation = validate(document,{fonts});
      if (!validation.valid) throw new Error(`${id}/${scenario.name}/${version}: ${JSON.stringify(validation.findings)}`);
      const diagnostics = [];
      const options = {fonts,text:'paths',strictReferences:true,trace:true,onDiagnostic:issue=>diagnostics.push(issue)};
      const resolved = resolvePresentation(document,options).slides[0];
      const context = resolveSlideContext(document,0,{fonts,strictReferences:true});
      const geometry = composeSlide(context.slide,{...context.options,fontFamilies:resolved.design.fonts,textMeasurement:resolved.textMeasurement,explain:true});
      const svg = toSvg(document,1,options);
      const png = await toPng(svg,{fonts});
      const base = path.join(output,`${scenario.name}-${version}`);
      await fs.writeFile(`${base}.opf.json`,JSON.stringify(document,null,2)+'\n');
      await fs.writeFile(`${base}.svg`,svg+'\n');
      await fs.writeFile(`${base}.png`,png);
      const evidence = {id,scenario:scenario.name,version,geometry,diagnostics,validation,resolvedDesign:resolved.design};
      if (id === 'text') {
        const annotation = value => typeof value === 'string' ? value : value.map(run=>run.text).join('');
        const extracted = slide => [annotation(slide.title), annotation(slide.subtitle), ...slide.blocks.map(block=>annotation(block.text))];
        const baselineText = extracted(original.slides[0]);
        const renderedText = extracted(document.slides[0]);
        if (JSON.stringify(baselineText)!==JSON.stringify(renderedText)) throw new Error('Text candidate changed source words');
        evidence.extractedText = renderedText;
        evidence.sameSourceText = true;
      }
      await fs.writeFile(`${base}.geometry.json`,JSON.stringify(evidence,null,2)+'\n');
      reports.push({id,scenario:scenario.name,version,png:`${base}.png`,diagnostics,
        items:geometry.items.map(item=>({path:item.path,type:item.type,box:item.box,fontSize:item.text?.fontSize,lines:item.text?.lines,listColumns:item.listColumns?.length,overflow:item.text?.overflow})),
      });
    }
  }
}
for (const id of ids) await fs.writeFile(path.join(here,`${id}-report.json`),JSON.stringify(reports.filter(report=>report.id===id),null,2)+'\n');
console.log(JSON.stringify(reports,null,2));

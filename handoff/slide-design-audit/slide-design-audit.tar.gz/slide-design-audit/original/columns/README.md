# Equal-column content matrix

22 homogeneous tests (two and three columns for10 leaf kinds plus group),10 mixed tests, and exact timeline acceptance negative/fixed controls. No engine, schema, or default changes.

Two columns use the corrected actual gallery record, with timeline acceptance added by layout tuning. Three columns use one embedded structural candidate declaring every schema kind; neither carries optional visual styling. All words, data, assets, measured fonts, exact geometry and findings accompany the previews.

Video is tested as the supported titled play placeholder. The schema has no poster field, and no playback is implied.

Some validation reports retain a font-policy layout warning: the validator requests intermediate Aptos weights directly, while the renderer first resolves the selected roles to loaded Intos families. Rendering succeeds with the same pinned handle. The warnings are preserved and require a separate shared-context investigation; they are not a claim that those layouts passed every validation check.

[Machine-readable manifest](manifest.json) · [Three-up sheet index](contact-sheets.json)

| No. | Case | Contents | Findings |
| --- | --- | --- | --- |
| 1 | [homogeneous-text-2col](homogeneous-text-2col.png) | text, text | 0 geometry; 0 validation warnings |
| 2 | [homogeneous-text-3col](homogeneous-text-3col.png) | text, text, text | 0 geometry; 0 validation warnings |
| 3 | [homogeneous-list-2col](homogeneous-list-2col.png) | list, list | 0 geometry; 0 validation warnings |
| 4 | [homogeneous-list-3col](homogeneous-list-3col.png) | list, list, list | 0 geometry; 0 validation warnings |
| 5 | [homogeneous-image-2col](homogeneous-image-2col.png) | image, image | 0 geometry; 0 validation warnings |
| 6 | [homogeneous-image-3col](homogeneous-image-3col.png) | image, image, image | 0 geometry; 0 validation warnings |
| 7 | [homogeneous-chart-2col](homogeneous-chart-2col.png) | chart, chart | 0 geometry; 0 validation warnings |
| 8 | [homogeneous-chart-3col](homogeneous-chart-3col.png) | chart, chart, chart | 0 geometry; 0 validation warnings |
| 9 | [homogeneous-table-2col](homogeneous-table-2col.png) | table, table | 0 geometry; 0 validation warnings |
| 10 | [homogeneous-table-3col](homogeneous-table-3col.png) | table, table, table | 0 geometry; 0 validation warnings |
| 11 | [homogeneous-video-2col](homogeneous-video-2col.png) | video, video | 0 geometry; 0 validation warnings |
| 12 | [homogeneous-video-3col](homogeneous-video-3col.png) | video, video, video | 0 geometry; 0 validation warnings |
| 13 | [homogeneous-code-2col](homogeneous-code-2col.png) | code, code | 0 geometry; 0 validation warnings |
| 14 | [homogeneous-code-3col](homogeneous-code-3col.png) | code, code, code | 0 geometry; 0 validation warnings |
| 15 | [homogeneous-metric-2col](homogeneous-metric-2col.png) | metric, metric | 0 geometry; 1 validation warnings |
| 16 | [homogeneous-metric-3col](homogeneous-metric-3col.png) | metric, metric, metric | 0 geometry; 1 validation warnings |
| 17 | [homogeneous-quote-2col](homogeneous-quote-2col.png) | quote, quote | 0 geometry; 1 validation warnings |
| 18 | [homogeneous-quote-3col](homogeneous-quote-3col.png) | quote, quote, quote | 0 geometry; 1 validation warnings |
| 19 | [homogeneous-timeline-2col](homogeneous-timeline-2col.png) | timeline, timeline | 0 geometry; 1 validation warnings |
| 20 | [homogeneous-timeline-3col](homogeneous-timeline-3col.png) | timeline, timeline, timeline | 0 geometry; 1 validation warnings |
| 21 | [homogeneous-group-2col](homogeneous-group-2col.png) | group, group | 0 geometry; 0 validation warnings |
| 22 | [homogeneous-group-3col](homogeneous-group-3col.png) | group, group, group | 0 geometry; 1 validation warnings |
| 23 | [mixed-chart-text](mixed-chart-text.png) | chart, text | 0 geometry; 0 validation warnings |
| 24 | [mixed-table-text](mixed-table-text.png) | table, text | 0 geometry; 0 validation warnings |
| 25 | [mixed-image-text](mixed-image-text.png) | image, text | 0 geometry; 0 validation warnings |
| 26 | [mixed-code-text](mixed-code-text.png) | code, text | 0 geometry; 0 validation warnings |
| 27 | [mixed-quote-metric-text](mixed-quote-metric-text.png) | quote, metric, text | 0 geometry; 1 validation warnings |
| 28 | [mixed-timeline-list-metric](mixed-timeline-list-metric.png) | timeline, list, metric | 0 geometry; 1 validation warnings |
| 29 | [mixed-group-chart-table](mixed-group-chart-table.png) | group, chart, table | 0 geometry; 0 validation warnings |
| 30 | [mixed-text-bullets-list](mixed-text-bullets-list.png) | text, text, list | 0 geometry; 0 validation warnings |
| 31 | [mixed-timeline-image](mixed-timeline-image.png) | timeline, image | 0 geometry; 1 validation warnings |
| 32 | [mixed-video-image-text](mixed-video-image-text.png) | video, image, text | 0 geometry; 0 validation warnings |

The timeline [negative control](two-column-timeline-negative.png) and [fixed control](two-column-timeline-fixed.png) retain identical content. Only their embedded two-column acceptance record differs.

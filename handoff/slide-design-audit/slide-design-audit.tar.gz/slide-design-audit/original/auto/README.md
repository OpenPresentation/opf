# Automatic composition audit

Twenty minimally styled examples, to be reviewed in batches of three after the gallery layouts. Every slide omits layout, composition, and design overrides. Only content and meaningful groups are authored.

The exact inputs, SVG, PNG, core geometry, validation report, font hashes, default design, and local source revisions are retained. See [index.json](index.json). The engine and catalog defaults are unchanged.

| No. | Example | Intended probe |
| --- | --- | --- |
| 1 | [Remove the handoff that slows every review](01-single-takeaway.png) | One short message; sparse-slide balance and body scale. |
| 2 | [Improve speed and preserve accountability](02-two-equal-ideas.png) | Two comparable observations with similar text lengths. |
| 3 | [Three habits make the process dependable](03-three-pillars.png) | Three short parallel ideas; compare row versus stacked choice. |
| 4 | [The exception path needs the explanation](04-uneven-comparison.png) | Two related arguments with very unequal space needs. |
| 5 | [Four workstreams support the launch](05-four-workstreams.png) | Four equal blocks; density and vertical rhythm. |
| 6 | [Focus the next month on five priorities](06-five-priorities.png) | Odd item count; incomplete final row and balance. |
| 7 | [Operating performance improved across the funnel](07-six-operating-metrics.png) | Six metrics; shared value and label alignment. |
| 8 | [Make the pilot ready for Monday](08-seven-actions.png) | Seven short blocks; leftover placement and reading order. |
| 9 | [Use the same checkpoints for every review](09-nine-checkpoints.png) | Nine concise blocks; small-cell thresholds and scan order. |
| 10 | [Review time fell as handoffs were removed](10-chart-and-takeaway.png) | One chart and one short interpretation; evidence versus commentary proportions. |
| 11 | [Expand the pilot after the remaining blockers close](11-table-and-decision.png) | A readable analytical table beside a concise decision. |
| 12 | [Keep field context visible during planning](12-image-and-explanation.png) | Illustrative landscape image with contextual copy; fit and empty space. |
| 13 | [Review visual evidence as a pair](13-image-pair-and-note.png) | Two matching image allocations and one short note; three mixed blocks. |
| 14 | [A visible owner changes the customer experience](14-quote-and-implication.png) | Quote, attribution, and a short interpretation. |
| 15 | [Expand in stages while closing the access risks](15-timeline-and-risks.png) | Timeline and related risks; timeline internal label fit. |
| 16 | [Make the escalation rule explicit](16-code-and-explanation.png) | A short code example and supporting explanation. |
| 17 | [Keep each owner close to their responsibilities](17-two-nested-groups.png) | Related heading and list pairs expressed only by nesting. |
| 18 | [Choose the rollout pace that support can sustain](18-three-nested-comparisons.png) | Three nested comparisons; title, metric, and supporting sentence proximity. |
| 19 | [The next rollout should preserve clear ownership while giving support time to resolve the remaining access dependencies](19-long-heading-and-list.png) | Long but ordinary title and subtitle; pressure on heading and body space. |
| 20 | [Expand the pilot with a clear support gate](20-mixed-business-review.png) | Chart, metric, list, and concise recommendation; mixed-content hierarchy. |

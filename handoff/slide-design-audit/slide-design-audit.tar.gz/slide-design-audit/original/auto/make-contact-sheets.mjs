// Keep every source slide unchanged; labels live outside the slide pixels.
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadFonts } from '../../../../opf-render/dist/fonts-node.js';
import { toPng } from '../../../../opf-render/dist/index.js';
const directory = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(await readFile(path.join(directory, 'index.json'), 'utf8'));
const fonts = await loadFonts({ pack: 'office' });
const width = 1920, height = 420, margin = 16, gap = 16, panel = (width - margin * 2 - gap * 2) / 3;
const escape = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('"', '&quot;');
const batches = [];
for (let offset = 0; offset < manifest.cases.length; offset += 3) {
  const entries = manifest.cases.slice(offset, offset + 3), number = Math.floor(offset / 3) + 1;
  const pieces = [];
  for (const [index, entry] of entries.entries()) {
    const svg = await readFile(path.join(directory, entry.files.svg));
    const x = margin + index * (panel + gap);
    pieces.push(`<text x="${x}" y="29" font-family="Intos" font-size="20" font-weight="700" fill="#1f2937">${escape(entry.id.replaceAll('-', ' '))}</text>`);
    pieces.push(`<image x="${x}" y="48" width="${panel}" height="${panel * 9 / 16}" href="data:image/svg+xml;base64,${svg.toString('base64')}"/>`);
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><rect width="100%" height="100%" fill="white"/>${pieces.join('')}</svg>`;
  const name = `batch-${String(number).padStart(2, '0')}`;
  await writeFile(path.join(directory, name + '.svg'), svg);
  await writeFile(path.join(directory, name + '.png'), await toPng(svg, { fonts }));
  batches.push({ number, ids: entries.map(entry => entry.id), png: path.join(directory, name + '.png'), svg: path.join(directory, name + '.svg'), slides: entries.map(entry => ({ id: entry.id, ...Object.fromEntries(Object.entries(entry.files).map(([key, value]) => [key === 'input' ? 'opf' : key, path.join(directory, value)])) })) });
}
await writeFile(path.join(directory, 'contact-sheets.json'), JSON.stringify({ width, height, batches }, null, 2) + '\n');
console.log(`Prepared ${batches.length} contact sheets in ${directory}`);

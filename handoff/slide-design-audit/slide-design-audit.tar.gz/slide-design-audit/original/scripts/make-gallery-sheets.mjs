#!/usr/bin/env node
// Three gallery slides per sheet, with labels outside the actual slide pixels.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {toPng} from '../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../opf-render/dist/fonts-node.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const phase = process.argv.find(value => value.startsWith('--phase='))?.slice(8) ?? 'baseline';
const directory = path.join(root,'artifacts/design-audit/gallery',phase);
const manifest = JSON.parse(await fs.readFile(path.join(directory,'manifest.json'),'utf8'));
const records = JSON.parse(await fs.readFile(path.join(root,'../pptx-gallery/data/layouts.json'),'utf8')).items;
const fonts = await loadFonts({pack:'office'});
const width=1920,height=420,margin=16,gap=16,panel=(width-margin*2-gap*2)/3;
const escape = value => String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
const batches=[];
for (let start=0;start<manifest.entries.length;start+=3) {
  const entries=manifest.entries.slice(start,start+3),number=Math.floor(start/3)+1;
  const pieces=[];
  for (const [index,entry] of entries.entries()) {
    const svg=await fs.readFile(entry.files.svg,'utf8'),x=margin+index*(panel+gap);
    const label=`${String(entry.order).padStart(2,'0')}  ${records.find(record=>record.id===entry.id)?.name??entry.id}`;
    pieces.push(`<text x="${x}" y="29" font-family="Intos" font-size="20" font-weight="700" fill="#1f2937">${escape(label)}</text>`);
    pieces.push(`<image x="${x}" y="48" width="${panel}" height="${panel*9/16}" href="data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}"/>`);
  }
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="${width}" height="${height}" fill="#ffffff"/>${pieces.join('')}</svg>`;
  const name=`batch-${String(number).padStart(2,'0')}`,svgPath=path.join(directory,name+'.svg'),pngPath=path.join(directory,name+'.png');
  await fs.writeFile(svgPath,svg+'\n');
  await fs.writeFile(pngPath,await toPng(svg,{fonts}));
  batches.push({number,ids:entries.map(entry=>entry.id),png:pngPath,svg:svgPath,slides:entries.map(entry=>({id:entry.id,...entry.files}))});
}
await fs.writeFile(path.join(directory,'contact-sheets.json'),JSON.stringify({phase,width,height,batches},null,2)+'\n');
console.log(JSON.stringify({batches:batches.map(({number,ids,png})=>({number,ids,png}))},null,2));

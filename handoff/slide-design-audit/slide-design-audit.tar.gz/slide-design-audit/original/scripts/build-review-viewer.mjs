#!/usr/bin/env node
// Build the local audit viewer from measured evidence and the primary designer's reviews.
// No server, network, or document writes are needed by the resulting HTML.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
// The local HTTP server serves this artifact folder, so keep an exact review copy
// beside the report rather than linking outside its document root.
await fs.copyFile(path.resolve(root,'../../docs/slide-design-principles.md'),path.join(root,'slide-design-principles.md'));
const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const optional=async file=>{try{return await read(file);}catch(error){if(error.code==='ENOENT')return undefined;throw error;}};
const relative=file=>path.relative(root,file).split(path.sep).join('/');
const reviews=await optional(path.join(root,'review.json'))??{};
const gallery=await read(path.join(root,'gallery/baseline/manifest.json'));
const columns=await optional(path.join(root,'columns/manifest.json'))??await optional(path.join(root,'columns/index.json'));
const auto=await optional(path.join(root,'auto/index.json'));
const reviewFor=(kind,id)=>Array.isArray(reviews[kind])?reviews[kind].find(item=>item.id===id)??{}:reviews[kind]?.[id]??{};
const excerpt=async file=>{const document=await read(file);delete document.catalogs;return JSON.stringify(document,null,2);};
const exists=async file=>{try{await fs.access(file);return true;}catch(error){if(error.code==='ENOENT')return false;throw error;}};
const normalizeFiles=(files,base=root)=>Object.fromEntries(Object.entries(files).filter(([,file])=>typeof file==='string').map(([key,file])=>[key,relative(path.resolve(base,file))]));
async function afterEvidence(review){
  const supplied=typeof review.after==='string'?{png:review.after}:review.after;
  if(!supplied?.png)return {};
  const files=normalizeFiles(supplied),base=path.resolve(root,files.png).replace(/\.png$/,'');
  for(const [key,extension]of [['opf','.opf.json'],['geometry','.geometry.json'],['findings','.findings.json'],['svg','.svg']]){
    if(!files[key]&&await exists(base+extension))files[key]=relative(base+extension);
  }
  return {after:files.png,afterFiles:files};
}
const entries=[];
for(const entry of gallery.entries){
  const files=Object.fromEntries(Object.entries(entry.files).map(([key,file])=>[key,relative(file)]));
  const review=reviewFor('gallery',entry.id);
  entries.push({kind:'gallery',number:entry.order,id:entry.id,title:entry.id,files,
    source:await excerpt(entry.files.opf),review,...await afterEvidence(review)});
}
const changeSpecs=[
  {id:'closing',title:'Closing — compact call to action',before:'candidates/closing/default-before',after:'candidates/closing/default-after.png',
    review:{outcome:'local layout comparison',analysis:'The original next step sits near the bottom edge, separated from the call to action. The comparison uses the same words and type sizes.',
      principleReview:'Proximity and visual balance: related content forms one compact centered group while preserving the heading hierarchy.',
      rationale:'The subtitle-to-next-step gap decreases from 244.96 to 24 pixels.',tradeoff:'The changed drawing needs a major gallery release under its current stability policy. It has not been published.'}},
  {id:'agenda-split',title:'Agenda split — additional layout',before:'candidates/agenda/default-before',after:'candidates/agenda/default-after.png',
    review:{outcome:'additional layout comparison',analysis:'The concise agenda is compared with a title-and-list split. The original full-width agenda remains available.',
      principleReview:'Balance, hierarchy and grouping: a compact title group sits beside the list, with a clear gutter and shared reading direction.',
      rationale:'Three, six and nine short entries retain the 32-pixel starting type size in the split arrangement.',tradeoff:'Nine long entries fit down to 24 pixels in the split while the original full-width agenda keeps 32 pixels. Detailed agendas should use the original.'}},
  {id:'two-column-timeline',title:'Two-column timeline — binding correction',before:'columns/two-column-timeline-negative',after:'columns/two-column-timeline-fixed.png',
    review:{outcome:'local layout correction',analysis:'The previous two-column definition omitted timeline from its accepted kinds. The control compares that definition with the corrected record using identical timelines.',
      principleReview:'Layout logic, alignment and content preservation: the two timelines bind to their separate named columns rather than falling below the intended grid.',
      rationale:'Two layout-unplaced diagnostics in the negative control are removed by adding the supported timeline kind to the layout record.',tradeoff:'This correction changes the catalog record only; it makes no shared engine or schema change.'}},
];
for(const [index,spec]of changeSpecs.entries()){
  if(!await exists(path.join(root,spec.before+'.png'))||!await exists(path.join(root,spec.after)))continue;
  const files={opf:spec.before+'.opf.json',svg:spec.before+'.svg',png:spec.before+'.png',geometry:spec.before+'.geometry.json'};
  if(await exists(path.join(root,spec.before+'.findings.json')))files.findings=spec.before+'.findings.json';
  const review={...spec.review,after:spec.after,...reviewFor('changes',spec.id)};
  entries.push({kind:'changes',number:index+1,id:spec.id,title:spec.title,files,
    source:await excerpt(path.join(root,files.opf)),review,...await afterEvidence(review)});
}
const columnCases=columns?.cases??[
  ...(columns?.entries??[]),
  ...(columns?.controls??[]).map((entry,index)=>({...entry,number:(columns?.entries?.length??0)+index+1})),
];
for(const [kind,cases]of [['columns',columnCases],['auto',auto?.cases??[]]])for(const [index,entry]of cases.entries()){
  const files=normalizeFiles(entry.files,path.join(root,kind));
  files.opf??=files.input;
  const review=reviewFor(kind,entry.id);
  entries.push({kind,number:entry.number??entry.order??index+1,id:entry.id,title:entry.title,files,purpose:entry.purpose,
    source:await excerpt(path.resolve(root,files.opf)),review,...await afterEvidence(review)});
}
const batches=[];
const sectionCounts={};
for(const kind of ['gallery','changes','columns','auto']){
  const list=entries.filter(entry=>entry.kind===kind);
  sectionCounts[kind]=list.length;
  for(let index=0;index<list.length;index+=3)batches.push({id:`${kind}-${String(index/3+1).padStart(2,'0')}`,kind,
    number:index/3+1,entries:list.slice(index,index+3)});
}
const focus=reviews.focus??[
  {title:'#6 Text — whole-slide balance',description:'Compare the original with a compact centered heading-and-prose group. The spatial comparison preserves the content and original type sizes.',
    images:[{label:'Original',file:'candidates/text/default-before.png'},{label:'Proposed group centering',file:'candidates/text/default-after.png'}],
    links:[{label:'Candidate geometry',file:'candidates/text/default-after.geometry.json'},{label:'Candidate OPF',file:'candidates/text/default-after.opf.json'}]},
  {title:'#7 List — three vertical-placement choices',description:'Internal alignment can be strong while the slide remains top-heavy. Compare the original, body-only centering, and centering the heading and list together. Words, fonts, columns and gutters stay identical.',
    images:[{label:'Original · body centered · whole group centered',file:'candidates/list/comparison.png'}],
    links:[{label:'Body-centered full slide',file:'candidates/list/body-centered.png'},{label:'Group-centered full slide',file:'candidates/list/group-centered.png'},{label:'Exact comparison evidence',file:'candidates/list/comparison.json'}]},
];
const focusHtml=focus.length?`<section id="review-focus"><h2>Latest review focus: vertical balance</h2><p class="intro">These are review illustrations. The gallery baseline is preserved, and shared engine behavior has not been changed.</p><div class="focus-grid">${focus.map(item=>`<article class="focus-card"><h3>${item.title}</h3><p>${item.description}</p><div class="focus-images">${item.images.map(image=>`<a href="${image.file}" target="_blank"><span>${image.label}</span><img src="${image.file}" alt="${image.label}"></a>`).join('')}</div><div class="files">${item.links.map(link=>`<a href="${link.file}" target="_blank">${link.label}</a>`).join('')}</div></article>`).join('')}</div></section>`:'';
const payload=JSON.stringify({batches,sectionCounts,versions:gallery.versions,node:gallery.node,options:gallery.options,columnProvenance:columns?.provenance,autoProvenance:auto?.provenance}).replaceAll('<','\\u003c');
const html=`<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Slide layout design audit — ${entries.length} review items</title>
<style>
:root{font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#17202b;background:#f6f7f9;font-size:15px;line-height:1.5}*{box-sizing:border-box}body{margin:0}header{background:#fff;border-bottom:1px solid #dce0e5;padding:20px 24px}h1{font-size:24px;line-height:1.2;margin:0 0 8px}header p{margin:0;max-width:1100px;color:#495463}a{color:#185790;text-underline-offset:3px}nav{position:sticky;top:0;z-index:2;display:flex;gap:12px;align-items:center;padding:12px 24px;background:#fff;border-bottom:1px solid #dce0e5}button,select{font:inherit;color:inherit;border:1px solid #b8c2cc;background:#fff;border-radius:4px;padding:7px 12px}button{cursor:pointer}button:disabled{opacity:.4;cursor:default}select{max-width:50vw}#batch-label{margin-left:auto;color:#495463}main{padding:24px}h2{font-size:21px;margin:0 0 6px}.intro{color:#495463;margin:0 0 20px;max-width:1100px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}.card{background:#fff;border:1px solid #dce0e5;border-radius:6px;overflow:hidden}.card-head{padding:14px 16px 10px}h3{font-size:18px;margin:0;text-transform:capitalize}.slide-button{display:block;padding:0;border:0;border-radius:0;width:100%;background:#011842}.slide-button img{display:block;aspect-ratio:16/9;width:100%;height:auto;object-fit:contain}.content{padding:16px}.outcome{font-weight:650;margin:0 0 12px}.outcome.pending{color:#66707d;font-weight:400}.field{margin:0 0 14px}.field strong{display:block;font-size:13px;letter-spacing:.02em;color:#495463;margin-bottom:3px}.field p{margin:0}.field ul{padding-left:20px;margin:0}.files{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:13px;border-top:1px solid #e4e7ec;padding-top:12px}.compare{display:flex;gap:8px;margin-bottom:12px}.compare button[aria-pressed=true]{background:#e8eef5;border-color:#557089}details{margin-top:14px;font-size:13px}summary{cursor:pointer;color:#185790}pre{font:12px/1.5 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f4f7;padding:12px;border-radius:4px;max-height:400px;overflow:auto}footer{padding:20px 24px;color:#495463;font-size:13px}dialog{padding:0;border:0;max-width:96vw;background:#fff;border-radius:6px}dialog::backdrop{background:#000b}dialog img{display:block;max-width:94vw;max-height:85vh;width:auto;height:auto}dialog .tools{padding:10px 12px;display:flex;gap:20px;align-items:center}dialog button{margin-left:auto}@media(max-width:1050px){.grid{grid-template-columns:1fr}.card{max-width:900px}nav{flex-wrap:wrap}#batch-label{display:none}}@media print{nav,footer{display:none}main{padding:0}.grid{gap:12px}.card{break-inside:avoid}details{display:none}}
</style>
<style>#review-focus{padding:24px;background:#fff;border-bottom:1px solid #dce0e5}.focus-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.focus-card{border:1px solid #dce0e5;border-radius:6px;padding:16px}.focus-card h3{font-size:18px;text-transform:none}.focus-card>p{margin:8px 0 14px;color:#495463}.focus-images{display:flex;align-items:flex-start;gap:12px}.focus-images a{display:block;flex:1;min-width:0;font-size:13px}.focus-images span{display:block;margin-bottom:6px}.focus-images img{display:block;width:100%;height:auto}.focus-card .files{margin-top:14px}@media(max-width:1050px){.focus-grid{grid-template-columns:1fr}}</style>
<header><h1>Slide layout design audit</h1><p>${sectionCounts.gallery} gallery layouts${sectionCounts.changes?` · ${sectionCounts.changes} layout change comparisons`:''}${sectionCounts.columns?` · ${sectionCounts.columns} column matrix cases and controls`:''} · ${sectionCounts.auto} automatic composition examples. Reviewed three slides at a time, with automatic composition last. Select a slide to inspect it at full size.</p><p><a href="slide-design-principles.md">Design principles</a> · <a href="https://chatgpt.com/space/page_14b30241024c819180b6becfdea362f1">Principles artifact</a> · <a href="review.json">Review data</a></p><p><a href="proposals.html" target="_blank" rel="noopener">Proposed changes — discuss and approve one item at a time</a></p></header>
${focusHtml}
<nav><button id="back">← Previous three</button><select id="select" aria-label="Review batch"></select><button id="next">Next three →</button><span id="batch-label"></span></nav>
<main><h2 id="heading"></h2><p id="intro" class="intro"></p><div id="cards" class="grid"></div></main>
<footer id="provenance"></footer>
<dialog id="zoom"><img id="zoom-image" alt="Full slide"><div class="tools"><a id="zoom-file" target="_blank">Open full image</a><button id="close">Close</button></div></dialog>
<script type="application/json" id="data">${payload}</script>
<script>
const data=JSON.parse(document.getElementById('data').textContent),batches=data.batches;
const q=id=>document.getElementById(id),escape=value=>String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const sectionLabel={gallery:'Gallery layouts',changes:'Layout changes — before and after',columns:'Column matrix — layouts and controls',auto:'Auto mode — automatic composition'},shortLabel={gallery:'Gallery',changes:'Layout changes',columns:'Column matrix',auto:'Auto mode'};
const hash=location.hash.slice(1).replace(/^(gallery|changes|columns|auto)([0-9])/,(_,kind,digit)=>kind+'-'+digit);
let current=Math.max(0,batches.findIndex(batch=>batch.id===hash));
q('select').innerHTML=batches.map((batch,index)=>'<option value="'+index+'">'+shortLabel[batch.kind]+' '+batch.number+' / '+Math.ceil(data.sectionCounts[batch.kind]/3)+' · '+batch.entries.map(entry=>entry.number).join(', ')+'</option>').join('');
const plain=value=>typeof value==='object'?JSON.stringify(value):String(value);
const fieldBody=value=>Array.isArray(value)?'<ul>'+value.map(item=>'<li>'+escape(plain(item))+'</li>').join('')+'</ul>':value&&typeof value==='object'?'<ul>'+Object.entries(value).map(([key,item])=>'<li><b>'+escape(key)+':</b> '+escape(plain(item))+'</li>').join('')+'</ul>':'<p>'+escape(value)+'</p>';
const textField=(label,value)=>value==null||value===''?'':'<div class="field"><strong>'+escape(label)+'</strong>'+fieldBody(value)+'</div>';
const proofLink=(label,file)=>file?'<a href="'+escape(file)+'" target="_blank">'+label+'</a>':'';
function show(){const batch=batches[current];q('heading').textContent=sectionLabel[batch.kind]+' ('+data.sectionCounts[batch.kind]+') · Batch '+batch.number+' of '+Math.ceil(data.sectionCounts[batch.kind]/3);
q('intro').textContent=batch.kind==='gallery'?'Layout and content only; deck and slide design overrides are omitted. Default navy background, white text, Aptos measured with its pinned Intos replacements.':batch.kind==='changes'?'These comparisons preserve the content and font inputs while changing local layout definitions. Use Before and Proposed after to inspect each result. The original gallery baseline is retained.':batch.kind==='columns'?'Controlled column cases compare content counts, lengths and arrangement using measured fonts. Each result includes the input document and individual geometry evidence; any proposed after uses the same source content.':'Automatic composition with no named layout or decorative styling. Cases vary content length, grouping and payloads; the input and measured diagnostics accompany each result.';
q('cards').innerHTML=batch.entries.map(entry=>{const review=entry.review??{},after=entry.after,proof=entry.afterFiles??{};return '<article class="card"><div class="card-head"><h3>'+entry.number+'. '+escape(entry.title)+'</h3></div><button class="slide-button" data-zoom="'+escape(entry.files.png)+'"><img src="'+escape(entry.files.png)+'" alt="'+escape(entry.title)+' baseline"></button><div class="content">'+(after?'<div class="compare"><button data-before="'+escape(entry.files.png)+'" aria-pressed="true">Before</button><button data-after="'+escape(after)+'" aria-pressed="false">Proposed after</button></div>':'')+'<p class="outcome '+(!review.outcome?'pending':'')+'">'+escape(review.outcome??'Review pending')+'</p>'+textField('Principle review',review.principleReview)+textField('Analysis',review.analysis??review.observation)+textField('Proposed improvement',review.proposal)+textField('Implementation',review.status)+textField('Why this helps',review.rationale)+textField('Tradeoffs',review.tradeoff)+'<div class="files">'+proofLink('Full-size baseline',entry.files.png)+proofLink('Portable OPF',entry.files.opf)+proofLink('Measured geometry',entry.files.geometry)+proofLink('Findings',entry.files.findings)+proofLink('SVG',entry.files.svg)+proofLink('Full-size proposed after',after)+proofLink('Proposed OPF',proof.opf)+proofLink('Proposed geometry',proof.geometry)+proofLink('Proposed findings',proof.findings)+proofLink('Proposed SVG',proof.svg)+'</div><details><summary>Minimal authoring JSON</summary><pre>'+escape(entry.source)+'</pre></details></div></article>';}).join('');
q('select').value=current;q('back').disabled=current===0;q('next').disabled=current===batches.length-1;q('batch-label').textContent=(current+1)+' of '+batches.length;history.replaceState(null,'','#'+batch.id);window.scrollTo(0,0);}
q('back').onclick=()=>{if(current>0){current--;show();}};q('next').onclick=()=>{if(current<batches.length-1){current++;show();}};q('select').onchange=event=>{current=Number(event.target.value);show();};
q('cards').onclick=event=>{const button=event.target.closest('button');if(!button)return;if(button.dataset.zoom){q('zoom-image').src=button.dataset.zoom;q('zoom-file').href=button.dataset.zoom;q('zoom').showModal();}else if(button.dataset.before||button.dataset.after){const card=button.closest('.card'),src=button.dataset.before??button.dataset.after;card.querySelector('img').src=src;card.querySelector('.slide-button').dataset.zoom=src;card.querySelectorAll('.compare button').forEach(candidate=>candidate.setAttribute('aria-pressed',candidate===button));}};
q('close').onclick=()=>q('zoom').close();q('zoom').onclick=event=>{if(event.target===q('zoom'))q('zoom').close();};document.onkeydown=event=>{if(q('zoom').open)return;if(event.key==='ArrowRight')q('next').click();if(event.key==='ArrowLeft')q('back').click();};
q('provenance').textContent='Core '+data.versions.core+' · Renderer '+data.versions.renderer+' · '+data.node+' · 1280 × 720 · Pinned office font files · Outlined SVG text · System fonts disabled · No network assets. A clean geometry report does not establish native PowerPoint pixel equivalence.';show();
</script></html>`;
await fs.writeFile(path.join(root,'report.html'),html);
console.log(JSON.stringify({viewer:path.join(root,'report.html'),...sectionCounts,batches:batches.length}));

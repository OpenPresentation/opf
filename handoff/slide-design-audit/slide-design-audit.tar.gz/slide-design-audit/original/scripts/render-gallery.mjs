#!/usr/bin/env node
// Reproducible gallery evidence. Run with the OPF checkout's local core loader.
// This writes audit artifacts only: catalog source and site caches are never modified.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {validate, resolveSlideContext} from '@openpresentation/opf';
import {composeSlide} from '@openpresentation/opf/composition';
import {toSvg, toPng, resolvePresentation} from '../../../../opf-render/dist/index.js';
import {loadFonts, BUNDLED_FONT_MANIFEST} from '../../../../opf-render/dist/fonts-node.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const read = async file => JSON.parse(await fs.readFile(file, 'utf8'));
const sha = value => createHash('sha256').update(value).digest('hex');
const arg = key => process.argv.find(value => value.startsWith(`--${key}=`))?.slice(key.length + 3);
const ids = (arg('ids') ?? 'cover,section,agenda').split(',');
const phase = arg('phase') ?? 'baseline';
const galleryRoot = arg('gallery') ? path.resolve(arg('gallery')) : undefined;
const recordsDir = arg('records-dir') ? path.resolve(arg('records-dir')) : undefined;
const source = await read(path.join(root, '../pptx-gallery/data/layout-examples.json'));
const siteLayouts = (await read(path.join(root, '../pptx-gallery/data/layouts.json'))).items;
const output = path.join(root, 'artifacts/design-audit/gallery', phase);
await fs.mkdir(output, {recursive:true});
const fonts = await loadFonts({pack:'office'});
const fontFiles = await Promise.all(fonts.fontFiles.map(async file => ({file, sha256:sha(await fs.readFile(file))})));
const git = directory => ({
  commit:execFileSync('git', ['rev-parse','HEAD'], {cwd:directory,encoding:'utf8'}).trim(),
  status:execFileSync('git', ['status','--short'], {cwd:directory,encoding:'utf8'}).trim(),
});
const manifests = [];
for (const id of ids) {
  fonts.registry.clearSubstitutions();
  const fixture = source.examples.find(value => value.id === id);
  if (!fixture) throw new Error(`No authored fixture for ${id}`);
  const document = structuredClone(fixture.document);
  // The default comparison deliberately uses no deck-level styling or slide-level decoration.
  delete document.design;
  for (const slide of document.slides) delete slide.design;
  if (galleryRoot || recordsDir) {
    const record = await read(path.join(recordsDir ?? path.join(galleryRoot,'catalog/layouts'), `${id}.json`));
    const {$schema, id:recordId, ...embedded} = record;
    document.catalogs.default.layouts[id] = embedded;
  }
  const diagnostics = [];
  const options = {fonts, text:'paths', strictReferences:true, trace:true, onDiagnostic:issue => diagnostics.push(issue)};
  const validation = validate(document, {fonts});
  if (!validation.valid) throw new Error(`${id}: validation failed: ${JSON.stringify(validation.findings)}`);
  const resolved = resolvePresentation(document, options).slides[0];
  const context = resolveSlideContext(document, 0, {fonts, strictReferences:true});
  // Match renderer bindSlide: it resolves the role's physical family once, then
  // composes with its script-aware measurement. This matters at intermediate weights.
  const geometry = composeSlide(context.slide, {...context.options,
    fontFamilies:resolved.design.fonts,textMeasurement:resolved.textMeasurement,explain:true});
  const svg = toSvg(document, 1, options);
  const png = await toPng(svg, {fonts});
  const original = fixture.document;
  const gallerySvg = toSvg(original, 1, options);
  const galleryPng = await toPng(gallerySvg, {fonts});
  const base = path.join(output,id);
  const json = JSON.stringify(document,null,2)+'\n';
  const evidence = {id,geometry,resolvedDesign:resolved.design,diagnostics,validation,
    substitutions:fonts.substitutions, differenceFromGallery:{removedDeckDesign:original.design ?? null,
      svgIdentical:gallerySvg===svg,pngIdentical:sha(galleryPng)===sha(png)}};
  await fs.writeFile(`${base}.opf.json`,json);
  await fs.writeFile(`${base}.svg`,svg+'\n');
  await fs.writeFile(`${base}.png`,png);
  await fs.writeFile(`${base}.geometry.json`,JSON.stringify(evidence,null,2)+'\n');
  await fs.writeFile(`${base}.gallery.svg`,gallerySvg+'\n');
  await fs.writeFile(`${base}.gallery.png`,galleryPng);
  manifests.push({id,order:siteLayouts.findIndex(layout => layout.id===id)+1,
    source:`pptx-gallery/data/layout-examples.json#${id}`,
    files:{opf:`${base}.opf.json`,svg:`${base}.svg`,png:`${base}.png`,geometry:`${base}.geometry.json`,galleryPng:`${base}.gallery.png`},
    hashes:{opf:sha(json),svg:sha(svg+'\n'),png:sha(png)},diagnostics:diagnostics.length,
    differenceFromGallery:evidence.differenceFromGallery});
}
let previousEntries = [];
try { previousEntries = (await read(path.join(output,'manifest.json'))).entries; }
catch (error) { if (error.code !== 'ENOENT') throw error; }
const entryMap = new Map(previousEntries.map(entry => [entry.id,entry]));
for (const entry of manifests) entryMap.set(entry.id,entry);
const manifest = {phase,scope:'Minimal authored content: layout references, content and portable catalog records. No deck or slide design overrides.',
  node:process.version,canvas:{width:1280,height:720},options:{fonts:{pack:'office',substitutionPolicy:'metric',loadSystemFonts:false},text:'paths',strictReferences:true,trace:true},
  versions:{core:(await read(path.join(root,'packages/javascript/package.json'))).version,
    renderer:(await read(path.join(root,'../opf-render/package.json'))).version},
  repositories:{core:git(root),renderer:git(path.join(root,'../opf-render')),site:git(path.join(root,'../pptx-gallery')),
    ...(galleryRoot?{gallery:git(galleryRoot)}:{})},
  galleryLayoutCount:siteLayouts.length,...(recordsDir?{candidateRecordDirectory:recordsDir}:{}),fontManifestSha256:sha(JSON.stringify(BUNDLED_FONT_MANIFEST)),fontFiles,
  entries:[...entryMap.values()].sort((a,b) => a.order-b.order)};
await fs.writeFile(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({output,entries:manifests},null,2));

#!/usr/bin/env node
// A static discussion queue. This page never records approval or applies changes.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=async file=>JSON.parse(await fs.readFile(path.join(root,file),'utf8'));
const optional=async file=>{try{return await read(file);}catch(error){if(error.code==='ENOENT')return undefined;throw error;}};
const queue=await read('proposal-queue.json');
assert.ok(Array.isArray(queue.items)&&queue.items.length,'The proposal queue must contain its authored items.');
const ids=new Set();
for(const item of queue.items){
  assert.match(item.id,/^P\d{2,3}$/,'A proposal needs its stable Pxx ID.');
  assert.ok(!ids.has(item.id),`Duplicate proposal ID: ${item.id}`);ids.add(item.id);
  for(const evidence of item.evidence??[]){
    assert.equal(typeof evidence.file,'string',`${item.id}: evidence needs a file reference.`);
    const file=path.resolve(root,evidence.file);
    assert.ok(file.startsWith(root+path.sep),`${item.id}: evidence must remain in the audit folder.`);
    await fs.access(file);
    // Reserve the real image ratio before loading so an individual deep link
    // stays on its title while evidence above it finishes loading.
    if(/\.png$/i.test(file)){
      const bytes=await fs.readFile(file);
      if(bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex'))){evidence.width=bytes.readUInt32BE(16);evidence.height=bytes.readUInt32BE(20);}
    }else if(/\.svg$/i.test(file)){
      const svg=await fs.readFile(file,'utf8'),tag=svg.match(/<svg\b[^>]*>/i)?.[0]??'';
      const viewBox=tag.match(/viewBox=["']([^"']+)["']/i)?.[1]?.trim().split(/[ ,]+/).map(Number);
      if(viewBox?.length===4&&viewBox[2]>0&&viewBox[3]>0){evidence.width=viewBox[2];evidence.height=viewBox[3];}
    }
  }
}
// Keep authored order within each section, with automatic composition last.
const items=[...queue.items.filter(item=>item.category!=='Auto mode'),...queue.items.filter(item=>item.category==='Auto mode')];
const batchCount=Math.ceil(items.filter(item=>item.category!=='Auto mode').length/3)+Math.ceil(items.filter(item=>item.category==='Auto mode').length/3);
const gallery=await optional('gallery/baseline/manifest.json');
const columns=await optional('columns/manifest.json');
const auto=await optional('auto/index.json');
const caseLinks={gallery:{},columns:{},auto:{}};
for(const [index,entry]of (gallery?.entries??[]).entries())caseLinks.gallery[entry.id]=`report.html#gallery-${String(Math.floor(index/3)+1).padStart(2,'0')}`;
for(const [index,entry]of [...(columns?.entries??[]),...(columns?.controls??[])].entries())caseLinks.columns[entry.id]=`report.html#columns-${String(Math.floor(index/3)+1).padStart(2,'0')}`;
for(const [index,entry]of (auto?.cases??[]).entries())caseLinks.auto[entry.id]=`report.html#auto-${String(Math.floor(index/3)+1).padStart(2,'0')}`;
caseLinks.gallery['agenda-split']='report.html#changes-01';
const payload=JSON.stringify({...queue,items,caseLinks}).replaceAll('<','\\u003c');
const esc=value=>String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const summary=queue.summary??{},summaryText=[summary.gallery&&`${summary.gallery} gallery layouts`,summary.columns&&`${summary.columns} column cases and controls`,summary.auto&&`${summary.auto} auto examples`].filter(Boolean).join(' · ');
const html=`<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(queue.title??'Slide design proposal queue')} — ${items.length} items</title>
<style>
:root{font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#17202b;background:#f5f6f8;font-size:16px;line-height:1.55}*{box-sizing:border-box}body{margin:0}a{color:#185790;text-underline-offset:3px}header,.navigation,.page,footer{max-width:1440px;margin:auto;padding:24px}header{padding-bottom:20px}h1{font-size:30px;line-height:1.2;margin:0 0 12px}header p{max-width:1050px;margin:8px 0;color:#495463}.links{display:flex;flex-wrap:wrap;gap:8px 20px;font-size:14px}.navigation{position:sticky;top:0;z-index:3;display:flex;align-items:center;gap:12px;flex-wrap:wrap;background:#f5f6f8eb;border-top:1px solid #dce0e5;border-bottom:1px solid #dce0e5;backdrop-filter:blur(10px);padding-top:12px;padding-bottom:12px}button,select,input{font:inherit;border:1px solid #b9c3cd;border-radius:4px;background:#fff;color:inherit;padding:8px 12px}button{cursor:pointer}button:disabled{opacity:.4;cursor:default}select{max-width:70vw}.page-status{margin-left:auto;font-size:14px;color:#495463}.jump-index{max-width:1440px;margin:auto;padding:0 24px 16px;display:flex;flex-wrap:wrap;gap:6px 14px;font-size:14px}.jump-index a[aria-current=true]{font-weight:750;color:#17202b}.page{padding-top:8px}.page>h2{font-size:21px;margin:0 0 14px}.proposal{background:#fff;border:1px solid #d8dfe6;border-radius:7px;padding:24px;margin-bottom:28px;scroll-margin-top:102px}.proposal.active{border-color:#4c6c8c;box-shadow:0 0 0 2px #dce7f2}.proposal h2{font-size:25px;line-height:1.25;margin:0 0 12px}.proposal h2 a{color:inherit;text-decoration:none}.meta{display:flex;flex-wrap:wrap;gap:8px 16px;font-size:14px;color:#495463;margin-bottom:18px}.stage{font-weight:650}.decision{font-weight:650;color:#17202b}.field{margin:0 0 18px}.field>h3{font-size:15px;margin:0 0 5px;color:#495463}.field>p{margin:0;max-width:1200px}.field ul{margin:0;padding-left:22px}.principles{display:grid;grid-template-columns:220px minmax(0,1fr);gap:8px 20px;margin:0}.principles dt{font-weight:650}.principles dd{margin:0}.evidence{border-top:1px solid #e0e5eb;padding-top:18px;margin-top:22px}.evidence>h3{font-size:17px;margin:0 0 6px}.evidence-notice{margin:0 0 14px;color:#495463;font-size:14px}.evidence-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}.evidence-grid.single{grid-template-columns:minmax(0,1fr)}figure{margin:0;min-width:0}.image-link{display:block;background:#eef1f5}.image-link img{width:100%;height:auto;display:block}figcaption{font-size:14px;margin:8px 0 0}figcaption b{display:block}.evidence-role{font-size:12px;text-transform:uppercase;letter-spacing:.035em;color:#526273;margin-right:8px}.evidence-note{display:block;color:#495463}.file-evidence{padding:14px 16px;background:#f3f5f8;border:1px solid #dce2e8;border-radius:4px}.file-evidence a{font-weight:650}.below-evidence{margin-top:22px}.approval{padding:16px 18px;background:#f1f5f9;border-left:4px solid #7b94ac;margin-top:20px}.approval h3{margin:0 0 6px;font-size:16px}.approval p{margin:0}.chat-action{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:18px}.chat-action p{margin:0}.chat-action code{font-size:16px;font-weight:750}.copy-id{width:82px;font-family:ui-monospace,monospace;cursor:text}.copy-status{font-size:13px;color:#495463}.affected{display:flex;flex-wrap:wrap;gap:8px 20px}.affected p{margin:0}.affected a{white-space:nowrap}details{margin-top:18px}summary{cursor:pointer;font-weight:600;color:#495463}.layout-index{background:#fff;border:1px solid #dce2e8;border-radius:6px;padding:18px;margin-top:28px}.layout-index table{border-collapse:collapse;width:100%;font-size:14px;margin-top:12px}.layout-index th,.layout-index td{text-align:left;padding:10px 12px;vertical-align:top;border-bottom:1px solid #e1e6ec}.layout-index th{background:#f4f6f8}footer{font-size:14px;color:#495463;padding-top:0}footer p{margin:8px 0}@media(max-width:760px){header,.navigation,.page,footer{padding-left:16px;padding-right:16px}.jump-index{padding-left:16px;padding-right:16px}.proposal{padding:18px}.evidence-grid{grid-template-columns:1fr}.principles{grid-template-columns:1fr;gap:3px}.principles dd{margin-bottom:10px}.page-status{margin-left:0}.layout-index{overflow-x:auto}h1{font-size:26px}.proposal h2{font-size:22px}}
</style>
<style>figcaption{margin:0 0 8px}.evidence-note{background:#f3f5f8;border-left:3px solid #64748b;padding:8px 10px;margin:6px 0 10px;color:#3b4148}@media(max-width:760px){.navigation{display:grid;grid-template-columns:1fr 1fr;gap:8px}#batch{grid-column:1/-1;grid-row:2;max-width:100%;width:100%}.page-status{display:none}.proposal{scroll-margin-top:146px}}</style>
<header><h1>${esc(queue.title??'Slide design proposal queue')}</h1><p>${esc(queue.intro??'Discuss and decide each logical proposal individually using its stable ID.')}</p><p>${items.length} proposals · ${esc(summaryText)}</p><p>This page does not record decisions or apply changes. Discuss or approve one proposal ID in chat.</p><div class="links"><a href="report.html">Back to slide audit</a>${queue.principles?.file?`<a href="${esc(queue.principles.file)}">Design principles</a>`:''}${queue.principles?.url?`<a href="${esc(queue.principles.url)}">Principles artifact</a>`:''}<a href="proposal-queue.json">Exact queue data</a></div></header>
<div class="jump-index" id="jump-index" aria-label="Proposal index"></div>
<nav class="navigation"><button id="previous">← Previous three</button><select id="batch" aria-label="Proposal batch"></select><button id="next">Next three →</button><span id="page-status" class="page-status"></span></nav>
<main class="page"><h2 id="batch-heading"></h2><div id="proposals"></div><section class="layout-index"><details><summary>Layout decisions and proposal index (${queue.layoutIndex?.length??0} layouts)</summary><table><thead><tr><th>Layout</th><th>Decision</th><th>Proposals</th><th>Review note</th></tr></thead><tbody id="layout-index"></tbody></table></details></section></main>
<footer id="footer">${queue.updatedAt?`<p>Queue updated: ${esc(queue.updatedAt)}</p>`:''}${(queue.notes??[]).map(note=>`<p>${esc(note)}</p>`).join('')}</footer>
<script type="application/json" id="queue-data">${payload}</script>
<script>
const data=JSON.parse(document.getElementById('queue-data').textContent),items=data.items;
const q=id=>document.getElementById(id),escape=value=>String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const batches=[];
for(const section of [{label:'Proposals',kind:'general',items:items.filter(item=>item.category!=='Auto mode')},{label:'Auto mode',kind:'auto',items:items.filter(item=>item.category==='Auto mode')}]){
for(let index=0;index<section.items.length;index+=3)batches.push({label:section.label,kind:section.kind,number:index/3+1,total:Math.ceil(section.items.length/3),items:section.items.slice(index,index+3)});}
const imageFile=file=>/\\.(png|svg|jpe?g|webp|gif)$/i.test(file??'');
const list=value=>Array.isArray(value)?value:value==null||value===''?[]:[value];
const bullets=value=>'<ul>'+list(value).map(item=>'<li>'+escape(item)+'</li>').join('')+'</ul>';
const field=(label,value)=>value==null||value===''||Array.isArray(value)&&!value.length?'':'<section class="field"><h3>'+escape(label)+'</h3>'+(Array.isArray(value)?bullets(value):'<p>'+escape(value)+'</p>')+'</section>';
const proposalLink=id=>items.some(item=>item.id===id)?'<a href="#'+escape(id)+'">'+escape(id)+'</a>':escape(id);
const affected=value=>Object.entries(value??{}).filter(([,ids])=>ids?.length).map(([kind,ids])=>'<p><b>'+escape({gallery:'Gallery',columns:'Columns',auto:'Auto'}[kind]??kind)+':</b> '+ids.map(id=>data.caseLinks[kind]?.[id]?'<a href="'+escape(data.caseLinks[kind][id])+'" target="_blank" rel="noopener">'+escape(id)+'</a>':escape(id)).join(', ')+'</p>').join('');
function evidence(item){const files=item.evidence??[];if(!files.length)return '<section class="evidence"><h3>Evidence</h3><p class="evidence-notice">No rendered proposal is available yet. The item needs design work before visual approval.</p></section>';
const hasAfter=files.some(file=>file.role==='after'||file.role==='comparison'),images=files.filter(file=>imageFile(file.file)),other=files.filter(file=>!imageFile(file.file));
return '<section class="evidence"><h3>Evidence</h3><p class="evidence-notice">'+(hasAfter?'The labels identify current output, proposed output and comparison illustrations. Open an image for its full resolution.':'Current evidence only. A proposed after image has not been rendered for this item.')+'</p><div class="evidence-grid '+(images.length===1?'single':'')+'">'+images.map(file=>'<figure><figcaption><b><span class="evidence-role">'+escape(file.role??'evidence')+'</span>'+escape(file.label)+'</b>'+(file.note?'<span class="evidence-note">'+escape(file.note)+'</span>':'')+'</figcaption><a class="image-link" href="'+escape(file.file)+'" target="_blank" rel="noopener"><img src="'+escape(file.file)+'" alt="'+escape(file.label)+'"'+(file.width&&file.height?' width="'+file.width+'" height="'+file.height+'"':'')+'></a></figure>').join('')+'</div>'+other.map(file=>'<p class="file-evidence"><span class="evidence-role">'+escape(file.role??'evidence')+'</span><a href="'+escape(file.file)+'" target="_blank" rel="noopener">'+escape(file.label)+'</a>'+(file.note?'<br><span class="evidence-note">'+escape(file.note)+'</span>':'')+'</p>').join('')+'</section>';}
function card(item,active){return '<article id="'+escape(item.id)+'" class="proposal '+(active?'active':'')+'"><h2><a href="#'+escape(item.id)+'">'+escape(item.id)+' · '+escape(item.title)+'</a></h2><div class="meta"><span>'+escape(item.category??'Proposal')+'</span><span class="stage">Stage: '+escape(item.stage??'Needs design work')+'</span><span class="decision">'+escape(item.decision??'Awaiting individual decision')+'</span></div>'+field('Scope',item.scope)+field('Problem',item.problem)+field('Recommendation',item.proposal)+(item.principles?.length?'<section class="field"><h3>Design principles</h3><dl class="principles">'+item.principles.map(principle=>'<dt>'+escape(principle.name)+'</dt><dd>'+escape(principle.assessment)+'</dd>').join('')+'</dl></section>':'')+evidence(item)+'<div class="below-evidence">'+field('Tradeoffs',item.tradeoffs)+'<section class="approval"><h3>Approval scope for '+escape(item.id)+'</h3><p>'+escape(item.approvalScope??'Discuss the scope in chat before implementation.')+'</p></section><div class="chat-action"><p>Discuss or approve <code>'+escape(item.id)+'</code> in chat.</p><input class="copy-id" aria-label="Copyable proposal ID" value="'+escape(item.id)+'" readonly><button data-copy="'+escape(item.id)+'">Copy ID</button><span class="copy-status" aria-live="polite"></span></div>'+field('Implementation and test gates',item.acceptance)+(item.dependencies?.length?'<section class="field"><h3>Dependencies</h3><p>'+item.dependencies.map(proposalLink).join(', ')+'</p></section>':'')+(affected(item.affected)?'<section class="field"><h3>Affected examples</h3><div class="affected">'+affected(item.affected)+'</div></section>':'')+(item.rejected?.length?'<details><summary>Alternatives not recommended</summary>'+bullets(item.rejected)+'</details>':'')+'</div></article>';}
let current=0;
q('batch').innerHTML=batches.map((batch,index)=>'<option value="'+index+'">'+batch.label+' '+batch.number+' / '+batch.total+' · '+batch.items.map(item=>escape(item.id)).join(', ')+'</option>').join('');
q('jump-index').innerHTML=items.map(item=>'<a href="#'+escape(item.id)+'" title="'+escape(item.title)+'">'+escape(item.id)+'</a>').join('');
q('layout-index').innerHTML=(data.layoutIndex??[]).map(entry=>'<tr><td>'+escape(entry.layout)+'</td><td>'+escape(entry.decision)+'</td><td>'+(entry.proposalIds??[]).map(proposalLink).join(', ')+'</td><td>'+escape(entry.note)+'</td></tr>').join('');
function show(id,scroll){const selected=batches.findIndex(batch=>batch.items.some(item=>item.id===id));if(selected>=0)current=selected;else current=Math.min(current,batches.length-1);
const batch=batches[current];q('proposals').innerHTML=batch.items.map(item=>card(item,item.id===id)).join('');q('batch-heading').textContent=(batch.kind==='auto'?'Auto mode':'Proposals')+' · Batch '+batch.number+' of '+batch.total+' · '+batch.items.map(item=>item.id).join(', ');q('batch').value=current;q('previous').disabled=current===0;q('next').disabled=current===batches.length-1;q('page-status').textContent=items.length+' logical items · batch '+(current+1)+' of '+batches.length;q('jump-index').querySelectorAll('a').forEach(link=>link.setAttribute('aria-current',link.hash==='#'+id));
if(scroll)requestAnimationFrame(()=>{(q(id)??q('batch-heading')).scrollIntoView({block:'start'});});}
function navigate(index){if(index<0||index>=batches.length)return;const id=batches[index].items[0].id;history.pushState(null,'','#'+id);show(id,true);}
q('previous').onclick=()=>navigate(current-1);q('next').onclick=()=>navigate(current+1);q('batch').onchange=event=>navigate(Number(event.target.value));
window.addEventListener('hashchange',()=>show(location.hash.slice(1).toUpperCase(),true));
q('proposals').onclick=async event=>{const button=event.target.closest('[data-copy]');if(!button)return;const row=button.closest('.chat-action'),input=row.querySelector('input'),status=row.querySelector('.copy-status');input.focus();input.select();try{await navigator.clipboard.writeText(button.dataset.copy);status.textContent='Copied '+button.dataset.copy;}catch{let copied=false;try{copied=document.execCommand('copy');}catch{}status.textContent=copied?'Copied '+button.dataset.copy:'ID selected; copy it with your keyboard.';}};
const initial=location.hash.slice(1).toUpperCase();show(initial||items[0].id,!!initial);
</script></html>`;
await fs.writeFile(path.join(root,'proposals.html'),html);
console.log(JSON.stringify({output:path.join(root,'proposals.html'),items:items.length,batches:batchCount}));

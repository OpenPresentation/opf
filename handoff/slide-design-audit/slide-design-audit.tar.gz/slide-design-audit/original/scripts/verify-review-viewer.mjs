import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire(path.resolve(root,'../../../opf-render/package.json'));
const {chromium}=require('playwright');
const executable=process.env.AUDIT_BROWSER_EXECUTABLE??'/Users/michael/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell';
const browser=await chromium.launch({headless:true,executablePath:executable});
try{
  const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1}),errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
  const viewerUrl=pathToFileURL(path.join(root,'report.html')).href;
  await page.goto(viewerUrl+'#gallery04');
  const waitImages=()=>page.waitForFunction(()=>[...document.querySelectorAll('#cards img')].every(img=>img.complete&&img.naturalWidth>0));
  assert.match(await page.locator('#heading').innerText(),/Gallery layouts.*Batch 4/,'Existing gallery hash must survive regeneration');
  await waitImages();
  await page.screenshot({path:path.join(root,'report-preview-gallery04.png'),fullPage:true});
  const data=JSON.parse(await page.locator('#data').textContent()),batches=data.batches;
  assert.deepEqual([...new Set(batches.map(batch=>batch.kind))],['gallery','changes','columns','auto'].filter(kind=>data.sectionCounts[kind]>0));
  assert.equal(batches.at(-1).kind,'auto','Automatic composition remains the final section');
  await page.locator('#select').selectOption('0');
  await waitImages();
  assert.match(await page.locator('#heading').innerText(),/Gallery layouts.*Batch 1/);
  assert.equal(await page.locator('.card').count(),3);
  await page.waitForFunction(()=>[...document.querySelectorAll('#review-focus img')].every(img=>img.complete&&img.naturalWidth>0));
  const principlesHref=await page.locator('header a').first().getAttribute('href');
  assert.equal(principlesHref,'slide-design-principles.md');
  assert.deepEqual(await fs.readFile(path.join(root,principlesHref)),await fs.readFile(path.resolve(root,'../../docs/slide-design-principles.md')));
  await page.screenshot({path:path.join(root,'report-preview.png'),fullPage:true});
  await page.locator('#next').click();
  assert.match(await page.locator('#heading').innerText(),/Gallery layouts.*Batch 2/);
  const firstAuto=batches.findIndex(batch=>batch.kind==='auto');
  await page.locator('#select').selectOption(String(firstAuto));
  await waitImages();
  assert.match(await page.locator('#heading').innerText(),/Auto mode.*Batch 1/);
  assert.equal(await page.locator('.card').count(),3);
  await page.locator('.slide-button').first().click();
  assert.equal(await page.locator('dialog').evaluate(element=>element.open),true);
  await page.locator('#close').click();
  let afterChecks=0,proofLinks=0;
  for(const [index,batch]of batches.entries()){
    await page.locator('#select').selectOption(String(index));
    await waitImages();
    assert.equal(await page.locator('.card').count(),batch.entries.length);
    const links=await page.locator('#cards .files a').evaluateAll(elements=>elements.map(element=>element.getAttribute('href')));
    for(const href of links){const url=new URL(href,viewerUrl);if(url.protocol==='file:')await fs.access(url);proofLinks++;}
    const afterButtons=page.locator('[data-after]');
    for(let index=0;index<await afterButtons.count();index++){
      await afterButtons.nth(index).click();await waitImages();afterChecks++;
    }
  }
  await page.locator('#select').selectOption(String(batches.length-1));
  await waitImages();
  assert.equal(await page.locator('.card').count(),2);
  assert.equal(await page.locator('#next').isDisabled(),true);
  assert.deepEqual(errors,[]);
  const evidence={checks:['Existing gallery hash preserved','Three examples per batch','Gallery then column matrix then final auto section','Next/back navigation','Full-size dialog','All batch images and individual proof links load','All proposed-after toggles load','Final batch has two slides','No JavaScript or console errors'],counts:data.sectionCounts,batches:batches.length,proofLinks,afterChecks,browser:browser.version(),result:'passed'};
  await fs.writeFile(path.join(root,'viewer-verification.json'),JSON.stringify(evidence,null,2)+'\n');
  console.log(JSON.stringify(evidence));
}finally{await browser.close();}

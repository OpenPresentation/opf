// P35: copied layout-record evidence only. No production source or shared heading policy edits.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {validate} from '@openpresentation/opf';
import {toSvg,toPng,resolvePresentation} from '../../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../../opf-render/dist/fonts-node.js';

const here=path.dirname(fileURLToPath(import.meta.url));
const audit=path.resolve(here,'../..');
const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const sha=value=>createHash('sha256').update(value).digest('hex');
const fonts=await loadFonts({pack:'office'});
const options={fonts,text:'paths',trace:true,strictReferences:true};
const source=await read(path.join(audit,'../../gallery/baseline/metrics.opf.json'));
const cases=[
  {id:'original',change:()=>{}},
  {id:'long-heading',change:deck=>{deck.slides[0].title='Pilot outcomes show stronger completion and faster task times across the two participating field teams';}},
  {id:'no-subtitle',change:deck=>{delete deck.slides[0].subtitle;}},
];
const records=[];
const headingSnapshot=geometry=>geometry.items.filter(item=>['title','subtitle','tag'].includes(item.field)).map(item=>({field:item.field,alignment:item.alignment,box:item.box,
  fontSize:item.text.fontSize,lineHeight:item.text.lineHeight,lines:item.text.lines,origins:item.text.placement?.lines.map(line=>({x:line.x,y:line.y,baseline:line.baseline,width:line.width}))}));
const baselineAlignment=[];
for(const id of ['metrics','scorecard','dashboard']){
  const evidence=await read(path.join(audit,'gallery/baseline',id+'.geometry.json'));
  baselineAlignment.push({id,headings:headingSnapshot(evidence.geometry)});
}
for(const id of ['scorecard','dashboard'])for(const heading of baselineAlignment.find(record=>record.id===id).headings)assert.equal(heading.alignment,'left',id+'/'+heading.field);
const currentMetrics=baselineAlignment.find(record=>record.id==='metrics').headings;
assert.equal(currentMetrics.find(item=>item.field==='title').alignment,'left');
assert.equal(currentMetrics.find(item=>item.field==='subtitle').alignment,'center');
for(const scenario of cases){
  const before=structuredClone(source);scenario.change(before);
  const after=structuredClone(before);
  after.catalogs.default.layouts.metrics.design.titleAlignment='center';
  assert.deepEqual(after.slides,before.slides,'each before/after pair preserves exact words/data/layout choice');
  const stripped=structuredClone(after);delete stripped.catalogs.default.layouts.metrics.design.titleAlignment;
  assert.deepEqual(stripped,before,'only copied layout titleAlignment changes');
  let original;
  for(const [phase,deck]of [['before',before],['after',after]]){
    const validation=validate(deck,{fonts});assert.equal(validation.valid,true,JSON.stringify(validation));
    const bound=resolvePresentation(deck,options).slides[0];
    assert.deepEqual(bound.geometry.diagnostics,[]);
    if(phase==='before')original=bound;
    else{
      assert.deepEqual(bound.design.fonts,original.design.fonts,'same fonts');
      assert.deepEqual(bound.design.colors,original.design.colors,'same colors');
      assert.deepEqual(bound.geometry.items.filter(item=>item.field!=='title'),original.geometry.items.filter(item=>item.field!=='title'),'subtitle and every non-title item deeply equal');
      assert.deepEqual(bound.geometry.regions,original.geometry.regions,'same body regions');
      assert.deepEqual(bound.geometry.headingAreas,original.geometry.headingAreas,'same heading allocations');
      const title=bound.geometry.items.find(item=>item.field==='title');
      const originalTitle=original.geometry.items.find(item=>item.field==='title');
      assert.deepEqual(title.box,originalTitle.box,'same title box');
      assert.equal(title.text.fontSize,originalTitle.text.fontSize,'same title type size');
      assert.equal(title.text.lineHeight,originalTitle.text.lineHeight,'same line height');
      assert.deepEqual(title.text.lines,originalTitle.text.lines,'same title wraps');
      assert.equal(title.alignment,'center');
    }
    const svg=toSvg(deck,1,options);const png=await toPng(svg,{fonts});
    if(scenario.id==='original'&&phase==='before')assert.equal(sha(png),sha(await fs.readFile(path.join(audit,'../../../original/gallery/baseline/metrics.png'))),'original before is byte-identical to retained baseline');
    const base=path.join(here,scenario.id+'-'+phase);
    await fs.writeFile(base+'.opf.json',JSON.stringify(deck,null,2)+'\n');
    await fs.writeFile(base+'.svg',svg+'\n');await fs.writeFile(base+'.png',png);
    await fs.writeFile(base+'.geometry.json',JSON.stringify({geometry:bound.geometry,design:bound.design,validation},null,2)+'\n');
    records.push({case:scenario.id,phase,input:base+'.opf.json',svg:base+'.svg',png:base+'.png',geometry:base+'.geometry.json',pngSha256:sha(png),headingSnapshot:headingSnapshot(bound.geometry),diagnostics:0});
  }
}
const esc=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;');
const panels=[];
const panelWidth=936,rowHeight=590;
for(const [row,scenario]of cases.entries())for(const [column,phase]of ['before','after'].entries()){
  const x=16+column*952,y=row*rowHeight;
  const svg=await fs.readFile(path.join(here,scenario.id+'-'+phase+'.svg'));
  const annotation=phase==='before'?': left title'+(scenario.id==='no-subtitle'?' (no subtitle)':', centered subtitle'):': centered title';
  panels.push(`<text x="${x}" y="${y+30}" font-family="Intos" font-size="22" fill="#1f2937">${esc(scenario.id+' — '+phase+annotation)}</text><image x="${x}" y="${y+48}" width="${panelWidth}" height="526.5" href="data:image/svg+xml;base64,${svg.toString('base64')}"/>`);
}
const sheet=`<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1770"><rect width="100%" height="100%" fill="white"/>${panels.join('')}</svg>`;
await fs.writeFile(path.join(here,'../../../original/proposals/metrics-alignment/three-cases-before-after.svg'),sheet+'\n');
await fs.writeFile(path.join(here,'../../../original/proposals/metrics-alignment/three-cases-before-after.png'),await toPng(sheet,{fonts}));
const report={
  id:'P35',title:'Metrics heading alignment',scope:'Proposal only: one copied embedded metrics layout design.titleAlignment:center. No production layout, engine, theme, queue, viewer or global policy changes; no approval inferred.',
  minimalChange:{path:'catalogs.default.layouts.metrics.design.titleAlignment',value:'center'},
  confirmedBaselineAlignment:baselineAlignment,
  invariants:['Exact words/data/layout choice in each before/after pair','Existing fonts, type sizes, wraps and colors','Subtitle and every non-title composed item deeply equal','Heading allocations and body regions unchanged','Original before PNG byte-identical to retained baseline'],
  evaluation:['Original metrics has a left title but a centered subtitle because its record sets contentAlignment:center. The proposal gives those related headings a shared center axis.','The long heading retains its exact fitted size and wraps while the text origins center each line. A title without subtitle also centers without changing body geometry.','This is a coherent local metrics option; it changes the title position relative to the left-aligned scorecard/dashboard and ordinary content-slide titles. Decide whether to prefer that local centered hierarchy or a consistent left-heading policy across the deck.','The proposal does not alter shared heading rules, resize type, rewrite text, or address the separate large support-note gap.'],
  versions:{core:'0.20.3',renderer:'0.20.2'},fonts:'Pinned office pack, same measurement/raster handle; SVG glyph paths; system fonts disabled',records,
  comparisonSheet:path.join(here,'../../../original/proposals/metrics-alignment/three-cases-before-after.png'),
};
await fs.writeFile(path.join(here,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({id:report.id,output:here,renders:records.length,diagnostics:0,baselineTitleAlignment:currentMetrics.map(item=>({field:item.field,alignment:item.alignment})),comparisonSheet:report.comparisonSheet},null,2));

// Same-content authored image-fit illustrations. Automatic policy remains unchanged.
// Run from OPF: node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/auto-image-fit/render.mjs
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {gallery} from '@openpresentation/gallery';
import {validate,resolveSlideContext} from '../../../../packages/javascript/dist/index.js';
import {composeSlide} from '../../../../packages/javascript/dist/composition.js';
import {loadFonts} from '../../../../../opf-render/dist/fonts-node.js';
import {resolvePresentation,toPng,toSvg} from '../../../../../opf-render/dist/index.js';

const directory=path.dirname(fileURLToPath(import.meta.url)),audit=path.resolve(directory,'../..'),auto=path.join(audit,'auto');
const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const save=(file,value)=>fs.writeFile(path.join(directory,file),JSON.stringify(value,null,2)+'\n');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const revision=directory=>execFileSync('git',['rev-parse','HEAD'],{cwd:directory,encoding:'utf8'}).trim();
const index=await read(path.join(auto,'index.json'));
const imageSource=await fs.readFile(path.join(auto,'../../../original/proposals/auto-image-fit/assets/landscape.png'));
assert.equal(hash(imageSource),index.provenance.source.illustration.rasterSha256,'Reuse the exact baseline illustration bytes');
await fs.mkdir(path.join(directory,'assets'),{recursive:true});
await fs.writeFile(path.join(directory,'../../../original/proposals/auto-image-fit/assets/landscape.png'),imageSource);
const imageData='data:image/png;base64,'+imageSource.toString('base64');
const sourceSize={width:imageSource.readUInt32BE(16),height:imageSource.readUInt32BE(20)};
const hasImage=host=>host&&typeof host==='object'&&(Object.hasOwn(host,'image')||Object.values(host).some(hasImage));
const noPlacementPolicy=host=>{if(!host||typeof host!=='object')return;assert.ok(!Object.hasOwn(host,'layout'),'No explicit layout may be introduced');assert.ok(!Object.hasOwn(host,'composition'),'No composition policy may be introduced');Object.values(host).forEach(noPlacementPolicy);};
const imageCases=[];
for(const entry of index.cases){const document=await read(path.join(auto,entry.files.input));if(document.slides.some(hasImage))imageCases.push(entry);}
assert.deepEqual(imageCases.map(entry=>entry.number),[12,13],'The current automatic corpus has exactly two image-bearing cases');
const fonts=await loadFonts({pack:'office'}),options={fonts,catalogs:[gallery],text:'paths',trace:true,
  imageResolver:source=>source==='../../../original/proposals/auto-image-fit/assets/landscape.png'?imageData:source};
const results=[];
for(const entry of imageCases){
  const sourceBytes=await fs.readFile(path.join(auto,entry.files.input)),original=JSON.parse(sourceBytes),candidate=structuredClone(original);
  noPlacementPolicy(original);candidate.design={...(candidate.design??{}),imageFit:'contain'};noPlacementPolicy(candidate);
  const stripped=structuredClone(candidate);delete stripped.design.imageFit;if(!Object.keys(stripped.design).length)delete stripped.design;
  assert.deepEqual(stripped,original,'Only design.imageFit may change; words, assets and source order are exact');
  const states=[];
  for(const [state,document]of [['before',original],['authored-contain',candidate]]){
    fonts.registry.clearSubstitutions();const diagnostics=[];
    const validation=validate(document,{fonts,catalogs:[gallery]});assert.equal(validation.valid,true,JSON.stringify(validation.findings));
    const bound=resolvePresentation(document,{...options,onDiagnostic:issue=>diagnostics.push(issue)}).slides[0];
    const context=resolveSlideContext(document,0,{fonts,catalogs:[gallery]});
    const geometry=composeSlide(context.slide,{...context.options,fontFamilies:bound.design.fonts,textMeasurement:bound.textMeasurement,explain:true});
    const {explanation,...withoutExplanation}=geometry;assert.deepEqual(withoutExplanation,bound.geometry);
    assert.equal(explanation.textMeasurement,'provided');assert.equal(explanation.textOutlines,'provided');
    const svg=toSvg(document,1,{...options,onDiagnostic:issue=>diagnostics.push(issue)}),png=await toPng(svg,{fonts});
    const stem=entry.id+'-'+state,opf=state==='before'?sourceBytes:Buffer.from(JSON.stringify(document,null,2)+'\n');
    const files={input:stem+'.opf.json',svg:stem+'.svg',png:stem+'.png',geometry:stem+'.geometry.json'};
    await fs.writeFile(path.join(directory,files.input),opf);await fs.writeFile(path.join(directory,files.svg),svg);await fs.writeFile(path.join(directory,files.png),png);
    await save(files.geometry,{geometry,resolvedDesign:bound.design,validation,renderDiagnostics:diagnostics,contextDiagnostics:context.diagnostics,substitutions:fonts.substitutions});
    states.push({state,files,sha256:{input:hash(opf),svg:hash(svg),png:hash(png)},geometry,svgSource:svg,resolvedDesign:bound.design,diagnostics,validationCounts:validation.counts});
  }
  const [before,after]=states;
  for(const kind of ['input','svg','png'])assert.equal(before.sha256[kind],entry.sha256[kind],entry.id+': original '+kind+' bytes must match recorded baseline exactly');
  assert.deepEqual(JSON.parse(JSON.stringify(before.geometry)),await read(path.join(auto,entry.files.geometry)),'Original serialized measured geometry must match baseline');
  assert.deepEqual(before.geometry.items.filter(item=>item.field!=='image'),after.geometry.items.filter(item=>item.field!=='image'),'All nonimage geometry must remain exact');
  for(const key of ['width','height','contentBox','groups','flows','composition','explanation'])assert.deepEqual(before.geometry[key],after.geometry[key],key+' must not change');
  assert.deepEqual(before.resolvedDesign.fonts,after.resolvedDesign.fonts,'Resolved font families must not change');
  assert.deepEqual(before.resolvedDesign.dimensions,after.resolvedDesign.dimensions,'Canvas dimensions must not change');
  const imagesBefore=before.geometry.items.filter(item=>item.field==='image'),imagesAfter=after.geometry.items.filter(item=>item.field==='image');
  const imageChecks=[];
  for(let index=0;index<imagesBefore.length;index++){
    const left=imagesBefore[index],right=imagesAfter[index];assert.equal(left.image.fit,'cover');assert.equal(right.image.fit,'contain');
    const reverted=structuredClone(right);reverted.image.fit=left.image.fit;assert.deepEqual(reverted,left,'Only accepted image.fit may change');
    const box=left.image.box,coverScale=Math.max(box.width/sourceSize.width,box.height/sourceSize.height),containScale=Math.min(box.width/sourceSize.width,box.height/sourceSize.height);
    imageChecks.push({path:left.path,frameUnchanged:box,beforeFit:'cover',afterFit:'contain',
      geometricSourceAreaVisibleBefore:box.width*box.height/(sourceSize.width*sourceSize.height*coverScale**2),geometricSourceAreaVisibleAfter:1,
      containedPicture:{x:box.x+(box.width-sourceSize.width*containScale)/2,y:box.y+(box.height-sourceSize.height*containScale)/2,width:sourceSize.width*containScale,height:sourceSize.height*containScale}});
  }
  assert.equal(after.svgSource,before.svgSource.replaceAll('preserveAspectRatio="xMidYMid slice"','preserveAspectRatio="xMidYMid meet"'),'The SVG must differ only in picture fit attributes');
  results.push({id:entry.id,number:entry.number,title:entry.title,inputDelta:{path:'/design/imageFit',value:'contain'},
    exactBaselineBytes:{input:true,svg:true,png:true},sameSourceContentAndAssets:true,noExplicitLayout:true,noCompositionPolicy:true,
    nonimageGeometryIdentical:true,imageFramesIdentical:true,automaticCandidateDecisionsIdentical:true,svgDiffOnlyPictureFit:true,
    imageChecks,states:states.map(({svgSource,geometry,resolvedDesign,...state})=>state)});
}
const escape=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
async function sheet(name,cases){
  const width=1920,margin=16,gap=16,panel=(width-2*margin-gap)/2,rowHeight=590,pieces=[];
  for(const [row,result]of cases.entries())for(const [column,state]of result.states.entries()){
    const x=margin+column*(panel+gap),y=row*rowHeight,svg=await fs.readFile(path.join(directory,state.files.svg));
    const label='Auto '+result.number+' · '+(state.state==='before'?'Current automatic output: cover':'Authored contain override only');
    pieces.push('<text x="'+x+'" y="'+(y+28)+'" font-family="Intos" font-size="20" font-weight="700" fill="#1f2937">'+escape(label)+'</text><image x="'+x+'" y="'+(y+48)+'" width="'+panel+'" height="'+panel*9/16+'" href="data:image/svg+xml;base64,'+svg.toString('base64')+'"/>');
  }
  const svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+width+'" height="'+rowHeight*cases.length+'"><rect width="100%" height="100%" fill="white"/>'+pieces.join('')+'</svg>';
  await fs.writeFile(path.join(directory,name+'.svg'),svg);await fs.writeFile(path.join(directory,name+'.png'),await toPng(svg,{fonts}));
}
for(const result of results)await sheet(result.id+'-before-after',[result]);
await sheet('auto-image-fit-two-comparisons',results);
await save('report.json',{proposal:'P33',status:'Authored fit illustration only. Automatic image-fit policy is not implemented or changed.',
  scope:'Exactly two image-bearing cases exist in the20-case automatic corpus. No video or movie fit, poster rendering or playback is examined.',
  command:'node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/auto-image-fit/render.mjs',
  source:{baseline:'../../auto/index.json',coreRevision:revision(path.resolve(directory,'../../../..')),rendererRevision:revision(path.resolve(directory,'../../../../../opf-render')),
    coreVersion:'0.20.3',rendererVersion:'0.20.2',galleryVersion:'3.0.0',node:process.version,asset:{file:'../../../original/proposals/auto-image-fit/assets/landscape.png',sha256:hash(imageSource),...sourceSize}},
  renderOptions:{pack:'office',substitutionPolicy:'metric',text:'paths',loadSystemFonts:false,sameHandleForMeasurementAndRaster:true},
  fontFiles:await Promise.all(fonts.fontFiles.map(async file=>({file,sha256:hash(await fs.readFile(file))}))),
  unchanged:{engine:true,schema:true,sourceCatalog:true,queue:true,viewer:true},results,
  tradeoffs:['Contain retains the whole illustration and leaves unused space inside the original automatic image frame.','Contain centers the picture inside that unchanged frame. The visible picture top moves down while the text stays fixed, so visible top alignment differs even though the frame geometry is identical.','The automatic frame proportions and text placement remain unchanged; this does not demonstrate a new automatic allocation or fit-selection policy.']});
console.log(JSON.stringify({output:directory,cases:results.map(({id,imageChecks})=>({id,imageChecks})),baselineBytesExact:true,nonimageGeometryIdentical:true,svgDiffOnlyPictureFit:true},null,2));

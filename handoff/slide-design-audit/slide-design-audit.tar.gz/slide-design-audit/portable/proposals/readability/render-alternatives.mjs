// Additional supported-control illustrations only; no production source or original probe is modified.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gallery } from '@openpresentation/gallery';
import { validate, resolveSlideContext } from '../../../../packages/javascript/dist/index.js';
import { composeSlide, layoutTable } from '../../../../packages/javascript/dist/composition.js';
import { loadFonts } from '../../../../../opf-render/dist/fonts-node.js';
import { resolvePresentation, toPng, toSvg } from '../../../../../opf-render/dist/index.js';

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(directory, '../../../..');
const load = async name => JSON.parse(await readFile(path.join(directory, name), 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const save = (name, value) => writeFile(path.join(directory, name), JSON.stringify(value, null, 2) + '\n');
const originalNames = (await readdir(directory)).filter(name => !name.includes('alternative') && !name.includes('before-A-B'));
const originalHashes = Object.fromEntries(await Promise.all(originalNames.map(async name => [name, hash(await readFile(path.join(directory, name)))])));
const fonts = await loadFonts({ pack: 'office' });
const options = { fonts, catalogs: [gallery], text: 'paths', trace: true };
const xmlText = value => value.replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&#39;', "'");
const attributes = text => Object.fromEntries([...text.matchAll(/([\w:-]+)="([^"]*)"/g)].map(([, key, value]) => [key, xmlText(value)]));
const svgTexts = svg => [...svg.matchAll(/<text\b([^>]*)>([\s\S]*?)<\/text>/g)].map(([, source, body]) => {
  const attrs = attributes(source);
  return { text: xmlText(body.replace(/<[^>]*>/g, '')), fontSize: Number(attrs['font-size']), x: Number(attrs.x), y: Number(attrs.y) };
});
const plainCell = cell => cell === null || typeof cell !== 'object' || Array.isArray(cell) ? { value: cell } : {
  value: cell.value ?? cell.name,
  ...(cell.format !== undefined ? { format: cell.format } : {}),
  ...(cell.colSpan !== undefined ? { colSpan: cell.colSpan } : {}),
  ...(cell.rowSpan !== undefined ? { rowSpan: cell.rowSpan } : {}),
};
const logicalTable = table => ({ columns: table.columns?.map(plainCell), rows: table.rows.map(row => row.map(plainCell)) });
const contentSignature = deck => {
  const content = host => ({
    ...Object.fromEntries(['title', 'subtitle', 'tag', 'text', 'items', 'bullets', 'image', 'video', 'chart', 'code', 'metric', 'quote', 'timeline'].filter(field => host[field] !== undefined).map(field => [field, host[field]])),
    ...(host.table ? { table: logicalTable(host.table) } : {}),
    ...(host.blocks ? { blocks: host.blocks.map(content) } : {}),
  });
  return deck.slides.map(content);
};
const textSummary = geometry => geometry.items.filter(item => item.text).map(item => ({ path: item.path, fontSize: item.text.fontSize, lines: item.text.lines, box: item.box, overflow: item.text.overflow, placementOverflow: item.text.placement?.overflow }));
const tableSummary = tables => tables.map(({ path: itemPath, layout }) => ({
  path: itemPath,
  rows: layout.rows.map(row => ({ box: row.box, cells: row.cells.map(cell => ({ text: cell.text, box: cell.box, fontSize: cell.fit.fontSize, lines: cell.fit.lines, overflow: cell.fit.overflow })) })),
}));
const render = async (stem, deck, allowDiagnostics = false) => {
  const signature = hash(JSON.stringify(contentSignature(deck)));
  const validation = validate(deck, { fonts, catalogs: [gallery] });
  assert.equal(validation.valid, true, JSON.stringify(validation.findings.filter(finding => finding.severity === 'error')));
  const bound = resolvePresentation(deck, options).slides[0];
  const context = resolveSlideContext(deck, 0, { fonts, catalogs: [gallery] });
  const geometry = composeSlide(context.slide, { ...context.options, fontFamilies: bound.design.fonts, textMeasurement: bound.textMeasurement, explain: true });
  const { explanation: _explanation, ...unexplained } = geometry;
  assert.deepEqual(unexplained, bound.geometry);
  const renderDiagnostics = [];
  const svg = toSvg(deck, 1, { ...options, onDiagnostic: issue => renderDiagnostics.push(issue) });
  const png = await toPng(svg, { fonts });
  assert.equal(signature, hash(JSON.stringify(contentSignature(deck))), 'Rendering must not alter source');
  if (!allowDiagnostics) {
    assert.equal(geometry.diagnostics.length, 0, JSON.stringify(geometry.diagnostics));
    assert.equal(renderDiagnostics.length, 0, JSON.stringify(renderDiagnostics));
  }
  const tables = geometry.items.filter(item => item.field === 'table').map(item => ({ path: item.path, layout: layoutTable(item.value, item.box, { minFontSize: geometry.composition.minFontSize, fontFamily: bound.design.fonts.body, textMeasurement: bound.textMeasurement, path: item.path, presentation: deck }) }));
  await save(stem + '.opf.json', deck);
  await save(stem + '.geometry.json', { geometry, tables, resolvedDesign: bound.design, validation, renderDiagnostics, actualSvgText: svgTexts(svg) });
  await writeFile(path.join(directory, stem + '.svg'), svg);
  await writeFile(path.join(directory, stem + '.png'), png);
  return { deck, bound, geometry, svg, tables, record: { input: stem + '.opf.json', svg: stem + '.svg', png: stem + '.png', geometry: stem + '.geometry.json', contentSha256: signature, pngSha256: hash(png), validationCounts: validation.counts, geometryDiagnostics: geometry.diagnostics, renderDiagnostics, fontFamilies: bound.design.fonts, text: textSummary(geometry), tables: tableSummary(tables) } };
};
const chartSummary = (deck, svg) => {
  const ticks = svgTexts(svg).filter(item => /^\d+(?:\.\d+)?%$/.test(item.text));
  const min = ticks.reduce((a, b) => parseFloat(a.text) < parseFloat(b.text) ? a : b);
  const max = ticks.reduce((a, b) => parseFloat(a.text) > parseFloat(b.text) ? a : b);
  const plotHeight = min.y - max.y;
  const chart = deck.slides[0].blocks.find(block => block.chart).chart;
  const bars = [...svg.matchAll(/<rect\b([^>]*)\/?\s*>/g)].map(([, source]) => attributes(source)).filter(attrs => /^slides\.0\.blocks\.0\.chart\.data\.rows\.\d+\.1$/.test(attrs['data-opf-path'] ?? '')).map(attrs => {
    const row = Number(/rows\.(\d+)\.1$/.exec(attrs['data-opf-path'])[1]);
    const value = chart.data.rows[row][1];
    const observed = Number(attrs.height) / plotHeight;
    const expected = value / (parseFloat(max.text) / 100);
    assert.ok(Math.abs(observed - expected) < .00002, 'Bar height must match unchanged data in the actual changed domain');
    return { row, sourceValue: value, sourceType: typeof value, x: Number(attrs.x), y: Number(attrs.y), width: Number(attrs.width), height: Number(attrs.height), heightFractionOfPlot: observed, expectedFractionAtActualDomain: expected };
  });
  assert.equal(bars.length, chart.data.rows.length);
  assert.equal(parseFloat(min.text), 0, 'Zero baseline must remain');
  return { domain: { minimumPercent: parseFloat(min.text), maximumPercent: parseFloat(max.text) }, tickCount: ticks.length, ticks, plotHeight, bars };
};

const priorReport = await load('report.json');
const chartBefore = await load('P19-chart-before.opf.json');
const chartA = await load('P19-chart-illustration.opf.json');
const chartBDeck = structuredClone(chartBefore);
chartBDeck.slides[0].composition = { minFontSize: 24 };
assert.deepEqual(chartBDeck.slides[0].blocks, chartBefore.slides[0].blocks);
const chartB = await render('P19-chart-alternative-b', chartBDeck);
const chartBeforeSvg = await readFile(path.join(directory, '../../../original/proposals/readability/P19-chart-before.svg'), 'utf8');
const chartASvg = await readFile(path.join(directory, '../../../original/proposals/readability/P19-chart-illustration.svg'), 'utf8');
const chartScales = { before: chartSummary(chartBefore, chartBeforeSvg), a: chartSummary(chartA, chartASvg), b: chartSummary(chartBDeck, chartB.svg) };
assert.deepEqual(chartScales.before.domain, { minimumPercent: 0, maximumPercent: 90 });
assert.deepEqual(chartScales.a.domain, chartScales.before.domain);
assert.deepEqual(chartScales.b.domain, { minimumPercent: 0, maximumPercent: 100 });
assert.equal(chartScales.b.tickCount, 6);
assert.deepEqual([...new Set(chartScales.b.ticks.map(tick => tick.fontSize))], [24]);

const tableA = await load('P20-table-illustration.opf.json');
const tableBefore = await load('P20-table-before.opf.json');
const tableBDeck = structuredClone(tableA);
tableBDeck.slides[0].composition.minFontSize = 32;
// Preserve the diagnostic from the direct floor-only input. The existing auto note row is not sized at the raised floor.
const tableB = await render('P20-table-alternative-b-rejected', tableBDeck, true);
assert.ok(tableB.geometry.diagnostics.some(issue => issue.code === 'text-overflow' && issue.path === 'slides.0.blocks.1.text'));
assert.deepEqual(tableBDeck.slides[0].blocks, tableA.slides[0].blocks, 'All table content, styles and companion words remain exact');
assert.deepEqual(logicalTable(tableBDeck.slides[0].blocks[0].table), logicalTable(tableBefore.slides[0].blocks[0].table));
assert.deepEqual(tableBDeck.catalogs, tableA.catalogs, 'No unrelated note width or row-allocation workaround');
const tableCellFits = tableB.tables.flatMap(table => table.layout.rows.flatMap(row => row.cells.map(cell => cell.fit)));
assert.ok(tableCellFits.every(fit => fit.fontSize === 32 && !fit.overflow));
assert.deepEqual(contentSignature(tableBefore), contentSignature(tableBDeck));
assert.deepEqual(contentSignature(chartBefore), contentSignature(chartBDeck));
assert.deepEqual(chartB.bound.design.fonts, priorReport.results.find(item => item.id === 'P19').before.fontFamilies);
assert.deepEqual(tableB.bound.design.fonts, priorReport.results.find(item => item.id === 'P20').before.fontFamilies);

const escapeXml = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('"', '&quot;');
const sheet = async (name, panels) => {
  const width = 2560, height = 580, margin = 16, gap = 16, panel = (width - 2 * margin - 2 * gap) / 3;
  const pieces = [];
  for (const [column, value] of panels.entries()) {
    const x = margin + column * (panel + gap);
    const source = await readFile(path.join(directory, value.png));
    pieces.push(`<text x="${x}" y="29" font-family="Intos" font-size="22" font-weight="700" fill="#1f2937">${escapeXml(value.label)}</text>`);
    pieces.push(`<text x="${x}" y="57" font-family="Intos" font-size="18" fill="#374151">${escapeXml(value.detail)}</text>`);
    pieces.push(`<image x="${x}" y="78" width="${panel}" height="${panel * 9 / 16}" href="data:image/png;base64,${source.toString('base64')}"/>`);
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><rect width="100%" height="100%" fill="white"/>${pieces.join('')}</svg>`;
  await writeFile(path.join(directory, name + '.svg'), svg);
  await writeFile(path.join(directory, name + '.png'), await toPng(svg, { fonts }));
};
await sheet('P19-before-A-B', [
  { png: '../../../original/proposals/readability/P19-chart-before.png', label: 'P19 baseline:16px labels', detail: '10ticks;0–90% domain; unchanged source data' },
  { png: '../../../original/proposals/readability/P19-chart-illustration.png', label: 'P19 A:19px labels', detail: '10ticks;0–90% domain retained' },
  { png: '../../../original/proposals/readability/P19-chart-alternative-b.png', label: 'P19 B:24px labels', detail: '6ticks;0–100% domain; bar heights recalculated' },
]);
await sheet('P20-before-A-B', [
  { png: '../../../original/proposals/readability/P20-table-before.png', label: 'P20 baseline:16px table', detail: 'Original grid, equal internal column widths' },
  { png: '../../../original/proposals/readability/P20-table-illustration.png', label: 'P20 A:24px table', detail: 'Same data/types/formats; lighter legal borders' },
  { png: '../../../original/proposals/readability/P20-table-alternative-b-rejected.png', label: 'P20 B:32px global floor — rejected', detail: 'Table fits; supporting note overflows its existing row' },
]);

for (const [name, digest] of Object.entries(originalHashes)) assert.equal(hash(await readFile(path.join(directory, name))), digest, 'Original file preserved: ' + name);
const fontFiles = await Promise.all(fonts.fontFiles.map(async file => ({ file: path.relative(root, file), sha256: hash(await readFile(file)) })));
assert.deepEqual(fontFiles, priorReport.fonts.files);
await save('alternatives-report.json', {
  scope: 'Additional B alternatives in copied audit fixtures only. No engine, schema, authoritative catalog, queue, viewer, defaults, original A probe, or original report changed. Existing authored controls illustrate desired readability; no automatic improvement or production approval is claimed.',
  command: 'node --import ./scripts/register-local-opf.mjs artifacts/design-audit/proposals/readability/render-alternatives.mjs',
  originalFilesPreserved: originalHashes,
  fonts: { pack: 'office', substitutionPolicy: 'metric', systemFonts: false, text: 'paths', sameHandleForAll: true, sameFilesAsOriginalProbes: true, files: fontFiles, substitutions: fonts.substitutions },
  results: [
    {
      id: 'P19', variant: 'B', label: 'Authored24px readability-floor illustration; automatic percentage domain expands from0–90% to0–100%.',
      before: priorReport.results.find(item => item.id === 'P19').before,
      a: priorReport.results.find(item => item.id === 'P19').after,
      b: chartB.record,
      comparisons: { png: '../../../original/proposals/readability/P19-before-A-B.png', svg: '../../../original/proposals/readability/P19-before-A-B.svg' },
      actualChanges: { authoredControl: { minFontSize: 24 }, scales: chartScales, sourceDataAndTypesIdentical: true, zeroBaselineRetained: true, fixedDomainPreserved: false, barHeightRecalculation: 'Each source value is unchanged. Baseline/A bar-height fraction is value/0.9; B fraction is value/1.0. Plot height also changes to accommodate24px labels, so absolute bar heights reflect both domain and plot geometry.' },
      rationale: 'The source measure is task-completion percentage. The full0–100% scale is a reasonable alternative that gives the percentage a stable contextual ceiling and permits six larger labels. The intentional domain expansion is visible and quantified.',
      limitations: ['No independently authored chart-specific font size, tick-count/interval/domain, frame or gridline controls were added.', 'The six ticks and0–100% ceiling are the existing renderer response to the global readability floor, not a new explicit-axis algorithm.', 'Global minFontSize may affect other slide type if it is below the floor; headings and note are recorded in geometry.'],
      proof: { contentWordsAndDataTypesAndFormatsIdentical: true, sameFontHandle: true, sameFontFamilies: true, sameFontFiles: true, sameBackgroundAndPalette: true, coreAndRendererGeometryEqual: true, noGeometryOrRenderDiagnostics: true },
    },
    {
      id: 'P20', variant: 'B', status: 'Rejected supported-control probe; A24 remains the clean partial positive.', label: 'Authored32px (24pt) global floor with the same legal A borders; table fits but supporting note overflows.',
      before: priorReport.results.find(item => item.id === 'P20').before,
      a: priorReport.results.find(item => item.id === 'P20').after,
      b: tableB.record,
      comparisons: { png: '../../../original/proposals/readability/P20-before-A-B.png', svg: '../../../original/proposals/readability/P20-before-A-B.svg' },
      actualChanges: { authoredControl: { minFontSize: 32 }, tableFontSizes: [...new Set(tableCellFits.map(fit => fit.fontSize))], sameLegalBordersAsA: true, equalColumnWidthsRetained: true, physicalRowAndColumnCountsPreserved: true, sourceWordsAndValuesAndScalarTypesAndFormatsPreserved: true, layoutUnchanged: true, otherTextChanges: { a: (await load('P20-table-illustration.geometry.json')).geometry.items.filter(item => item.text).map(item => ({ path: item.path, fontSize: item.text.fontSize, lines: item.text.lines, box: item.box, overflow: item.text.overflow })), b: textSummary(tableB.geometry) } },
      acceptedForPresentation: false,
      rejectionReason: 'The coarse global floor cannot isolate table typography. It also raises the subtitle25→32px and note24→32px. The original note auto row remains30.5px high, while the unchanged note now wraps to two39.04px lines and extends beyond the content box. The exact existing-control failure is retained; no unrelated layout workaround was applied.',
      futureSharedTarget: 'Independent table32px typography should retain the supporting note at its appropriate25px role and measure accepted table rows at the actual font. This remains an unimplemented shared-engine proposal requiring approval.',
      limitations: ['The global floor is not independent table typography control.', 'Internal table columns remain equal. Content-aware widths remain a pending shared proposal.', 'The B output is evidence of a rejected control combination, not a design recommendation or implemented fix.'],
      proof: { exactTableObjectIncludingBordersSameAsA: true, contentWordsAndDataTypesAndFormatsIdentical: true, allTableCellsAt32pxAndOneLine: tableCellFits.every(fit => fit.fontSize === 32 && fit.lines.length === 1 && !fit.overflow), noteTwoLinesAt32px: tableB.geometry.items.at(-1).text.lines.length === 2 && tableB.geometry.items.at(-1).text.fontSize === 32, allTextFits: false, sameFontHandle: true, sameFontFamilies: true, sameFontFiles: true, sameBackgroundAndPalette: true, coreAndRendererGeometryEqual: true, overflowRetainedInDiagnostics: true, noLayoutWorkaround: true },
    },
  ],
});
console.log(JSON.stringify({ report: 'alternatives-report.json', chart: chartB.record.png, chartScales: Object.fromEntries(Object.entries(chartScales).map(([key, value]) => [key, { domain: value.domain, tickCount: value.tickCount, plotHeight: value.plotHeight, barHeights: value.bars.map(bar => bar.height) }])), table: tableB.record.png, tableText: textSummary(tableB.geometry), originalsPreserved: Object.keys(originalHashes).length }, null, 2));

// Copied-fixture evidence only. Does not edit engine, theme, schema or catalog source.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gallery} from '@openpresentation/gallery';
import {validate} from '@openpresentation/opf';
import {chartPaletteForFill,textColorForFill} from '@openpresentation/opf/composition';
import {toSvg,toPng,resolvePresentation} from '../../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../../opf-render/dist/fonts-node.js';

const here=path.dirname(fileURLToPath(import.meta.url));
const audit=path.resolve(here,'../..');
const read=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const fonts=await loadFonts({pack:'office'});
const options={fonts,catalogs:[gallery],text:'paths',trace:true,strictReferences:true};
const sha=value=>createHash('sha256').update(value).digest('hex');
const luminance=hex=>hex.slice(1).match(/../g).map(value=>parseInt(value,16)/255).map(value=>value<=.04045?value/12.92:((value+.055)/1.055)**2.4).reduce((sum,value,index)=>sum+value*[.2126,.7152,.0722][index],0);
const contrast=(first,second)=>(Math.max(luminance(first),luminance(second))+.05)/(Math.min(luminance(first),luminance(second))+.05);
const baselineEvidence=await read(path.join(audit,'../../gallery/baseline/metrics.geometry.json'));
const originalPalette=baselineEvidence.resolvedDesign.colorScheme;
const targetPalette={...originalPalette,accent1:'#3A8DDE',accent2:'#9FBAD0'};
const accents=['accent1','accent2','accent3','accent4','accent5','accent6'];
assert.equal(new Set(accents.map(key=>targetPalette[key])).size,6,'all six accent slots remain unique');
for(const key of accents)assert.ok(contrast(targetPalette[key],targetPalette.dark2)>=4.5,key+' ordinary accent text on navy');
const records=[];
const stableItems=geometry=>geometry.items.map(item=>({path:item.path,type:item.type,box:item.box,alignment:item.alignment,
  fontSize:item.text?.fontSize,lineHeight:item.text?.lineHeight,lines:item.text?.lines,
  rich:item.text?.richLines?.map(line=>line.fragments.map(fragment=>({text:fragment.text,fontSize:fragment.fontSize,fontFamily:fragment.style.fontFamily,fontWeight:fragment.style.fontWeight}))),
  metric:item.metricLayout?.parts.map(part=>({role:part.role,path:part.path,text:part.text,box:part.box,requestedFontSize:part.requestedFontSize,fontFamily:part.style?.fontFamily})),
}));
for(const id of ['metrics','scorecard','dashboard']){
  const before=await read(path.join(audit,'gallery/baseline',id+'.opf.json'));
  const after=structuredClone(before);
  after.catalogs.custom={
    themes:{'readable-dark-illustration':{name:'Readable dark illustration',colorScheme:'readable-dark-illustration',fontScheme:'aptos',background:{type:'theme',slot:'dark2'},dimensions:'widescreen'}},
    colorSchemes:{'readable-dark-illustration':{name:'Readable dark illustration',...targetPalette}},
    fontSchemes:{aptos:structuredClone(gallery.fontSchemes.aptos)},
  };
  after.design={theme:'custom:readable-dark-illustration'};
  assert.deepEqual(after.slides,before.slides,'all words/data/layout choices stay exact');
  assert.deepEqual(after.catalogs.default,before.catalogs.default,'existing layout records unchanged');
  let original;
  for(const [phase,deck]of [['before',before],['after',after]]){
    const validation=validate(deck,{fonts,catalogs:[gallery]});assert.equal(validation.valid,true,JSON.stringify(validation));
    const bound=resolvePresentation(deck,options).slides[0];
    assert.deepEqual(bound.geometry.diagnostics,[]);
    if(phase==='before')original=bound;
    else{
      assert.deepEqual(stableItems(bound.geometry),stableItems(original.geometry),'positions, fit, content, fonts and sizes unchanged');
      assert.deepEqual(bound.design.fonts,original.design.fonts,'font families unchanged');
      assert.equal(bound.design.backgroundColor,original.design.backgroundColor,'navy retained');
      for(const key of ['background','surface','text','mutedText','accent','hyperlink','followedHyperlink','border'])assert.equal(bound.design.colors[key],original.design.colors[key],'unchanged role '+key);
      assert.equal(bound.design.colors.primary,targetPalette.accent1);
      assert.equal(bound.design.colors.secondary,targetPalette.accent2);
    }
    const svg=toSvg(deck,1,options);const png=await toPng(svg,{fonts});
    if(phase==='before')assert.equal(sha(png),sha(await fs.readFile(path.join(audit,'gallery/baseline',id+'.png'))),'before exactly matches retained baseline');
    const base=path.join(here,id+'-'+phase);
    await fs.writeFile(base+'.opf.json',JSON.stringify(deck,null,2)+'\n');
    await fs.writeFile(base+'.svg',svg+'\n');await fs.writeFile(base+'.png',png);
    await fs.writeFile(base+'.geometry.json',JSON.stringify({geometry:bound.geometry,design:bound.design,validation,exactSlideContentAndData:true,positionsFontsAndTypeUnchanged:true},null,2)+'\n');
    records.push({id,phase,input:base+'.opf.json',png:base+'.png',svg:base+'.svg',geometry:base+'.geometry.json',pngSha256:sha(png),diagnostics:0,resolvedColors:bound.design.colors,
      paintOccurrences:{legacyPrimary:(svg.match(/#2874A6/g)??[]).length,proposedPrimary:(svg.match(/#3A8DDE/g)??[]).length,proposedSecondary:(svg.match(/#9FBAD0/g)??[]).length}});
  }
}
const paletteContrast=Object.keys(originalPalette).map(slot=>({slot,before:originalPalette[slot],after:targetPalette[slot],changed:originalPalette[slot]!==targetPalette[slot],
  beforeOnNavy:contrast(originalPalette[slot],originalPalette.dark2),afterOnNavy:contrast(targetPalette[slot],targetPalette.dark2),
  beforeWhiteTextOnFill:contrast('#FFFFFF',originalPalette[slot]),afterWhiteTextOnFill:contrast('#FFFFFF',targetPalette[slot]),
  afterBlackTextOnFill:contrast('#000000',targetPalette[slot]),
  ordinaryTextOnNavyPasses45:contrast(targetPalette[slot],targetPalette.dark2)>=4.5,largeTextOrNontextOnNavyPasses3:contrast(targetPalette[slot],targetPalette.dark2)>=3,
}));
const pairwiseAccentContrast=[];
for(let first=0;first<accents.length;first++)for(let second=first+1;second<accents.length;second++)pairwiseAccentContrast.push({first:accents[first],second:accents[second],before:contrast(originalPalette[accents[first]],originalPalette[accents[second]]),after:contrast(targetPalette[accents[first]],targetPalette[accents[second]])});
const beforeRoles=records.find(record=>record.phase==='before').resolvedColors;
const afterRoles=records.find(record=>record.phase==='after').resolvedColors;
const roleContrast=Object.entries(beforeRoles).map(([role,color])=>({role,before:color,after:afterRoles[role],beforeOnNavy:contrast(color,originalPalette.dark2),afterOnNavy:contrast(afterRoles[role],targetPalette.dark2),
  context:['background','surface'].includes(role)?'canvas, not foreground text':role==='border'?'rule/frame; whether essential must be judged in context':'foreground role; fill use requires separate on-fill text contrast'}));
const rendererSeriesSlots=['#2874A6','#1B4F72','#5499C7','#7BDBB2','#3AC67A','#24A89E','#F59E0B','#EF4444','#8B5CF6','#14B8A6','#0F172A','#64748B'];
const actualChartSeriesPalette=chartPaletteForFill(targetPalette.dark2,rendererSeriesSlots).map((color,index)=>({index,rendererSource:rendererSeriesSlots[index],resolvedOnNavy:color,contrastOnNavy:contrast(color,targetPalette.dark2),sameBeforeAndAfter:true}));
const contextAwareOnAccentInk=accents.map(slot=>({slot,fill:targetPalette[slot],preferredInk:'#FFFFFF',existingHelperInk:textColorForFill(targetPalette[slot],'#FFFFFF'),contrast:contrast(textColorForFill(targetPalette[slot],'#FFFFFF'),targetPalette[slot])}));
const esc=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;');
const swatches=[];
for(const [row,palette]of [[0,originalPalette],[1,targetPalette]])for(const [index,slot]of accents.entries()){
  const x=30+index*255,y=60+row*230;
  swatches.push(`<rect x="${x}" y="${y}" width="225" height="125" fill="${palette[slot]}"/><text x="${x}" y="${y-15}" fill="white" font-family="Intos" font-size="20">${esc(slot)} ${esc(palette[slot])}</text><text x="${x}" y="${y+155}" fill="white" font-family="Intos" font-size="19">${contrast(palette[slot],palette.dark2).toFixed(2)}:1 on navy</text>`);
}
const swatchSvg=`<svg xmlns="http://www.w3.org/2000/svg" width="1560" height="500"><rect width="100%" height="100%" fill="#011842"/>${swatches.join('')}</svg>`;
await fs.writeFile(path.join(here,'../../../original/proposals/contrast/palette-before-after.svg'),swatchSvg+'\n');
await fs.writeFile(path.join(here,'../../../original/proposals/contrast/palette-before-after.png'),await toPng(swatchSvg,{fonts}));
const report={
  scope:'P18 copied-fixture illustration only. No engine/schema/theme/catalog source, queue or viewer edits. No approval is inferred.',
  authoredControl:'Existing supported embedded custom theme, color-scheme and unchanged Aptos font-scheme records; only copied decks reference the illustrated theme. No deck background, per-slide color or type overrides.',
  retained:{background:'#011842',surface:'#011842',text:'#FFFFFF',mutedText:'#F0F0F0',slidesWordsDataAndLayoutChoices:'exactly equal',fontHandle:'same pinned office pack',typeAndAllocation:'exactly equal',accent3to6:'unchanged',slotAndSeriesOrder:'unchanged'},
  changes:{accent1:{from:originalPalette.accent1,to:targetPalette.accent1,role:'primary remains primary; blue remains blue'},accent2:{from:originalPalette.accent2,to:targetPalette.accent2,role:'secondary remains secondary; dark blue becomes a pale steel blue'}},
  originalPalette,targetPalette,paletteContrast,pairwiseAccentContrast,roleContrast,actualChartSeriesPalette,contextAwareOnAccentInk,
  authoredControlLimitation:{
    ordinaryChartSeries:'Renderer-owned CHART_SERIES_COLORS passed through core chartPaletteForFill(surface). This per-surface series palette is unchanged; the custom theme color scheme is not used for unhighlighted chart series.',
    source:'repository:opf-render/src/charts.js:13',
    dashboardProof:'After SVG retains six #2874A6 bar fills alongside six #3A8DDE metric-value fills. Data, scales and chart payloads are unchanged.',
    forbiddenWorkaroundNotUsed:'No SVG recoloring, chart highlight override, data rewrite or production engine edit.',
    status:'Metric-role illustration is concrete. Whole-renderer palette behavior cannot be illustrated through a theme-only override in these chart contexts.',
  },
  observations:[
    'Original accent1 on navy is 3.41894:1. Existing 76px metric numbers meet the 3:1 large-text threshold; this is stronger prominence and ordinary-accent-text headroom, not a correction of a false large-text failure.',
    'All six target accent slots exceed 4.5:1 against the unchanged navy. No target accent duplicates another slot; accent3 is not reused as accent1.',
    'Primary and secondary roles, chart series order, source labels and data semantics are unchanged. Accent2 becomes much lighter, so visual hierarchy and existing brand identity need review.',
    'Higher contrast against navy lowers contrast of white text placed on accent fills. Accent1 white-on-fill falls below 4.5:1 and accent2 white-on-fill is lower still; dark on-accent text or context-aware role selection would be required where those fills carry ordinary text. Those contexts are not shown by these three fixtures.',
    'The existing textColorForFill helper already selects suitable dark ink for these lighter accent fills. The renderer uses it for table header defaults and inside chart labels. Those consumers can adapt automatically; explicit authored white ink still needs its actual fill checked. The report records the helper-selected ink and ratio for every target accent.',
    'Raw hyperlink and followedHyperlink slots remain weak against navy. The resolved unvisited hyperlink role falls back to white; the followedHyperlink role remains the legacy purple. No links occur in these fixtures, so this illustration is not a complete role-contrast policy.',
    'Border contrast remains unchanged. Decorative grid/frame strokes do not acquire a new emphasis; meaningful graphical boundaries need context-specific evaluation.',
    'Pairwise accent contrasts are recorded. Background contrast does not guarantee categorical discrimination or color-vision accessibility; labels/markers remain necessary for meaning.',
    'The three fixtures visibly exercise primary metric paint only. Proposed secondary resolves correctly but is not painted in those fixtures; its contrast is demonstrated by the diagnostic palette swatch board, not by altered source content.',
    'Dashboard chart bars remain the existing hardcoded primary blue, at 3.41894:1 on navy. These nontext bars already exceed 3:1. The theme-only proposal does not establish new chart-palette behavior.',
  ],
  versions:{core:'0.20.3',renderer:'0.20.2'},records,
};
await fs.writeFile(path.join(here,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({output:here,changes:report.changes,accentContrast:paletteContrast.filter(row=>row.slot.startsWith('accent')).map(({slot,beforeOnNavy,afterOnNavy,afterWhiteTextOnFill})=>({slot,beforeOnNavy,afterOnNavy,afterWhiteTextOnFill})),renderedCases:records.length},null,2));

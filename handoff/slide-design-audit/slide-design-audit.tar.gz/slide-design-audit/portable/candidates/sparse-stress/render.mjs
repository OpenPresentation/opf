// Evidence only: compare embedded candidate layouts. No catalog or engine changes.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {validate,resolveSlideContext} from '@openpresentation/opf';
import {composeSlide} from '@openpresentation/opf/composition';
import {loadFonts} from '../../../../../opf-render/dist/fonts-node.js';
import {resolvePresentation,toSvg,toPng} from '../../../../../opf-render/dist/index.js';
const output=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(output,'../..');
const read=async file=>JSON.parse(await fs.readFile(path.join(root,file),'utf8'));
const save=(file,value)=>fs.writeFile(path.join(output,file),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');
const fonts=await loadFonts({pack:'office'});
const original={text:await read('../../gallery/baseline/text.opf.json'),list:await read('../../gallery/baseline/list.opf.json')};
const candidateText=await read('../text/default-after.opf.json'),candidateList=await read('../list/group-centered.opf.json');
const candidates={text:candidateText.catalogs.default.layouts.text,list:candidateList.catalogs.custom.layouts.list};
const auto04=await read('../../auto/04-uneven-comparison.opf.json'),auto16=await read('../../auto/16-code-and-explanation.opf.json');
const faq=await read('../faq/long-3-before.opf.json');
const text=string=>({region:'body',text:string}),body=block=>({...structuredClone(block),region:'body'});
const scenarios=[
 ['text','original',slide=>{}],
 ['text','one-paragraph',slide=>{slide.blocks=slide.blocks.slice(0,1);}],
 ['text','two-paragraphs',slide=>{slide.blocks=slide.blocks.slice(0,2);}],
 ['text','unequal-prose',slide=>{slide.blocks=auto04.slides[0].blocks.map(body);}],
 ['text','three-detailed-passages',slide=>{slide.blocks=faq.slides[0].blocks.map(body);}],
 ['text','list-payload',slide=>{slide.blocks=[{region:'body',items:['Close the audit gaps','Pilot with two teams','Report every week','Assign the accountable owner']}];}],
 ['text','quote-payload',slide=>{slide.blocks=[{region:'body',quote:{text:'We can now see where participants need help.',attribution:'Pilot lead',source:'Illustrative quotation'}}];}],
 ['text','code-payload',slide=>{slide.blocks=auto16.slides[0].blocks.filter(block=>block.code).map(body);}],
 ['text','group-payload',slide=>{slide.blocks=[{region:'body',blocks:[{text:'Product team'},{items:['Resolve access blockers.','Confirm release scope.','Prepare the next pilot build.']}]}];}],
 ['text','title-only',slide=>{delete slide.blocks;}],
 ['text','long-heading',slide=>{slide.title='Start with a focused pilot so that each team can learn quickly and turn the evidence into a better decision';}],
 ['list','original',slide=>{}],
 ['list','single-list',slide=>{slide.blocks=slide.blocks.slice(0,1);}],
 ['list','two-lists',slide=>{slide.blocks=slide.blocks.slice(0,2);}],
 ['list','twelve-detailed-items',slide=>{slide.blocks=[{region:'body',items:Array.from({length:12},(_,i)=>[
 'Close the remaining access blockers before adding participants.',
 'Expand by two teams and retain the same accountable-owner model.',
 'Review response time, escalations, and satisfaction after four weeks.',
 'Use the results to choose the pace for the following month.',
 ][i%4])}];}],
 ['list','structured-items',slide=>{slide.blocks=[{region:'body',items:[
 {text:'Close access gaps',description:'Resolve both known blockers and confirm the owner for each dependency.'},
 {text:'Expand the pilot',description:'Add two teams while keeping the support model and baseline consistent.'},
 {text:'Review the evidence',description:'Compare response time, escalations and satisfaction after four weeks.'},
 ]}];}],
 ['list','numbered-items',slide=>{slide.blocks=[{region:'body',numbering:'arabic',items:['Resolve the access blockers.','Rehearse the support route.','Add the second pilot team.','Review the results.']}];}],
 ['list','text-payload',slide=>{slide.blocks=[text('Confirm the pilot participants and publish the intake checklist. Assign a support rotation and review the first results each Friday.')];}],
 ['list','group-payload',slide=>{slide.blocks=[{region:'body',blocks:[{text:'Product team'},{items:['Resolve access blockers.','Confirm release scope.','Prepare the next pilot build.']}]}];}],
 ['list','title-only',slide=>{delete slide.blocks;}],
 ['list','long-heading',slide=>{slide.title='Make the next step explicit so every team knows what must happen before the pilot can expand';}],
];
const reports=[];
const signature=geometry=>geometry.items.map(item=>({path:item.path,type:item.type,field:item.field,x:item.box.x,width:item.box.width,fontSize:item.text?.fontSize,lines:item.text?.lines,listColumns:item.listColumns?.length,overflow:item.text?.overflow,
 code:item.codeLayout?.parts?.map(p=>({kind:p.kind,size:p.fit?.fontSize,lines:p.fit?.lines})),quote:item.quoteLayout?.parts?.map(p=>({kind:p.kind,size:p.fit?.fontSize,lines:p.fit?.lines}))}));
for(const [layout,name,edit]of scenarios){
 const same=structuredClone(original[layout]);edit(same.slides[0]);
 const variants=[];
 for(const state of ['before','after']){
  fonts.registry.clearSubstitutions();
  const document=structuredClone(same);
  if(state==='after')document.catalogs.custom={layouts:{[layout]:candidates[layout]}};
  assert.deepEqual(document.slides,same.slides);
  const validation=validate(document,{fonts});
  assert.equal(validation.valid,true,JSON.stringify({layout,name,state,findings:validation.findings}));
  const diagnostics=[],options={fonts,text:'paths',strictReferences:true,trace:true,onDiagnostic:d=>diagnostics.push(d)};
  const resolved=resolvePresentation(document,options).slides[0],context=resolveSlideContext(document,0,{fonts,strictReferences:true});
  const geometry=composeSlide(context.slide,{...context.options,fontFamilies:resolved.design.fonts,textMeasurement:resolved.textMeasurement,explain:true});
  assert.deepEqual(geometry.items,resolved.geometry.items,'Direct core and renderer composition differ');
  const svg=toSvg(document,1,options),png=await toPng(svg,{fonts}),stem=`${layout}-${name}-${state}`;
  await save(stem+'.opf.json',document);await save(stem+'.svg',svg+'\n');await fs.writeFile(path.join(output,stem+'.png'),png);
  await save(stem+'.geometry.json',{geometry,validation,diagnostics,design:resolved.design});
  if(name==='original'&&state==='before')assert.ok(Buffer.from(png).equals(await fs.readFile(path.join(root,'gallery/baseline',layout+'.png'))),'Baseline PNG bytes differ');
  variants.push({state,png:stem+'.png',opf:stem+'.opf.json',geometry:stem+'.geometry.json',sha256:createHash('sha256').update(png).digest('hex'),items:signature(geometry),diagnostics,geometryDiagnostics:geometry.diagnostics,validationCounts:validation.counts});
 }
 const [before,after]=variants;
 const unchanged=JSON.stringify(before.items)===JSON.stringify(after.items);
 const changes=after.items.flatMap((a,i)=>{const b=before.items[i];return JSON.stringify(a)===JSON.stringify(b)?[]:[{before:b,after:a}];});
 reports.push({id:`${layout}-${name}`,layout,name,sameContent:true,horizontalTypeAndWrapUnchanged:unchanged,changes,variants});
}
const escape=string=>string.replaceAll('&','&amp;').replaceAll('<','&lt;');
const sheets=[];
for(const layout of ['text','list']){
 const cases=reports.filter(r=>r.layout===layout);
 for(let i=0;i<cases.length;i+=3){
  const slice=cases.slice(i,i+3),width=1800,pad=20,gap=20,head=36,row=530,height=slice.length*row+pad;
  let content=`<rect width="${width}" height="${height}" fill="#FFFFFF"/>`;
  for(const [j,c]of slice.entries())for(const [k,v]of c.variants.entries()){
   const x=pad+k*(width/2),y=pad+j*row,svg=await fs.readFile(path.join(output,v.png.replace(/\.png$/,'.svg')),'utf8');
   content+=`<text x="${x}" y="${y+23}" font-family="Intos" font-size="22" fill="#17202B">${escape(c.id)} · ${v.state}</text><image x="${x}" y="${y+head}" width="${width/2-gap-pad}" height="${(width/2-gap-pad)*9/16}" href="data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}"/>`;
  }
  const stem=`${layout}-stress-${String(i/3+1).padStart(2,'0')}`,svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">${content}</svg>`;
  await save(stem+'.svg',svg+'\n');await fs.writeFile(path.join(output,stem+'.png'),await toPng(svg,{fonts}));sheets.push({layout,png:stem+'.png',cases:slice.map(c=>c.id)});
 }
}
await save('report.json',{scope:'Evidence only. Existing embedded layout candidates, same content in each comparison. Long/different payloads are robustness controls, never a request to add prose to fill a sparse slide. No engine/catalog source edits.',fonts:'Pinned office pack; same handle for measurement and raster; paths SVG; system fonts disabled.',cases:reports,sheets});
console.log(JSON.stringify({cases:reports.length,images:reports.length*2,changes:reports.filter(c=>!c.horizontalTypeAndWrapUnchanged).map(c=>c.id),sheets},null,2));

// Controlled, same-content spatial comparison; candidate records only, no engine edits.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {validate,resolveSlideContext} from '@openpresentation/opf';
import {composeSlide} from '@openpresentation/opf/composition';
import {toSvg,toPng,resolvePresentation} from '../../../../opf-render/dist/index.js';
import {loadFonts} from '../../../../opf-render/dist/fonts-node.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),output=path.join(root,'candidates/list');
await fs.mkdir(output,{recursive:true});
const original=JSON.parse(await fs.readFile(path.join(root,'../gallery/baseline/list.opf.json'),'utf8'));
const baselineRecord=original.catalogs.default.layouts.list,fonts=await loadFonts({pack:'office'});
const middle=structuredClone(baselineRecord);middle.regions.body.anchor='middle';
const grouped=structuredClone(baselineRecord);grouped.areas=[['.'],['title'],['body'],['.']];grouped.rows=[1,'auto','auto',1];
const variants=[['default-before','Original: content at top',null],['body-centered','Body centered; headings fixed',middle],['group-centered','Heading + list group centered',grouped]];
const reports=[];
for(const [id,label,record]of variants){
  fonts.registry.clearSubstitutions();
  const document=structuredClone(original);
  if(record)document.catalogs.custom={layouts:{list:record}};
  assert.deepEqual(document.slides,original.slides,'Only the embedded candidate layout may change');
  const validation=validate(document,{fonts});assert.equal(validation.valid,true,JSON.stringify(validation.findings));
  const diagnostics=[],options={fonts,text:'paths',strictReferences:true,trace:true,onDiagnostic:issue=>diagnostics.push(issue)};
  const resolved=resolvePresentation(document,options).slides[0],context=resolveSlideContext(document,0,{fonts,strictReferences:true});
  const geometry=composeSlide(context.slide,{...context.options,fontFamilies:resolved.design.fonts,textMeasurement:resolved.textMeasurement,explain:true});
  const svg=toSvg(document,1,options),png=await toPng(svg,{fonts}),base=path.join(output,id);
  const json=JSON.stringify(document,null,2)+'\n';
  await fs.writeFile(base+'.json',json);await fs.writeFile(base+'.opf.json',json);await fs.writeFile(base+'.svg',svg+'\n');await fs.writeFile(base+'.png',png);
  const lists=geometry.items.filter(item=>item.field==='items'),heading=geometry.items.filter(item=>item.field==='title'||item.field==='subtitle');
  const firstBaselines=lists.map(item=>item.text.listEntries[0].marker.y);
  assert.ok(Math.max(...firstBaselines)-Math.min(...firstBaselines)<.01,'List columns retain a shared first baseline');
  const baseline=reports[0];
  const signature=lists.map(item=>({x:item.box.x,width:item.box.width,fontSize:item.text.fontSize,lines:item.text.lines}));
  if(baseline)assert.deepEqual(signature,baseline.horizontalAndTypeSignature,'X positions, widths, font sizes and line breaks must remain identical');
  const summary={id,label,png:base+'.png',json:base+'.json',svg:base+'.svg',sameSourceContent:true,diagnostics,
    headings:heading.map(item=>({field:item.field,y:item.box.y,height:item.box.height,fontSize:item.text.fontSize})),
    listStartY:lists[0].box.y,listContentHeight:lists[0].text.height,
    firstBaselines,sharedFirstBaseline:Math.max(...firstBaselines)-Math.min(...firstBaselines)<.01,
    horizontalAndTypeSignature:signature,sha256:createHash('sha256').update(png).digest('hex')};
  await fs.writeFile(base+'.geometry.json',JSON.stringify({summary,geometry,validation,substitutions:fonts.substitutions},null,2)+'\n');
  reports.push(summary);
}
const before=await fs.readFile(path.join(root,'../../original/gallery/baseline/list.png'));
assert.equal(createHash('sha256').update(before).digest('hex'),reports[0].sha256,'Original candidate must reproduce baseline pixels exactly');
const margin=16,gap=16,width=1920,height=420,panel=(width-margin*2-gap*2)/3;
const pieces=[];
for(const [index,report]of reports.entries()){
  const x=margin+index*(panel+gap),svg=await fs.readFile(report.svg,'utf8');
  pieces.push(`<text x="${x}" y="29" font-family="Intos" font-size="20" font-weight="700" fill="#1f2937">${report.label.replaceAll('&','&amp;').replaceAll('<','&lt;')}</text><image x="${x}" y="48" width="${panel}" height="${panel*9/16}" href="data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}"/>`);
}
const sheet=`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="${width}" height="${height}" fill="white"/>${pieces.join('')}</svg>`;
await fs.writeFile(path.join(output,'comparison.svg'),sheet+'\n');await fs.writeFile(path.join(output,'comparison.png'),await toPng(sheet,{fonts}));
await fs.writeFile(path.join(output,'comparison.json'),JSON.stringify({scope:'Same words, font bytes, font sizes, line breaks, gutters and columns. Only the custom candidate record changes vertical placement. Baseline is unchanged.',variants:reports},null,2)+'\n');
console.log(JSON.stringify({comparison:path.join(output,'comparison.png'),variants:reports.map(({id,listStartY,headings,firstBaselines,diagnostics})=>({id,listStartY,headings,firstBaselines,diagnostics}))},null,2));
